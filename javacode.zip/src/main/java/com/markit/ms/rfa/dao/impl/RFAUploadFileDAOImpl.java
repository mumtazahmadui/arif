package com.markit.ms.rfa.dao.impl;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.RFATemplateNames;
import com.markit.ms.rfa.bean.RFAUploadFile;
import com.markit.ms.rfa.bean.RfaUploadTemplateDownload;
import com.markit.ms.rfa.dao.IRfaUploadFileDAO;
import com.markit.ms.rfa.dto.RfaUploadFileSearchRequest;
import com.markit.ms.rs.select.all.domain.BulkRequest;

/**
 * @author sucheta.krishali
 *
 */
@Repository
public class RFAUploadFileDAOImpl extends BaseDAOImpl implements IRfaUploadFileDAO {

	@Value("${GET_UPLOAD_FILE_BY_IDS}")
	private String GET_UPLOAD_FILE_BY_IDS;
	
	
	@Value("${GET_UPLOAD_FILE_FILTER_UPLOADED_BY}")
	private String GET_UPLOAD_FILE_FILTER_UPLOADED_BY;
	
	@Value("${GET_UPLOAD_FILE_FILTER_PROCESSING_STATUS}")
	private String GET_UPLOAD_FILE_FILTER_PROCESSING_STATUS;
	
	@Value("${GET_UPLOAD_TEMPLATE_NAMES}")
	private String GET_UPLOAD_TEMPLATE_NAMES;

	@Override
	public List<RFAUploadFile> getUploadFileGrid(Long companyId, RfaUploadFileSearchRequest templateSearchRequest) {
		StringBuilder whereCondition = new StringBuilder();
		MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyId", companyId)
				.addValue("offset", templateSearchRequest.getOffSet())
				.addValue("page_size", templateSearchRequest.getPageSize());

		List<Lookup> uploadByLookUps = templateSearchRequest.getUploadBy();
		List<Lookup> processingStatusLookUps = templateSearchRequest.getProcessingStatus();

		// if mlTemplateNames are selected in search criteria
		if (null != uploadByLookUps && uploadByLookUps.size() > 0) {
			List<Long> uploadByLookupIds = new ArrayList<Long>();
			for (Lookup lookup : uploadByLookUps) {
				uploadByLookupIds.add(lookup.getId());
			}
			paramSource.addValue("uploadByLookupIds", uploadByLookupIds);
			whereCondition.append(" and rbuft.created_by in (:uploadByLookupIds)");
		}
		if (null != processingStatusLookUps && processingStatusLookUps.size() > 0) {
			List<String> processingStatusLookupIds = new ArrayList<String>();
			for (Lookup lookup : processingStatusLookUps) {
				processingStatusLookupIds.add(lookup.getValue());
			}
			paramSource.addValue("processingStatusLookupIds", processingStatusLookupIds);
			whereCondition.append(" and rbuft.bulk_upload_status in (:processingStatusLookupIds)");
		}

		String gridQuery = GET_UPLOAD_FILE_BY_IDS.replaceAll("whereCondition", whereCondition.toString());

		List<RFAUploadFile> uploadedFiles = namedParameterJdbcTemplate.query(gridQuery, paramSource,
				new RowMapper<RFAUploadFile>() {

					@Override
					public RFAUploadFile mapRow(ResultSet rs, int rowNum) throws SQLException {

						RFAUploadFile esce = new RFAUploadFile();
						esce.setId(rs.getString("id"));
						esce.setUploadBy(rs.getString("uploadBy"));
						esce.setUploadDate(rs.getString("uploadDate"));
						esce.setUploadBulkRequestId(rs.getString("uploadBulkRequestId"));
						esce.setErrorFileId(rs.getString("errorFileId"));
						esce.setBulkUploadStatus(rs.getString("bulkUploadStatus"));
						esce.setOriginalFileId(rs.getString("originalFileId"));
						esce.setRfaCountInitiated(rs.getString("rfaCountInitiated"));
						esce.setTotalRowCount(rs.getInt("totalRowCount"));
						return esce;
					}
				});
		return uploadedFiles;
	}

	@Override
	public List<Lookup> getFilterUploadedBy(Long companyId, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId)
				.addValue("filterString", "%"+filterString+"%");
		List<Map<String, Object>> uploadedByList  = namedParameterJdbcTemplate.queryForList(GET_UPLOAD_FILE_FILTER_UPLOADED_BY, paramSource);

		List<Lookup> lookupList = new ArrayList<Lookup>();
		for(Map<String, Object> uploadedBy : uploadedByList){
			Lookup lookup = new Lookup();
			lookup.setId(new Long(((BigDecimal)uploadedBy.get("ID")).longValue()));
			lookup.setValue((String)uploadedBy.get("UPLOAD_BY"));			
			lookupList.add(lookup);
		}

		return lookupList;
	}

	@Override
	public List<Lookup> getFilterProcessingStatus(Long companyId, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId)
				.addValue("filterString", "%"+filterString+"%");
		List<Map<String, Object>> processingStatusList  = namedParameterJdbcTemplate.queryForList(GET_UPLOAD_FILE_FILTER_PROCESSING_STATUS, paramSource);

		List<Lookup> lookupList = new ArrayList<Lookup>();
		for(Map<String, Object> processingStatus : processingStatusList){
			Lookup lookup = new Lookup();
			lookup.setId((Long)processingStatus.get("RowNumber"));
			lookup.setValue((String)processingStatus.get("PROCESSING_STATUS"));			
			lookupList.add(lookup);
		}

		return lookupList;
	}
	public List<Lookup> getTemplateNamesByCompany(Long companyId){
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId);
		List<Map<String, Object>> uploadTemplateList = namedParameterJdbcTemplate.queryForList(GET_UPLOAD_TEMPLATE_NAMES, paramSource);
		
		List<Lookup> lookupList = new ArrayList<Lookup>();
		for(Map<String, Object> templateList : uploadTemplateList){
			Lookup lookup = new Lookup();
			lookup.setId(new Long(((BigDecimal)templateList.get("templateId")).longValue()));
			lookup.setValue((String)templateList.get("templateName"));			
			lookupList.add(lookup);
		}

		return lookupList;
		
	}

}
