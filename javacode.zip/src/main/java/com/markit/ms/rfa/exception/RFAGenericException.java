/**
 * 
 */
package com.markit.ms.rfa.exception;

import org.springframework.http.HttpStatus;

/**
 * @author prashant.aggarwal
 *
 */
public class RFAGenericException extends RuntimeException{

	private static final long serialVersionUID = 4520424440363567932L;

	HttpStatus httpStatusCode;	

	String errorMessage;
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public HttpStatus getHttpStatusCode() {
		return httpStatusCode;
	}

	public void setHttpStatusCode(HttpStatus httpStatusCode) {
		this.httpStatusCode = httpStatusCode;
	}
	
	public RFAGenericException() {
		super();
	}

	public RFAGenericException(String errorMessage, HttpStatus httpStatusCode) {
		super();
		this.errorMessage = errorMessage;
		this.httpStatusCode = httpStatusCode;
	}
	
}
