package com.markit.ms.rfa.security.repository;

import com.markit.ms.rfa.security.domain.McpmUser;

public interface McpmSecurityUserRepository {
	
	public McpmUser findByAccountUniqueId(String accountUniqueId);
}
