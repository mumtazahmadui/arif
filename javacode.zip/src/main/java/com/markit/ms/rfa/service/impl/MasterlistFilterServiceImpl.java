package com.markit.ms.rfa.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.dao.IMasterlistFilterDAO;
import com.markit.ms.rfa.service.IMasterlistFilterService;

@Service
public class MasterlistFilterServiceImpl implements IMasterlistFilterService {
	
	@Autowired
	IMasterlistFilterDAO masterlistFilterDAO;

	@Override
	public List<String> agreementDateLookup(Long id, String filterString) {
		return masterlistFilterDAO.agreementDateLookup(id, filterString);
	}

	@Override
	public List<Lookup> investmentManagerLookup(Long id, String filterString) {
		return masterlistFilterDAO.investmentManagerLookup(id, filterString);
	}

	@Override
	public List<Lookup> partyALookup(Long id, String filterString) {
		return masterlistFilterDAO.partyALookup(id, filterString);
	}
	
	@Override
	public List<String> masterlistIdentifierLookup(Long id, String filterString) {
		return masterlistFilterDAO.masterlistIdentifierLookup(id, filterString);
	}

	@Override
	public List<Lookup> agreementTypeLookup(String filterString) {
		return masterlistFilterDAO.agreementTypeLookup(filterString);
	}
	
}
