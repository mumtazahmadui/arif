package com.markit.ms.rfa.util;

import java.util.Arrays;
import java.util.List;

public interface PartyBDeskConstants {

	/*static final String ONBOARDING_ESCALATED = "O-E";
	static final String ONBOARDING_NOTIFIED = "O-N";
	static final String ONBOARDING_IN_PROGRESS = "O-P";
	static final String ONBOARDING_COMPLETED = "O-C";
	static final String KYC_ESCALATED = "K-E";
	static final String KYC_NOTIFIED = "K-N";
	static final String KYC_IN_PROGRESS = "K-P";
	static final String KYC_COMPLETED = "K-C";
	static final String TAX_ESCALATED = "T-E";
	static final String TAX_NOTIFIED = "T-N";
	static final String TAX_IN_PROGRESS = "T-P";
	static final String TAX_COMPLETED = "T-C";
	static final String CREDIT_ESCALATED = "C-E";
	static final String CREDIT_NOTIFIED = "C-N";
	static final String CREDIT_IN_PROGRESS = "C-P";
	static final String CREDIT_COMPLETED = "C-C";
	static final String LEGAL_ESCALATED = "L-E";
	static final String LEGAL_NOTIFIED = "L-N";
	static final String LEGAL_IN_PROGRESS = "L-P";
	static final String LEGAL_COMPLETED = "L-C";
	static final String OPERATIONS_ESCALATED = "OP-E";
	static final String OPERATIONS_NOTIFIED = "OP-N";
	static final String OPERATIONS_IN_PROGRESS = "OP-P";
	static final String OPERATIONS_COMPLETED = "OP-C";
	static final String MANAGER_ESCALATED = "M-E";
	static final String MANAGER_NOTIFIED = "M-N";
	static final String MANAGER_IN_PROGRESS = "M-P";
	static final String MANAGER_COMPLETED = "M-C";*/

	
	int UNCHECKED=0;
	int CHECKED=1;
	
	enum DESKTYPES {
		ONBOARDING("Onboarding"),KYC("KYC"),TAX("Tax"),
		CREDIT("Credit"),LEGAL("Legal"),OPERATIONS("Operations"),
		MANAGER("Manager"),BSDESK1("BS - Desk1"),BSDESK2("BS - Desk2");
		
		public String deskName;
		
		DESKTYPES(String deskName) {
			this.deskName=deskName;
		}
		
		public static DESKTYPES fromString(String str){
			if (null == str){
				return null;
			}
			for (DESKTYPES type : DESKTYPES.values()){
				if (type.deskName.equalsIgnoreCase(str)) return type;
			}
			return null;
		}
		
	}
	
	enum ONBOARDING {
		ESCALATED("O-E"), NOTIFIED("O-N"), IN_PROGRESS("O-P"), COMPLETED("O-C");

		public String code;

		private ONBOARDING(String code) {
			this.code = code;
		}
	}
	
	enum KYC {
		ESCALATED("K-E"), NOTIFIED("K-N"), IN_PROGRESS("K-P"), COMPLETED("K-C");

		public String code;

		private KYC(String code) {
			this.code = code;
		}
	}
	
	enum TAX {
		ESCALATED("T-E"), NOTIFIED("T-N"), IN_PROGRESS("T-P"), COMPLETED("T-C");

		public String code;

		private TAX(String code) {
			this.code = code;
		}
	}
	
	enum CREDIT {
		ESCALATED("C-E"), NOTIFIED("C-N"), IN_PROGRESS("C-P"), COMPLETED("C-C");

		public String code;

		private CREDIT(String code) {
			this.code = code;
		}
	}
	
	enum LEGAL {
		ESCALATED("L-E"), NOTIFIED("L-N"), IN_PROGRESS("L-P"), COMPLETED("L-C");

		public String code;

		private LEGAL(String code) {
			this.code = code;
		}
	}
	
	enum OPERATIONS {
		ESCALATED("OP-E"), NOTIFIED("OP-N"), IN_PROGRESS("OP-P"), COMPLETED("OP-C");

		public String code;

		private OPERATIONS(String code) {
			this.code = code;
		}
	}
	
	enum MANAGER {
		ESCALATED("M-E"), NOTIFIED("M-N"), IN_PROGRESS("M-P"), COMPLETED("M-C");

		public String code;

		private MANAGER(String code) {
			this.code = code;
		}
	}
	
	List<String> BS_DESK_CODES = Arrays.asList("BS-D1","BS-D2");

	 List<String> ESCALATED_DESK_CODES = Arrays.asList(ONBOARDING.ESCALATED.code, 
			KYC.ESCALATED.code, 
			TAX.ESCALATED.code,
			CREDIT.ESCALATED.code,
			LEGAL.ESCALATED.code,
			OPERATIONS.ESCALATED.code,
			MANAGER.ESCALATED.code);
	 
	enum NOTIFICATION_ACTION {
		CUSTOM, BULK, ESCALATION
	}
	 
}
