package com.markit.ms.rfa.bean.enumeration;

public enum RFADealerAction {

	NOT_ACTIONED("Not Actioned"), PENDING_EXECUTION("Pending Execution"), REJECTED("Rejected"), PENDING("Pending"),
	EXECUTED("Executed"),WITHDRAWN("Withdrawn");

	private String name;

	private RFADealerAction(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

}
