package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;

public class PartyBResultSetExtractor implements ResultSetExtractor<List<Entity>> {

	@Override
	public List<Entity> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Map<Long, Entity> partyBMap = new HashMap<Long, Entity>();
		while(rs.next()){
			Entity partyB = partyBMap.get(rs.getLong("entityid"));
			if(partyB == null){
				partyB = new Entity();
				partyB.setName(rs.getString("legal_name"));
				partyB.setId(rs.getLong("entityid"));
				partyBMap.put(rs.getLong("entityid"), partyB);
			}
		}
		List<Entity> entities = new ArrayList<Entity>(partyBMap.values());
		return entities;
	}

	
/*	Map<Long, Company> companyMap = new HashMap<Long, Company>();
	while(rs.next()){
		Company company = companyMap.get(rs.getLong("companyid"));
		if (company == null){
			company = new Company();
			company.setCompanyName(rs.getString("companyname"));
			company.setId(rs.getLong("companyid"));
			companyMap.put(rs.getLong("companyid"), company);
		}
	}
	List<Company> companies = new ArrayList<Company>(companyMap.values());
	return companies;*/
	
	
}
