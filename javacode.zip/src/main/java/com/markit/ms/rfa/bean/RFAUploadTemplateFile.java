package com.markit.ms.rfa.bean;

/**
 * @author Neeraj Kumar Nirala
 *
 */
public class RFAUploadTemplateFile{
	
	private Long fileId;
	private Long uploadTemplateId;

	
	public Long getFileId() {
		return fileId;
	}


	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	
	public RFAUploadTemplateFile() {
	}

	
	public Long getUploadTemplateId() {
		return uploadTemplateId;
	}

	public void setUploadTemplateId(Long uploadTemplateId) {
		this.uploadTemplateId = uploadTemplateId;
	}

	
}
