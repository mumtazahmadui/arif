package com.markit.ms.rfa.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.dao.ILetterTemplateDAO;
import com.markit.ms.rfa.dao.rowmapper.LetterTemplateRowMapper;
import com.markit.ms.rfa.dto.TemplateSearchRequest;
import com.markit.ms.rfa.util.CommonUtil;

@Repository
public class LetterTemplateDAOImpl extends BaseDAOImpl implements ILetterTemplateDAO
{
    @Value("${SAVE_RFA_LETTER_TEMPLATE}")
    private String SAVE_RFA_LETTER_TEMPLATE;
    
    @Value("${UPDATE_RFA_LETTER_TEMPLATE}")
    private String UPDATE_RFA_LETTER_TEMPLATE;
    
    @Value("${DELETE_RFA_LETTER_TEMPLATE}")
    private String DELETE_RFA_LETTER_TEMPLATE;
    
    @Value("${GET_RFA_LETTER_TEMPLATE_BY_ID}")
    private String GET_RFA_LETTER_TEMPLATE_BY_ID;
    
    @Value("${GET_RFA_LETTER_TEMPLATE_NAME_BY_ID}")
    private String GET_RFA_LETTER_TEMPLATE_NAME_BY_ID;
    
    @Value("${GET_ALL_RFA_LETTER_TEMPLATES_BY_COMPANY_ID}")
    private String GET_ALL_RFA_LETTER_TEMPLATES_BY_COMPANY_ID;
    
    @Value("${GET_RFA_LETTER_TEMPLATE_GRID}")
    private String GET_RFA_LETTER_TEMPLATE_GRID;
    
    @Value("${GET_RFA_LETTER_TEMPLATE_GRID_TOTAL_COUNT}")
    private String GET_RFA_LETTER_TEMPLATE_GRID_TOTAL_COUNT;
    
    @Value("${GET_RFA_LETTER_TEMPLATE_BY_NAME}")
    private String GET_RFA_LETTER_TEMPLATE_BY_NAME;
    
    @Override
    public LetterTemplate saveLetterTemplate(LetterTemplate letterTemplate)
    {        
        SqlParameterSource paramSource = new MapSqlParameterSource()
        	.addValue("name", letterTemplate.getName())
            .addValue("companyid", letterTemplate.getCompanyId())
            .addValue("content", letterTemplate.getContent().getBytes())
            .addValue("is_active_version", letterTemplate.getIsActiveVersion())
            .addValue("created_by", letterTemplate.getCreatedBy())
            .addValue("modified_by", letterTemplate.getModifiedBy())
            .addValue("agreed", 1);
        KeyHolder keyHolder = new GeneratedKeyHolder();
        namedParameterJdbcTemplate.update(SAVE_RFA_LETTER_TEMPLATE, paramSource, keyHolder);
        letterTemplate.setId(keyHolder.getKey().longValue());
        return getLetterTemplateById(letterTemplate.getId(), 0L,letterTemplate.getCompanyId());
    }
    
    @Override
    public LetterTemplate updateLetterTemplate(LetterTemplate letterTemplate)
    {        
    	SqlParameterSource paramSource = new MapSqlParameterSource()
    		.addValue("id", letterTemplate.getId())
			.addValue("name", letterTemplate.getName())
			.addValue("companyid", letterTemplate.getCompanyId())
			.addValue("content", letterTemplate.getContent().getBytes())
			.addValue("is_active_version", letterTemplate.getIsActiveVersion())
			.addValue("created_by", letterTemplate.getCreatedBy())
			.addValue("modified_by", letterTemplate.getModifiedBy())
			.addValue("created_date", letterTemplate.getCreatedDate())
			.addValue("modified_date", letterTemplate.getModifiedDate())
    		.addValue("deleted", letterTemplate.getDeleted());
    	namedParameterJdbcTemplate.update(UPDATE_RFA_LETTER_TEMPLATE, paramSource);
    	return getLetterTemplateById(letterTemplate.getId(), 0L,letterTemplate.getCompanyId());
    }
    
    @Override
    public LetterTemplate deleteLetterTemplate(Long id,Long companyId)
    {        
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id).addValue("companyId",companyId);
    	namedParameterJdbcTemplate.update(DELETE_RFA_LETTER_TEMPLATE, paramSource);
    	return getLetterTemplateById(id, 1L,companyId);
    }
    
    @Override
	public List<LetterTemplate> getAllLetterTemplatesByCompanyId(Long companyId) {
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", companyId);
    	List<LetterTemplate> letterTemplateList = namedParameterJdbcTemplate.query(
    			GET_ALL_RFA_LETTER_TEMPLATES_BY_COMPANY_ID, paramSource, new LetterTemplateRowMapper(Boolean.TRUE));
    	return letterTemplateList;
	}
    
    @Override
	public List<LetterTemplate> getLetterTemplateGrid(Long companyId, TemplateSearchRequest letterTemplateSearchRequest) {
    	List<Lookup> templateNameList = letterTemplateSearchRequest.getTemplateName();
    	List<Lookup> createdByList = letterTemplateSearchRequest.getCreatedBy();
    	List<Lookup> modifiedByList = letterTemplateSearchRequest.getModifiedBy();
    	StringBuilder whereCondition = new StringBuilder();
    	
    	MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("offset", letterTemplateSearchRequest.getOffSet())
			.addValue("page_size", letterTemplateSearchRequest.getPageSize());
    	
    	if(null != templateNameList && templateNameList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : templateNameList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and rlt.id in (:name)");
    		paramSource.addValue("name", filteredIdList);
    	}
    	if(null != createdByList && createdByList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : createdByList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and rlt.created_by in (:created_by)");
			paramSource.addValue("created_by", filteredIdList);
    	}
    	if(null != modifiedByList && modifiedByList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : modifiedByList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and rlt.modified_by in (:modified_by)");
			paramSource.addValue("modified_by", filteredIdList);
    	}
    	
    	String gridQuery = GET_RFA_LETTER_TEMPLATE_GRID.replaceAll("whereCondition", whereCondition.toString());
    	
    	List<LetterTemplate> letterTemplateList = namedParameterJdbcTemplate.query(
    			gridQuery, paramSource, new LetterTemplateRowMapper(Boolean.FALSE));
    	return letterTemplateList;
	}
    
    @Override
	public Long getLetterTemplateGridTotalCount(Long companyId, TemplateSearchRequest letterTemplateSearchRequest) {
    	List<Lookup> templateNameList = letterTemplateSearchRequest.getTemplateName();
    	List<Lookup> createdByList = letterTemplateSearchRequest.getCreatedBy();
    	List<Lookup> modifiedByList = letterTemplateSearchRequest.getLinkedBy();
    	StringBuilder whereCondition = new StringBuilder();
    	
    	MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId);
    	
    	if(null != templateNameList && templateNameList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : templateNameList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and id in (:name)");
    		paramSource.addValue("name", filteredIdList);
    	}
    	if(null != createdByList && createdByList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : createdByList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and created_by in (:created_by)");
			paramSource.addValue("created_by", filteredIdList);
    	}
    	if(null != modifiedByList && modifiedByList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : modifiedByList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and modified_by in (:modified_by)");
			paramSource.addValue("modified_by", filteredIdList);
    	}
    	
    	String countQuery = GET_RFA_LETTER_TEMPLATE_GRID_TOTAL_COUNT.replaceAll("whereCondition", whereCondition.toString());
    	
    	Long totalCount = namedParameterJdbcTemplate.queryForObject(countQuery, paramSource, Long.class);
    	return totalCount;
	}
    
    @Override
    public LetterTemplate getLetterTemplateById(Long id, Long deleted,Long companyId)
    {        
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id).addValue("deleted", deleted).addValue("companyId",companyId);
    	LetterTemplate letterTemplate = namedParameterJdbcTemplate.queryForObject(
    			GET_RFA_LETTER_TEMPLATE_BY_ID, paramSource, new LetterTemplateRowMapper(Boolean.TRUE));
    	return letterTemplate;
    }
    
    @Override
	public Long getLetterTemplateByName(Long companyId, String name) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", companyId).addValue("name",
				name);
		try {
			// Have called queryForList instead of queryForObject because old
			// data has multiple template with same name. After this change
			// there can not be 2 template with same name.
			List<Long> id = namedParameterJdbcTemplate.queryForList(GET_RFA_LETTER_TEMPLATE_BY_NAME, paramSource,
					Long.class);
			if (CommonUtil.isNotNull(id) && !id.isEmpty())
				return id.get(0);
			else
				return null;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public String getLetterTemplateNameById(Long letterTemplateId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", letterTemplateId);
    	String letterTemplateName = namedParameterJdbcTemplate.queryForObject(
    			GET_RFA_LETTER_TEMPLATE_NAME_BY_ID, paramSource, String.class);
    	return letterTemplateName;
	}
}
