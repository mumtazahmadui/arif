package com.markit.ms.rfa.controller;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.annotation.Resource;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.beust.jcommander.internal.Maps;
import com.markit.fileutil.common.domain.MCFile;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.kyc.esign.util.EsignDocUtil;
import com.markit.kyc.esign.util.SignatureGenerator;
import com.markit.kyc.security.UserUtils;
import com.markit.ms.common.constants.PermissionConstants;
import com.markit.ms.common.model.CommonBaseRequest;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.rfa.bean.AmendmentContent;
import com.markit.ms.rfa.bean.AmendmentDownloadRequest;
import com.markit.ms.rfa.bean.AmendmentDownloadTransitionLog;
import com.markit.ms.rfa.bean.DatePinned;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.bean.PartyAPlaceHolder;
import com.markit.ms.rfa.bean.RejectionReason;
import com.markit.ms.rfa.bean.ReviewData;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.dto.BulkEmailNotification;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.security.McpmUserxsDetails;
import com.markit.ms.rfa.security.domain.McpmUser;
import com.markit.ms.rfa.service.IAmendmentChangeService;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.service.IPartyAPlaceholderService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.ConsolidateFileUtil;
import com.markit.ms.rfa.util.PDFContextGenerator;
import com.markit.ms.rfa.util.PDFUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.markit.ms.rfa.bean.enumeration.RFAStatusEnum;

import net.sourceforge.jtds.util.Logger;

@RestController
@RequestMapping(value = "/v1")
@Api(value = "amendmentLetters" , description = "Amendment Letter APIs")
public class AmendmentLetterActionsController {
	
	@Resource
	private IFileService fileService;
	
	@Autowired
	private IAmendmentLetterService amendmentLetterService;
	
	@Autowired
	private IAmendmentChangeService amendmentChangeService;
	
	@Autowired
	ConsolidateFileUtil consolidateFileUtil;
	
	@Resource
	private QueryService<String> getBSRfaStatus;
	
	@Resource
	private QueryService<String> getSSRfaStatus;
	
	@Resource
	private QueryService<Long> checkAmendmentHasReview;

	@Resource
	private QueryService<byte[]> selectAmendmentContent;
	
	@Resource
	private QueryService<Integer> selectAmendmentExhibitAgreed;
	
	@Resource
	private QueryService<Grid> selectPartyAPlaceholder;
	
	@Resource 
	private IReportGenerator reportGenerator;
	
	@Resource 
	private QueryService<Long> selectSSFileIDForAmendment;
	
	@Resource 
	private QueryService<Long> selectBSFileIDForAmendment;
	
	@Resource QueryService<Grid> bsSignatures;
	
	@Resource QueryService<Grid> ssSignatures;
	
	@Resource private SignatureGenerator signatureGenerator;
	
	@Resource QueryService<Long> selectAmendmentSSSignaturePlaceholderCount;
	@Resource QueryService<Long> selectAmendmentBSSignaturePlaceholderCount;
	@Resource QueryService<String> selectNextStepForAmendment;
	@Resource IPartyAPlaceholderService partyAPlaceholderService;

	@Resource private QueryService<Grid> getAmendmentDetails;
	
	@Value("${SAVE_RFA_AMENDMENT_CHANGE_LOG}")
	private String SAVE_RFA_AMENDMENT_CHANGE_LOG;
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}", method = RequestMethod.GET,  params = "fields")
    @ApiOperation(value = "Get Amendment Content")
    public @ResponseBody AmendmentContent getAmendmentLetterFields(@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response,
    		@RequestParam String fields) throws Exception{
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		AmendmentContent amendmentContent  = new AmendmentContent();
		if(fields.equals("content"))
			amendmentContent.setContent(CommonUtil.getValueFromBase64(selectAmendmentContent.executeQuery(params)));
		    amendmentContent.setAgreed(selectAmendmentExhibitAgreed.executeQuery(params));
		return amendmentContent;
    }
	@RequestMapping(value = "amendmentLetters/{amendmentId}/signaturePlaceholders", method = RequestMethod.GET)
    @ApiOperation(value = "Get Amendment Signature placeholders")
    public @ResponseBody Map<String,String> getSignaturePlaceholders(@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		Map<String,String> placeholderCount = Maps.newHashMap();
		Map<String,Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		Long ssPlaceholderCount = selectAmendmentSSSignaturePlaceholderCount.executeQuery(params);
		Long bsPlaceholderCount = selectAmendmentBSSignaturePlaceholderCount.executeQuery(params);
		placeholderCount.put("bs_placeholder_count", bsPlaceholderCount == null ? "0" : "" + bsPlaceholderCount);
		placeholderCount.put("ss_placeholder_count", ssPlaceholderCount == null ? "0" : "" + ssPlaceholderCount);
		return placeholderCount;
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/buySideSignaturePlaceHolders/{placeholderIndex}", method = RequestMethod.GET)
    @ApiOperation(value = "Get BS Placeholder images")
    public @ResponseBody Map<String, Object> getBSSignaturePlaceholderImages(@PathVariable Long amendmentId, 
    		@PathVariable int placeholderIndex,
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		params.put("placeholderIndex", placeholderIndex);
		
		Grid signatures = bsSignatures.executeQuery(params);
		List<String> images = new ArrayList<String>();
		for ( Map<String, String> signature : signatures.getRows()) {
			String name = signature.get("NAME");
			String title = signature.get("TITLE");
			String email = signature.get("EMAIL");
			String signatureDate = signature.get("CALENDAR_DATE");
			String signStyle = signature.get("SIGN_STYLE");
			String signText = signature.get("SIGN_TEXT");
			//String index = signature.get("PLACEHOLDER_INDEX");
			byte[] imageBytes = signatureGenerator.generateSignatureImage(signText, name, name, title, email, signStyle !=null ? Integer.parseInt(signStyle):1, signatureDate);
			String encodedImage = Base64.encodeBase64String(imageBytes);
			images.add(encodedImage);
		}
		Map<String, Object> result  = new HashMap<String, Object>();
		result.put("imageType", "data:image/gif;base64");
		result.put("images", images);
		
		return result;
    }

	@RequestMapping(value = "amendmentLetters/{amendmentId}/sellSideSignaturePlaceHolders/{placeholderIndex}", method = RequestMethod.GET)
    @ApiOperation(value = "Get BS Placeholder images")
    public @ResponseBody Map<String, Object> getSSSignaturePlaceholderImages(@PathVariable Long amendmentId, 
    		@PathVariable int placeholderIndex,
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		params.put("placeholderIndex", placeholderIndex);
		
		Grid signatures = ssSignatures.executeQuery(params);
		List<String> images = new ArrayList<String>();
		for ( Map<String, String> signature : signatures.getRows()) {
			String name = signature.get("NAME");
			String title = signature.get("TITLE");
			String email = signature.get("EMAIL");
			String signatureDate = signature.get("CALENDAR_DATE");
			String signStyle = signature.get("SIGN_STYLE");
			String signText = signature.get("SIGN_TEXT");
			//String index = signature.get("PLACEHOLDER_INDEX");
			byte[] imageBytes = signatureGenerator.generateSignatureImage(signText, name, name, title, email, signStyle !=null ? Integer.parseInt(signStyle):1, signatureDate);
			String encodedImage = Base64.encodeBase64String(imageBytes);
			images.add(encodedImage);
		}
		Map<String, Object> result  = new HashMap<String, Object>();
		result.put("imageType", "data:image/gif;base64");
		result.put("images", images);
		
		return result;
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/partyAPlaceHolder", method = RequestMethod.GET)
    @ApiOperation(value = "Get PartyA Placeholder")
    public @ResponseBody PartyAPlaceHolder getPartyAPlaceholder(@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		return partyAPlaceholderService.getPartyAPlaceholder(amendmentId);
    }
	

	@RequestMapping(value = "amendmentLetters/{amendmentId}/partyAPlaceHolder", method = RequestMethod.POST, consumes = "application/json")
    @ApiOperation(value = "Get PartyA Placeholder")
	@ResponseStatus(value=HttpStatus.CREATED)
    public void updatePartyAPlaceholder(@RequestBody PartyAPlaceHolder partyAPlaceholder,
    		@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		long userId = CommonUtil.getUserIdFromSession(request);
		 partyAPlaceholderService.updatePartyAPlaceholder(partyAPlaceholder, amendmentId, userId);
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/datePinnedPlaceHolder", method = RequestMethod.GET)
    @ApiOperation(value = "Get PartyA Placeholder")
    public @ResponseBody DatePinned getDatePinnedPlaceholder(@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		DatePinned datePinned  = new DatePinned();
		return datePinned;
    }
	

	@RequestMapping(value = "amendmentLetters/{amendmentId}/actions/edit_content", method = RequestMethod.PUT)
	@ApiOperation(value = "Get PartyA Placeholder")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	public void updateAmendmentContent(@PathVariable Long amendmentId, 
			@RequestBody AmendmentContent amendmentContent, 
			HttpServletRequest request, 
			HttpServletResponse response) throws Exception{
		long userId = CommonUtil.getUserIdFromSession(request);
		amendmentLetterService.updateContent(amendmentId, userId, amendmentContent);
		amendmentChangeService.saveRfaChangeLogAudit(amendmentContent.getChangelog(), amendmentId,
				"LETTER",amendmentContent.getPartyType(),SAVE_RFA_AMENDMENT_CHANGE_LOG);
		amendmentChangeService.saveRfaCommentAudit(amendmentContent.getCommentlog(), amendmentId,
				"LETTER",amendmentContent.getPartyType(),SAVE_RFA_AMENDMENT_CHANGE_LOG);
	}

	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/legalReviews", method = RequestMethod.POST)
    @ApiOperation(value = "Add Legal Review to amendment letter")
    public void addLegalReview(@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		long userId = CommonUtil.getUserIdFromSession(request);
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		params.put("review_type",2);
		if(checkAmendmentHasReview.executeQuery(params) !=0){
			response.setStatus(HttpStatus.BAD_REQUEST.value());
		} else {
			response.setStatus(HttpStatus.CREATED.value());
			Long reviewId = amendmentLetterService.addReview(2, userId, amendmentId);
			WebUtils.addLocationHeaderToResponse(response, "/v1/amendmentLetters/" + amendmentId + "/legalReviews/" + reviewId);
		}
		
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/onBoardingReviews", method = RequestMethod.POST)
    @ApiOperation(value = "Add Legal Review to amendment letter")
    public void addonBoardingReviews(@PathVariable Long amendmentId, 
    		HttpServletRequest request,
    		HttpServletResponse response) throws Exception{
		long userId = CommonUtil.getUserIdFromSession(request);
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		params.put("review_type",1);
		if(checkAmendmentHasReview.executeQuery(params) !=0){
			response.setStatus(HttpStatus.BAD_REQUEST.value());
		} else {
			response.setStatus(HttpStatus.CREATED.value());
			Long reviewId = amendmentLetterService.addReview(1, userId, amendmentId);
			WebUtils.addLocationHeaderToResponse(response, "/v1/amendmentLetters/" + amendmentId + "/onBoardingReviews/" + reviewId);
		}
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/onBoardingReviews/{reviewId}", method = RequestMethod.GET, produces= "application/json")
    @ApiOperation(value = "Add Legal Review to amendment letter")
	@ResponseStatus(value=HttpStatus.OK)
    public @ResponseBody ReviewData getOnBoardingReviews(@PathVariable Long amendmentId,
    		@PathVariable Long reviewId,
    		HttpServletRequest request) throws Exception{
		
		ReviewData reviewData = amendmentLetterService.getReview(reviewId, 1, amendmentId);
		return reviewData;
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/legalReviews/{reviewId}", method = RequestMethod.GET, produces= "application/json")
    @ApiOperation(value = "Add Legal Review to amendment letter")
	@ResponseStatus(value=HttpStatus.OK)
    public @ResponseBody ReviewData getLegalReviews(@PathVariable Long amendmentId,
    		@PathVariable Long reviewId,
    		HttpServletRequest request) throws Exception{
		
		ReviewData reviewData = amendmentLetterService.getReview(reviewId, 2, amendmentId);
		return reviewData;
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/legalReviews/{reviewId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "Delete Legal Review to amendment letter")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
    public void deleteLegalReview(@PathVariable Long amendmentId, 
    		@PathVariable Long reviewId,
    		HttpServletRequest request) throws Exception{
		long userId = CommonUtil.getUserIdFromSession(request);
		amendmentLetterService.deleteReview(reviewId, userId, amendmentId);
		
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/onBoardingReviews/{reviewId}", method = RequestMethod.DELETE)
    @ApiOperation(value = "Delete Legal Review to amendment letter")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
    public void deleteOnBoardingReviews(@PathVariable Long amendmentId, 
    		@PathVariable Long reviewId, 
    		HttpServletRequest request,
    		HttpServletRequest response) throws Exception{
		long userId = CommonUtil.getUserIdFromSession(request);
		amendmentLetterService.deleteReview(reviewId, userId, amendmentId);
    }
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/actions/reject", method = RequestMethod.PUT)
	@ApiOperation(value = "Reject Amendment Letter")
	@RolesAllowed({PermissionConstants.SS_RFA, PermissionConstants.SS_RFA_SIGNATORY})
	public void rejectAmendmentLetter(@PathVariable Long amendmentId, @RequestParam(required=true) String reason
			, HttpServletRequest request, HttpServletResponse response) throws Exception {
		rejectAmendment(amendmentId, reason, request, response);
	}
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/actions/rejectWithPayload", method = RequestMethod.PUT)
	@ApiOperation(value = "Reject Amendment Letter")
	@RolesAllowed({PermissionConstants.SS_RFA, PermissionConstants.SS_RFA_SIGNATORY})
	public void rejectAmendmentLetterWithPayload(@PathVariable Long amendmentId, @RequestBody RejectionReason rejectionReason
			, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String reason = rejectionReason.getReason();
		rejectAmendment(amendmentId, reason, request, response);
	}
	private void rejectAmendment(Long amendmentId, String reason,
			HttpServletRequest request, HttpServletResponse response)
			throws UnsupportedEncodingException, RFAUIException, Exception {
		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		reason = CommonUtil.convertToUTF8(reason.getBytes());
		if(reason != null && reason.length() > 500) {
			throw new RFAUIException("Rejection Reason cannot be greater than 500 chars");
		}
		String ssRfaStatus = getSSRfaStatus.executeQuery("amendment_id", amendmentId);
		if(!AmendmentStatus.RECEIVED.name().equalsIgnoreCase(ssRfaStatus)) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
		} else {
			amendmentLetterService.rejectAmendmentLetter(amendmentId, userIdFromSession, 
					companyIdFromSession, reason, companyTypeFromSession);
			response.setStatus(HttpStatus.NO_CONTENT.value());
		}
	}
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/actions/deleteAmendment", method = RequestMethod.PUT)
	@ApiOperation(value = "Delete Amendment Letter")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	public void deleteAmendmentLetter(@PathVariable Long amendmentId, @RequestBody RejectionReason deleteReason
			, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String reason = deleteReason.getReason();
		deleteAmendment(amendmentId, reason, request, response);
	}
	
	private void deleteAmendment(Long amendmentId, String reason, HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException, RFAUIException, Exception{

		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		String eventName = RFAConstants.EVENT_NAME_DELETED_BS;
		if (reason != null && reason.length() > 2000) {
			throw new RFAUIException("Deletion Reason cannot be greater than 2000 chars");
		}
		String bsRfaStatus = getBSRfaStatus.executeQuery("amendment_id", amendmentId);

		if (!(AmendmentStatus.DRAFT.name().equalsIgnoreCase(bsRfaStatus)
				|| AmendmentStatus.RECALLED.name().equalsIgnoreCase(bsRfaStatus))) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
		} else {
			Long fileId = selectBSFileIDForAmendment.executeQuery("amendmentId", amendmentId);
			amendmentLetterService.deleteAmendmentLetter(amendmentId, userIdFromSession, companyTypeFromSession);
			if (CommonUtil.isNull(fileId)) {
				PDFContext pdfContext = PDFContextGenerator.getBuySideRFAIDContext();
				byte[] pdf = reportGenerator.getPDFContent(amendmentId, pdfContext);
				final String FILE_NAME = amendmentId + ".pdf";

				MCFile mcFile = fileService.saveFile(FILE_NAME, pdf, companyIdFromSession, userIdFromSession);
				fileId = mcFile.getFileId();
			}
			byte[] fileByte = fileService.getFile(fileId, companyIdFromSession);
			int noOfPages = EsignDocUtil.getNoOfPages(fileByte);
			amendmentLetterService.addTransitionLogs(userIdFromSession, null, amendmentId, null, eventName, fileId,
					null, noOfPages, reason);

		}
	}
	@RequestMapping(value = "amendmentLetters/{amendmentId}/actions/edit", method = RequestMethod.PUT)
	@ApiOperation(value = "Edit Rejected Amendment Letter")
	@RolesAllowed({PermissionConstants.BS_RFA, PermissionConstants.BS_RFA_SIGNATORY})
	public void editRejectedAmendmentLetter(@PathVariable Long amendmentId
			, HttpServletRequest request, HttpServletResponse response) {
		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
		String bsRfaStatus = getBSRfaStatus.executeQuery("amendment_id", amendmentId);
		if(!(AmendmentStatus.REJECTED.name().equalsIgnoreCase(bsRfaStatus)
				||AmendmentStatus.RECALLED.name().equalsIgnoreCase(bsRfaStatus))) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
		} else {
			amendmentLetterService.editRejectedAmendmentLetter(amendmentId, userIdFromSession);
			response.setStatus(HttpStatus.NO_CONTENT.value());
		}
	}
	
	  @RequestMapping(method = RequestMethod.GET, value = "amendmentLetters/{amendmentId}/actions/rfaid_pdf")
	  public @ResponseBody void openRfaIdPDF(@PathVariable Long amendmentId
			  , HttpServletResponse response
			  , HttpServletRequest request) throws Exception {
		  	String companyType = CommonUtil.getCompanyTypeFromSession(request);
		  	Long sessionCompanyId = CommonUtil.getCompanyIdFromSession(request);
		  	Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
			if(!isUserCompanyisEitherBSorSS(sessionCompanyId,amendmentId)) {
				return;
			}
			
		  	byte[] pdf = null;
			byte[] wSignByte = consolidateFileUtil.consolidateWetSignsByRFAId(amendmentId, sessionCompanyId, userIdFromSession);
		if (companyType.equals(RFAConstants.COMPANY_TYPE_SS)) {
			Long fileId = selectSSFileIDForAmendment.executeQuery("amendmentId", amendmentId);
			if (fileId != null) {
				pdf = fileService.getFile(fileId, 1L);
			} else {
				String ssNextStep = selectNextStepForAmendment.executeQuery("amendmentId", amendmentId);
				PDFContext pdfContext = PDFContextGenerator.getSellSideRFAIDContext();
				if ("SS_SEND_RFA".equalsIgnoreCase(ssNextStep)) {
					pdfContext = PDFContextGenerator.getSellSideRFAIDSignedContext();
				}
				if (CommonUtil.isNotNull(wSignByte))
					pdf = PDFUtil.merge(reportGenerator.getPDFContent(amendmentId, pdfContext), wSignByte);
				else
					pdf = reportGenerator.getPDFContent(amendmentId, pdfContext);
			}
		} else {
			Long fileId = selectBSFileIDForAmendment.executeQuery("amendmentId", amendmentId);
			if (fileId != null) {
				pdf = fileService.getFile(fileId, 1L);
			} else {
				PDFContext pdfContext = PDFContextGenerator.getBuySideRFAIDContext();
				if (CommonUtil.isNotNull(wSignByte))
					pdf = PDFUtil.merge(reportGenerator.getPDFContent(amendmentId, pdfContext), wSignByte);
				else
					pdf = reportGenerator.getPDFContent(amendmentId, pdfContext);
			}
		}
		final String FILE_NAME = amendmentId +".pdf";
	    WebUtils.write2Response(response, pdf, "application/pdf",  FILE_NAME, true);
	  }

	  @RequestMapping(method = RequestMethod.POST, value = "amendmentLetters/actions/rfaid_pdf", consumes = "application/json")
	  public @ResponseBody void openRfaIdPDF(@RequestBody AmendmentDownloadRequest amendmentDownloadRequest
			  , HttpServletResponse response
			  , HttpServletRequest request) throws Exception {
		  	String companyType = CommonUtil.getCompanyTypeFromSession(request);
		  	Long companyId = CommonUtil.getCompanyIdFromSession(request);
		  	Long sessionCompanyId = CommonUtil.getCompanyIdFromSession(request);
		  	Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
		  	String eventName = null;
			if(!isUserCompanyisEitherBSorSS(sessionCompanyId,amendmentDownloadRequest.getAmendmentIds()[0])) {
				return;
			}
			Map<String, byte[]> data = new HashMap<String, byte[]>();
		  	for(Long amendmentId : amendmentDownloadRequest.getAmendmentIds()) {
				byte[] wSignByte = consolidateFileUtil.consolidateWetSignsByRFAId(amendmentId, companyId, userIdFromSession);
				
		  		if(companyType.equals(RFAConstants.COMPANY_TYPE_SS) ) {
		  			Long fileId= selectSSFileIDForAmendment.executeQuery("amendmentId",amendmentId);
		  			if( fileId != null) {
		  				data.put(String.valueOf(amendmentId) + ".pdf", fileService.getFile(fileId, 1L));
		  			} else {
		  				String ssNextStep = selectNextStepForAmendment.executeQuery("amendmentId",amendmentId);
		  				PDFContext pdfContext = PDFContextGenerator.getSellSideRFAIDContext();
		  				if("SS_SEND_RFA".equalsIgnoreCase(ssNextStep)) {
		  					pdfContext = PDFContextGenerator.getSellSideRFAIDSignedContext();
					}
					if (CommonUtil.isNull(wSignByte))
						data.put(String.valueOf(amendmentId) + ".pdf", reportGenerator.getPDFContent(amendmentId, pdfContext));
					else
						data.put(String.valueOf(amendmentId) + ".pdf",
								PDFUtil.merge(reportGenerator.getPDFContent(amendmentId, pdfContext), wSignByte));

				}
		  			eventName = RFAConstants.EVENT_NAME_PRINT_DOWNLOAD_SS;
		  		} else {
		  			Long fileId= selectBSFileIDForAmendment.executeQuery("amendmentId",amendmentId);
		  			if( fileId != null) {
					data.put(String.valueOf(amendmentId) + ".pdf", fileService.getFile(fileId, 1L));
				} else {
					PDFContext pdfContext = PDFContextGenerator.getBuySideRFAIDContext();
					if (CommonUtil.isNull(wSignByte))
						data.put(String.valueOf(amendmentId) + ".pdf", reportGenerator.getPDFContent(amendmentId, pdfContext));
					else
						data.put(String.valueOf(amendmentId) + ".pdf",
								PDFUtil.merge(reportGenerator.getPDFContent(amendmentId, pdfContext), wSignByte));
				}
				eventName = RFAConstants.EVENT_NAME_PRINT_DOWNLOAD_BS;

			}
		}
		if (amendmentDownloadRequest.isDownloadable()) {
			List<AmendmentDownloadTransitionLog> amendmentDownloadTransitionLogs = new ArrayList<AmendmentDownloadTransitionLog>();
			DateTime dateTime = new DateTime().withZone(DateTimeZone.forTimeZone(TimeZone.getTimeZone("GMT")));
			String currentDate = dateTime.toString("dd-MM-yyyy HH:mm:ss");
			Long downloadId = amendmentLetterService.getNextAvailableDownloadId();
			if (data.size() > 1) {
				WebUtils.writeZip2Response(response, data, currentDate + "_" + downloadId + ".zip");
				for (Long amendmentId : amendmentDownloadRequest.getAmendmentIds()) {
					String docId = amendmentLetterService.getNextAvailableDocId(amendmentId);
					Long fileId = consolidateFileUtil.consolidateAllSigns(amendmentId, companyId, userIdFromSession,
							companyType);
					byte[] fileByte = fileService.getFile(fileId, companyId);
					int noOfPages = EsignDocUtil.getNoOfPages(fileByte);
					amendmentDownloadTransitionLogs.add(generateDownloadTransitionLogData(request.getRemoteAddr(), userIdFromSession,
							eventName, downloadId, amendmentId, fileId, noOfPages, docId));
					amendmentLetterService.updateStatus(RFAStatusEnum.PRINTED.getName(), amendmentId,companyType);

				}
				amendmentLetterService.addDownloadTransitionLogs(amendmentDownloadTransitionLogs);
			} else {
				WebUtils.write2Response(response, data.values().stream().findFirst().get(), "application/pdf",
						currentDate + "_" + downloadId + ".pdf");
				updateLogForPrintNDownloadSinglePDF(amendmentDownloadRequest.getAmendmentIds()[0], request.getRemoteAddr(), companyType, companyId, userIdFromSession, eventName, downloadId);

			}
		} else {
			WebUtils.write2Response(response, data.values().stream().findFirst().get(), "application/pdf",
					data.keySet().stream().findFirst().get(), true);
		}
	}
	private void updateLogForPrintNDownloadSinglePDF(Long amendmentId,
			String ipAddress, String companyType, Long companyId, Long userIdFromSession, String eventName , Long downloadId) throws Exception {

		Long fileId = consolidateFileUtil.consolidateAllSigns(amendmentId, companyId, userIdFromSession,
				companyType);
		byte[] fileByte = fileService.getFile(fileId, companyId);
		int noOfPages = EsignDocUtil.getNoOfPages(fileByte);

		amendmentLetterService.addTransitionLogs(userIdFromSession, ipAddress,
				Long.valueOf(amendmentId), downloadId, eventName, fileId,null,noOfPages,null);
		amendmentLetterService.updateStatus(RFAStatusEnum.PRINTED.getName(), Long.valueOf(amendmentId),companyType);
	}
	private AmendmentDownloadTransitionLog generateDownloadTransitionLogData(String ipAddress,
			Long userIdFromSession, String eventName, Long downloadId, Long amendmentId, Long fileId, int noOfPages, String docId) {
		AmendmentDownloadTransitionLog amendmentDownloadTransitionLog = new AmendmentDownloadTransitionLog();
		amendmentDownloadTransitionLog.setAmendmentId(amendmentId);
		amendmentDownloadTransitionLog.setDownloadId(downloadId);
		amendmentDownloadTransitionLog.setEventName(eventName);
		amendmentDownloadTransitionLog.setFileId(fileId);
		amendmentDownloadTransitionLog.setIpAddress(ipAddress);
		amendmentDownloadTransitionLog.setNoOfPages(noOfPages);
		amendmentDownloadTransitionLog.setUserId(userIdFromSession);
		amendmentDownloadTransitionLog.setDocId(docId);
		return amendmentDownloadTransitionLog;
	}
	  
	private boolean isUserCompanyisEitherBSorSS(Long sessionCompanyId, Long amendmentId) {
		Grid amendmentDetails = getAmendmentDetails.executeQuery("amendmentId", amendmentId);
		
		Map<String,String> row = amendmentDetails.getRows().get(0);
		
		String partyACompanyId = row.get("PARTYA_COMPANY_ID");
		String imCompanyId = row.get("IM_COMPANY_ID");
		boolean accessAllowedForBSRFAID = imCompanyId.equalsIgnoreCase(""+sessionCompanyId) ? true : false;
		boolean accessAllowedForSSRFAID = partyACompanyId.equalsIgnoreCase(""+sessionCompanyId) ? true : false;
		return (accessAllowedForBSRFAID || accessAllowedForSSRFAID);
	}
	
	@RequestMapping(value = "amendmentLetters/{amendmentId}/actions/send_amendment_letter", method = RequestMethod.POST)
	@ApiOperation(value = "Send RFA")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	public void sendRFA(@PathVariable Long amendmentId, HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
			McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
			McpmUser mcpmUser = mcpmUserxsDetails.getEffectiveUser();
			String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
			amendmentLetterService.sendRFA(amendmentId, userIdFromSession, companyTypeFromSession, mcpmUser.getCompanyId());
		}
		catch (Exception e){
			Logger.logException(e);
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "bulkNotifications", method = RequestMethod.POST, consumes = "application/json")
	public void bulkSellsideEmailNotification(@RequestBody CommonBaseRequest<BulkEmailNotification> commonBaseRequest,
			HttpServletRequest request) throws Exception {
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		BulkEmailNotification emailNotificationObj = commonBaseRequest.getData();
		amendmentLetterService.sendBulkEmailNotification(emailNotificationObj, companyTypeFromSession);
	}
	
	@RequestMapping(value = "amendmentLetters", method=RequestMethod.GET)
	public @ResponseBody CommonBaseResponse<List<Long>> getEsignedAmendmentLetters(HttpServletRequest request, 
			@RequestParam(value="fromRow") Long offset,
			@RequestParam(value="pageSize") Long pageSize,
			@RequestParam(value="filterString") String filterString,
			@RequestParam(value="state") String state){
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		CommonBaseResponse<List<Long>> commonBaseResponse = new CommonBaseResponse<List<Long>>();
		List<Long> amendmendIds = null;
		if("ssEsign".equalsIgnoreCase(state)) {
			amendmendIds =  amendmentLetterService.getBulkNotificationRFA(companyId, filterString, offset, pageSize);
		}
		commonBaseResponse.setData(amendmendIds);
		return commonBaseResponse;
	}
}
