package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.rfa.bean.AmendmentChangeAudit;
import com.markit.ms.rfa.bean.AmendmentCommentAudit;

public interface IAmendmentChangeDAO {

	public void saveRfaCommentAudit(List<AmendmentCommentAudit> commentAuditList, Long rfaid, String source,
			String partyType,String query);

	public void saveRfaChangeLogAudit(List<AmendmentChangeAudit> changeAuditList, Long rfaid, String source,
			String partyType,String query);

}
