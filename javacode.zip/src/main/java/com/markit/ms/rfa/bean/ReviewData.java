package com.markit.ms.rfa.bean;

public class ReviewData {
private OnBoardingReviewData onboarding;
private LegalReviewData legal;

public ReviewData(){
	onboarding = new OnBoardingReviewData();
	legal = new LegalReviewData();
}

public OnBoardingReviewData getOnboarding() {
	return onboarding;
}
public void setOnboarding(OnBoardingReviewData onboarding) {
	this.onboarding = onboarding;
}
public LegalReviewData getLegal() {
	return legal;
}
public void setLegal(LegalReviewData legal) {
	this.legal = legal;
}

}
