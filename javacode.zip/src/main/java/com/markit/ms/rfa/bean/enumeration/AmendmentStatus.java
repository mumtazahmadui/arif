package com.markit.ms.rfa.bean.enumeration;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.markit.ms.rfa.bean.enumeration.serializers.AmendmentStatusDeserializer;
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
@JsonDeserialize(using=AmendmentStatusDeserializer.class)
public enum AmendmentStatus {
	DRAFT("Draft", "Draft"),
	SUBMITTED("Submitted", "Submitted"),
	RECEIVED("Received", "Received"),
	PARTIALLY_COMPLETED("Partially Completed", "Partially Completed"),
	COMPLETED("Completed", "Completed"),
	RECALLED("Recalled", "Recalled"),
	REJECTED("Rejected", "Rejected"),
	DELETED("Deleted", "Deleted");
	
	private String displayName;
	private String trueName;

	private AmendmentStatus(String displayName, String trueName){
		this.displayName = displayName;
		this.trueName= trueName;
	}
	
	public String getTrueName()
    {
        return this.trueName;
    }

	public String getDisplayName()
    {
        return this.displayName;
    }	
	
	public static AmendmentStatus fromString(String str){
		if (str == null)
			return null;
		for (AmendmentStatus stat: AmendmentStatus.values()){
			if (stat.trueName.equalsIgnoreCase(str)) return stat;
		}
		return null;
	}

}
