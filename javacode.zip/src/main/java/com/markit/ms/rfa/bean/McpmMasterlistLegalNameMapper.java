package com.markit.ms.rfa.bean;

public class McpmMasterlistLegalNameMapper {
	
	private String masterlistLegalName;
	private String mcpmLegalName;
	
	public String getMasterlistLegalName() {
		return masterlistLegalName;
	}
	public void setMasterlistLegalName(String masterlistLegalName) {
		this.masterlistLegalName = masterlistLegalName;
	}
	public String getMcpmLegalName() {
		return mcpmLegalName;
	}
	public void setMcpmLegalName(String mcpmLegalName) {
		this.mcpmLegalName = mcpmLegalName;
	}
}
