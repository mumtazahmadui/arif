package com.markit.ms.rfa.rfabulkupload.chain.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.markit.ms.common.constants.SpringConstants;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.rfabulkupload.command.impl.FundNameChangeCommand;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
@Scope(SpringConstants.SPRING_SCOPE_PROTOTYPE)
public class FncModificationChain implements ActionChain {

	private ActionChain chain;

	@Autowired
	FundNameChangeCommand fundNameChangeCommand;

	@Autowired
	CommonValidator commonValidator;

	@Override
	public void setNextChain(ActionChain actionChain) {
		this.chain = actionChain;
	}

	@Override
	public void process(RfaBulkUploadRow rfaBulkUploadRow) {
		fundNameChangeCommand.execute(rfaBulkUploadRow, chain);

		// TODO: Why were we checking parentEntityAlreadyPresent in old
		// ModificationChain code??
		if (CommonUtil.isNull(this.chain) && rfaBulkUploadRow.getRequestIdentified().size() == 0 && rfaBulkUploadRow.getErrors().isEmpty())
			rfaBulkUploadRow.addError(RFAConstants.REQUEST_TYPE_NOT_IDENTIFIED);

		// process next step
		if (CommonUtil.isNotNull(this.chain))
			this.chain.process(rfaBulkUploadRow);

	}

}
