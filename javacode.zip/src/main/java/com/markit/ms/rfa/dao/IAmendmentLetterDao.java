package com.markit.ms.rfa.dao;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.rfa.bean.AmendmentContent;
import com.markit.ms.rfa.bean.AmendmentDownloadTransitionLog;
import com.markit.ms.rfa.bean.AmendmentHistory;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.AmendmentSignData;
import com.markit.ms.rfa.bean.BulkActionBean;
import com.markit.ms.rfa.bean.ReviewData;
import com.markit.ms.rfa.bean.report.AmendmentLetterPDFBean;
import com.markit.ms.rfa.dto.AmendmentLetterSearchRequest;

public interface IAmendmentLetterDao {
	public AmendmentLetter saveAmendmentLetter(Long companyId, String companyType, AmendmentLetter amendmentLetter,
			Date agreementDate, String ipAddress) throws Exception;

	public AmendmentLetter updateAmendmentLetter(Long companyId, String companyType, AmendmentLetter amendmentLetter,
			Long userId);

	public AmendmentLetter getAmendmentLetterById(Long id, Long companyId);
	
	public AmendmentLetter getAmendmentLetterById(Long amendmentId);

	public List<AmendmentLetter> getBSAmendmentLetterGrid(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest);

	public List<AmendmentLetter> getSSAmendmentLetterGrid(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest);

	public Long getBSAmendmentLetterGridTotalCount(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest);

	public Long getSSAmendmentLetterGridTotalCount(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest);

	public AmendmentLetterPDFBean getAmendmentLetterPDFBean(Long amendmentletterId);

	public AmendmentLetter recallAmendmentLetter(Long companyId, Long userId, Long amendmentLetterId);

	public List<AmendmentHistory> history(Long amendmentLetterId, Long companyId);

	public int signSellSide(Signature signature, AmendmentLetter amendmentLetter);

	public Long getSignFileId(Long amendment_id, Long companyId);

	public void rejectAmendmentLetter(Long amendmentId, Long userId, Long companyId, String reason);

	public void editRejectedAmendmentLetter(Long amendmentId, Long userId);

	public Long addReview(int reviewId, long userId, long amendmentId);

	public void deleteReview(long reviewId, long userId, Long amendmentId);

	public ReviewData getReview(Long reviewId, int reviewType, Long amendmentId);

	public void updateContent(Long amendmentId, Long userId, AmendmentContent amendmentContent);

	public void sendRFA(Long amendmentId, Long userId, String companyType);

	public void updateBSTaskAndNextSteps(Long amendmentId, String action);

	public void createRFAStateTransitionLog(Long amendmentId, String amendmentStatus, Long userId, Boolean isBSCompany);

	public void createRFAStateTransitionLogForBothBSAndSS(Long amendmentId, String amendmentStatus, Long userId);

	public List<Long> getBulkNotificationRFA(Long companyId, String filterString, Long offset, Long pageSize);

	public void saveErrorMessage(String actionName, Long rfaId, String errorMessage, Long userId);

	public void saveChaser(BulkActionBean bulkActionBean);

	void updateChasers(List<Long> rfaIds, Long userId);

	public String getAmendmentMlTemplateWithSleeve(Long amendmentId);

	public void saveBulkUploadFileTemplate(Long templateId, Long cmpanyId, Long fileId, Long bulkRequestId);

	public Long getBulkRFAUploadId(Long bulkRequestId);

	public void updateBulkUploadFileTemplate(Long fileId, Long bulkRequestId, String status);

	public void updateBulkRequest(Long bulkRequestId, String upperCase);

	public Entity getMasterlistEntity(Long partyBEntityId, Long masterAgreementId);

	List<Long> getWetSignData(Long amendmentId);

	Long getLatestESignData(Long amendmentId);

	public void addTransitionLogs(Long userId, String ipAddress, Long amendmentLetterId, Long downloadId, String eventName,Long fileId,Long uploadedFileId,int noOfPages,String reason);

	public Long getUploadedFile(Long amendmentLetterId);
	
	Map<Long, AmendmentSignData> getSignHoverData(Long companyId, List<Long> rfaIds,String companyType);
	
	Map<Long, AmendmentSignData> getSignCountData(Long companyId, List<Long> rfaIds,String companyType);

	public Long getNextAvailableDownloadId();

	public void addDownloadTransitionLogs(List<AmendmentDownloadTransitionLog> amendmentDownloadTransitionLogs);

	public void updatNotifiedByfor(List<Long> rfaIds, Long notifiedByUserId);

	public String getNextAvailableDocId(Long amendmentId);
	
	public void updateStatus(String status,Long amendmentId,String companyType) ;

	public void updateChangesCount(Long amendmentId, int changeCount, String source);

	public void updateChangesRespondedCount(Long amendmentId, int respondedCount);

	public void updateCommentsCount(int size, Long amendmentId, String source, String partyType);

	public void updateResolvedCommentsCount(int resolvedCommentsCount, Long amendmentId);
	
	public void deleteAmendmentLetter(Long amendmentId, Long userId);


}
