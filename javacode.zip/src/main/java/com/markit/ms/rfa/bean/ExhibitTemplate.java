package com.markit.ms.rfa.bean;

import java.util.Date;
import java.util.List;

public class ExhibitTemplate {
	private Long id;
	private String name;
	private Long companyId;
	private String textContent;
	private String htmlContent;
	private List<ExhibitTemplateColumn> columns;
	private Date createdDate;
	private Date modifiedDate;
	private Date linkedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Long linkedBy;
	private String createdByString;
	private String modifiedByString;
	private String linkedByString;
	private Long deleted;
	
	private boolean showExhibitLink;
	
	private Date agreementDate;
	
	private String partyATrueLegalName;
	
	private String masterlistIdentifier;
	
	private Integer agreed;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getTextContent() {
		return textContent;
	}
	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}
	public String getHtmlContent() {
		return htmlContent;
	}
	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}
	public List<ExhibitTemplateColumn> getColumns() {
		return columns;
	}
	public void setColumns(List<ExhibitTemplateColumn> columns) {
		this.columns = columns;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getLinkedDate() {
		return linkedDate;
	}
	public void setLinkedDate(Date linkedDate) {
		this.linkedDate = linkedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getLinkedBy() {
		return linkedBy;
	}
	public void setLinkedBy(Long linkedBy) {
		this.linkedBy = linkedBy;
	}
	public String getCreatedByString() {
		return createdByString;
	}
	public void setCreatedByString(String createdByString) {
		this.createdByString = createdByString;
	}
	public String getLinkedByString() {
		return linkedByString;
	}
	public void setLinkedByString(String linkedByString) {
		this.linkedByString = linkedByString;
	}
	public Long getDeleted() {
		return deleted;
	}
	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}
	public boolean isShowExhibitLink() {
		return showExhibitLink;
	}
	public void setShowExhibitLink(boolean showExhibitLink) {
		this.showExhibitLink = showExhibitLink;
	}
	public Date getAgreementDate() {
		return agreementDate;
	}
	public void setAgreementDate(Date agreementDate) {
		this.agreementDate = agreementDate;
	}
	public String getPartyATrueLegalName() {
		return partyATrueLegalName;
	}
	public void setPartyATrueLegalName(String partyATrueLegalName) {
		this.partyATrueLegalName = partyATrueLegalName;
	}
	public String getMasterlistIdentifier() {
		return masterlistIdentifier;
	}
	public void setMasterlistIdentifier(String masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedByString() {
		return modifiedByString;
	}
	public void setModifiedByString(String modifiedByString) {
		this.modifiedByString = modifiedByString;
	}
	public Integer getAgreed() {
		return agreed;
	}
	public void setAgreed(Integer agreed) {
		this.agreed = agreed;
	}
}
