package com.markit.ms.rfa.service;

import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.markit.ms.rs.select.all.domain.BulkRequestParam;
import com.markit.ms.rs.select.all.domain.SelectAllConfig;

/**
 * This interface provides the select all framework feature.
 * 
 * @author abhishek.tiwari
 *
 */
public interface RFABulkRequestService {
	
	void doProcess(Long savedBulkRequestId, Long userId, Long companyId, String configBeanName,Long templateId, String ipAddress);
	


	Long saveBulkUploadRFARequest(SelectAllConfig config, Long userId, Long companyId,Long fileId) throws UnknownHostException;


	
}
