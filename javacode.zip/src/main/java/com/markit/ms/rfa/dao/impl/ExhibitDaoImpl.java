package com.markit.ms.rfa.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.bean.ExhibitColumn;
import com.markit.ms.rfa.dao.IExhibitDao;
import com.markit.ms.rfa.dao.resultsetextractor.ExhibitResultSetExtractor;

@Repository
public class ExhibitDaoImpl extends BaseDAOImpl implements IExhibitDao{

	@Value("${SAVE_EXHIBIT}")
	private String SAVE_EXHIBIT;
	
    @Value("${SAVE_EXHIBIT_COL}")
    private String SAVE_EXHIBIT_COL;
    
    @Value("${UPDATE_EXHIBIT}")
    private String UPDATE_EXHIBIT;
    
    @Value("${UPDATE_EXHIBIT_COL}")
    private String UPDATE_EXHIBIT_COL;
    
    @Value("${GET_RFA_EXHIBIT}")
	private String GET_RFA_EXHIBIT;
    
    @Override
	public Exhibit createExhibit(Exhibit exhibit) {
    	MapSqlParameterSource params = new MapSqlParameterSource()
    		.addValue("amendment_id", exhibit.getAmendmentId())
    	    .addValue("text_content", exhibit.getTextContent().getBytes())
    	    .addValue("html_content", exhibit.getHtmlContent().getBytes())
    	    .addValue("created_by", exhibit.getCreatedBy())
    	    .addValue("modified_by", exhibit.getModifiedBy());
    	
    	KeyHolder keyHolder = new GeneratedKeyHolder();
        namedParameterJdbcTemplate.update(SAVE_EXHIBIT, params, keyHolder);
        exhibit.setId(keyHolder.getKey().longValue());
    	
    	if(null != exhibit.getColumns()) {
        	List<ExhibitColumn> exhibitColumnList = exhibit.getColumns();
        	for (ExhibitColumn exhibitColumn : exhibitColumnList) {
        		params = new MapSqlParameterSource()
        	        .addValue("exhibit_id", exhibit.getId())
        	        .addValue("column_name", exhibitColumn.getColumnName())
        	        .addValue("column_index", exhibitColumn.getColumnIndex())
        	        .addValue("column_style", exhibitColumn.getColumnStyle())
        	        .addValue("created_by", exhibitColumn.getCreatedBy())
        	        .addValue("modified_by", exhibitColumn.getModifiedBy());
        		keyHolder = new GeneratedKeyHolder();
                namedParameterJdbcTemplate.update(SAVE_EXHIBIT_COL, params, keyHolder);
                exhibitColumn.setId(keyHolder.getKey().longValue());
    		}
        }
    	exhibit = getExhibitById(exhibit.getId());
    	return exhibit;
	}

	@Override
	public Exhibit updateExhibit(Exhibit exhibit) {
		MapSqlParameterSource params = new MapSqlParameterSource()
    		.addValue("id", exhibit.getAmendmentId())
    	    .addValue("text_content", exhibit.getTextContent().getBytes())
    	    .addValue("html_content", exhibit.getHtmlContent().getBytes())
    	    .addValue("modified_by", exhibit.getModifiedBy());
    	
        namedParameterJdbcTemplate.update(UPDATE_EXHIBIT, params);
    	
    	if(null != exhibit.getColumns()) {
        	List<ExhibitColumn> exhibitColumnList = exhibit.getColumns();
        	for (ExhibitColumn exhibitColumn : exhibitColumnList) {
        		params = new MapSqlParameterSource()
        	        .addValue("column_name", exhibitColumn.getColumnName())
        	        .addValue("column_index", exhibitColumn.getColumnIndex())
        	        .addValue("column_style", exhibitColumn.getColumnStyle())
        	        .addValue("modified_by", exhibitColumn.getModifiedBy());
        		if(null != exhibitColumn.getId() && exhibitColumn.getId() > 0) {
        			params.addValue("id", exhibitColumn.getId())
        					.addValue("deleted", exhibitColumn.getDeleted());
        			namedParameterJdbcTemplate.update(UPDATE_EXHIBIT_COL, params);
        		} else {
        			params.addValue("exhibit_id", exhibit.getId())
        					.addValue("created_by", exhibitColumn.getCreatedBy());
        			namedParameterJdbcTemplate.update(SAVE_EXHIBIT_COL, params);
        		}
    		}
        }
    	exhibit = getExhibitById(exhibit.getId());
    	return exhibit;
	}
	
	@Override
	public Exhibit getExhibitById(Long exhibitId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("exhibitId", exhibitId);
		Exhibit exhibit = namedParameterJdbcTemplate.query(GET_RFA_EXHIBIT, paramSource, new ExhibitResultSetExtractor());
		return exhibit;
	}
}
