package com.markit.ms.rfa.bean;

import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;

public class BulkValidationBean extends BulkActionBean {

	private BulkActionValidationType validationType;

	public BulkActionValidationType getValidationType() {
		return validationType;
	}

	public void setValidationType(BulkActionValidationType validationType) {
		this.validationType = validationType;
	}
}