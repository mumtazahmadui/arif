package com.markit.ms.rfa.batch.service.impl;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.batch.service.BulkUploadService;
import com.markit.ms.rfa.service.RFABulkRequestService;

@Service
public class BulkUploadServiceImpl implements BulkUploadService {

	private static final Logger logger = LoggerFactory.getLogger(BulkUploadServiceImpl.class);

	private static final int DEFAULT_MAX_THREAD_POOL_SIZE = 4;

	private static final ExecutorService executorService = Executors.newFixedThreadPool(DEFAULT_MAX_THREAD_POOL_SIZE);

	@Resource
	private RFABulkRequestService bulkRequestService;

	@Resource
	private QueryService<Integer> getThrottlingLevel;

	@Override
	public void validateThrottlingForAction(String bulkAction, int throttlingLevel, Long companyId)
			throws IllegalAccessException {
		if (throttlingLevel == 0) {
			return;
		}

		Map<String, Object> map = new HashMap<>();
		map.put("companyId", companyId);
		map.put("bulkAction", bulkAction);

		int companyThrottlingLevel = getThrottlingLevel.executeQuery(map);
		if (companyThrottlingLevel >= throttlingLevel) {
			throw new IllegalAccessException("Throttling level reached!!");
		}
	}

	// @Override
	// @Transactional(propagation = Propagation.NEVER)
	// public Long processRequest(SelectAllConfig config, List<BulkRequestParam>
	// requestParamList,
	// Map<Long, List<BulkRequestParam>> requestObjectParamMap, Long userId, Long
	// companyId) throws Exception {
	// validateThrottlingForAction(config.getActionName(),
	// config.getThrottlingLevel(), companyId);
	// long bulkRequestId = bulkRequestService.saveBulkRequest(config,
	// requestParamList, requestObjectParamMap, userId, companyId);
	//
	// process(bulkRequestId, userId, companyId, true, config.getConfigBeanName());
	// logger.info("Bulk request id: "+Long.toString(bulkRequestId));
	// return bulkRequestId;
	// }

	@Override
	public void process(final Long savedBulkRequestId, final Long userId, Long companyId, final String configBeanName,
			Long templateId, String ipAddress) {

		executorService.submit(new Runnable() {
			@Override
			public void run() {
				bulkRequestService.doProcess(savedBulkRequestId, userId, companyId, configBeanName, templateId,
						ipAddress);
			}
		});

	}
	
	@Override
	public void processSynchronous(Long savedBulkRequestId, Long userId, Long companyId, String configBeanName,
			Long templateId, String ipAddress) {
		bulkRequestService.doProcess(savedBulkRequestId, userId, companyId, configBeanName, templateId, ipAddress);
	}

}
