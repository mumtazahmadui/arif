/*
 * Author: Neeraj Kumar Nirala
 * Reader file to start batch job to read from Excel file
 * 
 */

package com.markit.ms.rfa.batch;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;

import com.markit.ms.common.service.IFileService;
import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.bean.RFAUploadTemplateFile;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.util.RFABulkUploadUtil;

public class BulkRFAUploadRequestItemReader implements ItemReader<RfaBulkUploadRow>{

	private static final Logger logger = LoggerFactory.getLogger(BulkRFAUploadRequestItemReader.class);

	private int index = 0;

	private Long bulkRequestId;

	private Long templateId;

	private Long batchId;

	private Long companyId;

	private String configBeanName;

	private List<RfaBulkUploadRow> bulkRfaBulkUploadRowList;
	
	private List<String> errorMessage = new ArrayList<>();
	


	private JobExecution jobExecution;
	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Autowired
	private IFileService fileService;

	@PostConstruct
	public void postContructMethod() {
		LinkedHashMap<String, RFAUploadTemplateField> identifierLabelMap = new LinkedHashMap<>();
		RFAUploadTemplate rfaUploadTemplate = uploadTemplateDAO.getUploadTemplateById(templateId);
		RFAUploadTemplateFile rfaUploadTemplateFile = uploadTemplateDAO.getUploadedFileId(bulkRequestId);
		identifierLabelMap = covertFieldLabelToIdentifier(rfaUploadTemplate.getTemplateFields(), identifierLabelMap);
		byte[] fileBytes = fileService.getFile(rfaUploadTemplateFile.getFileId(), companyId);
		bulkRfaBulkUploadRowList = RFABulkUploadUtil.readXLSXFile(fileBytes, identifierLabelMap, rfaUploadTemplateFile,
				rfaUploadTemplate,errorMessage);
	}

	private LinkedHashMap<String, RFAUploadTemplateField> covertFieldLabelToIdentifier(
			List<RFAUploadTemplateField> listOfUploadTemplateField,
			LinkedHashMap<String, RFAUploadTemplateField> identifierLabelMap) {
		for (RFAUploadTemplateField uploadTemplateField : listOfUploadTemplateField) {
			identifierLabelMap.put(uploadTemplateField.getFieldIdentifier(), uploadTemplateField);

		}
		
		return identifierLabelMap;
	}
	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		jobExecution = stepExecution.getJobExecution();
		jobExecution.getExecutionContext().put("errorMessage", errorMessage);
	}

	@Override
	public RfaBulkUploadRow read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		if ((null == bulkRfaBulkUploadRowList) || (index == bulkRfaBulkUploadRowList.size())) {
			return null;
		}
		return bulkRfaBulkUploadRowList.get(index++);
	}

	/* SPRING RELATED METHODS */
	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public void setConfigBeanName(String configBeanName) {
		this.configBeanName = configBeanName;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
}