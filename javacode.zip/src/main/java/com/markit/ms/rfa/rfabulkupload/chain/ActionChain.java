package com.markit.ms.rfa.rfabulkupload.chain;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;

public interface ActionChain {

	void setNextChain(ActionChain actionChain);
	
	void process(RfaBulkUploadRow rfaBulkUploadRow);
	
}
