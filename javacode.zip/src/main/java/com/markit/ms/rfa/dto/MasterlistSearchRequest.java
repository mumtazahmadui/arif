package com.markit.ms.rfa.dto;

import java.util.List;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseSearchRequest;
public class MasterlistSearchRequest extends CommonBaseSearchRequest{
	
	private List<String> masterAgreementDate;
	private List<Lookup> investmentManager;
	private List<Lookup> partyA;
	private List<String> masterlist_identifier;
	
	private List<Lookup> agreementType;

	public List<String> getMasterAgreementDate() {
		return masterAgreementDate;
	}
	public void setMasterAgreementDate(List<String> masterAgreementDate) {
		this.masterAgreementDate = masterAgreementDate;
	}
	public List<Lookup> getInvestmentManager() {
		return investmentManager;
	}
	public void setInvestmentManager(List<Lookup> investmentManager) {
		this.investmentManager = investmentManager;
	}
	public List<Lookup> getPartyA() {
		return partyA;
	}
	public void setPartyA(List<Lookup> partyA) {
		this.partyA = partyA;
	}
	public List<String> getMasterlist_identifier() {
		return masterlist_identifier;
	}
	public void setMasterlist_identifier(List<String> masterlist_identifier) {
		this.masterlist_identifier = masterlist_identifier;
	}
	public List<Lookup> getAgreementType() {
		return agreementType;
	}
	public void setAgreementType(List<Lookup> agreementType) {
		this.agreementType = agreementType;
	}

	
	
	
}
