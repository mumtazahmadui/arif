package com.markit.ms.rfa.service;

import java.util.List;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.dto.RfaUploadTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAUIException;

/**
 * @author sucheta.krishali
 *
 */
public interface IRfaUploadTemplateService {

	RFAUploadTemplate saveUploadTemplate(RFAUploadTemplate uploadTemplate) throws RFAUIException;
	void deleteUploadTemplateById(Long id) throws RFAException;
	RFAUploadTemplate getUploadTemplate(Long id);
	RFAUploadTemplate editUploadTemplate(RFAUploadTemplate uploadTemplate) throws RFAUIException ;
	public List<RFAUploadTemplate> getUploadTemplateGrid(Long companyId, RfaUploadTemplateSearchRequest templateSearchRequest);
	SXSSFWorkbook downloadUploadTemplate(Long templateId) throws Exception;


}
