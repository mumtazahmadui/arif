package com.markit.ms.rfa.dao;

import com.markit.ms.rfa.bean.RfaErrorFile;

public interface IRfaErrorFileDao {

	void create(RfaErrorFile rfaErrorFile);

	RfaErrorFile read(long id);
	
	public int deleteFile(long fileId,long companyId) ;
}