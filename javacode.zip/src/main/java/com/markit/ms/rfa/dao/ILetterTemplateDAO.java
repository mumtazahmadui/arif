package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.dto.TemplateSearchRequest;

public interface ILetterTemplateDAO
{
	LetterTemplate saveLetterTemplate(LetterTemplate letterTemplate);

	LetterTemplate updateLetterTemplate(LetterTemplate letterTemplate);

	LetterTemplate deleteLetterTemplate(Long id,Long companyId);

	List<LetterTemplate> getAllLetterTemplatesByCompanyId(Long companyId);

	List<LetterTemplate> getLetterTemplateGrid(Long companyId, TemplateSearchRequest letterTemplateSearchRequest);

	Long getLetterTemplateGridTotalCount(Long companyId, TemplateSearchRequest letterTemplateSearchRequest);

	LetterTemplate getLetterTemplateById(Long id, Long deleted,Long companyId);

	Long getLetterTemplateByName(Long companyId, String name);

	String getLetterTemplateNameById(Long letterTemplateId);
}
