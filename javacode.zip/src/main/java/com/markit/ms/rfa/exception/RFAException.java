package com.markit.ms.rfa.exception;


public class RFAException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String errorCode;
	public RFAException() {
		super();
	}

	public RFAException(String message, Throwable cause) {
		super(message + 
		        (cause == null?"":(" : " +cause.getMessage())), 
		            cause);
	}

	public RFAException(String message) {
		super(message);
	}
	
	public RFAException(String message , String errorCode) {
		super(message + "");
		this.errorCode = errorCode;
	}


	public RFAException(Throwable cause) {
		super(cause);
	}

	public String getErrorCode() {
		return errorCode;
	}
}
