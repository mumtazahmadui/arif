package com.markit.ms.rfa.bean;

import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;

public class RfaNotificationBean extends BulkNotificationBean {

	private long uploadId;

	public long getUploadId() {
		return uploadId;
	}

	public void setUploadId(long uploadId) {
		this.uploadId = uploadId;
	}

	


}