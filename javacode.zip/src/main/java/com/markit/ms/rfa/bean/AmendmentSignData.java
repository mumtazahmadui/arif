package com.markit.ms.rfa.bean;

import java.util.ArrayList;
import java.util.List;

public class AmendmentSignData {

	private Long id;
	private Integer eSignCount;
	private Integer wSignCount;
	private List<SignHoverData> eSignHoverData = new ArrayList<SignHoverData>();
	private List<SignHoverData> wSignHoverData = new ArrayList<SignHoverData>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer geteSignCount() {
		return eSignCount;
	}

	public void seteSignCount(Integer eSignCount) {
		this.eSignCount = eSignCount;
	}

	public Integer getwSignCount() {
		return wSignCount;
	}

	public void setwSignCount(Integer wSignCount) {
		this.wSignCount = wSignCount;
	}

	public List<SignHoverData> geteSignHoverData() {
		return eSignHoverData;
	}

	public void seteSignHoverData(List<SignHoverData> eSignHoverData) {
		this.eSignHoverData = eSignHoverData;
	}

	public List<SignHoverData> getwSignHoverData() {
		return wSignHoverData;
	}

	public void setwSignHoverData(List<SignHoverData> wSignHoverData) {
		this.wSignHoverData = wSignHoverData;
	}

	public static class SignHoverData {
		
		private String signatoryName;
		private String date;
		private String notifiedBy;
		public String getSignatoryName() {
			return signatoryName;
		}
		public void setSignatoryName(String signatoryName) {
			this.signatoryName = signatoryName;
		}
		public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public String getNotifiedBy() {
			return notifiedBy;
		}
		public void setNotifiedBy(String notifiedBy) {
			this.notifiedBy = notifiedBy;
		}
		
		
		
	}
}
