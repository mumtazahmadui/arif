package com.markit.ms.rfa.dao;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.bean.NewExhibitRequest;
import com.markit.ms.rfa.bean.PartyBEntity;

public interface INewExhibitDao {
	void updateExhibit(Long amendmentId, Long userId, Long exhibitId,
			NewExhibitRequest newExhibitRequest, boolean isBulkUpdate);
	public Long getExhibitColId(Long amendmentId, String columnName);
	public boolean validateExhibitData(Long rfaId, Set<Long> columnIdList, Set<Long> partybEntityIdList);
	public void createExhibit(Long masterAgreementId, Long amendmentId, List<PartyBEntity> partyBList, Long userId, Map<Long, Exhibit> rfaBulkUploadExhibit,String partytype);
	void updateExhibitSS(Long amendmentId, Long userId, Long exhibitId,NewExhibitRequest newExhibitRequest);
}
