package com.markit.ms.rfa.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class McpmEntityUpdate {
	@JsonIgnore
	private Long entityId;
	
	private String legalName;

	private String lei;

	private String monikerName;
	
	private String updatedBy;

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public String getLei() {
		return lei;
	}

	public void setLei(String lei) {
		this.lei = lei;
	}

	public String getMonikerName() {
		return monikerName;
	}

	public void setMonikerName(String monikerName) {
		this.monikerName = monikerName;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}	
}
