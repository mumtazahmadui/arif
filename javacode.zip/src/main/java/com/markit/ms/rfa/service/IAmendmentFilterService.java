package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.common.bean.Lookup;

public interface IAmendmentFilterService {

	public List<String> getAgreementDate(long companyid, String filterString);
	
	public List<Lookup> getInvestmentManager(long companyid, String filterString, String companyType);
	
	public List<String> getMasterlistIdentifier(Long companyId, String filterString, String companyType);
	
	public List<Lookup> getPartyA(long companyid, String filterString);
	
	public List<Lookup> getPartyB(long companyid, String filterString, String companyType);

	public List<String> getAdditionAction(String filterString);
	
	public List<String> getRequestStatus(String filterString);

	public List<String> getSellsideRequestStatus(String filterString);
	
	public List<Lookup> getReviewStatus(String filterString);
	
	public List<String> getPartyBClientIdentifier(long companyid, String filterString, String companyType);
	
	public List<String> getPartyBLei(Long companyId, String filterString, String companyType);
	
	public List<String>  getSubmitdate(long companyid, String filterString);

	public List<Long> getRfaId(Long companyId, String filterString, String companyType, String amendmentStatus);
	
	public List<String> getAgreementType(Long companyId, String filterString, String companyType);
	
	public List<Lookup> getMyStatus(String filterString, String companyType);
}
