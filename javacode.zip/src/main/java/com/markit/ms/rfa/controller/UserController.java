package com.markit.ms.rfa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.User;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.service.IUserService;
import com.wordnik.swagger.annotations.Api;

/*@RestController
@RequestMapping(value = "/v1/user")*/
@Api(value = "User" , description = "User API")
@Deprecated
public class UserController {

	@Autowired
	IUserService userService;
	
    @RequestMapping(value = "{id}",method = RequestMethod.GET)
    public CommonBaseResponse<User> getUser(@PathVariable long id){
    	CommonBaseResponse<User> commonBaseResponse = new CommonBaseResponse<User>();
    	User user = userService.getUser(id);
    	commonBaseResponse.setData(user);
    	return commonBaseResponse;
    }
	
	
}
