package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.ExhibitValueChange;
import com.markit.ms.rfa.bean.FundNameChange;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;
import com.markit.ms.rfa.util.CommonUtil;

public class AmendmentLetterResultSetExtractor implements ResultSetExtractor<AmendmentLetter> {

	private boolean hasContent = false;
	private AmendmentLetter amendmentLetter = null;
	public AmendmentLetterResultSetExtractor() {
		
	}
	
	public AmendmentLetterResultSetExtractor(boolean hasContent,AmendmentLetter amendmentLetter) {
		this.amendmentLetter = amendmentLetter;
		this.hasContent = hasContent;
	}

	@Override
	public AmendmentLetter extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		if(this.amendmentLetter == null) {
			this.amendmentLetter = populateAmendmentWithoutContent(rs);
		} 
		if(hasContent)
			amendmentLetter = populateAmendmentWithContent(amendmentLetter, rs);
		return amendmentLetter;
	}

	private AmendmentLetter populateAmendmentWithContent(
			AmendmentLetter amendmentLetter, ResultSet rs) throws SQLException {
		if(rs.next()){
			amendmentLetter.setContent(CommonUtil.getValueFromBase64(rs.getBytes("LETTER_CONTENT")));
			amendmentLetter.getExhibit().setTextContent(CommonUtil.getValueFromBase64(rs.getBytes("EXHIBIT_TEXT_CONTENT")));
			amendmentLetter.getExhibit().setHtmlContent(CommonUtil.getValueFromBase64(rs.getBytes("EXHIBIT_HTML_CONTENT")));
		}
		return amendmentLetter;
	}

	private AmendmentLetter populateAmendmentWithoutContent(ResultSet rs)
			throws SQLException {
		AmendmentLetter amendmentLetter = null;
		Map<Long,AmendmentLetter > amendmentLetterMap = new HashMap<Long ,AmendmentLetter>();
		Map<Long,PartyBEntity> partyBEntityMap = new LinkedHashMap<Long,PartyBEntity>();
		while (rs.next()){
			amendmentLetter = amendmentLetterMap.get(rs.getLong("amendmentId"));
			if(amendmentLetter == null){
				amendmentLetter = new AmendmentLetter();
				amendmentLetter.setId(rs.getLong("amendmentId"));
				amendmentLetter.setName(rs.getString("amendmentName"));
				amendmentLetter.setBsNextStep(rs.getString("bs_next_step"));
				amendmentLetter.setSsNextStep(rs.getString("ss_next_step"));
				amendmentLetter.setAmendmentStatus(AmendmentStatus.fromString(rs.getString("amendmentStatus")));
				amendmentLetter.setAmendmentStatusSS(AmendmentStatus.fromString(rs.getString("amendmentStatus_SS")));
				amendmentLetter.setCreationFlow(rs.getString("creationFlow"));
			
				amendmentLetter.setLetterTemplateId(rs.getLong("letterTemplateId"));
				amendmentLetter.setExhibitTemplateId(rs.getLong("exhibitTemplateId"));
				amendmentLetter.setDeleted(rs.getLong("amendment_deleted"));
				MasterAgreement masterAgreement = new MasterAgreement();
				masterAgreement.setId(rs.getLong("masterAgreementId"));
				masterAgreement.setName(rs.getString("masterAgreementName"));
				masterAgreement.setAgreementDate(rs.getDate("masterAgreementDate"));
				masterAgreement.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
				masterAgreement.setDeleted(rs.getLong("ma_deleted"));
				
				Entity investmentManager = new Entity();
	            investmentManager.setId(rs.getLong("investmentManagerId"));
	            investmentManager.setName(rs.getString("investmentManagerName"));
	            investmentManager.setTrueLegalName(rs.getString("investmentManagerTrueLegalName"));
	            investmentManager.setClientIdentifier(rs.getString("investmentManagerCLI"));
	            investmentManager.setLei(rs.getString("investmentManagerLei"));
	            masterAgreement.setInvestmentManager(investmentManager);
	            
	            Entity partyACompany = new Entity();
	            partyACompany.setName(rs.getString("partyAName"));
	            partyACompany.setId(rs.getLong("partyACompId"));
	            partyACompany.setTrueLegalName(rs.getString("partyATrueLegalName"));
	            partyACompany.setClientIdentifier(rs.getString("partyACLI"));
	            partyACompany.setLei(rs.getString("partyALei"));
	            masterAgreement.setPartyA(partyACompany);
	            amendmentLetter.setMasterAgreement(masterAgreement);
	            
	            amendmentLetterMap.put(rs.getLong("amendmentId"), amendmentLetter);
	            amendmentLetter.setPartyBEntities(new ArrayList<PartyBEntity>());
	            
			}
			PartyBEntity partyB = new PartyBEntity();
			partyB.setId(rs.getLong("partybId"));
			Entity entity = new Entity();
			entity.setId(rs.getLong("entityId"));
			entity.setName(rs.getString("partyBName"));
			entity.setTrueLegalName(rs.getString("partyBTrueLegalName"));
			entity.setClientIdentifier(rs.getString("partyBCLI"));
			entity.setLei(rs.getString("partyBLei"));
			entity.setIsSleeve(rs.getLong("isSleeve"));
			partyB.setEntity(entity);
			partyB.setAcknowledgementStatus(PartyBAckStatus.fromString(rs.getString("partyBAckStatus")));
			partyB.setIsAdded(rs.getLong("isAdded")==1 ? true : false);
			partyB.setIsModified(rs.getLong("addedForModification")==1 ? true : false);
			partyB.setAmendmentId(rs.getLong("amendmentId"));
			partyB.setMasterAgreementId(rs.getLong("masterAgreementId"));
			partyB.setReason(rs.getString("reason"));
			partyB.setDeleted(rs.getLong("pb_deleted"));
			partyBEntityMap.put(partyB.getId(),partyB);
			populateExhibitValueChangeInPartyB(rs,partyB);
			populateFundNameChangeInPartyB(rs,partyB);
		}
		for(Long key : partyBEntityMap.keySet()) {
			amendmentLetter.getPartyBEntities().add(partyBEntityMap.get(key));
		}
	
		return amendmentLetter;
	}
	private void populateExhibitValueChangeInPartyB(ResultSet rs,
			PartyBEntity partyBEntity) throws SQLException {
		Long exhibitValueChangeId = rs.getLong("exhibitValueChangeId");
		if(null != exhibitValueChangeId && exhibitValueChangeId > 0) {
			ExhibitValueChange exhibitValueChange =  new ExhibitValueChange();
			exhibitValueChange.setId(exhibitValueChangeId);
			String exhibitValueChangeBSComment = rs.getString("exhibitValueChangeBSComment");
			exhibitValueChange.setComment(exhibitValueChangeBSComment);
			partyBEntity.setExhibitValueChange(exhibitValueChange);
		}
	}
	private void populateFundNameChangeInPartyB(ResultSet rs,
			PartyBEntity partyBEntity) throws SQLException {
		Long fundNameChangeId = rs.getLong("fundNameChangeId");
		if(null != fundNameChangeId && fundNameChangeId > 0) {
			FundNameChange fundNameChange =  new FundNameChange();
			fundNameChange.setId(fundNameChangeId);
			fundNameChange.setOldLei(rs.getString("fundNameChangeOldLEI"));
			fundNameChange.setCurrentLei(rs.getString("fundNameChangeCurrentLEI"));
			fundNameChange.setOldTrueLegalName(rs.getString("fundNameChangeOldTrueLegalName"));
			fundNameChange.setCurrentTrueLegalName(rs.getString("fundNameChangeCurrentTrueLegalName"));
			fundNameChange.setOldClientIdentifier(rs.getString("fundNameChangeOldClientIdentifier"));
			fundNameChange.setCurrentClientIdentifier(rs.getString("fundNameChangeCurrentClientIdentifier"));
			Integer fundNameChangeUpdateMCPMLEI = rs.getInt("fundNameChangeUpdateMCPMLEI");
			fundNameChange.setUpdateMcpmLei((fundNameChangeUpdateMCPMLEI !=null && fundNameChangeUpdateMCPMLEI == 1) ? true : false);
			Integer fundNameChangeUpdateMCPMLegalName = rs.getInt("fundNameChangeUpdateMCPMLegalName");
			fundNameChange.setUpdateMcpmLegalName((fundNameChangeUpdateMCPMLegalName != null && fundNameChangeUpdateMCPMLegalName == 1)? true : false);
			Integer fundNameChangeUpdateMCPMClientIdentifier = rs.getInt("fundNameChangeUpdateMCPMClientIdentifier");
			fundNameChange.setUpdateMcpmClientIdentifier((fundNameChangeUpdateMCPMClientIdentifier !=null && fundNameChangeUpdateMCPMClientIdentifier == 1)? true : false);
			fundNameChange.setComment(rs.getString("fundNameChangeComment"));
			partyBEntity.setFundNameChange(fundNameChange);
		}
	}
	
}
