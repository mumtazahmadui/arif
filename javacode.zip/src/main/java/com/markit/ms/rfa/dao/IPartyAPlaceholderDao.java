package com.markit.ms.rfa.dao;

import java.io.UnsupportedEncodingException;

import com.markit.ms.rfa.bean.PartyAPlaceHolder;

public interface IPartyAPlaceholderDao {
void updatePartyAPlaceholder(PartyAPlaceHolder partyAPlaceholder,
		Long amendmentId, Long userId) throws UnsupportedEncodingException;
}
