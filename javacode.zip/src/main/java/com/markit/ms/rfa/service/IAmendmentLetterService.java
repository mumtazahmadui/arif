package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.model.CommonFileResponse;
import com.markit.ms.rfa.bean.AmendmentContent;
import com.markit.ms.rfa.bean.AmendmentDownloadTransitionLog;
import com.markit.ms.rfa.bean.AmendmentHistory;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.BulkActionBean;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.ReviewData;
import com.markit.ms.rfa.dto.AmendmentLetterSearchRequest;
import com.markit.ms.rfa.dto.BulkEmailNotification;

public interface IAmendmentLetterService {

	public List<AmendmentLetter> bulkUpdateAmendmentLetter(Long companyId, String companyType, Long userId,
			List<AmendmentLetter> amendmentLetterList) throws Exception;

	public AmendmentLetter getAmendmentLetterById(Long amendmentLetterId, Long companyId);

	public List<AmendmentLetter> getAmendmentLetterGrid(Long companyId,
			AmendmentLetterSearchRequest commonBaseSearchRequest);

	public Long getAmendmentLetterGridTotalCount(Long companyId, AmendmentLetterSearchRequest commonBaseSearchRequest);

	public CommonFileResponse validateAmendmentLetters(Long companyId, List<AmendmentLetter> amendmentLetterList,
			Long userId) throws Exception;

	public Integer signAmendmentLetter(Long amendmentLetterId, Long companyId, Signature signatureInput,
			String loginName, Long loginTime, byte[] content) throws Exception;

	public Long bulkSignRFA(List<Signature> signataureList, final Long companyId, final long userId,
			final String loginName, Long loginTime) throws Exception;

	public AmendmentLetter recallAmendmentLetter(Long companyId, Long userId, Long amendmentLetterId) throws Exception;
	
	public void addTransitionLogs(Long userId, String ipAddress, Long amendmentLetterId, Long downloadId, String eventName,Long fileId,Long uploadedFileId,int noOfPages,String reason) throws Exception;

	public List<PartyBEntity> withdrawPartyB(Long companyId, String companyType, Long amendmentLetterId, Long userId,
			List<PartyBEntity> partyBList) throws Exception;

	public AmendmentLetter updateAmendmentLetter(Long companyId, String companyType, AmendmentLetter amendmentLetter,
			Long userId);

	public List<AmendmentHistory> history(Long id, Long companyId);

	public Long getSignFileId(Long amendment_id, Long companyId);

	public Long addReview(int reviewId, long userId, long amendmentId);

	public void deleteReview(long i, long userId, Long amendmentId);

	public void rejectAmendmentLetter(Long amendmentId, Long userId, Long companyId, String reason, String companyType)
			throws Exception;
	
	public void deleteAmendmentLetter(Long amendmentId, Long userId, String companyType) throws Exception;
	
	public void editRejectedAmendmentLetter(Long amendmentId, Long userId);

	public ReviewData getReview(Long reviewId, int i, Long amendmentId);

	public void updateContent(Long amendmentId, Long userId, AmendmentContent amendmentContent);

	public void sendRFA(Long amendmentId, Long userId, String companyType, Long companyId) throws Exception;

	public void sendBulkEmailNotification(BulkEmailNotification notificationObj, String companyType) throws Exception;

	public List<Long> getBulkNotificationRFA(Long companyId, String filterString, Long offset, Long pageSize);

	public List<AmendmentLetter> bulkSaveAmendmentLetters(Long companyId, String companyType, Long userId,
			List<AmendmentLetter> data, String ipAddress) throws Exception;

	public List<AmendmentLetter> saveAmendmentLetters(Long companyId, String companyType, Long userId,
			List<AmendmentLetter> data, String ipAddress) throws Exception;

	public void saveErrorMessage(String actionName, Long rfaId, String errorMessage, Long userId);

	public void saveChasers(BulkActionBean bulkActionBean);

	public void updateChasers(List<Long> rfaIds, Long userId);

	Long bulkSendRFA(List<Long> amendmentIds, Long userId, String companyType, Long companyId) throws Exception;

	public void saveBulkUploadFileTemplate(Long templateId, Long userId, Long fileId, Long bulkRequestId);

	public Long bulkUploadRFA(final Long userId, final String companyType, final Long companyId, Long fileId,
			Long templateId, String ipAddress) throws Exception;

	public long getBulkRFAUploadId(Long bulkRequestId);

	public void updateBulkUploadFileTemplate(Long fileId, Long bulkRequestId, String status);

	public boolean isEntityAlreadyPresent(Long partyBEntityId, Long masterAgreementId, Long amendmentId);

	public void updateBulkRequest(Long bulkRequestId, String bulkUploadStatusComplete);

	PartyBEntity isEntityExistingInAnotherRfa(Long entityId, Long masterAgreementId, Long amendmentId);

	public boolean isPartyBAlreadyPresent(Long partyBEntityId, Long masterAgreementId);

	PartyBEntity isEntityExistingInAnotherRfa(Long entityId, Long masterAgreementId, Long amendmentId, String callingSource);

	Long getUploadedFile(Long amendmentLetterId) throws Exception;

	AmendmentLetter getAmendmentLetterById(Long amendmentLetterId);

	public Long getNextAvailableDownloadId();

	public void addDownloadTransitionLogs(List<AmendmentDownloadTransitionLog> amendmentDownloadTransitionLogs);

	public void updatNotifiedByfor(List<Long> rfaIds, Long notifiedByUserId);

	public String getNextAvailableDocId(Long amendmentId);
	
	public void updateStatus(String status, Long amendmentId,String companyType);

}
