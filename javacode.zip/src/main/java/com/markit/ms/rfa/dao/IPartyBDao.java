package com.markit.ms.rfa.dao;

import java.util.List;
import java.util.Map;

import com.markit.ms.rfa.bean.PartyBEntity;

public interface IPartyBDao {
	public PartyBEntity withdrawPartyB(Long userId, PartyBEntity partyBEntity);
	public PartyBEntity getPartyBEntityById(Long id);
	public void copyPartyBEntitiesToSnap(Long amendmentId, Long userId);
	public Long getPartyBIdByLegalName(String legalName, Long amendmentId);
	public Long getPartyBIdByLegalNameAndClientId(String legalName, String clientId, Long amendmentId);
	public List<PartyBEntity> getSleevesInProgress(Long parentEntityId, Long masterAgreementId);
	public Long getPartyBIdFromMCPM(String fieldName, String fieldValue, Long companyId);
	List<Long> getPartyBFromAmendmentId(Long amendmentId);
	/**
	 * get party B details for selected amendments and partyBs
	 * @return
	 */
	List<Map<String, Object>> getPartyBDetailsForDeskNotification(List<Long> partyBAmendmentIds, String companyType);
	public List<Map<String, Object>> getAmendmentDetailsForDeskNotification(List<Long> amendmentIds);
	/**
	 * 
	 * @return
	 * list of BS or SS amendment status of partyB's based on company type
	 */
	List<String> getPartyBAmendmentStatus(List<Long> partyBIds, String companyType);
}