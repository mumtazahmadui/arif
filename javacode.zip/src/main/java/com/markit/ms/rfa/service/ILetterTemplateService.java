package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.dto.TemplateSearchRequest;

public interface ILetterTemplateService {

	LetterTemplate saveLetterTemplate(LetterTemplate letterTemplate);
	
	LetterTemplate updateLetterTemplate(LetterTemplate letterTemplate);
	
	LetterTemplate deleteLetterTemplate(Long id,Long companyId);
	
	List<LetterTemplate> getAllLetterTemplatesByCompanyId(Long companyId);

	List<LetterTemplate> getLetterTemplateGrid(Long companyId, TemplateSearchRequest letterTemplateSearchRequest);

	Long getLetterTemplateGridTotalCount(Long companyId, TemplateSearchRequest letterTemplateSearchRequest);
	
	LetterTemplate getLetterTemplateById(Long letterTemplateId,Long companyId);
	
	String getLetterTemplateNameById(Long letterTemplateId);
}
