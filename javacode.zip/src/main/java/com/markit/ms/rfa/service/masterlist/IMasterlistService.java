package com.markit.ms.rfa.service.masterlist;

import java.util.List;

import javax.activity.InvalidActivityException;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.dto.MasterlistSearchRequest;
import com.markit.ms.rfa.exception.RFAUIException;

public interface IMasterlistService {
	public List<Masterlist> getMasterlistGrid(Long companyId, MasterlistSearchRequest masterlistSearchRequest);
	public Long getMasterlistGridTotalCount(Long companyId, MasterlistSearchRequest masterlistSearchRequest);
	public SXSSFWorkbook downloadMasterlist(Long masterAgreementId) throws Exception;
	public SXSSFWorkbook downloadMcpmPartybMappingFile(Long masterAgreementId) throws Exception;
	public void deleteMasterlist(Long companyId, Long masterAgreementId) throws InvalidActivityException;
	public void updateAgreementType(Long companyId, Long masterAgreementId, Masterlist masterlist) throws RFAUIException;
}
