package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.util.CommonUtil;

public class LetterTemplateRowMapper implements RowMapper<LetterTemplate> {
	Boolean includeContent = false;
	
	public LetterTemplateRowMapper(Boolean includeContent){
		this.includeContent = includeContent;
	}
	public LetterTemplate mapRow(ResultSet rs, int rowNum) throws SQLException {
		LetterTemplate letterTemplate = new LetterTemplate();
		letterTemplate.setId(rs.getLong("id"));
		letterTemplate.setName(rs.getString("name"));
		letterTemplate.setCompanyId(rs.getLong("companyid"));
		if(this.includeContent){
			letterTemplate.setContent(CommonUtil.getValueFromBase64(rs.getBytes("content")));
		}
		letterTemplate.setIsActiveVersion(rs.getBoolean("is_active_version"));
		letterTemplate.setCreatedBy(rs.getLong("created_by"));
		letterTemplate.setModifiedBy(rs.getLong("modified_by"));
		letterTemplate.setCreatedByString(rs.getString("created_by_string"));
		letterTemplate.setModifiedByString(rs.getString("modified_by_string"));
		letterTemplate.setCreatedDate(rs.getDate("created_date"));
		letterTemplate.setModifiedDate(rs.getDate("modified_date"));
		letterTemplate.setDeleted(rs.getLong("deleted"));
		letterTemplate.setAgreed(rs.getInt("agreed"));
		return letterTemplate;
	}
}
