package com.markit.ms.rfa.rfabulkupload.command;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;

public interface ActionCommand {

	void execute(RfaBulkUploadRow rfaBulkUploadRow, ActionChain nextChain);
	
}
