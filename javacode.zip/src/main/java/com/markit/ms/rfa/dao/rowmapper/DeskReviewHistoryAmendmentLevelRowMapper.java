package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.dto.PartyBDeskReviewDetails;

public class DeskReviewHistoryAmendmentLevelRowMapper implements RowMapper<PartyBDeskReviewDetails>{

	@Override
	public PartyBDeskReviewDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		PartyBDeskReviewDetails data = new PartyBDeskReviewDetails();
		data.setDeskStatus(rs.getInt("isReviewed"));
		Date date = rs.getDate("actionedDate");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-YYYY");
		data.setActionDate(sdf.format(date));
		data.setActionedBy(rs.getString("actionedBy"));
		data.setTotalAuditCount(rs.getInt("totalCount"));
		return data;
	}

}
