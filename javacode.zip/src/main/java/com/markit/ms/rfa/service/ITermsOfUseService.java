package com.markit.ms.rfa.service;

public interface ITermsOfUseService {
public void saveTermsOfUse(byte[] fileBytes, String version, Long companyId, Long userId) throws Exception;
}
