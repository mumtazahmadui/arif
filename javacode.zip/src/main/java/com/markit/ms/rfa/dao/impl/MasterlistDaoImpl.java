package com.markit.ms.rfa.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.http.HttpResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.bean.MasterlistDownload;
import com.markit.ms.rfa.bean.MasterlistValidatorBean;
import com.markit.ms.rfa.bean.McpmMasterlistLegalNameMapper;
import com.markit.ms.rfa.dao.IMasterlistDao;
import com.markit.ms.rfa.dao.rowmapper.CompanyTypeRowMapper;
import com.markit.ms.rfa.dao.rowmapper.MasterlistActiveRemoveTabRowMapper;
import com.markit.ms.rfa.dao.rowmapper.MasterlistModifiedTabRowMapper;
import com.markit.ms.rfa.dao.rowmapper.MasterlistRowMapper;
import com.markit.ms.rfa.dao.rowmapper.MasterlistValidatorBeanRowMapper;
import com.markit.ms.rfa.dao.rowmapper.McpmMasterlistLegalNameRowMapper;
import com.markit.ms.rfa.dto.MasterlistSearchRequest;

import electric.servlet.HTTPError;

@Repository
public class MasterlistDaoImpl extends BaseDAOImpl implements IMasterlistDao {

    @Value("${GET_MASTERLIST_GRID}")
    private String GET_MASTERLIST_GRID;
    
    @Value("${GET_MASTERLIST_GRID_TOTAL_COUNT}")
    private String GET_MASTERLIST_GRID_TOTAL_COUNT;
    
    @Value("${GET_MASTERLIST_ACTIVE_REMOVE_TABS}")
    private String GET_MASTERLIST_ACTIVE_REMOVE_TABS;
    
    @Value("${GET_MASTERLIST_MODIFIED_TAB}")
    private String GET_MASTERLIST_MODIFIED_TAB;
    
    @Value("${GET_MASTERLIST_CONTROL_COLUMN}")
    private String GET_MASTERLIST_CONTROL_COLUMN;
    
    @Value("${GET_MASTERLIST_UPDATE_DATE}")
    private String GET_MASTERLIST_UPDATE_DATE;
    
    @Value("${GET_COMPANY_TYPE}")
    private String GET_COMPANY_TYPE;
    
    @Value("${GET_MCPM_MASTERLIST_LEGAL_NAME_MAPPING}")
    private String GET_MCPM_MASTERLIST_LEGAL_NAME_MAPPING;
    
    @Value("${GET_MASTERLIST}")
    private String GET_MASTERLIST;
    
    @Value("${DELETE_MASTERLIST}")
    private String DELETE_MASTERLIST;
    
    @Value("${UPDATE_MASTER_AGREEMENT_TYPE}")
    private String UPDATE_MASTER_AGREEMENT_TYPE;
    
    @Value("${GET_MASTER_AGREEMENT}")
    private String GET_MASTER_AGREEMENT;
    
    @Value("${GET_UNIQUE_MASTER_AGREEMENT}")
    private String GET_UNIQUE_MASTER_AGREEMENT;
    
    @Value("${UPDATE_MASTER_AGREEMENT_ML_TEMPLATE}")
    private String UPDATE_MASTER_AGREEMENT_ML_TEMPLATE;

	@Override
	public List<Masterlist> getMasterlistGrid(Long companyId, MasterlistSearchRequest masterlistSearchRequest) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("companyid", companyId);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, params, new CompanyTypeRowMapper());
		
		List<String> masterAgreementDateList = masterlistSearchRequest.getMasterAgreementDate();
    	List<Lookup> investmentManagerList = masterlistSearchRequest.getInvestmentManager();
    	List<Lookup> partyAList = masterlistSearchRequest.getPartyA();
    	List<String> masterlist_identifierList = masterlistSearchRequest.getMasterlist_identifier();
    	List<Lookup> agreementTypeList = masterlistSearchRequest.getAgreementType();
    	StringBuilder whereCondition = new StringBuilder();
    	
    	MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("offset", masterlistSearchRequest.getOffSet())
			.addValue("page_size", masterlistSearchRequest.getPageSize());
		
		if("SS".equalsIgnoreCase(companyType)) {
			whereCondition.append(" and e2.companyid=:companyid");
		} else {
			whereCondition.append(" and e1.companyid=:companyid");
		}
		
    	if(null != masterAgreementDateList && masterAgreementDateList.size() > 0) {
    		whereCondition.append(" and agreement_date in (:agreement_date)");
    		paramSource.addValue("agreement_date", masterAgreementDateList);
    	}
    	if(null != masterlist_identifierList && masterlist_identifierList.size() > 0) {
    		whereCondition.append(" and masterlist_identifier in (:masterlist_identifier)");
    		paramSource.addValue("masterlist_identifier", masterlist_identifierList);
    	}
    	if(null != investmentManagerList && investmentManagerList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : investmentManagerList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and e1.entityid in (:investment_manager)");
			paramSource.addValue("investment_manager", filteredIdList);
    	}
    	if(null != partyAList && partyAList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : partyAList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and e2.entityid in (:partyA)");
			paramSource.addValue("partyA", filteredIdList);
    	}
    	
 
       	if(null != agreementTypeList && agreementTypeList.size() > 0) {
       		
       		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : agreementTypeList) {
    			filteredIdList.add(lookup.getId());
			}
    	
       		whereCondition.append(" and rfv.id in (:agreementType)");
    		paramSource.addValue("agreementType", filteredIdList);
    	}
    	
    	String gridQuery = GET_MASTERLIST_GRID.replaceAll("whereCondition", whereCondition.toString());
    	
    	List<Masterlist> masterlists = namedParameterJdbcTemplate.query(
    			gridQuery, paramSource, new MasterlistRowMapper());
    	return masterlists;
	}

	@Override
	public Long getMasterlistGridTotalCount(Long companyId,
			MasterlistSearchRequest masterlistSearchRequest) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("companyid", companyId);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, params, new CompanyTypeRowMapper());
		
		List<String> masterAgreementDateList = masterlistSearchRequest.getMasterAgreementDate();
    	List<Lookup> investmentManagerList = masterlistSearchRequest.getInvestmentManager();
    	List<Lookup> partyAList = masterlistSearchRequest.getPartyA();
    	List<String> masterlist_identifierList = masterlistSearchRequest.getMasterlist_identifier();
    	List<Lookup> agreementTypeList = masterlistSearchRequest.getAgreementType();
    	StringBuilder whereCondition = new StringBuilder();
    	
    	MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", companyId);
    	
    	if("SS".equalsIgnoreCase(companyType)) {
			whereCondition.append(" and e2.companyid=:companyid");
		} else {
			whereCondition.append(" and e1.companyid=:companyid");
		}
    	
    	if(null != masterAgreementDateList && masterAgreementDateList.size() > 0) {
    		whereCondition.append(" and agreement_date in (:agreement_date)");
    		paramSource.addValue("agreement_date", masterAgreementDateList);
    	}
    	if(null != masterlist_identifierList && masterlist_identifierList.size() > 0) {
    		whereCondition.append(" and masterlist_identifier in (:masterlist_identifier)");
    		paramSource.addValue("masterlist_identifier", masterlist_identifierList);
    	}
    	if(null != investmentManagerList && investmentManagerList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : investmentManagerList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and e1.entityid in (:investment_manager)");
			paramSource.addValue("investment_manager", filteredIdList);
    	}
    	if(null != partyAList && partyAList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : partyAList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and e2.entityid in (:partyA)");
			paramSource.addValue("partyA", filteredIdList);
    	}

       	if(null != agreementTypeList && agreementTypeList.size() > 0) {
       		
       		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : agreementTypeList) {
    			filteredIdList.add(lookup.getId());
			}
    	
       		whereCondition.append(" and  ma.agreement_type_id in (:agreementType)");
    		paramSource.addValue("agreementType", filteredIdList);
    	}
    	
    	String countQuery = GET_MASTERLIST_GRID_TOTAL_COUNT.replaceAll("whereCondition", whereCondition.toString());
    	
    	Long totalCount = namedParameterJdbcTemplate.queryForObject(countQuery, paramSource, Long.class);
    	return totalCount;
    	
	}

	@Override
	public List<MasterlistDownload> getMasterlistActiveRemoveTabs(Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", masterAgreementId);
    	List<MasterlistDownload> activeRemoveTabMasterlist = namedParameterJdbcTemplate.query(
    			GET_MASTERLIST_ACTIVE_REMOVE_TABS, paramSource, new MasterlistActiveRemoveTabRowMapper());
    	return activeRemoveTabMasterlist;
	}

	@Override
	public List<MasterlistDownload> getMasterlistModifiedTab(Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", masterAgreementId);
    	List<MasterlistDownload> modifiedTabMasterlist = namedParameterJdbcTemplate.query(
    			GET_MASTERLIST_MODIFIED_TAB, paramSource, new MasterlistModifiedTabRowMapper());
    	return modifiedTabMasterlist;
	}
	
	@Override
	public String getMasterlistControlColumn(Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("master_agreement_id", masterAgreementId);
		String controlColumn = null;
		try{
			controlColumn = namedParameterJdbcTemplate.queryForObject(GET_MASTERLIST_CONTROL_COLUMN, paramSource, String.class);
		} catch(EmptyResultDataAccessException error){
			controlColumn = "";
		}
		return controlColumn;
	}
	
	@Override
	public Date getMasterlistUpdateDate(Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("master_agreement_id", masterAgreementId);
		Date masterlistUpdateDate = null;
		try{
			masterlistUpdateDate = namedParameterJdbcTemplate.queryForObject(GET_MASTERLIST_UPDATE_DATE, paramSource, Date.class);
		} catch(EmptyResultDataAccessException error){
			masterlistUpdateDate = null;
		}
		return masterlistUpdateDate;
	}

	@Override
	public List<McpmMasterlistLegalNameMapper> getMcpmMasterlistLegalNameMapping(Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", masterAgreementId);
    	List<McpmMasterlistLegalNameMapper> mcpmMasterlistLegalNameMappingList = namedParameterJdbcTemplate.query(
    			GET_MCPM_MASTERLIST_LEGAL_NAME_MAPPING, paramSource, new McpmMasterlistLegalNameRowMapper());
    	return mcpmMasterlistLegalNameMappingList;
	}
	
	@Override
	public List<Masterlist> getMasterlistWithoutRfa(Long companyId, Long masterAgreementId)
	{
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("companyId", companyId);
		paramSource.addValue("masterAgreementId", masterAgreementId);
		List<Masterlist> masterlists = null;
		try{
			masterlists = namedParameterJdbcTemplate.query(GET_MASTERLIST, paramSource, new MasterlistRowMapper());
		} catch(EmptyResultDataAccessException error){
			masterlists = null;
		}
		return masterlists;
	}
	
	@Override
	public void deleteMasterlist(Long masterAgreementId)
	{
		MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue("masterAgreementId", masterAgreementId);
		try{
			namedParameterJdbcTemplate.update(DELETE_MASTERLIST, paramSource);
		} catch(EmptyResultDataAccessException error){
			error.printStackTrace();
		}
	}
	
	@Override
	public void updateAgreementType(Long masterAgreementId, Long agreementTypeId)
	{
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("masterAgreementId", masterAgreementId);
		paramSource.addValue("agreementTypeId", agreementTypeId);
		try{
			namedParameterJdbcTemplate.update(UPDATE_MASTER_AGREEMENT_TYPE, paramSource);
			namedParameterJdbcTemplate.update(UPDATE_MASTER_AGREEMENT_ML_TEMPLATE, paramSource);
		} catch(Exception error){
			error.printStackTrace();
		}
	}
	
	@Override
	public MasterlistValidatorBean getMasterAgreementById(Long masterAgreementId)
	{
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("masterAgreementId", masterAgreementId);
		List<MasterlistValidatorBean> masterlists = null;
		try{
			masterlists = namedParameterJdbcTemplate.query(GET_MASTER_AGREEMENT, paramSource, new MasterlistValidatorBeanRowMapper());
			return masterlists.get(0); 
		} catch(EmptyResultDataAccessException error){
			return null;
		}
	}
	
	@Override
	public List<MasterlistValidatorBean> getUniqueMasterAgreement(MasterlistValidatorBean masterlist)
	{
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("imId", masterlist.getInvestmentManagerId());
		paramSource.addValue("partyaId", masterlist.getPartyAId());
		paramSource.addValue("agreementDate", masterlist.getMasterAgreementDate());
		paramSource.addValue("masterlistIdentifier", masterlist.getMasterlistIdentifier());
		paramSource.addValue("agreementTypeId", masterlist.getAgreementTypeId());
		List<MasterlistValidatorBean> masterlists = null;
		try{
			masterlists = namedParameterJdbcTemplate.query(GET_UNIQUE_MASTER_AGREEMENT, paramSource, new MasterlistValidatorBeanRowMapper());
		} catch(EmptyResultDataAccessException error){
			masterlists = null;
		}
		return masterlists;
	}
}

