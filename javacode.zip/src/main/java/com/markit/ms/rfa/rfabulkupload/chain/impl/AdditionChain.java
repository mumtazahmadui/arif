package com.markit.ms.rfa.rfabulkupload.chain.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.markit.ms.common.constants.SpringConstants;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.impl.AdditionCommand;
import com.markit.ms.rfa.rfabulkupload.command.impl.SleeveAdditionCommand;
import com.markit.ms.rfa.util.CommonUtil;

@Service
@Scope(SpringConstants.SPRING_SCOPE_PROTOTYPE)
public class AdditionChain implements ActionChain {

	private ActionChain chain;

	@Autowired
	AdditionCommand partyBAddition;

	@Autowired
	SleeveAdditionCommand sleeveAddition;

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Override
	public void setNextChain(ActionChain actionChain) {
		this.chain = actionChain;
	}

	@Override
	public void process(RfaBulkUploadRow rfaBulkUploadRow) {
		partyBAddition.execute(rfaBulkUploadRow, chain);

		if (!rfaBulkUploadRow.getPartyBExistsInAnotherRfa()) {
			sleeveAddition.execute(rfaBulkUploadRow, chain);
		}

		if (CommonUtil.isNotNull(this.chain)) {
			this.chain.process(rfaBulkUploadRow);
		}
	}

}
