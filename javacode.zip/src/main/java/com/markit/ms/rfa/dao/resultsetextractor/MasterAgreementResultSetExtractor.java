package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.MasterAgreement;

public class MasterAgreementResultSetExtractor implements ResultSetExtractor<MasterAgreement> {

	@Override
	public MasterAgreement extractData(ResultSet rs) throws SQLException, DataAccessException {
		
		MasterAgreement agreement = null;
		
		while (rs.next()){
			agreement = new MasterAgreement();

			agreement.setId(rs.getLong("id"));
			agreement.setAgreementDate(rs.getDate("agreement_date"));
			agreement.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
			agreement.setAgreementType(rs.getString("agreementType"));
			
			Entity partyA = new Entity();
			partyA.setId(rs.getLong("partyAEntityId"));
			partyA.setName(rs.getString("partyAName"));
			partyA.setTrueLegalName(rs.getString("partyALegalName"));
			partyA.setClientIdentifier(rs.getString("partyAClientIdentifier"));
			partyA.setLei(rs.getString("partyALeiName"));
			agreement.setPartyA(partyA);
			
			Entity investmentManager = new Entity();
			investmentManager.setId(rs.getLong("IMEntityId"));
			investmentManager.setName(rs.getString("IMName"));
			investmentManager.setTrueLegalName(rs.getString("IMLegalName"));
			investmentManager.setClientIdentifier(rs.getString("IMClientIdentifier"));
			investmentManager.setLei(rs.getString("IMLeiName"));
			agreement.setInvestmentManager(investmentManager);

		}
		return agreement;
	}

}
