package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.common.bean.Entity;

public class EntityRowMapper implements RowMapper<Entity> {

	@Override
	public Entity mapRow(ResultSet rs, int rowNum) throws SQLException {
		Entity entity = new Entity();
		entity.setId(rs.getLong("entity_id"));
		entity.setTrueLegalName(rs.getString("legal_name"));
		entity.setClientIdentifier(rs.getString("client_identifier"));
		entity.setLei(rs.getString("lei_name"));
		return entity;
	}
}
