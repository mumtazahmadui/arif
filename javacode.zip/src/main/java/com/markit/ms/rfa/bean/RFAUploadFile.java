package com.markit.ms.rfa.bean;

import com.markit.ms.rs.select.all.domain.BulkRequest;

public class RFAUploadFile {
	
	private String id;
	private String uploadBulkRequestId;

	private String uploadBy;
	private String uploadDate;
	private String uploadTemplateId;
	private String errorFileId;
	
	private String  originalFileId;
	private String bulkUploadStatus;
	private String rfaCountInitiated;
	
	private BulkRequest bulkRequest;
	
	
	//Added extra field to store count of total rows returned for UploadTemplate Grid Search
	private Integer totalRowCount;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUploadBulkRequestId() {
		return uploadBulkRequestId;
	}
	public void setUploadBulkRequestId(String uploadBulkRequestId) {
		this.uploadBulkRequestId = uploadBulkRequestId;
	}
	public String getUploadBy() {
		return uploadBy;
	}
	public void setUploadBy(String uploadBy) {
		this.uploadBy = uploadBy;
	}
	public String getUploadDate() {
		return uploadDate;
	}
	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}
	public String getUploadTemplateId() {
		return uploadTemplateId;
	}
	public void setUploadTemplateId(String uploadTemplateId) {
		this.uploadTemplateId = uploadTemplateId;
	}
	public String getErrorFileId() {
		return errorFileId;
	}
	public void setErrorFileId(String errorFileId) {
		this.errorFileId = errorFileId;
	}
	public BulkRequest getBulkRequest() {
		return bulkRequest;
	}
	public void setBulkRequest(BulkRequest bulkRequest) {
		this.bulkRequest = bulkRequest;
	}
	public Integer getTotalRowCount() {
		return totalRowCount;
	}
	public void setTotalRowCount(Integer totalRowCount) {
		this.totalRowCount = totalRowCount;
	}
	public String getBulkUploadStatus() {
		return bulkUploadStatus;
	}
	public void setBulkUploadStatus(String bulkUploadStatus) {
		this.bulkUploadStatus = bulkUploadStatus;
	}
	public String getOriginalFileId() {
		return originalFileId;
	}
	public void setOriginalFileId(String originalFileId) {
		this.originalFileId = originalFileId;
	}
	public String getRfaCountInitiated() {
		return rfaCountInitiated;
	}
	public void setRfaCountInitiated(String rfaCountInitiated) {
		this.rfaCountInitiated = rfaCountInitiated;
	}
	
	
	
	
	
			
}
