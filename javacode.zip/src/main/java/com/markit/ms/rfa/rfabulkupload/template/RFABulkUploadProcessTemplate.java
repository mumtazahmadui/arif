package com.markit.ms.rfa.rfabulkupload.template;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.batch.BulkRFAUploadRequestProcessedItemReader;
import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.rfabulkupload.util.ConflictingActionsValidator;
import com.markit.ms.rfa.rfabulkupload.util.ErrorGenerator;
import com.markit.ms.rfa.service.IEntityService;
import com.markit.ms.rfa.service.IExhibitTemplateService;
import com.markit.ms.rfa.service.IMasterAgreementService;
import com.markit.ms.rfa.service.IMasterlistFilterService;
import com.markit.ms.rfa.service.IRfaBulkUploadService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author prashant.aggarwal
 *
 */
@Component
public class RFABulkUploadProcessTemplate {

	@Autowired
	private IRfaBulkUploadService bulkUploadService;

	@Autowired
	private IExhibitTemplateService exhibitTemplateService;

	@Autowired
	IMasterAgreementService masterAgreementService;

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Autowired
	IEntityService entityService;

	@Autowired
	IMasterlistFilterService masterlistFilterService;

	@Autowired
	ConflictingActionsValidator conflictingActionsValidator;

	@Autowired
	CommonValidator commonValidator;

	private static final Logger logger = LoggerFactory.getLogger(RFABulkUploadProcessTemplate.class);

	private Map<Long, HashMap<Long, Set<BulkUploadAction>>> entityRequestedActionsPerAgreement = new HashMap<Long, HashMap<Long, Set<BulkUploadAction>>>();
	private List<String> monikarNameList = new ArrayList<String>();
	private List<Long> sleeveEntityIdList = new ArrayList<Long>();
	private List<Long> partyBEntityIdList = new ArrayList<Long>();
	private Set<RfaBulkUploadRow> rfaBulkUploadRowSet = new HashSet<RfaBulkUploadRow>();

	public void setRfaBulkUploadRowSet(Set<RfaBulkUploadRow> rfaBulkUploadRowSet) {
		this.rfaBulkUploadRowSet = rfaBulkUploadRowSet;
	}

	public void setMonikarNameList(List<String> monikarNameList) {
		this.monikarNameList = monikarNameList;
	}

	public List<Long> getSleeveEntityIdList() {
		return sleeveEntityIdList;
	}

	public List<Long> getPartyBEntityIdList() {
		return partyBEntityIdList;
	}

	public void setPartyBEntityIdList(List<Long> partyBEntityIdList) {
		this.partyBEntityIdList = partyBEntityIdList;
	}

	public void setSleeveEntityIdList(List<Long> sleeveEntityIdList) {
		this.sleeveEntityIdList = sleeveEntityIdList;
	}

	public void setEntityRequestedActionsPerAgreement(
			Map<Long, HashMap<Long, Set<BulkUploadAction>>> entityRequestedActionsPerAgreement) {
		this.entityRequestedActionsPerAgreement = entityRequestedActionsPerAgreement;
	}

	public final RfaBulkUploadRow rfaBulkUploadProcess(RfaBulkUploadRow rfaBulkUploadRow) {

		logger.info("Processing row number: " + rfaBulkUploadRow.getRowNum());
		try {
			if (!rfaBulkUploadRow.validateMandatoryFields())
				return rfaBulkUploadRow;

			validateData(rfaBulkUploadRow);

			if (CommonUtil.isNull(rfaBulkUploadRow.getAction()))
				return rfaBulkUploadRow;

			determineMLIdentifier(rfaBulkUploadRow);

			if (CommonUtil.isNull(rfaBulkUploadRow.getMasterAgreement()))
				return rfaBulkUploadRow;

			validateExhibitLinkageAndColumns(rfaBulkUploadRow);

			determineAction(rfaBulkUploadRow);
			if (CommonUtil.isNotNull(rfaBulkUploadRow.getPartyBExistsInAnotherRfa()) && rfaBulkUploadRow.getPartyBExistsInAnotherRfa())
				return rfaBulkUploadRow;

			if (rfaBulkUploadRow.getRequestIdentified().isEmpty())
				return rfaBulkUploadRow;

			determineLetterTemplate(rfaBulkUploadRow);

			if (rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.SLEEVE_ADDITION))
				checkDuplicateMonikarName(rfaBulkUploadRow);

			if (rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.SLEEVE_ADDITION)
					|| rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.ADDITION))
				checkSleeveAdditionConflict(rfaBulkUploadRow);

			if (CommonUtil.isNull(rfaBulkUploadRow.getLetterTemplate()))
				return rfaBulkUploadRow;

			checkPlaceholderExistsForAction(rfaBulkUploadRow);

			checkConflictingActions(rfaBulkUploadRow);

			rfaBulkUploadRowSet.add(rfaBulkUploadRow);

			logger.info("Validated row no. : " + rfaBulkUploadRow.getRowNum() /* + method() */);

		} catch (Exception e) {
			e.printStackTrace();
			rfaBulkUploadRow.addError(RFAConstants.EXCEPTION_CASE);
		}
		return rfaBulkUploadRow;
	}

	private void checkSleeveAdditionConflict(RfaBulkUploadRow rfaBulkUploadRow) {
		if (sleeveEntityIdList.contains(rfaBulkUploadRow.getPartyBEntityId())
				|| partyBEntityIdList.contains(rfaBulkUploadRow.getSleeveEntityId())) {
			commonValidator.populateConflictActionErrors(rfaBulkUploadRow, RFAConstants.RFA_UPLOAD_CONFLICTING_ACTION);
		} else {
			if (CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveEntityId()))
				sleeveEntityIdList.add(rfaBulkUploadRow.getSleeveEntityId());
			if (CommonUtil.isNotNull(rfaBulkUploadRow.getPartyBEntityId()))
				partyBEntityIdList.add(rfaBulkUploadRow.getPartyBEntityId());
		}
	}

	private void checkDuplicateMonikarName(RfaBulkUploadRow rfaBulkUploadRow) {
		String sleeveClientIdentifierName = null;
		String sleeveLabel = null;
		if (rfaBulkUploadRow.getUploadTemplateField(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD) != null
				&& rfaBulkUploadRow.getUploadTemplateField(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD)
						.getEntityIdentifier() == 1) {
			sleeveLabel = rfaBulkUploadRow.getUploadTemplateField(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD)
					.getFieldLabel();
			sleeveClientIdentifierName = rfaBulkUploadRow.getSleeveClientIdentifier();
		}

		if (monikarNameList.contains(sleeveClientIdentifierName)) {
			for (RfaBulkUploadRow rfaBulkUploadRow1 : rfaBulkUploadRowSet) {
				if (CommonUtil.isEqual(String.valueOf(rfaBulkUploadRow1.getSleeveClientIdentifier()),
						String.valueOf(rfaBulkUploadRow.getSleeveClientIdentifier()))
						&& CommonUtil.isNotEqual(String.valueOf(rfaBulkUploadRow1.getPartyBEntityId()),
								String.valueOf(rfaBulkUploadRow.getPartyBEntityId()))) {
					Map<String, String> placeHolderMap = new HashMap<String, String>();
					placeHolderMap.put("sleeveLabel", sleeveLabel);
					rfaBulkUploadRow.addError(RFAConstants.DUPLICATE_INFORMATION_PROVIDED_FOR_SLEEVE, placeHolderMap);
					break;
				}
			}

		} else
			monikarNameList.add(sleeveClientIdentifierName);
	}

	private void checkConflictingActions(RfaBulkUploadRow rfaBulkUploadRow) {

		if (entityRequestedActionsPerAgreement.containsKey(rfaBulkUploadRow.getMasterAgreementId())) {
			Map<Long, Set<BulkUploadAction>> processedEntityActionsMap = entityRequestedActionsPerAgreement
					.get(rfaBulkUploadRow.getMasterAgreementId());
			boolean hasConflictingAction = conflictingActionsValidator.hasConflictingActions(rfaBulkUploadRow,
					processedEntityActionsMap);
			if (!hasConflictingAction) {
					addEntityIdToActionsMap(rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getRequestIdentified(), processedEntityActionsMap);
			}
		} else {
			HashMap<Long, Set<BulkUploadAction>> entityActionsMap = new HashMap<Long, Set<BulkUploadAction>>();
			addEntityIdToActionsMap(rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getRequestIdentified(), entityActionsMap);
			entityRequestedActionsPerAgreement.put(rfaBulkUploadRow.getMasterAgreementId(), entityActionsMap);

		}
	}

	private void addEntityIdToActionsMap(Long entityId, Set<BulkUploadAction> requestedActions,
			Map<Long, Set<BulkUploadAction>> entityActionsMap) {
		if (entityActionsMap.containsKey(entityId)) {
			entityActionsMap.get(entityId).addAll(requestedActions);
		} else {
			Set<BulkUploadAction> actions = new HashSet<BulkUploadAction>();
			actions.addAll(requestedActions);
			entityActionsMap.put(entityId, actions);
		}
	}

	private void determineMLIdentifier(RfaBulkUploadRow rfaBulkUploadRow) {
		masterAgreementService.getMasterAgreement(rfaBulkUploadRow);
	}

	private void validateExhibitLinkageAndColumns(RfaBulkUploadRow rfaBulkUploadRow) {

		ExhibitTemplate exhibitTemplate = exhibitTemplateService.getExhibitTemplateByMasterAgreementId(
				rfaBulkUploadRow.getMasterAgreementId(), rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());

		rfaBulkUploadRow.setExhibitTemplate(exhibitTemplate);

		if (exhibitTemplate == null) {
			rfaBulkUploadRow.addError(RFAConstants.RFA_EXHIBIT_LINKAGE_DOESNT_EXIST);
		}
		rfaBulkUploadRow.validateExhibitColumns();
	}

	private void validateData(RfaBulkUploadRow rfaBulkUploadRow) {

		String actionRule = rfaBulkUploadRow.getRfaUploadTemplate().getRule(RFAConstants.PARTYB_ACTION);
		if (!BulkUploadAction.fromType(actionRule).equals(BulkUploadAction.BLANK))
			rfaBulkUploadRow.setAction(BulkUploadAction.fromType(actionRule));

		if (rfaBulkUploadRow.getAction() == null) {
			rfaBulkUploadRow.addError(RFAConstants.RFA_INVALID_ACTION);
		}

		rfaBulkUploadRow.validateDateFormat();
		rfaBulkUploadRow.validateAgreementType();
		validatePartyA(rfaBulkUploadRow);

		List<Lookup> agreementTypes = masterlistFilterService.agreementTypeLookup("");
		for (Lookup lookup : agreementTypes)
			if (lookup.getValue().equalsIgnoreCase(rfaBulkUploadRow.getAgreementType()))
				return;
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		placeHolderMap.put("fieldLabel", rfaBulkUploadRow.getRfaUploadTemplate().getFieldLabel(RFAConstants.AGREEMENT_TYPE));
		rfaBulkUploadRow.addError(RFAConstants.AGRREEMENT_TYPE_NOT_PRESENT, placeHolderMap);
	}

	private void validatePartyA(RfaBulkUploadRow rfaBulkUploadRow) {
		Entity entity = entityService.getPartyAEntity(rfaBulkUploadRow.getPartyATrueLegalName());
		if (CommonUtil.isNull(entity)) {
			Map<String, String> placeHolderMap = new HashMap<String, String>();
			placeHolderMap.put("fieldLabel", rfaBulkUploadRow.getRfaUploadTemplate().getFieldLabel(RFAConstants.PARTYA_TRUE_LEGAL_NAME_FIELD));
			rfaBulkUploadRow.addError(RFAConstants.PARTY_A_DOES_NOT_EXIST, placeHolderMap);
		} else {
			// setting partyATrueLegalName from ref table as we need this to set in key of
			// identifying master agreement from ref table
			if (rfaBulkUploadRow.getRfaUploadTemplate().getRule(RFAConstants.MASTERLIST_IDENTIFIER)
					.equalsIgnoreCase(RFAConstants.REF_TABLE)) {
				rfaBulkUploadRow.setPartyATrueLegalName(entity.getTrueLegalName());
			}
		}
	}

	private void determineAction(RfaBulkUploadRow rfaBulkUploadRow) {

		bulkUploadService.determineActionOnMl(rfaBulkUploadRow);
	}

	private void determineLetterTemplate(RfaBulkUploadRow rfaBulkUploadRow) {

		rfaBulkUploadRow = bulkUploadService.determineLetterTemplate(rfaBulkUploadRow);

	}

	private void checkPlaceholderExistsForAction(RfaBulkUploadRow rfaBulkUploadRow) {

		Map<BulkUploadAction, LetterTemplate> requestIdentifiedMap = rfaBulkUploadRow.getLetterTemplate();

		for (BulkUploadAction requestIdentified : requestIdentifiedMap.keySet()) {
			Map<String, String> placeHolderMap = new HashMap<String, String>();
			placeHolderMap.put("requestType", requestIdentified.getName());
			String errorMessage = ErrorGenerator.generate(RFAConstants.PLACEHOLDER_NOT_FOUND_IN_LETTER_TEMPLATE,
					placeHolderMap);
			rfaBulkUploadRow.checkPlaceholder(requestIdentified, requestIdentifiedMap.get(requestIdentified),
					errorMessage);
		}

	}

}
