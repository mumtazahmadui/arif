package com.markit.ms.rfa.service;

import java.util.List;

public interface IRfaFileService {
	
	public void saveRfaFile(Long fileId, String action, Long userId);

	public void saveRfaFileToAmendment(Long fileId, List<Long> rfaIds);

	public List<Long> getRfaIdByFileId(Long fileId);
}
