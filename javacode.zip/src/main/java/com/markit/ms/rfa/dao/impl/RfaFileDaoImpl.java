package com.markit.ms.rfa.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.dao.IRfaFileDao;

@Repository
public class RfaFileDaoImpl extends BaseDAOImpl implements IRfaFileDao {
	
	@Value("${SAVE_RFA_FILE}")
	private String SAVE_RFA_FILE;
	
	@Value("${SAVE_RFA_FILE_TO_AMENDMENT}")
	private String SAVE_RFA_FILE_TO_AMENDMENT;
	
	@Value("${GET_RFA_ID_BY_FILE_ID}")
	private String GET_RFA_ID_BY_FILE_ID;

	@Override
	public void saveRfaFile(Long fileId, String action, Long userId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
	    	.addValue("fileId", fileId)
	    	.addValue("action", action)
	    	.addValue("userId", userId);
		namedParameterJdbcTemplate.update(SAVE_RFA_FILE, params);
	}

	@Override
	public void saveRfaFileToAmendment(Long fileId, Long rfaId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
	    	.addValue("fileId", fileId)
	    	.addValue("rfaId", rfaId);
		namedParameterJdbcTemplate.update(SAVE_RFA_FILE_TO_AMENDMENT, params);
	}

	@Override
	public List<Long> getRfaIdByFileId(Long fileId) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("fileId", fileId);
		List<Long> rfaIdList = namedParameterJdbcTemplate.queryForList(GET_RFA_ID_BY_FILE_ID, params, Long.class);
		return rfaIdList;
	}
}
