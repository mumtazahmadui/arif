package com.markit.ms.rfa.dao;

import java.util.List;
import com.markit.ms.common.bean.Lookup;


/**
 * @author prashant.aggarwal
 *
 */
public interface IMasterlistFilterDAO
{
	public List<String> agreementDateLookup(Long id, String filterString);
	public List<Lookup> investmentManagerLookup(Long id, String filterString);
	public List<Lookup> partyALookup(Long id, String filterString);
	public List<String> masterlistIdentifierLookup(Long id, String filterString);
	public List<Lookup> agreementTypeLookup(String filterString);
}
