package com.markit.ms.rfa.bean;

public class ExistingPartyB {

	private Long id;
	private Boolean belongsToPlaceholderAmendment;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Boolean getBelongsToPlaceholderAmendment() {
		return belongsToPlaceholderAmendment;
	}
	public void setBelongsToPlaceholderAmendment(
			Boolean belongsToPlaceholderAmendment) {
		this.belongsToPlaceholderAmendment = belongsToPlaceholderAmendment;
	}
}
