package com.markit.ms.rfa.bean;

import java.util.Map;

import org.joda.time.DateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;
/***
 * Holds the status details for each desk of amendment letter partyB.
 * <p>
 * Table (RFA_PARTYB_DESK_STATUS)
 * </p>
 * 
 * @since RFA5.0
 */
public class PartyBDeskReviewStatus {
	
	@JsonIgnore
	private Long id;
	@JsonIgnore
	private Long partyBId;
	@JsonIgnore
	private Long createdBy;
	@JsonIgnore
	private DateTime createdDate;
	@JsonIgnore
	private Long modifiedBy;
	@JsonIgnore
	private DateTime modifiedDate;
	private int onboardingEscalation;
	private int onboardingNotified;
	private int onboardingInProgress;
	private int onboardingCompleted;
	private int kycEscalation;
	private int kycNotified;
	private int kycInProgress;
	private int kycCompleted;
	private int taxEscalation;
	private int taxNotified;
	private int taxInProgress;
	private int taxCompleted;
	private int creditEscalation;
	private int creditNotified;
	private int creditInProgress;
	private int creditCompleted;
	private int legalEscalation;
	private int legalNotified;
	private int legalInProgress;
	private int legalCompleted;
	private int operationsEscalation;
	private int operationsNotified;
	private int operationsInProgress;
	private int operationsCompleted;
	private int managerEscalation;
	private int managerNotified;
	private int managerInProgress;
	private int managerCompleted;
	private int deskOneStatus;
	private int deskTwoStatus;
	private Map<String,String> bsCPDeskStatus;
	
	public int getDeskOneStatus() {
		return deskOneStatus;
	}
	public void setDeskOneStatus(int deskOneStatus) {
		this.deskOneStatus = deskOneStatus;
	}
	public int getDeskTwoStatus() {
		return deskTwoStatus;
	}
	public void setDeskTwoStatus(int deskTwoStatus) {
		this.deskTwoStatus = deskTwoStatus;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public DateTime getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public DateTime getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(DateTime modifiedDate) {
		this.modifiedDate = modifiedDate;
	}	
	public Long getPartyBId() {
		return partyBId;
	}
	public void setPartyBId(Long partyBId) {
		this.partyBId = partyBId;
	}
	public int getOnboardingEscalation() {
		return onboardingEscalation;
	}
	public void setOnboardingEscalation(int onboardingEscalation) {
		this.onboardingEscalation = onboardingEscalation;
	}
	public int getOnboardingNotified() {
		return onboardingNotified;
	}
	public void setOnboardingNotified(int onboardingNotified) {
		this.onboardingNotified = onboardingNotified;
	}
	public int getOnboardingInProgress() {
		return onboardingInProgress;
	}
	public void setOnboardingInProgress(int onboardingInProgress) {
		this.onboardingInProgress = onboardingInProgress;
	}
	public int getOnboardingCompleted() {
		return onboardingCompleted;
	}
	public void setOnboardingCompleted(int onboardingCompleted) {
		this.onboardingCompleted = onboardingCompleted;
	}
	public int getKycEscalation() {
		return kycEscalation;
	}
	public void setKycEscalation(int kycEscalation) {
		this.kycEscalation = kycEscalation;
	}
	public int getKycNotified() {
		return kycNotified;
	}
	public void setKycNotified(int kycNotified) {
		this.kycNotified = kycNotified;
	}
	public int getKycInProgress() {
		return kycInProgress;
	}
	public void setKycInProgress(int kycInProgress) {
		this.kycInProgress = kycInProgress;
	}
	public int getKycCompleted() {
		return kycCompleted;
	}
	public void setKycCompleted(int kycCompleted) {
		this.kycCompleted = kycCompleted;
	}
	public int getTaxEscalation() {
		return taxEscalation;
	}
	public void setTaxEscalation(int taxEscalation) {
		this.taxEscalation = taxEscalation;
	}
	public int getTaxNotified() {
		return taxNotified;
	}
	public void setTaxNotified(int taxNotified) {
		this.taxNotified = taxNotified;
	}
	public int getTaxInProgress() {
		return taxInProgress;
	}
	public void setTaxInProgress(int taxInProgress) {
		this.taxInProgress = taxInProgress;
	}
	public int getTaxCompleted() {
		return taxCompleted;
	}
	public void setTaxCompleted(int taxCompleted) {
		this.taxCompleted = taxCompleted;
	}
	public int getCreditEscalation() {
		return creditEscalation;
	}
	public void setCreditEscalation(int creditEscalation) {
		this.creditEscalation = creditEscalation;
	}
	public int getCreditNotified() {
		return creditNotified;
	}
	public void setCreditNotified(int creditNotified) {
		this.creditNotified = creditNotified;
	}
	public int getCreditInProgress() {
		return creditInProgress;
	}
	public void setCreditInProgress(int creditInProgress) {
		this.creditInProgress = creditInProgress;
	}
	public int getCreditCompleted() {
		return creditCompleted;
	}
	public void setCreditCompleted(int creditCompleted) {
		this.creditCompleted = creditCompleted;
	}
	public int getLegalEscalation() {
		return legalEscalation;
	}
	public void setLegalEscalation(int legalEscalation) {
		this.legalEscalation = legalEscalation;
	}
	public int getLegalNotified() {
		return legalNotified;
	}
	public void setLegalNotified(int legalNotified) {
		this.legalNotified = legalNotified;
	}
	public int getLegalInProgress() {
		return legalInProgress;
	}
	public void setLegalInProgress(int legalInProgress) {
		this.legalInProgress = legalInProgress;
	}
	public int getLegalCompleted() {
		return legalCompleted;
	}
	public void setLegalCompleted(int legalCompleted) {
		this.legalCompleted = legalCompleted;
	}
	public int getOperationsEscalation() {
		return operationsEscalation;
	}
	public void setOperationsEscalation(int operationsEscalation) {
		this.operationsEscalation = operationsEscalation;
	}
	public int getOperationsNotified() {
		return operationsNotified;
	}
	public void setOperationsNotified(int operationsNotified) {
		this.operationsNotified = operationsNotified;
	}
	public int getOperationsInProgress() {
		return operationsInProgress;
	}
	public void setOperationsInProgress(int operationsInProgress) {
		this.operationsInProgress = operationsInProgress;
	}
	public int getOperationsCompleted() {
		return operationsCompleted;
	}
	public void setOperationsCompleted(int operationsCompleted) {
		this.operationsCompleted = operationsCompleted;
	}
	public int getManagerEscalation() {
		return managerEscalation;
	}
	public void setManagerEscalation(int managerEscalation) {
		this.managerEscalation = managerEscalation;
	}
	public int getManagerNotified() {
		return managerNotified;
	}
	public void setManagerNotified(int managerNotified) {
		this.managerNotified = managerNotified;
	}
	public int getManagerInProgress() {
		return managerInProgress;
	}
	public void setManagerInProgress(int managerInProgress) {
		this.managerInProgress = managerInProgress;
	}
	public int getManagerCompleted() {
		return managerCompleted;
	}
	public void setManagerCompleted(int managerCompleted) {
		this.managerCompleted = managerCompleted;
	}
	public Map<String,String> getBsCPDeskStatus() {
		return bsCPDeskStatus;
	}
	public void setBsCPDeskStatus(Map<String,String> bsCPDeskStatus) {
		this.bsCPDeskStatus = bsCPDeskStatus;
	}
	
	
}
