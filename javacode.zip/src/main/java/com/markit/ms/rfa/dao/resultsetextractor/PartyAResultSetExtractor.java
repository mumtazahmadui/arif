package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;

public class PartyAResultSetExtractor implements ResultSetExtractor<List<Entity>> {

	@Override
	public List<Entity> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Map<Long, Entity> entityMap = new HashMap<Long, Entity>();
		while(rs.next()){
			Entity entity = entityMap.get(rs.getLong("entityid"));
			if (entity == null){
				entity = new Entity();
				entity.setName(rs.getString("name"));
				entity.setId(rs.getLong("entityid"));
				entityMap.put(rs.getLong("entityid"), entity);
			}
		}
		List<Entity> entityList = new ArrayList<Entity>(entityMap.values());
		return entityList;
	}
}
