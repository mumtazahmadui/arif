package com.markit.ms.rfa.rfabulkupload.command.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Component
public class SleeveRemoval {

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Autowired
	CommonValidator commonValidator;

	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	public void process(RfaBulkUploadRow rfaBulkUploadRow) {

		PartyBEntity existingSleeve = null;

		if (CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveEntityId())) {

			Boolean sleeveExistsInRFA = commonValidator.checkIfEntityExistingInAnotherRfa(rfaBulkUploadRow,
					rfaBulkUploadRow.getSleeveEntityId(), rfaBulkUploadRow.getMasterAgreementId(),
					true, null);

			if (sleeveExistsInRFA) {
				rfaBulkUploadRow.setPartyBExistsInAnotherRfa(sleeveExistsInRFA);
				return;
			}
			Boolean sleeveAlreadyPresentInML = commonValidator.checkIfEntityExistInMasterList(rfaBulkUploadRow,
					rfaBulkUploadRow.getSleeveEntityId(), rfaBulkUploadRow.getMasterAgreementId(),true);

			existingSleeve = amendmentLetterService.isEntityExistingInAnotherRfa(rfaBulkUploadRow.getSleeveEntityId(),
					rfaBulkUploadRow.getMasterAgreementId(), null);
			
			Boolean entityExistsInRemoveTab = commonValidator.checkIfEntityExistingInRemovalTab(rfaBulkUploadRow,
					rfaBulkUploadRow.getSleeveEntityId(), rfaBulkUploadRow.getMasterAgreementId());
			
			if(entityExistsInRemoveTab&& rfaBulkUploadRow.getRequestIdentified().size() == 0){
				populateSleeveRemovalErrors(rfaBulkUploadRow,RFAConstants.PARTYB_EXIST_IN_REMOVE_TAB_IN_MASTERLIST);
			} else if(!sleeveAlreadyPresentInML && rfaBulkUploadRow.getRequestIdentified().size() == 0 && !entityExistsInRemoveTab){
				populateSleeveRemovalErrors(rfaBulkUploadRow,RFAConstants.PARTYB_DOESNT_EXIST_IN_MASTERLIST);
			}

			Boolean validSleeveParentRelation = commonValidator.validateParentSleeveRelation(rfaBulkUploadRow.getSleeveEntityId(), 
					rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());
			
			if (!validSleeveParentRelation && sleeveAlreadyPresentInML) {
				populateSleeveTaggedToAnotherParentError(rfaBulkUploadRow);
			}
			
			// we need to ensure that sleeve added is not rejected from SS side
			if (validSleeveParentRelation && sleeveAlreadyPresentInML && CommonUtil.isNotNull(existingSleeve) && !entityExistsInRemoveTab
					&& CommonUtil.isNotNull(existingSleeve.getIsAdded())
					&& ((existingSleeve.getIsAdded()
							&& !existingSleeve.getAcknowledgementStatus().equals(PartyBAckStatus.REJECTED_SENT))
							|| (existingSleeve.getAcknowledgementStatus().equals(PartyBAckStatus.REJECTED_SENT)
									&& !existingSleeve.getIsAdded()))) {

				rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.SLEEVE_REMOVAL);

			}
		} else if (CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveClientIdentifier())
				&& CommonUtil.isNull(rfaBulkUploadRow.getSleeveEntityId())
				&& rfaBulkUploadRow.getRequestIdentified().size() == 0) {
			populateSleeveRemovalErrors(rfaBulkUploadRow, RFAConstants.PARTYB_DOESNT_EXIST_IN_MASTERLIST);
		}
	}
	
	private void populateSleeveRemovalErrors(RfaBulkUploadRow rfaBulkUploadRow,String errorMessage){
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
		placeHolderMap.put("requestType", "Removal");
		rfaBulkUploadRow.addError(errorMessage, placeHolderMap);
	}
	
	private void populateSleeveTaggedToAnotherParentError(RfaBulkUploadRow rfaBulkUploadRow) {
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		placeHolderMap.put("sleeveIdentifier", rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
		placeHolderMap.put("partybIdentifier", rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());			
		rfaBulkUploadRow.addError(RFAConstants.SLEEVE_TAGGED_TO_ANOTHER_PARENT, placeHolderMap);
	}	
}
