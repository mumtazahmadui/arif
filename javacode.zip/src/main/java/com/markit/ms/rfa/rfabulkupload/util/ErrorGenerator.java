package com.markit.ms.rfa.rfabulkupload.util;

import java.util.Map;

import org.apache.commons.lang.text.StrSubstitutor;

public class ErrorGenerator {

	public static String generate(String error, Map<String, String> placeHolderMap) {
		String errorMessgae = StrSubstitutor.replace(error, placeHolderMap);
		return errorMessgae;

	}	
	
}
