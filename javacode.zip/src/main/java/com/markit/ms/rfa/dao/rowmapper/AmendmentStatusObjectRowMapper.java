package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.AmendmentStatusObject;

public class AmendmentStatusObjectRowMapper implements RowMapper<AmendmentStatusObject> {

	@Override
	public AmendmentStatusObject mapRow(ResultSet rs, int rowNum) throws SQLException {
		AmendmentStatusObject amendmentStatusObject = new AmendmentStatusObject();
		amendmentStatusObject.setAmendmentStatus(rs.getString("amendment_status"));
		amendmentStatusObject.setRequestType(rs.getString("request_type"));
		return amendmentStatusObject;
	}
}
