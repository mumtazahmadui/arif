package com.markit.ms.rfa.service.impl;

import static com.markit.ms.rfa.util.RFAUtil.createBulkRequestParam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.beust.jcommander.internal.Lists;
import com.google.common.collect.Maps;
import com.markit.fileutil.common.domain.MCFile;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.domain.Grid.Row;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.esign.util.EsignDocUtil;
import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.bean.User;
import com.markit.ms.common.model.CommonFileResponse;
import com.markit.ms.common.service.ICompanyService;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.service.IHTMLParser;
import com.markit.ms.common.service.IPDFService;
import com.markit.ms.common.service.IRFAMailService;
import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.common.service.ISignatureService;
import com.markit.ms.common.service.IUserService;
import com.markit.ms.common.service.impl.HTMLParserImpl;
import com.markit.ms.rfa.batch.service.BulkUploadService;
import com.markit.ms.rfa.bean.AmendmentContent;
import com.markit.ms.rfa.bean.AmendmentDownloadTransitionLog;
import com.markit.ms.rfa.bean.AmendmentHistory;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.AmendmentSignData;
import com.markit.ms.rfa.bean.AmendmentStatusObject;
import com.markit.ms.rfa.bean.BulkActionBean;
import com.markit.ms.rfa.bean.BulkEmailVelocityTemplateValues;
import com.markit.ms.rfa.bean.BulkValidationBean;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.NextActions;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.ReviewData;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;
import com.markit.ms.rfa.command.validator.BulkActionValidationInvoker;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;
import com.markit.ms.rfa.dao.IDocumentVersionHistoryDao;
import com.markit.ms.rfa.dao.IPartyBDao;
import com.markit.ms.rfa.dto.AmendmentLetterSearchRequest;
import com.markit.ms.rfa.dto.BulkEmailNotification;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.service.IAmendmentLettterPDFService;
import com.markit.ms.rfa.service.IDeskReviewService;
import com.markit.ms.rfa.service.IEntityService;
import com.markit.ms.rfa.service.ILetterTemplateService;
import com.markit.ms.rfa.service.IMasterAgreementService;
import com.markit.ms.rfa.service.IMcsRedirectUrlGenerator;
import com.markit.ms.rfa.service.IPartyBPlaceholderService;
import com.markit.ms.rfa.service.IPartyBService;
import com.markit.ms.rfa.service.RFABulkRequestService;
import com.markit.ms.rfa.service.masterlist.IMasterlistService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.ConsolidateFileUtil;
import com.markit.ms.rfa.util.PDFContextGenerator;
import com.markit.ms.rfa.util.PDFUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.markit.ms.rs.select.all.domain.BulkRequestParam;
import com.markit.ms.rs.select.all.domain.BulkRequestParamEnum;
import com.markit.ms.rs.select.all.domain.SelectAllConfig;
import com.markit.ms.rs.select.all.repository.BulkRequestRepository;
import com.markit.ms.rs.select.all.service.annotation.SelectAllMethod;
import com.markit.ms.rs.select.all.service.annotation.SelectAllParam;
import com.markit.ms.rs.select.all.service.intf.SelectAllService;


@Service
public class AmendmentLetterServiceImpl implements IAmendmentLetterService {
	
	private static final Logger logger = LoggerFactory.getLogger(AmendmentLetterServiceImpl.class.getName());
	
	private static final String KEY_BULK_SEND_RFA = "BULK_SEND_RFA";
	
	private static final String KEY_BULK_SIGN_RFA = "BULK_SIGN_RFA";
	
	private static final String KEY_BULK_UPLOAD_RFA = "BULK_UPLOAD_RFA";
	
	private static final List<String> BS_GROUP = Collections.unmodifiableList(Arrays.asList(new String[] { "bs.rfa", "bs.rfa.signatory" }));

	private static final List<String> SS_GROUP = Collections.unmodifiableList(Arrays.asList(new String[] { "ss.rfa.read", "ss.rfa",
			"ss.rfa.signatory" }));
	private static final List<String> SS_ONBOARDING = Collections.unmodifiableList(Arrays.asList(new String[] { "ss.rfa.onboarding" }));
	
	@Autowired
	private IAmendmentLetterDao amendmentLetterDao;
	
	@Autowired
	private IMasterAgreementService masterAgreementService;
	
	@Autowired
	private IFileService fileService;
	
	@Autowired
	private IPDFService pdfService;
	
	@Autowired
	private ISignatureService signatureService;
	
	@Autowired
	private IAmendmentLettterPDFService amendmentLetterPDFService;
	
	@Autowired
	private IRFAMailService rfaMailService;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IPartyBService partyBService;
	
	@Autowired
	private IHTMLParser htmlParser;
	
	@Autowired
	private ICompanyService companyService;
	
	@Autowired
	private ILetterTemplateService letterTemplateService;
	
	
	@Resource
	private RFABulkRequestService bulkRequestService;
	
	@Resource
	private BulkUploadService bulkUploadService;
	
	@Resource
	private QueryService<String> getConfigProperty;
	
	@Autowired
	private IPartyBPlaceholderService iPartyBPlaceHolderService;
	
	@Autowired
	private IEntityService entityService;	
	
	@Resource
	private BulkRequestRepository bulkRequestRepository;
	
	@Resource(name="sellsideRejectsRfaEmail")
	private IMcsRedirectUrlGenerator sellsideRejectsRfaEmail;
	
	@Resource(name="buysideSendsRfaEmail")
	private IMcsRedirectUrlGenerator buysideSendsRfaEmail;
	
	@Resource(name="sellsideSendsRfa")
	private IMcsRedirectUrlGenerator sellsideSendsRfa;
	
	@Resource(name="buysideWithdrawsPartyB")
	private IMcsRedirectUrlGenerator buysideWithdrawsPartyB;
	
	@Resource(name="buysideRecallsRfaEmail")
	private IMcsRedirectUrlGenerator buysideRecallsRfaEmail;
	
	@Resource(name="sellsideSignatoryEsign")
	private IMcsRedirectUrlGenerator sellsideSignatoryEsign;
	
	@Resource
	private QueryService<Grid> getRejectRfaEmailDetails;
		
	@Resource
	private QueryService<Grid> getBuysideSendRfaDetails;
	
	@Resource
	private QueryService<Grid> getSellsideSendRfaDetails;
	
	@Resource
	private QueryService<Grid> getRecallRfaDetails;
	
	@Resource
	private QueryService<Grid> getWithdrawPartyBDetails;

	@Resource
	private QueryService<byte[]> selectAmendmentContent;

	@Resource
	private IReportGenerator reportGenerator;

	@Resource
	private IDocumentVersionHistoryDao documentVersionHistoryDao;

	@Resource
	private IPartyBDao partyBDao;

	@Autowired
	private IMasterlistService masterlistService;

	@Autowired
	private BulkActionValidationInvoker bulkValidationInvoker;

	@Autowired
	private SelectAllService selectAllService;

	@Resource
	private SelectAllConfig bulkSendRfaSelectAllConfig;
	
	@Resource
	private SelectAllConfig bulkSignRfaSelectAllConfig;
	
	@Resource
	private SelectAllConfig bulkUploadSelectAllConfig;
	
	@Autowired
	private BulkActionValidationInvoker bulkActionValidationInvoker;
	
	@Autowired
	IDeskReviewService reviewService;
	
	@Autowired
	ConsolidateFileUtil consolidateFileUtil;
	
	@PostConstruct
	public void postContructMethod() {
		Assert.notNull(bulkSendRfaSelectAllConfig);
		Assert.notNull(bulkSignRfaSelectAllConfig);
		Assert.notNull(bulkUploadSelectAllConfig);
		bulkSendRfaSelectAllConfig.setActionName(KEY_BULK_SEND_RFA);
		bulkSendRfaSelectAllConfig.setSelectAllActionBean(this);
		
		bulkSignRfaSelectAllConfig.setActionName(KEY_BULK_SIGN_RFA);
		bulkSignRfaSelectAllConfig.setSelectAllActionBean(this);
		
		bulkUploadSelectAllConfig.setActionName(KEY_BULK_UPLOAD_RFA);
		bulkUploadSelectAllConfig.setSelectAllActionBean(this);
	}
	
	@Override
	@Deprecated
	public AmendmentLetter getAmendmentLetterById(Long amendmentLetterId, Long companyId) {
		AmendmentLetter amendmentLetter = amendmentLetterDao.getAmendmentLetterById(amendmentLetterId, companyId);
		return amendmentLetter;
	}
	
	@Override
	public AmendmentLetter getAmendmentLetterById(Long amendmentLetterId) {
		AmendmentLetter amendmentLetter = amendmentLetterDao.getAmendmentLetterById(amendmentLetterId);
		return amendmentLetter;
	}	
	
	@Override
	@Transactional //check the transaction for multiple rows
	public List<AmendmentLetter> bulkSaveAmendmentLetters(Long companyId, String companyType
			, Long userId, List<AmendmentLetter> amendmentLetterList,String ipAddress) throws Exception {
		List<AmendmentLetter> returnedList = new ArrayList<AmendmentLetter>();
		//applyContentToAmendments(amendmentLetterList, companyId);
    	for (AmendmentLetter amendmentLetter : amendmentLetterList) {
    		//Long fileId = amendmentLetterPDFService.saveAmendmentLetterPDF(amendmentLetter, companyId, "amendmentLetter", userId);
    		//amendmentLetter.setFileId(fileId);
    		//amendmentLetter.setSignFileId(fileId);
    		String mlTemplateWithSleeve = masterAgreementService.getMlTemplateWithSleeve(amendmentLetter.getMasterAgreement().getId());
    		if(null != mlTemplateWithSleeve){
    			amendmentLetter.setMlTemplatename(mlTemplateWithSleeve);
    			if(!(mlTemplateWithSleeve.equalsIgnoreCase(RFAConstants.LEGACY_WITH_AGREEMENT_TYPE_WITH_SLEEVE)
    					|| mlTemplateWithSleeve.equalsIgnoreCase(RFAConstants.LEGACY_NO_AGREEMENT_TYPE_WITH_SLEEVE))){
    				amendmentLetter.setMlCompanyID(companyId);
    			}
    		} else {
	    		Boolean sleevePresentInAmendment = checkForSleeveInAmendment(amendmentLetter);
	    		String masterlistTemplateName = masterAgreementService.getMasterlistMlTemplateName(amendmentLetter.getMasterAgreement().getId());
	    		amendmentLetter.setMlTemplatename(getMlTemplateNameForAmendment(masterlistTemplateName, sleevePresentInAmendment));
    		}
    		amendmentLetter.setBsSignPlaceholderCount(htmlParser.getSignaturePlaceholderCount(amendmentLetter.getContent(), 1));
    		amendmentLetter.setSsSignPlaceholderCount(htmlParser.getSignaturePlaceholderCount(amendmentLetter.getContent(), 0));
    		java.sql.Date agreementDate = masterAgreementService.getMasterAgreementDateById(amendmentLetter.getMasterAgreement().getId());
    		AmendmentLetter amendmentLetterObj = amendmentLetterDao.saveAmendmentLetter(companyId, companyType, amendmentLetter, agreementDate, ipAddress);
    		returnedList.add(amendmentLetterObj);
    	}
    	return returnedList;
	}
	
	@Override
	public List<AmendmentLetter> saveAmendmentLetters(Long companyId, String companyType
			, Long userId, List<AmendmentLetter> amendmentLetterList,String ipAddress) throws Exception {
		List<AmendmentLetter> returnedList = new ArrayList<AmendmentLetter>();
		//applyContentToAmendments(amendmentLetterList, companyId);
		for (AmendmentLetter amendmentLetter : amendmentLetterList) {
			//Long fileId = amendmentLetterPDFService.saveAmendmentLetterPDF(amendmentLetter, companyId, "amendmentLetter", userId);
			//amendmentLetter.setFileId(fileId);
			//amendmentLetter.setSignFileId(fileId);
			String mlTemplateWithSleeve = masterAgreementService.getMlTemplateWithSleeve(amendmentLetter.getMasterAgreement().getId());
			if(null != mlTemplateWithSleeve){
				amendmentLetter.setMlTemplatename(mlTemplateWithSleeve);
				if(!(mlTemplateWithSleeve.equalsIgnoreCase(RFAConstants.LEGACY_WITH_AGREEMENT_TYPE_WITH_SLEEVE)
						|| mlTemplateWithSleeve.equalsIgnoreCase(RFAConstants.LEGACY_NO_AGREEMENT_TYPE_WITH_SLEEVE))){
					amendmentLetter.setMlCompanyID(companyId);
				}
			} else {
				Boolean sleevePresentInAmendment = checkForSleeveInAmendment(amendmentLetter);
				String masterlistTemplateName = masterAgreementService.getMasterlistMlTemplateName(amendmentLetter.getMasterAgreement().getId());
				amendmentLetter.setMlTemplatename(getMlTemplateNameForAmendment(masterlistTemplateName, sleevePresentInAmendment));
			}
			amendmentLetter.setBsSignPlaceholderCount(htmlParser.getSignaturePlaceholderCount(amendmentLetter.getContent(), 1));
			amendmentLetter.setSsSignPlaceholderCount(htmlParser.getSignaturePlaceholderCount(amendmentLetter.getContent(), 0));
			java.sql.Date agreementDate = masterAgreementService.getMasterAgreementDateById(amendmentLetter.getMasterAgreement().getId());
			AmendmentLetter amendmentLetterObj = amendmentLetterDao.saveAmendmentLetter(companyId, companyType, amendmentLetter, agreementDate, ipAddress);
			returnedList.add(amendmentLetterObj);
		}
		return returnedList;
	}

	@Override
	@Transactional
	public List<AmendmentLetter> bulkUpdateAmendmentLetter(Long companyId, String companyType
			, Long userId, List<AmendmentLetter> amendmentLetterList) throws Exception {
		List<AmendmentLetter> returnedList = new ArrayList<AmendmentLetter>();
    	for (AmendmentLetter amendmentLetter : amendmentLetterList) {	
    		amendmentLetter.setAmendmentStatus(getAmendmentStatus(amendmentLetter));
    		AmendmentLetter amendmentLetterObj = amendmentLetterDao.updateAmendmentLetter(companyId, companyType, amendmentLetter,userId);
    		returnedList.add(amendmentLetterObj);
    	}
    	return returnedList;
	}

	private AmendmentStatus getAmendmentStatus(AmendmentLetter newAmendmentLetter) {
		if(newAmendmentLetter.getAmendmentStatus() == AmendmentStatus.PARTIALLY_COMPLETED){
			AmendmentLetter oldAmendmentLetter = this.getAmendmentLetterById(newAmendmentLetter.getId());
			if(isPartyStatusChangedFromPending(newAmendmentLetter.getPartyBEntities(),oldAmendmentLetter.getPartyBEntities())) {
				return AmendmentStatus.PARTIALLY_COMPLETED;
			}
		}
		return newAmendmentLetter.getAmendmentStatus();
	}
	
	
	private void applyContentToAmendments(List<AmendmentLetter> amendmentLetterList, Long companyId){
		for (int i=0; i < amendmentLetterList.size(); i++){
			AmendmentLetter amendmentLetter = amendmentLetterList.get(i);
			amendmentLetterList.get(i).setContent(letterTemplateService.getLetterTemplateById(amendmentLetter.getLetterTemplateId(), companyId).getContent());
		}
	}
	
	private boolean isPartyStatusChangedFromPending(
			List<PartyBEntity> newPartyBEntities,
			List<PartyBEntity> oldPartyBEntities) {
		boolean result = false;
		Map<Long,PartyBEntity> oldPartyMap = new HashMap<Long,PartyBEntity>(); 
		for (PartyBEntity oldPartyB : oldPartyBEntities){
			oldPartyMap.put(oldPartyB.getId(), oldPartyB);
		}
		for(PartyBEntity newPartyB : newPartyBEntities) {
			PartyBEntity oldPartyBEntity = oldPartyMap.get(newPartyB.getId());
			if(oldPartyBEntity.getAcknowledgementStatus() == PartyBAckStatus.PENDING
					&& (newPartyB.getAcknowledgementStatus() == PartyBAckStatus.ACCEPTED
							||(newPartyB.getAcknowledgementStatus() == PartyBAckStatus.REJECTED && newPartyB.getReason() != null))) {
				result = true;
			}
		}
		return result;
	}

	@Override
	@Transactional
	public AmendmentLetter updateAmendmentLetter(Long companyId, String companyType, AmendmentLetter amendmentLetter, Long userId) {
    		return amendmentLetterDao.updateAmendmentLetter(companyId, companyType, amendmentLetter, userId);
	}

	@Override
	public List<AmendmentLetter> getAmendmentLetterGrid(Long companyId, AmendmentLetterSearchRequest amendmentLetterSearchRequest) {
		List<Long> amendmentIds = new ArrayList<Long>();
		List<AmendmentLetter> amendmentLetters = null;
		if(amendmentLetterSearchRequest.getCompanyType() == CompanyType.BS)
		{
			amendmentLetters = amendmentLetterDao.getBSAmendmentLetterGrid(companyId, amendmentLetterSearchRequest);
			/*if (amendmentLetterSearchRequest.getTask() != null && amendmentLetterSearchRequest.getTask().equalsIgnoreCase("Exhibit Completion")){
				amendmentLetters = removeInvalidExhibitCompletionLetters(amendmentLetters);
			}*/
			for(AmendmentLetter amendmentLetter : amendmentLetters){
				populateBSAmendmentActions(amendmentLetter);
				amendmentIds.add(amendmentLetter.getId());
			}
		}else{
			amendmentLetters = amendmentLetterDao.getSSAmendmentLetterGrid(companyId, amendmentLetterSearchRequest);
			for(AmendmentLetter amendmentLetter : amendmentLetters){
				populateSSAmendmentActions(amendmentLetter);
				amendmentIds.add(amendmentLetter.getId());
			}
		}
		if(amendmentIds.size()>0) {
			Map<Long, AmendmentSignData> signaturesCountData = amendmentLetterDao.getSignCountData(companyId, amendmentIds,amendmentLetterSearchRequest.getCompanyType().getName());
			Map<Long, AmendmentSignData> signaturesHoverData = amendmentLetterDao.getSignHoverData(companyId, amendmentIds,amendmentLetterSearchRequest.getCompanyType().getName());
			populateEsignWsignData(signaturesCountData, signaturesHoverData, amendmentLetters);
		}
		return amendmentLetters;
	}
	
	private void populateEsignWsignData(Map<Long, AmendmentSignData> signaturesCountData,
			Map<Long, AmendmentSignData> signaturesHoverData, List<AmendmentLetter> amendmentLetters) {
		
		for(AmendmentLetter amendmentLetter : amendmentLetters) {
			AmendmentSignData amendmentSignCountData = signaturesCountData.get(amendmentLetter.getId());
			if(null != amendmentSignCountData) {
				amendmentLetter.seteSigncount(amendmentSignCountData.geteSignCount() == null ? 0 : amendmentSignCountData.geteSignCount());
				amendmentLetter.setwSignCount(amendmentSignCountData.getwSignCount() == null ? 0 : amendmentSignCountData.getwSignCount());
			}
			AmendmentSignData amendmentSignHoverData = signaturesHoverData.get(amendmentLetter.getId());
			if(null != amendmentSignHoverData) {
				amendmentLetter.seteSignHoverMetadata(amendmentSignHoverData.geteSignHoverData());
				amendmentLetter.setwSignHoverMetadata(amendmentSignHoverData.getwSignHoverData());
			}
		}
	}

	@Override
	public Long getAmendmentLetterGridTotalCount(Long companyId, AmendmentLetterSearchRequest commonBaseSearchRequest) {
		if (CompanyType.BS == commonBaseSearchRequest.getCompanyType()) {
			return amendmentLetterDao.getBSAmendmentLetterGridTotalCount(companyId, commonBaseSearchRequest);
		} else {
			return amendmentLetterDao.getSSAmendmentLetterGridTotalCount(companyId, commonBaseSearchRequest);
		}
	}

	@Override
	public CommonFileResponse validateAmendmentLetters(Long companyId, List<AmendmentLetter> amendmentLetterList, Long userId) throws Exception {
		Map<String, List<PartyBEntity>> addPartyBErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<String, List<PartyBEntity>> removePartyBErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<String, List<PartyBEntity>> modifiedPartyBErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<String, List<PartyBEntity>> sleeveRequestedOnAnotherRfaErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<String, List<PartyBEntity>> sleeveRemovalPartyBErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<String, List<PartyBEntity>> sleeveParentNotOnActiveTabErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<String, List<PartyBEntity>> sleeveExistsOnActiveTabErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<String, List<PartyBEntity>> sleevesInProgressErrorMap = new HashMap<String, List<PartyBEntity>>();
		Map<Long, AmendmentLetter> additionPlaceholderErrorMap = new HashMap<Long, AmendmentLetter>();
		Map<Long, AmendmentLetter> removalPlaceholderErrorMap = new  HashMap<Long, AmendmentLetter>();
		Map<Long, AmendmentLetter> modificationPlaceholderErrorMap = new  HashMap<Long, AmendmentLetter>();
		Map<String, String> letterTemplateMap = new  HashMap<String, String>();
		List<PartyBEntity> rejectedRecalledPartybList = new ArrayList<PartyBEntity>();
		try {
		//applyContentToAmendments(amendmentLetterList, companyId);
		for (AmendmentLetter amendmentLetter : amendmentLetterList) {
			String letterTemplateName = letterTemplateService.getLetterTemplateNameById(amendmentLetter.getLetterTemplateId());
			List<PartyBEntity> partyBEntities = amendmentLetter.getPartyBEntities();
			List<Long> partyBEntityIds = new ArrayList<Long>();
			List<PartyBEntity> partyBToBeAdded = new ArrayList<PartyBEntity>();
			List<PartyBEntity> partyBToBeRemoved = new ArrayList<PartyBEntity>();
			List<PartyBEntity> partyBForFundNameChange = new ArrayList<PartyBEntity>();
			List<PartyBEntity> partyBForExhibitValueChange = new ArrayList<PartyBEntity>();
			
			for (PartyBEntity partyBEntity : partyBEntities) {
				Long entityId = partyBEntity.getEntity().getId();
				partyBEntityIds.add(partyBEntity.getEntity().getId());
				
				Long masterAgreementId = amendmentLetter.getMasterAgreement().getId();
				String masterlistTrueLegalName = masterAgreementService.getMasterlistTrueLegalName(entityId, masterAgreementId);
				MasterAgreement masterAgreement = amendmentLetter.getMasterAgreement();
				partyBEntity.getEntity().setMasterlistTrueLegalName(null != masterlistTrueLegalName ? masterlistTrueLegalName : "");
				partyBEntity.setMasterAgreement(masterAgreement);
				
				if(null != partyBEntity.getIsAdded() && partyBEntity.getIsAdded() && (null == partyBEntity.getIsModified() || !partyBEntity.getIsModified())) {
					partyBToBeAdded.add(partyBEntity);
				} else if(null != partyBEntity.getIsModified() && partyBEntity.getIsModified() && null != partyBEntity.getFundNameChange()) {
					partyBForFundNameChange.add(partyBEntity);
				} else if(null != partyBEntity.getIsModified() && partyBEntity.getIsModified() && null != partyBEntity.getExhibitValueChange()) {
					partyBForExhibitValueChange.add(partyBEntity);
				} else if(null != partyBEntity.getIsAdded() && !partyBEntity.getIsAdded()) {
					partyBToBeRemoved.add(partyBEntity);
				}
			}
			
			Boolean hasAdditionPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
			Boolean hasRemovalPlaceholder = HTMLParserImpl.hasPartyBRemovalPlaceholder(amendmentLetter);
			Boolean hasFundNameChangePlaceholder = HTMLParserImpl.hasPartyBFundNameChangePlaceholder(amendmentLetter);
			Boolean hasExhibitValueChangePlaceholder = HTMLParserImpl.hasPartyBExhibitValueChangePlaceholder(amendmentLetter);
			java.sql.Date agreementDate = masterAgreementService.getMasterAgreementDateById(amendmentLetter.getMasterAgreement().getId());
			amendmentLetter.getMasterAgreement().setAgreementDate(agreementDate);
			
			StringBuilder partyARelation = new StringBuilder().append(amendmentLetter.getMasterAgreement().getPartyA().getTrueLegalName());
			String formattedAgreementDate = CommonUtil.getDateForFormat(agreementDate, "dd-MMM-yyyy");
			partyARelation.append(" - ").append(formattedAgreementDate);
			if(null != amendmentLetter.getMasterAgreement().getMasterlistIdentifier()) {
				partyARelation.append(" - ").append(amendmentLetter.getMasterAgreement().getMasterlistIdentifier());
			}
			
			if (!partyBToBeAdded.isEmpty() && !hasAdditionPlaceholder) {
				additionPlaceholderErrorMap.put(amendmentLetter.getMasterAgreement().getId(), amendmentLetter);
			}
			if (!partyBToBeRemoved.isEmpty() && !hasRemovalPlaceholder) {
				removalPlaceholderErrorMap.put(amendmentLetter.getMasterAgreement().getId(), amendmentLetter);
			}
			if (!partyBForFundNameChange.isEmpty()&& !hasFundNameChangePlaceholder){
				modificationPlaceholderErrorMap.put(amendmentLetter.getMasterAgreement().getId(), amendmentLetter);
			}
			if (!partyBForExhibitValueChange.isEmpty()&& !hasExhibitValueChangePlaceholder){
				modificationPlaceholderErrorMap.put(amendmentLetter.getMasterAgreement().getId(), amendmentLetter);
			}
			if ((!partyBForFundNameChange.isEmpty() && !hasFundNameChangePlaceholder)
					|| (!partyBForExhibitValueChange.isEmpty()&& !hasExhibitValueChangePlaceholder)){
				letterTemplateMap.put(partyARelation.toString(), letterTemplateName);
			}
			
			Long masterAgreementId = amendmentLetter.getMasterAgreement().getId();
			List<PartyBEntity> existingPartyBList = masterAgreementService.getExistingPartyB(masterAgreementId, partyBEntityIds, amendmentLetter.getId());
			Map<Long,PartyBEntity> existingPartyBMap = createMapForExistingParties(existingPartyBList);
			List<PartyBEntity> addPartyBErrorList = addPartyBErrorMap.get(partyARelation.toString());
			List<PartyBEntity> removePartyBErrorList = removePartyBErrorMap.get(partyARelation.toString());
			List<PartyBEntity> modifiedPartyBErrorList = modifiedPartyBErrorMap.get(partyARelation.toString());
			List<PartyBEntity> removeSleevePartyBErrorList = sleeveRemovalPartyBErrorMap.get(partyARelation.toString());
			List<PartyBEntity> sleeveParentNotOnActiveTabErrorList = sleeveParentNotOnActiveTabErrorMap.get(partyARelation.toString());
			List<PartyBEntity> sleeveRequestedOnAnotherRfaErrorList = sleeveRequestedOnAnotherRfaErrorMap.get(partyARelation.toString());
			List<PartyBEntity> sleeveExistsOnActiveTabErrorList = sleeveExistsOnActiveTabErrorMap.get(partyARelation.toString());
			List<PartyBEntity> sleevesInProgressErrorList = sleevesInProgressErrorMap.get(partyARelation.toString());
			
			for (PartyBEntity partyB: partyBToBeAdded){
				if(partyB.getEntity().getIsSleeve() != null && partyB.getEntity().getIsSleeve() == 1) {
					if (partyB.getDeleted() != null && partyB.getDeleted() == 1) continue;
					Entity parentEntity = entityService.getParentEntity(partyB.getEntity().getId());
					Long parentEntityId = parentEntity.getId();
					boolean isParentEntityAlsoAdded = isParentEntityAlsoAdded(parentEntityId, partyBToBeAdded);
					boolean isParentEntityAlreadyPresent = isEntityAlreadyPresent(parentEntityId, masterAgreementId, amendmentLetter.getId());
					boolean isSleeveExistingInMasterlist = isSleeveExistingInMasterlist(partyB.getEntity().getId(), partyBToBeAdded, masterAgreementId);
					PartyBEntity sleeveExistingInAnotherRfa = isEntityExistingInAnotherRfa(partyB.getEntity().getId(), masterAgreementId, amendmentLetter.getId());
							
					if((!isParentEntityAlsoAdded && !isParentEntityAlreadyPresent)) {
						if(null == sleeveParentNotOnActiveTabErrorList) {
							sleeveParentNotOnActiveTabErrorList = new ArrayList<PartyBEntity>();
						}
						if (partyB.getEntity().getParentTrueLegalName() == null && parentEntity.getTrueLegalName() != null){	// For Edit RFA
							partyB.getEntity().setParentTrueLegalName(parentEntity.getTrueLegalName());
						}
						if (partyB.getEntity().getParentClientIdentifier() == null && parentEntity.getClientIdentifier() != null){  // For Edit RFA
							partyB.getEntity().setParentClientIdentifier(parentEntity.getClientIdentifier());
						}
						sleeveParentNotOnActiveTabErrorList.add(partyB);
						continue;
					}
					if(isSleeveExistingInMasterlist){
						if(null == sleeveExistsOnActiveTabErrorList){
							sleeveExistsOnActiveTabErrorList = new ArrayList<PartyBEntity>();
						}
						sleeveExistsOnActiveTabErrorList.add(partyB);
						continue;
					}
					if((sleeveExistingInAnotherRfa.getAmendmentId() != null) && (sleeveExistingInAnotherRfa.getAmendmentId() > 0)
							&& (sleeveExistingInAnotherRfa.getAcknowledgementStatus() != PartyBAckStatus.REJECTED_SENT)
							&& (sleeveExistingInAnotherRfa.getAcknowledgementStatus() != PartyBAckStatus.WITHDRAWN)
							&& (sleeveExistingInAnotherRfa.getAcknowledgementStatus() != PartyBAckStatus.ACCEPTED_SENT)){
						if(null == sleeveRequestedOnAnotherRfaErrorList){
							sleeveRequestedOnAnotherRfaErrorList = new ArrayList<PartyBEntity>();
						}
						sleeveRequestedOnAnotherRfaErrorList.add(sleeveExistingInAnotherRfa);
						continue;
					}
				}
				PartyBEntity existingPartyB = existingPartyBMap.get(partyB.getEntity().getId());

				if( existingPartyB != null){
					PartyBAckStatus ackStatus = existingPartyB.getAcknowledgementStatus();
					AmendmentStatus amendmentStatus = existingPartyB.getAmendmentStatus();
					Boolean isAdded = existingPartyB.getIsAdded();
					Boolean isModified = existingPartyB.getIsModified();
					if(!(null != ackStatus && !isAdded && !isModified && ackStatus == PartyBAckStatus.ACCEPTED_SENT)
							//&& !(null != ackStatus && isAdded && !isModified && ackStatus == PartyBAckStatus.REJECTED) 
							&& !(null != ackStatus && isAdded && !isModified && ackStatus == PartyBAckStatus.REJECTED_SENT) 
							&& !(null != ackStatus && isAdded && !isModified && ackStatus == PartyBAckStatus.WITHDRAWN)) {
						if(null != amendmentStatus && (amendmentStatus == AmendmentStatus.RECALLED || amendmentStatus == AmendmentStatus.REJECTED) && !isModified) {
							//existingPartyB.setRequestType("Addition");
							existingPartyB.setRequestType(masterAgreementService.getRequestTypeForValidation(existingPartyB.getId()));
							rejectedRecalledPartybList.add(existingPartyB);
						} else {
							if(!isModified) {
								if(partyB.getEntity().getIsSleeve() != null && partyB.getEntity().getIsSleeve() == 1){
									PartyBEntity sleeveExistingInAnotherRfa = isEntityExistingInAnotherRfa(partyB.getEntity().getId(), masterAgreementId, amendmentLetter.getId());
									if(sleeveRequestedOnAnotherRfaErrorList == null){
										sleeveRequestedOnAnotherRfaErrorList = new ArrayList<PartyBEntity>();
									}
									sleeveRequestedOnAnotherRfaErrorList.add(sleeveExistingInAnotherRfa);
								}
								else{
									if(null == addPartyBErrorList) {
										addPartyBErrorList = new ArrayList<PartyBEntity>();
									}
									addPartyBErrorList.add(partyB);
								}
							}
						}
						if(isModified) {
							List<AmendmentStatusObject> amendmentStatusObjectList = masterAgreementService.getAmendmentStatusOfModifiedEntityNotYetResponded(
									masterAgreementId, amendmentLetter.getId(), partyB.getEntity().getId());
							
							String amendmentStatusOfModifiedEntityNotYetResponded = amendmentStatusObjectList.get(0).getAmendmentStatus();
							if(!RFAConstants.NOT_YET_RESPONDED_STATUS.equalsIgnoreCase(amendmentStatusOfModifiedEntityNotYetResponded)) {
								if(null != amendmentStatusOfModifiedEntityNotYetResponded && (
										amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
											|| amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))) {
									/*existingPartyB.setRequestType(amendmentStatusObjectList.get(0).getRequestType());
									rejectedRecalledPartybList.add(existingPartyB);*/
									PartyBEntity partyBEntity = new PartyBEntity();
									partyBEntity.setId(existingPartyB.getId());
									partyBEntity.setEntity(existingPartyB.getEntity());
									partyBEntity.setAmendmentId(existingPartyB.getAmendmentId());
									partyBEntity.setRequestType(amendmentStatusObjectList.get(0).getRequestType());
									rejectedRecalledPartybList.add(partyBEntity);
								} else {
									if(null == addPartyBErrorList) {
										addPartyBErrorList = new ArrayList<PartyBEntity>();
									}
									addPartyBErrorList.add(partyB);
								}
								
								if(amendmentStatusObjectList.size() > 1) {
									amendmentStatusOfModifiedEntityNotYetResponded = amendmentStatusObjectList.get(1).getAmendmentStatus();
									if(null != amendmentStatusOfModifiedEntityNotYetResponded && (
											amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
												|| amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))
												&& (RFAConstants.MODIFICATION_FUND_NAME_CHANGE.equalsIgnoreCase(amendmentStatusObjectList.get(1).getRequestType())
														|| RFAConstants.MODIFICATION_EXHIBIT_VALUE_CHANGE.equalsIgnoreCase(amendmentStatusObjectList.get(1).getRequestType()))) {
										/*existingPartyB.setRequestType(amendmentStatusObjectList.get(1).getRequestType());
										rejectedRecalledPartybList.add(existingPartyB);*/
										PartyBEntity partyBEntity = new PartyBEntity();
										partyBEntity.setId(existingPartyB.getId());
										partyBEntity.setEntity(existingPartyB.getEntity());
										partyBEntity.setAmendmentId(existingPartyB.getAmendmentId());
										partyBEntity.setRequestType(amendmentStatusObjectList.get(1).getRequestType());
										rejectedRecalledPartybList.add(partyBEntity);
									}
								}
							} else {
								if(null == addPartyBErrorList) {
									addPartyBErrorList = new ArrayList<PartyBEntity>();
								}
								addPartyBErrorList.add(partyB);
							}
						}
					}
				} 
			}
			
			for (PartyBEntity partyB: partyBToBeRemoved) {
				if (partyB.getAutoAdded() != null && partyB.getAutoAdded()) continue;
				if(partyB.getEntity().getIsSleeve() != null && partyB.getEntity().getIsSleeve() == 1) {
					Entity parentEntity = entityService.getParentEntity(partyB.getEntity().getId());
					Long parentEntityId = parentEntity.getId();
					boolean isParentEntityAlsoAdded = isParentEntityAlsoAdded(parentEntityId, partyBToBeAdded);
					boolean isParentEntityAlreadyPresent = isEntityAlreadyPresent(parentEntityId, masterAgreementId, amendmentLetter.getId());
					if(!isParentEntityAlsoAdded && !isParentEntityAlreadyPresent) { // TODO: Revisit...is this is necessary?
						if(null == removeSleevePartyBErrorList ) {
							removeSleevePartyBErrorList  = new ArrayList<PartyBEntity>();
						}
						removeSleevePartyBErrorList .add(partyB);
						continue;
					}
				}
				// If users attempts to remove sleeve via "Select Party B Step"...
				PartyBEntity existingPartyB  = existingPartyBMap.get(partyB.getEntity().getId());
				if (existingPartyB != null && 
						(existingPartyB.getEntity().getIsSleeve() == 1? true : false) 
						&& !(partyB.getEntity().getIsSleeve() == 1? true : false)){
					if(null == removePartyBErrorList) {
						removePartyBErrorList = new ArrayList<PartyBEntity>();
					}
					removePartyBErrorList.add(partyB);
					continue;
				}
				
				if(existingPartyB != null){
					PartyBAckStatus ackStatus = existingPartyB.getAcknowledgementStatus();
					AmendmentStatus amendmentStatus = existingPartyB.getAmendmentStatus();
					Boolean isAdded = existingPartyB.getIsAdded();
					Boolean isModified = existingPartyB.getIsModified();
					if(!(null != ackStatus && isAdded && ackStatus == PartyBAckStatus.ACCEPTED_SENT)
							//&& !(null != ackStatus && !isAdded && ackStatus == PartyBAckStatus.REJECTED)
							&& !(null != ackStatus && !isAdded && ackStatus == PartyBAckStatus.REJECTED_SENT)
							&& !(null != ackStatus && !isAdded && ackStatus == PartyBAckStatus.WITHDRAWN)
							&& !(null != ackStatus && isAdded && isModified && ackStatus == PartyBAckStatus.ACCEPTED_SENT)
							//&& !(null != ackStatus && isAdded && isModified && ackStatus == PartyBAckStatus.REJECTED)
							&& !(null != ackStatus && isAdded && isModified && ackStatus == PartyBAckStatus.REJECTED_SENT)
							&& !(null != ackStatus && isAdded && isModified && ackStatus == PartyBAckStatus.WITHDRAWN)) {
						if(null != amendmentStatus
								&& (amendmentStatus == AmendmentStatus.RECALLED|| amendmentStatus == AmendmentStatus.REJECTED) && !isModified) {
							//existingPartyB.setRequestType(RFAConstants.REMOVAL);
							existingPartyB.setRequestType(masterAgreementService.getRequestTypeForValidation(existingPartyB.getId()));
							rejectedRecalledPartybList.add(existingPartyB);
						} else {
							if(!isModified) {
								
								if(partyB.getEntity().getIsSleeve() != null && partyB.getEntity().getIsSleeve() == 1){
									if(null == removeSleevePartyBErrorList ) {
										removeSleevePartyBErrorList  = new ArrayList<PartyBEntity>();
									}
									removeSleevePartyBErrorList .add(partyB);									
								} else{
									if(null == removePartyBErrorList) {
										removePartyBErrorList = new ArrayList<PartyBEntity>();
									}
									removePartyBErrorList.add(partyB);
								}
							}
						}
					}
					List<AmendmentStatusObject> amendmentStatusObjectList = masterAgreementService.getAmendmentStatusOfModifiedEntityNotYetResponded(
							masterAgreementId, amendmentLetter.getId(), partyB.getEntity().getId());
					
					String amendmentStatusOfModifiedEntityNotYetResponded = amendmentStatusObjectList.get(0).getAmendmentStatus();
					if(!RFAConstants.NOT_YET_RESPONDED_STATUS.equalsIgnoreCase(amendmentStatusOfModifiedEntityNotYetResponded) && !AmendmentStatus.COMPLETED.getDisplayName().equalsIgnoreCase(amendmentStatusOfModifiedEntityNotYetResponded)) {
						if(null != amendmentStatusOfModifiedEntityNotYetResponded && (
								amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
									|| amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))) {
							/*existingPartyB.setRequestType(amendmentStatusObjectList.get(0).getRequestType());
							rejectedRecalledPartybList.add(existingPartyB);*/
							PartyBEntity partyBEntity = new PartyBEntity();
							partyBEntity.setId(existingPartyB.getId());
							partyBEntity.setEntity(existingPartyB.getEntity());
							partyBEntity.setAmendmentId(existingPartyB.getAmendmentId());
							partyBEntity.setRequestType(amendmentStatusObjectList.get(0).getRequestType());
							rejectedRecalledPartybList.add(partyBEntity);
						} else {
							if(null == removePartyBErrorList) {
								removePartyBErrorList = new ArrayList<PartyBEntity>();
							}
							removePartyBErrorList.add(partyB);
						}
						
						if(amendmentStatusObjectList.size() > 1) {
							amendmentStatusOfModifiedEntityNotYetResponded = amendmentStatusObjectList.get(1).getAmendmentStatus();
							if(null != amendmentStatusOfModifiedEntityNotYetResponded && (
									amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
										|| amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))
										&& (RFAConstants.MODIFICATION_FUND_NAME_CHANGE.equalsIgnoreCase(amendmentStatusObjectList.get(1).getRequestType())
												|| RFAConstants.MODIFICATION_EXHIBIT_VALUE_CHANGE.equalsIgnoreCase(amendmentStatusObjectList.get(1).getRequestType()))) {
								/*existingPartyB.setRequestType(amendmentStatusObjectList.get(1).getRequestType());
								rejectedRecalledPartybList.add(existingPartyB);*/
								PartyBEntity partyBEntity = new PartyBEntity();
								partyBEntity.setId(existingPartyB.getId());
								partyBEntity.setEntity(existingPartyB.getEntity());
								partyBEntity.setAmendmentId(existingPartyB.getAmendmentId());
								partyBEntity.setRequestType(amendmentStatusObjectList.get(1).getRequestType());
								rejectedRecalledPartybList.add(partyBEntity);
							}
						}
					}
					
					List<PartyBEntity> sleevesInProgress = partyBService.getSleevesInProgress(partyB.getEntity().getId(), masterAgreementId);
					if (sleevesInProgress != null && sleevesInProgress.size() > 0){
						if(null == sleevesInProgressErrorList ) {
							sleevesInProgressErrorList  = new ArrayList<PartyBEntity>();
						}
						for (PartyBEntity sleeveInProgress : sleevesInProgress){
							sleevesInProgressErrorList.add(sleeveInProgress);
						}
						continue;
					}
				} else {
					if (partyB.getEntity().getIsSleeve() != null && partyB.getEntity().getIsSleeve() == 1){
						if(null == removeSleevePartyBErrorList ) {
							removeSleevePartyBErrorList  = new ArrayList<PartyBEntity>();
						}
						removeSleevePartyBErrorList .add(partyB);
						continue;
					}
					
					if(null == removePartyBErrorList) {
						removePartyBErrorList = new ArrayList<PartyBEntity>();
					}
					removePartyBErrorList.add(partyB);
				}
			}
			
			for (PartyBEntity partyB: partyBForFundNameChange){
				PartyBEntity existingPartyB  = existingPartyBMap.get(partyB.getEntity().getId());
				if(existingPartyB != null) {
					if (existingPartyB.getEntity().getIsSleeve() == 1){
						if(null == modifiedPartyBErrorList) {
							modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
						}
						modifiedPartyBErrorList.add(partyB);
						continue;
					}
					PartyBAckStatus ackStatus = existingPartyB.getAcknowledgementStatus();
					AmendmentStatus amendmentStatus = existingPartyB.getAmendmentStatus();
					Boolean isAdded = existingPartyB.getIsAdded();
					Boolean isModified = existingPartyB.getIsModified();
					if(isAdded && !isModified) {
						if(!(null != ackStatus && ackStatus == PartyBAckStatus.ACCEPTED_SENT)) {
							/*if(null == modifiedPartyBErrorList) {
								modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
							}
							modifiedPartyBErrorList.add(partyB);*/
							if(null != amendmentStatus && (amendmentStatus == AmendmentStatus.RECALLED || amendmentStatus == AmendmentStatus.REJECTED)) {
								//existingPartyB.setRequestType(RFAConstants.MODIFICATION_FUND_NAME_CHANGE);
								existingPartyB.setRequestType(masterAgreementService.getRequestTypeForValidation(existingPartyB.getId()));
								rejectedRecalledPartybList.add(existingPartyB);
							} else {
								if(null == modifiedPartyBErrorList) {
									modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
								}
								modifiedPartyBErrorList.add(partyB);
							}
						}
					} else if(isAdded && isModified) {
						String amendmentStatusOfFNCEntityNotYetResponded = masterAgreementService.getAmendmentStatusOfFNCEntityNotYetResponded(
								masterAgreementId, amendmentLetter.getId(), partyB.getEntity().getId());
						if(!RFAConstants.NOT_YET_RESPONDED_STATUS.equalsIgnoreCase(amendmentStatusOfFNCEntityNotYetResponded)) {
							if(null != amendmentStatusOfFNCEntityNotYetResponded && (
									amendmentStatusOfFNCEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
										|| amendmentStatusOfFNCEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))) {
								//existingPartyB.setRequestType(RFAConstants.MODIFICATION_FUND_NAME_CHANGE);
								PartyBEntity partyBEntity = new PartyBEntity();
								partyBEntity.setId(existingPartyB.getId());
								partyBEntity.setEntity(existingPartyB.getEntity());
								partyBEntity.setAmendmentId(existingPartyB.getAmendmentId());
								partyBEntity.setRequestType(RFAConstants.MODIFICATION_FUND_NAME_CHANGE);
								rejectedRecalledPartybList.add(partyBEntity);
							} else {
								if(null == modifiedPartyBErrorList) {
									modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
								}
								modifiedPartyBErrorList.add(partyB);
							}
						}
					} else if(!isAdded) {
						if(!(//ackStatus == PartyBAckStatus.REJECTED || 
								ackStatus == PartyBAckStatus.REJECTED_SENT)) {
							if(null != amendmentStatus && (amendmentStatus == AmendmentStatus.RECALLED || amendmentStatus == AmendmentStatus.REJECTED)) {
								existingPartyB.setRequestType(RFAConstants.REMOVAL);
								rejectedRecalledPartybList.add(existingPartyB);
							} else {
								if(null == modifiedPartyBErrorList) {
									modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
								}
								modifiedPartyBErrorList.add(partyB);
							}
						}
					}
				} else {
					if(null == modifiedPartyBErrorList) {
						modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
					}
					modifiedPartyBErrorList.add(partyB);
				}
			}
			
			for (PartyBEntity partyB: partyBForExhibitValueChange){
				PartyBEntity existingPartyB  = existingPartyBMap.get(partyB.getEntity().getId());
				if(existingPartyB != null) {
					if (existingPartyB.getEntity().getIsSleeve() == 1){
						if(null == modifiedPartyBErrorList) {
							modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
						}
						modifiedPartyBErrorList.add(partyB);
						continue;
					}
					PartyBAckStatus ackStatus = existingPartyB.getAcknowledgementStatus();
					AmendmentStatus amendmentStatus = existingPartyB.getAmendmentStatus();
					Boolean isAdded = existingPartyB.getIsAdded();
					Boolean isModified = existingPartyB.getIsModified();
					
					if(isAdded && !isModified) {
						if(!(null != ackStatus && ackStatus == PartyBAckStatus.ACCEPTED_SENT)) {
							/*if(null == modifiedPartyBErrorList) {
								modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
							}
							modifiedPartyBErrorList.add(partyB);*/
							if(null != amendmentStatus && (amendmentStatus == AmendmentStatus.RECALLED || amendmentStatus == AmendmentStatus.REJECTED)) {
								//existingPartyB.setRequestType(RFAConstants.MODIFICATION_EXHIBIT_VALUE_CHANGE);
								existingPartyB.setRequestType(masterAgreementService.getRequestTypeForValidation(existingPartyB.getId()));
								rejectedRecalledPartybList.add(existingPartyB);
							} else {
								if(null == modifiedPartyBErrorList) {
									modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
								}
								modifiedPartyBErrorList.add(partyB);
							}
						}
					} else if(isAdded && isModified) {
						String amendmentStatusOfEVCEntityNotYetResponded = masterAgreementService.getAmendmentStatusOfEVCEntityNotYetResponded(
								masterAgreementId, amendmentLetter.getId(), partyB.getEntity().getId());
						if(!RFAConstants.NOT_YET_RESPONDED_STATUS.equalsIgnoreCase(amendmentStatusOfEVCEntityNotYetResponded)) {
							if(null != amendmentStatusOfEVCEntityNotYetResponded && (
									amendmentStatusOfEVCEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
										|| amendmentStatusOfEVCEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))) {
								//existingPartyB.setRequestType(RFAConstants.MODIFICATION_EXHIBIT_VALUE_CHANGE);
								PartyBEntity partyBEntity = new PartyBEntity();
								partyBEntity.setId(existingPartyB.getId());
								partyBEntity.setEntity(existingPartyB.getEntity());
								partyBEntity.setAmendmentId(existingPartyB.getAmendmentId());
								partyBEntity.setRequestType(RFAConstants.MODIFICATION_EXHIBIT_VALUE_CHANGE);
								rejectedRecalledPartybList.add(partyBEntity);
							} else {
								if(null == modifiedPartyBErrorList) {
									modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
								}
								modifiedPartyBErrorList.add(partyB);
							}
						}
					} else if(!isAdded) {
						if(!(//ackStatus == PartyBAckStatus.REJECTED || 
								ackStatus == PartyBAckStatus.REJECTED_SENT)) {
							if(null != amendmentStatus && (amendmentStatus == AmendmentStatus.RECALLED || amendmentStatus == AmendmentStatus.REJECTED)) {
								existingPartyB.setRequestType(RFAConstants.REMOVAL);
								rejectedRecalledPartybList.add(existingPartyB);
							} else {
								if(null == modifiedPartyBErrorList) {
									modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
								}
								modifiedPartyBErrorList.add(partyB);
							}
						}
					}
				} else {
					if(null == modifiedPartyBErrorList) {
						modifiedPartyBErrorList = new ArrayList<PartyBEntity>();
					}
					modifiedPartyBErrorList.add(partyB);
				}
			}
			
			if(null != addPartyBErrorList) {
				addPartyBErrorMap.put(partyARelation.toString(), addPartyBErrorList);
			}
			if(null != removePartyBErrorList) {
				removePartyBErrorMap.put(partyARelation.toString(), removePartyBErrorList);
			}
			if(null != modifiedPartyBErrorList) {
				modifiedPartyBErrorMap.put(partyARelation.toString(), modifiedPartyBErrorList);
			}
			if (null != sleeveRequestedOnAnotherRfaErrorList){
				sleeveRequestedOnAnotherRfaErrorMap.put(partyARelation.toString(), sleeveRequestedOnAnotherRfaErrorList);
			}
			if (null != removeSleevePartyBErrorList){
				sleeveRemovalPartyBErrorMap.put(partyARelation.toString(), removeSleevePartyBErrorList);
			}
			if (null != sleeveParentNotOnActiveTabErrorList){
				sleeveParentNotOnActiveTabErrorMap.put(partyARelation.toString(), sleeveParentNotOnActiveTabErrorList);
			}
			if (null != sleeveExistsOnActiveTabErrorList){
				sleeveExistsOnActiveTabErrorMap.put(partyARelation.toString(), sleeveExistsOnActiveTabErrorList);
			}
			if (null != sleevesInProgressErrorList){
				sleevesInProgressErrorMap.put(partyARelation.toString(), sleevesInProgressErrorList);
			}
		}
		
		if(addPartyBErrorMap.size() >  0 || removePartyBErrorMap.size() > 0 || modifiedPartyBErrorMap.size() > 0
				|| sleeveRequestedOnAnotherRfaErrorMap.size() > 0 || sleeveRemovalPartyBErrorMap.size() > 0
				|| rejectedRecalledPartybList.size() > 0  || additionPlaceholderErrorMap.size() > 0
				|| removalPlaceholderErrorMap.size() > 0 || modificationPlaceholderErrorMap.size() > 0
				|| sleeveParentNotOnActiveTabErrorMap.size() > 0 || sleeveExistsOnActiveTabErrorMap.size() > 0
				|| sleevesInProgressErrorMap.size() > 0) {
			CommonFileResponse commonFileResponse = amendmentLetterPDFService.generateErrorPDF(companyId
					, addPartyBErrorMap, removePartyBErrorMap, modifiedPartyBErrorMap
					, sleeveRequestedOnAnotherRfaErrorMap, sleeveRemovalPartyBErrorMap 
					, sleeveExistsOnActiveTabErrorMap,sleeveParentNotOnActiveTabErrorMap, sleevesInProgressErrorMap, rejectedRecalledPartybList
					, additionPlaceholderErrorMap, removalPlaceholderErrorMap, modificationPlaceholderErrorMap
					, letterTemplateMap, userId);
			return commonFileResponse;
		}
		} catch (Exception e){
			e.printStackTrace();
			CommonFileResponse fileResponse = new CommonFileResponse();
			fileResponse.setFileId(-1L);	
			fileResponse.setFileType("N/A");
			return fileResponse;
		}
		return null;
	}

/*	private List<Entity> getSleevesInProgress(PartyBEntity parentPartyB, Long masterAgreementId){
		entityService.getSleevesInProgress(parentPartyB.getEntity().getId(), parentPartyB.getMasterAgreement());
		return entityService.getSleevesInProgress(parentPartyB.getEntity().getId(), masterAgreementId);
	}*/
	
	private boolean isSleeveExistingInMasterlist(Long sleeveEntityId, List<PartyBEntity> partyBToBeAdded, Long masterAgreementId){
		for (PartyBEntity partyBEntity : partyBToBeAdded){
			if(partyBEntity.getEntity().getId() == sleeveEntityId && partyBEntity.getEntity().getIsSleeve() == 0) return true;
		}
		List<Long> sleeveEntityIds = new ArrayList<>();
		sleeveEntityIds.add(sleeveEntityId);
		List<PartyBEntity> existingPartyBList = masterAgreementService.getExistingPartyB(masterAgreementId, sleeveEntityIds, null);
		
		
		PartyBEntity partyBEntity = new PartyBEntity();
		if (existingPartyBList != null && existingPartyBList.size() > 0) {
			partyBEntity = existingPartyBList.get(0);
			if (partyBEntity != null && partyBEntity.getAcknowledgementStatus() != null && partyBEntity.getAmendmentStatus() != null
					&& (partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.ACCEPTED_SENT)
					&& (partyBEntity.getAmendmentStatus() == AmendmentStatus.COMPLETED 
					|| partyBEntity.getAmendmentStatus() == AmendmentStatus.PARTIALLY_COMPLETED)) return partyBEntity.getIsAdded();
		}
		return false;
	}
	
	@Override
	public PartyBEntity isEntityExistingInAnotherRfa(Long entityId, Long masterAgreementId, Long amendmentId){

		List<Long> sleeveEntityIds = new ArrayList<>();
		sleeveEntityIds.add(entityId);
		List<PartyBEntity> existingPartyBList = masterAgreementService.getExistingPartyB(masterAgreementId, sleeveEntityIds, amendmentId);
		
		PartyBEntity partyBEntity = new PartyBEntity();
		if (existingPartyBList != null && existingPartyBList.size() > 0) {
			partyBEntity = existingPartyBList.get(0);
			if (partyBEntity != null) return partyBEntity;
		}
		return partyBEntity;
	}
	
	private boolean isParentEntityAlsoAdded(Long parentEntityId, List<PartyBEntity> partyBToBeAdded) {
		for (PartyBEntity partyBEntity : partyBToBeAdded) {
			if(partyBEntity.getEntity().getId() == parentEntityId) {
				if (partyBEntity.getDeleted() != null && partyBEntity.getDeleted() == 1) return false;
				else return true;
			}
		}
		return false;
	}
	
	@Override
	public boolean isEntityAlreadyPresent(Long entityId, Long masterAgreementId, Long amendmentId) {
		boolean isEntityAlreadyPresent = false;
		List<Long> entityIds = new ArrayList<>();
		entityIds.add(entityId);
		List<PartyBEntity> existingPartyBList = masterAgreementService.getExistingPartyB(masterAgreementId, entityIds, amendmentId);
		if(null != existingPartyBList && existingPartyBList.size() == 1) {
			PartyBEntity existingParentPartyB = existingPartyBList.get(0);
			if(existingParentPartyB != null){
				isEntityAlreadyPresent = true;
				PartyBAckStatus ackStatus = existingParentPartyB.getAcknowledgementStatus();
				AmendmentStatus amendmentStatus = existingParentPartyB.getAmendmentStatus();
				Boolean isAdded = existingParentPartyB.getIsAdded();
				Boolean isModified = existingParentPartyB.getIsModified();
				
				if ((null != ackStatus && !isAdded && !isModified && ackStatus == PartyBAckStatus.ACCEPTED_SENT)
						|| (null != ackStatus && isAdded && !isModified && ackStatus == PartyBAckStatus.REJECTED_SENT)
						|| (null != ackStatus && isAdded && !isModified && ackStatus == PartyBAckStatus.WITHDRAWN)) {
					return false;
				}
				else {
					if(null != amendmentStatus && (amendmentStatus == AmendmentStatus.RECALLED || amendmentStatus == AmendmentStatus.REJECTED 
							|| amendmentStatus == AmendmentStatus.DRAFT || amendmentStatus == AmendmentStatus.SUBMITTED) && !isModified) {
						return false;
					}
					if(isModified) {
						List<AmendmentStatusObject> amendmentStatusObjectList = masterAgreementService.getAmendmentStatusOfModifiedEntityNotYetResponded(
								masterAgreementId, amendmentId, entityId);
						
						String amendmentStatusOfModifiedEntityNotYetResponded = amendmentStatusObjectList.get(0).getAmendmentStatus();
						
						if(!RFAConstants.NOT_YET_RESPONDED_STATUS.equalsIgnoreCase(amendmentStatusOfModifiedEntityNotYetResponded)) {
							
							if(null != amendmentStatusOfModifiedEntityNotYetResponded && (
									amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
										|| amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))) {
								return false;
							}
							
							if(amendmentStatusObjectList.size() > 1) {
								amendmentStatusOfModifiedEntityNotYetResponded = amendmentStatusObjectList.get(1).getAmendmentStatus();
								if(null != amendmentStatusOfModifiedEntityNotYetResponded && (
										amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.RECALLED.toString())
											|| amendmentStatusOfModifiedEntityNotYetResponded.equalsIgnoreCase(AmendmentStatus.REJECTED.toString()))
											&& (RFAConstants.MODIFICATION_FUND_NAME_CHANGE.equalsIgnoreCase(amendmentStatusObjectList.get(1).getRequestType())
													|| RFAConstants.MODIFICATION_EXHIBIT_VALUE_CHANGE.equalsIgnoreCase(amendmentStatusObjectList.get(1).getRequestType()))) {
									return false;
								}
							}
							
						} else {
							return false;
						}
					}
				}
			} 
		}
		return isEntityAlreadyPresent;
	}

	private Map<Long,PartyBEntity> createMapForExistingParties(
			List<PartyBEntity> existingPartyBList) {
		Map<Long,PartyBEntity> map = (Map<Long, PartyBEntity>) new LinkedHashMap<Long,PartyBEntity>();
		for (PartyBEntity partyBEntity : existingPartyBList) {
			map.put(partyBEntity.getEntity().getId(), partyBEntity);
		}
		return map;
	}

	private void populateSSAmendmentActions(AmendmentLetter amendmentLetter){
		NextActions actions = new NextActions();
		actions.setViewHistory(amendmentLetter.isHistory());
		
		actions.setEsignHover(new NextActions.EsignHover());
		actions.getEsignHover().setSignedCount(amendmentLetter.getSignedCount());
		actions.getEsignHover().setTotalCount(amendmentLetter.getSsSignPlaceholderCount());
		
		if((amendmentLetter.getAmendmentStatus() == AmendmentStatus.RECEIVED || amendmentLetter.getAmendmentStatus() == AmendmentStatus.PARTIALLY_COMPLETED)
				&& amendmentLetter.getPartyBAdded().size() > 0){
			actions.setDocumentLink(true);
		}
		
		//  Recalled / Rejected
				if(amendmentLetter.getAmendmentStatus() == AmendmentStatus.RECALLED 
						||  amendmentLetter.getAmendmentStatus() == AmendmentStatus.REJECTED) {
					amendmentLetter.setNextActions(actions);
					return;
				}
		// Completed
		if(amendmentLetter.getAmendmentStatus() == AmendmentStatus.COMPLETED) {
					amendmentLetter.setNextActions(actions);
					return;
		}		
		if(amendmentLetter.getAmendmentStatus() == AmendmentStatus.RECEIVED) {
			actions.setRejectRFA(true);
		}
		//1.  Pending Response
		System.out.println("Amendment ID:" + amendmentLetter.getId());
		if(CommonUtil.isNotNull(amendmentLetter.getSsNextStep())) {
			
			if(amendmentLetter.getSsNextStep().equals("SS_RESPONSE_PENDING") || amendmentLetter.getSsNextStep().equals("SS_RESPONSE_PENDING_UPDATED") ) {
				actions.setResponsePending(true);
				amendmentLetter.setNextActions(actions);
				return;
			}
			//2.  Esign
			if(amendmentLetter.getSsNextStep().equals("SS_ESIGN") ) {
				actions.setResponsePending(false);
				actions.setResponsePendingActions(true);
				
				actions.seteSign(true);
				amendmentLetter.setNextActions(actions);
				return;
			}
			//3. SS Need to send RFA
			if(amendmentLetter.getSsNextStep().equals("SS_SEND_RFA")) {
				//actions.setResponsePending(false);
				actions.setSendRFA(true);
				actions.seteSign(true);
				amendmentLetter.setNextActions(actions);
				return;
			}
			//3. Esign signed
			if(amendmentLetter.getSsNextStep().equals("SS_SENT_RFA")) {
				if(amendmentLetter.getAmendmentStatus() == AmendmentStatus.PARTIALLY_COMPLETED) {
					actions.setResponsePending(true);
				}
				//actions.setRejectRFA(true);
				//actions.setSendRFA(true);
				//actions.seteSign(true);
				amendmentLetter.setNextActions(actions);
				return;
			}
		}
		
		amendmentLetter.setNextActions(actions);
	}
	

	private void populateBSAmendmentActions(AmendmentLetter amendmentLetter){
		NextActions actions = new NextActions();
		actions.setViewHistory(amendmentLetter.isHistory());
		String nextStep = amendmentLetter.getBsNextStep();
		
		actions.setEsignHover(new NextActions.EsignHover());
		actions.getEsignHover().setSignedCount(amendmentLetter.getSignedCount());
		actions.getEsignHover().setTotalCount(amendmentLetter.getBsSignPlaceholderCount());
		if(CommonUtil.isNotNull(nextStep)){
		// 1. Rejected / Recalled
		if (nextStep.equals("BS_EDIT_DRAFT")){
			actions.setEditRFA(true);
			amendmentLetter.setNextActions(actions);
			return;
		}
		// 2. Ready For Send
		if (nextStep.equals("BS_SEND_RFA")){
			actions.setSendRFA(true);
			actions.seteSign(true);
			amendmentLetter.setNextActions(actions);
			return;
		}
		//3. Sent by BS
		if (nextStep.equals("BS_SENT_RFA")){
			if (amendmentLetter.getAmendmentStatus() == AmendmentStatus.COMPLETED){
				amendmentLetter.setNextActions(actions);
				return;
			} else if (amendmentLetter.getAmendmentStatus() == AmendmentStatus.SUBMITTED){
				if(!amendmentLetter.getSsNextStep().equals("SS_SEND_RFA"))
					actions.setRecallAmendment(true);
				amendmentLetter.setNextActions(actions);
				return;
			} else if (amendmentLetter.getAmendmentStatus() == AmendmentStatus.PARTIALLY_COMPLETED){
				if(null != amendmentLetter.getPartyBPending() && amendmentLetter.getPartyBPending().size() >0 ){
					actions.setWithdrawPartyB(true);
					amendmentLetter.setNextActions(actions);
					return;
				}
			} 
		}
		//4. Linked Editor
		if (nextStep.equals("BS_LINKED_EXHIBIT_EDITOR")){
			actions.setEditAmendment(true);
			if(amendmentLetter.getIgnoreExhibit() == 0){
				actions.setEditLinkedExhibit(true);
			}
			amendmentLetter.setNextActions(actions);
			return;
		}
		//4. Next step is BS Esign
		if (nextStep.equals("BS_ESIGN")){
			actions.setEditAmendment(true);
			if(amendmentLetter.getIgnoreExhibit() == 0){
				actions.setEditLinkedExhibitAction(true);
			}
			actions.seteSign(true);
			amendmentLetter.setNextActions(actions);
			return;
		}
		}
		amendmentLetter.setNextActions(actions);
	}
	
	@Transactional	
	@SelectAllMethod(name = KEY_BULK_SIGN_RFA,objectIdIndex=0,objectIdType=Long.class)
	public Integer signAmendmentLetter(Long amendmentLetterId,
			@SelectAllParam(index = 1) Long companyId, 
			@SelectAllParam(index = 2,isObjectAttribute = true) Signature signatureInput, 
			@SelectAllParam(index = 3) String loginName,
			@SelectAllParam(index = 4) Long loginTime)
			throws Exception {
		AmendmentLetter amendmentLetter = this.getAmendmentLetterById(amendmentLetterId);
		
		signatureInput.setCompanyId(companyId);
		signatureInput.setSignType("E_SIGN");
		
		handleInvalidSign(signatureInput, amendmentLetter);
		logger.info("Calling Signature Service for Esign");
		Signature signature = signatureService.saveSignature(signatureInput, amendmentLetter.getFileId(), amendmentLetter.getName() + "sign",
				loginName,loginTime, null);
		logger.info("Called Signature Service for Esign");
		logger.info("Signing Amendment Letter");
		return amendmentLetterDao.signSellSide(signature, amendmentLetter);		
	}
	
	@Transactional	
	public Integer signAmendmentLetter(Long amendmentLetterId,
			@SelectAllParam(index = 1) Long companyId, 
			@SelectAllParam(index = 2,isObjectAttribute = true) Signature signatureInput, 
			@SelectAllParam(index = 3) String loginName,
			@SelectAllParam(index = 4) Long loginTime,
			@SelectAllParam(index = 5) byte[] content)
			throws Exception {
		AmendmentLetter amendmentLetter = this.getAmendmentLetterById(amendmentLetterId);
		
		signatureInput.setCompanyId(companyId);
		
		handleInvalidSign(signatureInput, amendmentLetter);
		logger.info("Calling Signature Service for Esign");
		Signature signature = signatureService.saveSignature(signatureInput, amendmentLetter.getFileId(), amendmentLetter.getName() + "sign",
				loginName,loginTime, content);
		logger.info("Called Signature Service for Esign");
		logger.info("Signing Amendment Letter");
		return amendmentLetterDao.signSellSide(signature, amendmentLetter);		
	}
	

	private void handleInvalidSign(Signature signatureInput, AmendmentLetter amendmentLetter) throws RFAException {
		if (signatureInput.isSellSide()) {
			populateSSAmendmentActions(amendmentLetter);
			if (!amendmentLetter.getNextActions().geteSign()) {
				throw new RFAException("SS RFA already Signed", "400");
			}
		}
	}
	
//	@Transactional
	public Long bulkSignRFA(List<Signature> signataureList, final Long companyId, final long userId, final String loginName,final Long loginTime) throws Exception {
		
		List<BulkRequestParam> requestParamList = Lists.newArrayList();		
		requestParamList.add(createBulkRequestParam(1,"companyId",companyId,BulkRequestParamEnum.PRIMITIVE));
		requestParamList.add(createBulkRequestParam(3,"email",loginName,BulkRequestParamEnum.PRIMITIVE));
		requestParamList.add(createBulkRequestParam(4,"loginTime",loginTime,BulkRequestParamEnum.PRIMITIVE));
		
		Map<Long,List<BulkRequestParam>> requestObjectParamMap = signataureList.stream().collect(Collectors.toMap(a -> a.getAmendmentId(), a -> Lists.newArrayList(createBulkRequestParam(2, "signature", a, BulkRequestParamEnum.JSON))));
		
		return selectAllService.processRequest(bulkSignRfaSelectAllConfig,requestParamList,requestObjectParamMap,userId,companyId); 						
	}
			
	//TODO PartyB initial Status should be SUBMITTED. The following check should be modified accordingly.  
	@Override
	@Transactional
	public AmendmentLetter recallAmendmentLetter(Long companyId, Long userId, Long amendmentLetterId) throws Exception {
		AmendmentLetter amendmentLetter = null;
		AmendmentLetter amendmentLetterObj = amendmentLetterDao.getAmendmentLetterById(amendmentLetterId, companyId);

		if (AmendmentStatus.SUBMITTED == amendmentLetterObj.getAmendmentStatus()) {
			amendmentLetter = amendmentLetterDao.recallAmendmentLetter(companyId, userId, amendmentLetterId);
			// 1. Get Amendment Details...
			Grid grid = getRecallRfaDetails.executeQuery("amendmentId", amendmentLetterId);
			Row row = grid.getRowList().get(0);

			// 2. Get users for email notification
			List<String> emailList = userService.getAllUsersForCompanyByPermissionName(Long.valueOf(row.get("partya_entityid")), SS_GROUP);

			if (CollectionUtils.isNotEmpty(emailList)) {
				// 3. Generate url for redirection
				Map<String, String> urlGeneratorParams = new HashMap<String, String>();
				urlGeneratorParams.put("amendment_id", "" + row.get("rfa_id"));
				String url = buysideRecallsRfaEmail.generateUrl(urlGeneratorParams);

				// 4. Set email template params
				Map<String, Object> emailTemplateParams = new HashMap<String, Object>();
				emailTemplateParams.put("partya_legal_name", row.get("partya_legal_name"));
				emailTemplateParams.put("im_legal_name", row.get("im_legal_name"));
				emailTemplateParams.put("submited_date", row.get("submited_date"));
				emailTemplateParams.put("rfa_id", row.get("rfa_id"));
				emailTemplateParams.put("url", url);
				
				Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
				subjectVariables.put("subj_suffix", row.get("im_legal_name"));
				
				rfaMailService.sendEmail(emailList, emailTemplateParams, "email_rfa_recalled.vm", "email_rfa_subj.vm", subjectVariables);
			}
		}
		return amendmentLetter;
	}

	@Transactional
	@Override
	public List<PartyBEntity> withdrawPartyB(Long companyId, String companyType
			, Long amendmentLetterId, Long userId, List<PartyBEntity> partyBList) throws Exception {
		AmendmentLetter amendmentLetterObj = amendmentLetterDao.getAmendmentLetterById(amendmentLetterId, companyId);
		List<PartyBEntity> returnedList = null;
		if(AmendmentStatus.PARTIALLY_COMPLETED == amendmentLetterObj.getAmendmentStatus()){
			returnedList = partyBService.withdrawPartyB(userId, partyBList);
			iPartyBPlaceHolderService.updateAmendmentBySsResponse(amendmentLetterId, userId);
			amendmentLetterDao.updateBSTaskAndNextSteps(amendmentLetterId,"WITHDRAW");
			
			// 0 . Add in PartyB Snap table
			partyBService.copyPartyBEntitiesToSnap(amendmentLetterId,userId);
			
			//	1.	Get Amendment Details...
			Map<String, Object> queryParams = new HashMap<String, Object>();
			queryParams.put("amendmentId", amendmentLetterId);
			Grid grid = getWithdrawPartyBDetails.executeQuery(queryParams);
			Row row = grid.getRowList().get(0);
			
			//	2.	Get users for email notification
			List<String> emailList = userService.getAllUsersForCompanyByPermissionName(Long.valueOf(row.get("partya_entityid")), SS_GROUP);
			
			if (CollectionUtils.isNotEmpty(emailList)) {
				// 3. Generate url for redirection
				Map<String, String> urlGeneratorParams = Maps.newHashMapWithExpectedSize(1);
				urlGeneratorParams.put("amendment_id", row.get("rfa_id"));
				String url = buysideWithdrawsPartyB.generateUrl(urlGeneratorParams);

				// 4. Set email template params
				Map<String, Object> emailTemplateParams = Maps.newHashMapWithExpectedSize(6);
				emailTemplateParams.put("partya_legal_name", row.get("partya_legal_name"));
				emailTemplateParams.put("im_legal_name", row.get("im_legal_name"));
				emailTemplateParams.put("submited_date", row.get("submited_date"));
				emailTemplateParams.put("rfa_id", row.get("rfa_id"));
				emailTemplateParams.put("withdrawn_count", partyBList.size());
				emailTemplateParams.put("url", url);
				
				Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
				subjectVariables.put("subj_suffix", row.get("im_legal_name"));
				
				rfaMailService.sendEmail(emailList, emailTemplateParams, "email_rfa_withdrawn.vm", "email_rfa_subj.vm", subjectVariables);
			}
		}
		return returnedList;
	}
	
	@Override
	public List<AmendmentHistory> history(Long amendmentLetterId, Long companyId) {
		return amendmentLetterDao.history(amendmentLetterId, companyId);
	}

	@Override
	public Long getSignFileId(Long amendment_id, Long companyId) {
		return amendmentLetterDao.getSignFileId(amendment_id, companyId);
	}

	@Override
	public Long addReview(int reviewId, long userId, long amendmentId) {
		return amendmentLetterDao.addReview(reviewId, userId, amendmentId);
	}

	@Override
	public void deleteReview(long reviewId, long userId, Long amendmentId) {
		amendmentLetterDao.deleteReview(reviewId, userId, amendmentId);
	}
	
	@Override
	@Transactional
	public void rejectAmendmentLetter(Long amendmentId, Long userId, Long companyId, String reason, String companyType) throws Exception {
		if (CompanyType.isSSCompany(companyType)) {
			amendmentLetterDao.rejectAmendmentLetter(amendmentId, userId, companyId, reason);
			Grid grid = getRejectRfaEmailDetails.executeQuery("amendmentId", amendmentId);
			Row row = grid.getRowList().get(0);
			
			String investmentManagerEntityId = row.get("im_entityid");
			List<String> emailList = userService.getAllUsersForCompanyByPermissionName(Long.valueOf(investmentManagerEntityId), BS_GROUP);
			if (CollectionUtils.isNotEmpty(emailList)) {
			
				Map<String, String> additionalUrlParams = new HashMap<String, String>();
				additionalUrlParams.put("amendment_id", amendmentId.toString());
				String url = sellsideRejectsRfaEmail.generateUrl(additionalUrlParams);
				
				Map<String, Object> emailTemplateParams  = new HashMap<String, Object>();
				emailTemplateParams.put("rfaUrl", url);
				emailTemplateParams.put("partyA", row.get("partya_legal_name"));
				emailTemplateParams.put("investment_manager", row.get("im_legal_name"));
				emailTemplateParams.put("received_date", row.get("submited_date"));
				emailTemplateParams.put("rejected_date", row.get("rejected_date"));
				emailTemplateParams.put("rfaId", row.get("rfa_id"));
				emailTemplateParams.put("reason", reason);
				
				Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
				subjectVariables.put("subj_suffix", row.get("partya_inst_entity"));
				
				rfaMailService.sendEmail(emailList, emailTemplateParams, "email_rfa_reject.vm", "email_rfa_subj.vm", subjectVariables);
			}
		} else {
			throw new RFAException(RFAConstants.SS_COMPANY_ACTION_ONLY, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
		}
	}
	
	@Override
	@Transactional
	public void deleteAmendmentLetter(Long amendmentId, Long userId, String companyType) throws Exception {
		if (CompanyType.isBSCompany(companyType)) {
			amendmentLetterDao.deleteAmendmentLetter(amendmentId, userId);
			
		} else {
			throw new RFAException(RFAConstants.BS_COMPANY_ACTION_ONLY, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
		}
	}
	
	@Override
	public void editRejectedAmendmentLetter(Long amendmentId, Long userId) {
		amendmentLetterDao.editRejectedAmendmentLetter(amendmentId, userId);
	}

	@Override
	public ReviewData getReview(Long reviewId, int reviewType, Long amendmentId) {
		return amendmentLetterDao.getReview(reviewId, reviewType, amendmentId);
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public void updateContent(Long amendmentId, Long userId,
			AmendmentContent amendmentContent) {
		amendmentLetterDao.updateContent(amendmentId, userId, amendmentContent);
	}

	@Override
	@Transactional
	@SelectAllMethod(name = KEY_BULK_SEND_RFA, objectIdIndex = 0, objectIdType = Long.class)
	public void sendRFA(Long amendmentId, @SelectAllParam(index = 1) Long userId, @SelectAllParam(index = 2) String companyType,
			@SelectAllParam(index = 3) Long companyId) throws Exception {
		byte[] fullPdf= null;
		if (!isValidRfaIdToSend(amendmentId, companyId, companyType)) {
			logger.error("RFA already sent: " + amendmentId);
			return;
		}

		PDFContext pdfContext = RFAConstants.COMPANY_TYPE_SS.equals(companyType) ? PDFContextGenerator.getSellSideSendRFAContext()
				: PDFContextGenerator.getBuySideSendRFAContext();
		byte[] docVersionPDF = reportGenerator.getPDFContentSychronous(amendmentId, pdfContext);
		byte[] wetSignByte = consolidateFileUtil.consolidateWetSignsByRFAId(amendmentId,  companyId,  userId);
		if (CommonUtil.isNotNull(wetSignByte))
			fullPdf = PDFUtil.merge(docVersionPDF, wetSignByte);
		else
			fullPdf = docVersionPDF;
		String digest = EsignDocUtil.getDigest(fullPdf);
		int noOfPages = EsignDocUtil.getNoOfPages(fullPdf);
		MCFile mcFile = fileService.saveFile(fullPdf, companyId, amendmentId + "-send", userId);

		amendmentLetterDao.sendRFA(amendmentId, userId, companyType);
		logger.info("Executing copyPartyBEntitiesToSnap for: " + amendmentId);
		partyBDao.copyPartyBEntitiesToSnap(amendmentId, userId);
		logger.info("Executing documentVersionHistoryDao.sendRFA for: " + amendmentId);
		documentVersionHistoryDao.sendRFA(amendmentId, mcFile.getFileId(), companyType, userId, digest, noOfPages);
		if (RFAConstants.COMPANY_TYPE_SS.equals(companyType)) {
			logger.info("Executing signatureService.freezeSellSideSignatures for: " + amendmentId);
			signatureService.freezeSellSideSignatures(amendmentId);
		}

		if (RFAConstants.COMPANY_TYPE_BS.equals(companyType)) {
			//update notified checkbox status
			reviewService.updateNotifiedStatusOnSendRFA(amendmentId,userId);
			sendRFAEmailToSS(amendmentId);
		} else {
			logger.info("Executing sendRFAEmailToBS for: " + amendmentId);
			sendRFAEmailToBS(amendmentId);
			logger.info("Executing updateMasterAgreement for: " + amendmentId);
			updateMasterAgreement(amendmentId);
		}
	}

	@Transactional
	private void updateMasterAgreement(Long amendmentId)
	{
		String masterlistMlTemplateWithSleeve = masterAgreementService.getMlTemplateWithSleeveNameByAmendment(amendmentId);
		String amendmentMlTemplateWithSleeve = amendmentLetterDao.getAmendmentMlTemplateWithSleeve(amendmentId);
		if(null == masterlistMlTemplateWithSleeve && null != amendmentMlTemplateWithSleeve){
			masterAgreementService.updateMasterAgreement(amendmentId);
		}
	}

	private boolean isValidRfaIdToSend(Long amendmentId, Long companyId, String companyType) {
		BulkValidationBean validationBean = new BulkValidationBean();
		validationBean.setCompanyId(companyId);
		validationBean.setCompanyType(companyType);
		validationBean.setRfaIdList(Lists.newArrayList(amendmentId));
		validationBean.setValidationType(BulkActionValidationType.SEND);
		return !bulkActionValidationInvoker.convertValidRfaIdsToList(bulkActionValidationInvoker.invoke(validationBean)).isEmpty();
	}

	private void sendRFAEmailToBS(Long amendmentId) throws Exception {
		Grid grid = getSellsideSendRfaDetails.executeQuery("amendmentId", amendmentId);
		if (!grid.isEmpty()) {
			Row row = grid.getRowList().get(0);
			List<String> emailList = userService.getAllUsersForCompanyByPermissionName(Long.valueOf(row.get("im_entityid")), BS_GROUP);
			if (CollectionUtils.isNotEmpty(emailList)) {
				Map<String, String> urlGeneratorParams = new HashMap<String, String>();
				urlGeneratorParams.put("amendment_id", "" + row.get("rfa_id"));
				String url = sellsideSendsRfa.generateUrl(urlGeneratorParams);

				Map<String, Object> emailTemplateParams = new HashMap<String, Object>();
				emailTemplateParams.put("partya_legal_name", row.get("partya_legal_name"));
				emailTemplateParams.put("im_legal_name", row.get("im_legal_name"));
				emailTemplateParams.put("submited_date", row.get("submited_date"));
				emailTemplateParams.put("rfa_id", row.get("rfa_id"));
				emailTemplateParams.put("url", url);
				
				Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
				subjectVariables.put("subj_suffix", row.get("partya_inst_entity"));
				
				rfaMailService.sendEmail(emailList, emailTemplateParams, "email_rfa_ss_signed.vm", "email_rfa_subj.vm", subjectVariables);
			}
		}
	}

	private void sendRFAEmailToSS(Long amendmentId) throws Exception {
		Grid grid = getBuysideSendRfaDetails.executeQuery("amendmentId", amendmentId);
		if (!grid.isEmpty()) {
			Row row = grid.getRowList().get(0);
			List<String> emailList = userService.getAllUsersForCompanyByPermissionName(Long.valueOf(row.get("partya_entityid")), SS_ONBOARDING);
			if (CollectionUtils.isNotEmpty(emailList)) {
				Map<String, String> urlGeneratorParams = Maps.newHashMapWithExpectedSize(2);
				urlGeneratorParams.put("amendment_id", row.get("rfa_id"));
				urlGeneratorParams.put("exhibit_id", row.get("exhibit_id"));
				String url = buysideSendsRfaEmail.generateUrl(urlGeneratorParams);

				Map<String, Object> emailTemplateParams = Maps.newHashMapWithExpectedSize(4);
				emailTemplateParams.put("partya_legal_name", row.get("partya_legal_name"));
				emailTemplateParams.put("im_legal_name", row.get("im_legal_name"));
				emailTemplateParams.put("rfa_id", row.get("rfa_id"));
				emailTemplateParams.put("url", url);
				
				Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
				subjectVariables.put("subj_suffix", row.get("im_legal_name"));
				
				rfaMailService.sendEmail(emailList, emailTemplateParams, "email_rfa_bs_signed.vm", "email_rfa_subj.vm", subjectVariables);
			}
		}
	}
	
//	@Transactional
	public Long bulkSendRFA(List<Long> amendmentIds, final Long userId, final String companyType, final Long companyId) throws Exception {
		List<BulkRequestParam> requestParamList = Lists.newArrayList(3);
		requestParamList.add(createBulkRequestParam(1, "userId", userId, BulkRequestParamEnum.PRIMITIVE));
		requestParamList.add(createBulkRequestParam(2, "companyType", companyType, BulkRequestParamEnum.PRIMITIVE));
		requestParamList.add(createBulkRequestParam(3, "companyId", companyId, BulkRequestParamEnum.PRIMITIVE));

		Map<Long, List<BulkRequestParam>> requestObjectParamMap = Maps.newLinkedHashMap();
		amendmentIds.forEach(id -> {
			requestObjectParamMap.put(id, Collections.emptyList());
		});
		return selectAllService.processRequest(bulkSendRfaSelectAllConfig, requestParamList, requestObjectParamMap, userId, companyId); 			
	}
	
	public Long bulkUploadRFA(final Long userId, final String companyType, final Long companyId,Long fileId,Long templateId, String ipAddress) throws Exception {
		List<BulkRequestParam> requestParamList = Lists.newArrayList(3);
		requestParamList.add(createBulkRequestParam(1, "userId", userId, BulkRequestParamEnum.PRIMITIVE));
		requestParamList.add(createBulkRequestParam(2, "companyType", companyType, BulkRequestParamEnum.PRIMITIVE));
		requestParamList.add(createBulkRequestParam(3, "companyId", companyId, BulkRequestParamEnum.PRIMITIVE));

		
		return processBulkUploadRFARequest(bulkUploadSelectAllConfig, requestParamList,userId, companyId,fileId,templateId, ipAddress); 			
	}
	
	@Override
	public List<Long> getBulkNotificationRFA(Long companyId, String filterString, Long offset, Long pageSize) {
		return amendmentLetterDao.getBulkNotificationRFA(companyId, filterString, offset, pageSize);
	}
	
	/**
	 * Please use BulkActionEmailNotificationInvoker method going forward...
	 */
	@Transactional
	@Deprecated 
	public void sendBulkEmailNotification(BulkEmailNotification notificationObj, String companyType) throws Exception {
		if (CompanyType.isSSCompany(companyType)){
			
			//	1.	Map each RFA Id with it's corresponding URL
			List<Long> rfaIds = notificationObj.getRfaIds();
			Map<String, String> urlGeneratorParams;
			Map<String, String> emailTemplateUrlParams = new HashMap<String, String>();
			for (Long rfaId : rfaIds){
				urlGeneratorParams = new HashMap<String, String>();
				urlGeneratorParams.put("amendment_id", ""+rfaId);
				String url = sellsideSignatoryEsign.generateUrl(urlGeneratorParams);
				emailTemplateUrlParams.put(""+rfaId, url);
			}
			
			//	2.	Build object for velocity template with URLs and contact details...
			List<BulkEmailVelocityTemplateValues> velocityTemplateObjs = new ArrayList<BulkEmailVelocityTemplateValues>();
			List<User> users = notificationObj.getSignatories();
			for (User user : users){
				BulkEmailVelocityTemplateValues velocityObj = new BulkEmailVelocityTemplateValues();
				velocityObj.setRfaUrls(emailTemplateUrlParams);
				velocityObj.setFname(user.getFname());
				velocityObj.setEmail(user.getEmail());
				velocityTemplateObjs.add(velocityObj);
			}
			
			//	3.	Generate Template and send each template...
			for (BulkEmailVelocityTemplateValues velObj : velocityTemplateObjs){
				List<String> emailList = new ArrayList<String>();
				Map<String, Object> additionalParams = new HashMap<String, Object>();
				emailList.add(velObj.getEmail());
				additionalParams.put("velObj", velObj);
				rfaMailService.sendEmail(emailList, additionalParams, "sellside_bulk_email_notification.vm", "email_rfa_subj.vm");
			}
		}
	}
	
	@Override
	@Transactional
	public void saveErrorMessage(String actionName, Long rfaId, String errorMessage, Long userId) {
		amendmentLetterDao.saveErrorMessage(actionName, rfaId, errorMessage, userId);
	}
	
	@Override
	@Transactional
	public void saveChasers(BulkActionBean bulkNotificationBean){
		amendmentLetterDao.saveChaser(bulkNotificationBean);
	}
	
	@Transactional
	public void updateChasers(List<Long> rfaIds, Long userId) {
		amendmentLetterDao.updateChasers(rfaIds, userId);
	}
	
	private Boolean checkForSleeveInAmendment(AmendmentLetter amendmentLetter)
	{
		if(null != amendmentLetter.getPartyBEntities()) {
        	List<PartyBEntity> partyBEntityList = amendmentLetter.getPartyBEntities();
        	for (PartyBEntity partyBEntity : partyBEntityList) {
        		Long isSleeve = partyBEntity.getEntity().getIsSleeve();
        		if(null != isSleeve && 1 == isSleeve){
        			return true;
        		}
        	}
		}
		return false;
	}

	private String getMlTemplateNameForAmendment(String mlTemplateName, Boolean sleevePresentInAmendment)
	{
		if(sleevePresentInAmendment){
			if(mlTemplateName.equalsIgnoreCase(RFAConstants.LEGACY) || mlTemplateName.equalsIgnoreCase(RFAConstants.LEGACY_NO_AGREEMENT_TYPE_WITH_SLEEVE)){
				return RFAConstants.LEGACY_NO_AGREEMENT_TYPE_WITH_SLEEVE;
			} else {
				return RFAConstants.LEGACY_WITH_AGREEMENT_TYPE_WITH_SLEEVE;
			}
		} else {
			return mlTemplateName;	
		}
	}
	
	@Override
	public void saveBulkUploadFileTemplate(Long templateId, Long userId, Long companyId,Long bulkRequestId) {
		amendmentLetterDao.saveBulkUploadFileTemplate(templateId, userId, companyId,bulkRequestId);
	}
	@Override
	public long getBulkRFAUploadId(Long bulkRequestId){
		return amendmentLetterDao.getBulkRFAUploadId(bulkRequestId);
	}
	@Transactional(propagation = Propagation.NEVER)
	public Long processBulkUploadRFARequest(SelectAllConfig config, List<BulkRequestParam> requestParamList,
			 Long userId, Long companyId,Long fileId,Long templateId, String ipAddress) throws Exception {
		bulkUploadService.validateThrottlingForAction(config.getActionName(), config.getThrottlingLevel(), companyId);
		long bulkRequestId = bulkRequestService.saveBulkUploadRFARequest(config, userId, companyId,fileId);

		bulkUploadService.process(bulkRequestId, userId, companyId, config.getConfigBeanName(), templateId, ipAddress);
		/*bulkUploadService.processSynchronous(bulkRequestId, userId, companyId, config.getConfigBeanName(), templateId, ipAddress);*/
		logger.info("Bulk request id: "+Long.toString(bulkRequestId));
		return bulkRequestId;
	}
	
	@Override
	public void updateBulkUploadFileTemplate(Long fileId, Long bulkRequestId, String status) {
		amendmentLetterDao.updateBulkUploadFileTemplate(fileId,bulkRequestId, status);
	}

	@Override
	public void updateBulkRequest(Long bulkRequestId, String bulkUploadStatusComplete) {
		amendmentLetterDao.updateBulkRequest(bulkRequestId, bulkUploadStatusComplete.toUpperCase());
	}

	@Override
	public boolean isPartyBAlreadyPresent(Long partyBEntityId, Long masterAgreementId) {
		List<Long> partyBs = new ArrayList<Long>();
		partyBs.add(partyBEntityId);
		List<PartyBEntity> existingPartyBList = masterAgreementService.getExistingPartyB(masterAgreementId, partyBs,
				null);
		Map<Long, PartyBEntity> existingPartyBMap = createMapForExistingParties(existingPartyBList);

		PartyBEntity existingPartyB = existingPartyBMap.get(partyBEntityId);

		Boolean entityAlreadyPresent = isEntityAlreadyPresent(partyBEntityId, masterAgreementId, null);

		if (CommonUtil.isNotNull(existingPartyB) && CommonUtil.isNotNull(existingPartyB.getAmendmentStatus())
				&& AmendmentStatus.COMPLETED.getDisplayName()
						.equalsIgnoreCase(existingPartyB.getAmendmentStatus().getDisplayName())
				&& CommonUtil.isNotNull(existingPartyB.getAcknowledgementStatus())
				&& ((PartyBAckStatus.ACCEPTED_SENT.getName()
						.equalsIgnoreCase(existingPartyB.getAcknowledgementStatus().getName())
						&& !existingPartyB.getIsAdded() && !existingPartyB.getIsModified())
						|| (PartyBAckStatus.REJECTED_SENT.getName().equalsIgnoreCase(
								existingPartyB.getAcknowledgementStatus().getName()) && existingPartyB.getIsAdded() && !existingPartyB.getIsModified()))) {
			
			entityAlreadyPresent = false;
			
		} else if (CommonUtil.isNotNull(existingPartyB) && CommonUtil.isNotNull(existingPartyB.getAmendmentStatus())
				&& AmendmentStatus.COMPLETED.getDisplayName()
						.equalsIgnoreCase(existingPartyB.getAmendmentStatus().getDisplayName())
				&& CommonUtil.isNotNull(existingPartyB.getAcknowledgementStatus())
				&& PartyBAckStatus.ACCEPTED_SENT.getName()
						.equalsIgnoreCase(existingPartyB.getAcknowledgementStatus().getName())
				&& (existingPartyB.getIsAdded() || existingPartyB.getIsModified())) {
			
			entityAlreadyPresent = true;
			
		}

		return entityAlreadyPresent;
	}
	
	@Override
	public PartyBEntity isEntityExistingInAnotherRfa(Long entityId, Long masterAgreementId, Long amendmentId, String callingSource){

		List<Long> sleeveEntityIds = new ArrayList<>();
		sleeveEntityIds.add(entityId);
		List<PartyBEntity> existingPartyBList = masterAgreementService.getExistingPartyB(masterAgreementId, sleeveEntityIds, amendmentId, callingSource);
		
		PartyBEntity partyBEntity = new PartyBEntity();
		if (existingPartyBList != null && existingPartyBList.size() > 0) {
			partyBEntity = existingPartyBList.get(0);
			if (partyBEntity != null) return partyBEntity;
		}
		return partyBEntity;
	}

	@Override
	public Long getUploadedFile(Long amendmentLetterId)
			throws Exception {
			return amendmentLetterDao.getUploadedFile(amendmentLetterId);
	}
	
	@Override
	public void addTransitionLogs(Long userId, String ipAddress, Long amendmentLetterId, Long downloadId, String eventName,Long fileId,Long uploadedFileId,int noOfPages,String reason)
			throws Exception {
			amendmentLetterDao.addTransitionLogs(userId, ipAddress, amendmentLetterId, downloadId, eventName,fileId, uploadedFileId,noOfPages,reason);
		
	}

	@Override
	public Long getNextAvailableDownloadId() {
		return amendmentLetterDao.getNextAvailableDownloadId();
		
	}

	@Override
	public void addDownloadTransitionLogs(List<AmendmentDownloadTransitionLog> amendmentDownloadTransitionLogs) {
		amendmentLetterDao.addDownloadTransitionLogs(amendmentDownloadTransitionLogs);
		
	}

	@Override
	public void updatNotifiedByfor(List<Long> rfaIds, Long notifiedByUserId) {
		amendmentLetterDao.updatNotifiedByfor(rfaIds, notifiedByUserId);
		
	}

	@Override
	public String getNextAvailableDocId(Long amendmentId) {
		return amendmentLetterDao.getNextAvailableDocId(amendmentId);
	}
	
	@Override
	public void updateStatus(String status, Long amendmentId,String companyType) {
		amendmentLetterDao.updateStatus(status,amendmentId,companyType);
	}
	
}