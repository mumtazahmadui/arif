package com.markit.ms.rfa.service;

import java.util.List;
import java.util.Map;

import com.markit.ms.common.bean.Lookup;

public interface IRfaUploadTemplateFilterService {

	List<Lookup> uploadTemplateLookUp(Long companyId, String filterString);
	public Map<String,List<String>>  getFilterValues() ;
	public Map<String,String>  getDefaultValue() ;

}
