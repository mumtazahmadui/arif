package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.bean.MasterAgreementBasic;

public class MasterAgreementBasicResultSetExtractor implements
ResultSetExtractor<Map<Long, List<MasterAgreementBasic>>> {

	@Override
	public Map<Long, List<MasterAgreementBasic>> extractData(ResultSet rs) throws SQLException,
	DataAccessException {

		Map<Long, List<MasterAgreementBasic>> agreementMap = new LinkedHashMap<Long, List<MasterAgreementBasic>>();

		while(rs.next()){
			List<MasterAgreementBasic>  masterAgreements = agreementMap.get(rs.getLong("ml_template_id"));

			MasterAgreementBasic masterAgreement = new MasterAgreementBasic();
			masterAgreement.setAgreementDate(rs.getDate("agreement_date"));
			masterAgreement.setInvestmentManager(rs.getString("Investment Manager"));
			masterAgreement.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
			masterAgreement.setPartyA(rs.getString("Party A True Legal Name"));

			if(masterAgreements == null){
				List<MasterAgreementBasic> masterAgreementList = new ArrayList<MasterAgreementBasic>();
				masterAgreementList.add(masterAgreement);
				agreementMap.put(rs.getLong("ml_template_id"), masterAgreementList);
			}else{
				masterAgreements.add(masterAgreement);
				agreementMap.put(rs.getLong("ml_template_id"), masterAgreements);
			}
		}
		return agreementMap;
	}

}
