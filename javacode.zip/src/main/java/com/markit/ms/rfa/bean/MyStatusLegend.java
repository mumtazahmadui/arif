package com.markit.ms.rfa.bean;

public class MyStatusLegend {

	private String label;
	private String initials;
	private String role;
	private String deskLookupReviewDetail;
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getInitials() {
		return initials;
	}
	public void setInitials(String initials) {
		this.initials = initials;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getDeskLookupReviewDetail() {
		return deskLookupReviewDetail;
	}
	public void setDeskLookupReviewDetail(String deskLookupReviewDetail) {
		this.deskLookupReviewDetail = deskLookupReviewDetail;
	}
	
}
