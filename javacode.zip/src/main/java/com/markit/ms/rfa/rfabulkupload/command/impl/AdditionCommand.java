package com.markit.ms.rfa.rfabulkupload.command.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.ActionCommand;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Component
public class AdditionCommand implements ActionCommand {

	@Autowired
	CommonValidator commonValidator;

	public void execute(RfaBulkUploadRow rfaBulkUploadRow, ActionChain nextChain) {

		Boolean partyBExistsInRFA = commonValidator.checkIfEntityExistingInAnotherRfa(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false, null);

		rfaBulkUploadRow.setPartyBExistsInAnotherRfa(partyBExistsInRFA);
		if (partyBExistsInRFA) {
			return;
		}
		Boolean parentEntityAlreadyPresentInML = commonValidator.checkIfEntityExistInMasterList(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false);

		if (CommonUtil.isNull(nextChain) && parentEntityAlreadyPresentInML
				&& (CommonUtil.isNull(rfaBulkUploadRow.getSleeveTrueLegalName())
						&& CommonUtil.isNull(rfaBulkUploadRow.getSleeveClientIdentifier()))) {
			populateAlreadyInMasterlistError(rfaBulkUploadRow,rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());
		}
		if (CommonUtil.isNull(nextChain) && CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveEntityId())) {
			Boolean sleeveAlreadyPresentInML = commonValidator.checkIfEntityExistInMasterList(rfaBulkUploadRow,
					rfaBulkUploadRow.getSleeveEntityId(), rfaBulkUploadRow.getMasterAgreementId(), true);
			if (parentEntityAlreadyPresentInML && sleeveAlreadyPresentInML) {
				populateAlreadyInMasterlistError(rfaBulkUploadRow,
						rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());
				populateAlreadyInMasterlistError(rfaBulkUploadRow,
						rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
			}
		}

		if (!partyBExistsInRFA && !parentEntityAlreadyPresentInML)
			rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.ADDITION);

	}
	
	private void populateAlreadyInMasterlistError(RfaBulkUploadRow rfaBulkUploadRow, String entityIdentifier) {
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		placeHolderMap.put("entityIdentifier", entityIdentifier);
		placeHolderMap.put("requestType", "Addition");
		rfaBulkUploadRow.addError(RFAConstants.ALREADY_IN_MASTERLIST, placeHolderMap);
	}

}
