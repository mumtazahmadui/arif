package com.markit.ms.rfa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.markit.kyc.security.UserUtils;

@Controller
@RequestMapping("/test")
public class TestController {
	
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public @ResponseBody Object getCurrentUserDetails() {
		return UserUtils.getUserxsUserDetailsFromSession();
	}
}
