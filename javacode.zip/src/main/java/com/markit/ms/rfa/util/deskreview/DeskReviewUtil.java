package com.markit.ms.rfa.util.deskreview;

import com.markit.ms.rfa.bean.enumeration.CompanyType;

public class DeskReviewUtil {

	public static Boolean isInvalidGetRequestForDeskReviewHistory(String deskCode, String companyType) {

		if (("BS-D1".equals(deskCode) || "BS-D2".equals(deskCode)) && CompanyType.isSSCompany(companyType))
			return true;

		if (!"BS-D1".equals(deskCode) && !"BS-D2".equals(deskCode) && CompanyType.isBSCompany(companyType))
			return true;

		return false;
	}

	public static Boolean isInvalidPostRequestForDeskReviewHistory(String deskCode, String companyType) {
		return true;
	}

}
