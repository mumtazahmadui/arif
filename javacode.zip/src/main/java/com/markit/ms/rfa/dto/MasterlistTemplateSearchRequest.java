package com.markit.ms.rfa.dto;

import java.util.List;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseSearchRequest;
/**
 * @author prashant.aggarwal
 *
 */
public class MasterlistTemplateSearchRequest extends CommonBaseSearchRequest{

	private List<Lookup> mlTemplateName;

	public List<Lookup> getMlTemplateName() {
		return mlTemplateName;
	}

	public void setMlTemplateName(List<Lookup> mlTemplateName) {
		this.mlTemplateName = mlTemplateName;
	}


}
