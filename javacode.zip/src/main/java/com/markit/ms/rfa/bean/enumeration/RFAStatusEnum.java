package com.markit.ms.rfa.bean.enumeration;

public enum RFAStatusEnum {

	PRINTED("Printed"), NOTIFIED("Notified"), SIGNED("Signed");
	private String name;

	private RFAStatusEnum(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

}
