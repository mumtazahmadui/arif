package com.markit.ms.rfa.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.service.IHTMLParser;
import com.markit.ms.rfa.bean.PartyAPlaceHolder;
import com.markit.ms.rfa.dao.IPartyAPlaceholderDao;
import com.markit.ms.rfa.service.IPartyAPlaceholderService;
import com.markit.ms.rfa.util.CommonUtil;
@Service
public class PartyAPlaceholderServiceImpl implements IPartyAPlaceholderService {

	@Resource private QueryService<Grid> selectPartyAPlaceholder;
	@Resource private QueryService<byte[]> selectPartyAText;
	@Resource private IPartyAPlaceholderDao partyAPlaceholderDao;
	@Resource private IHTMLParser htmlParser;
	
	@Override
	public PartyAPlaceHolder getPartyAPlaceholder(Long amendmentId) throws UnsupportedEncodingException {
		if(!htmlParser.hasPartyAPlaceholder(amendmentId)){
			PartyAPlaceHolder partyAPlaceHolder = new PartyAPlaceHolder();
			partyAPlaceHolder.setPartyAText(CommonUtil.encodeString(""));
			return partyAPlaceHolder;
		}
		
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		PartyAPlaceHolder partyAPlaceHolder  = new PartyAPlaceHolder();
		Grid partyAPlaceholderGrid = selectPartyAPlaceholder.executeQuery(params);
		byte [] preText= selectPartyAText.executeQuery(params);
		Map<String,String> partyAPlaceholderRow = partyAPlaceholderGrid.getRows().get(0);
		
		if(preText == null) {
			StringBuffer buffer = new StringBuffer();
			buffer.append("dated ")
			.append(partyAPlaceholderRow.get("agreement_date"))
			.append(" between ")
			.append(partyAPlaceholderRow.get("investment_manager"))
			.append(" and ")
			.append(partyAPlaceholderRow.get("counterparty_name"));
			partyAPlaceHolder.setPartyAText(CommonUtil.encodeString(buffer.toString()));
		} else {
			partyAPlaceHolder.setPartyAText(CommonUtil.getValueFromBase64(preText));
		}
		return partyAPlaceHolder;
	}
	
	
	@Override
	public void updatePartyAPlaceholder(PartyAPlaceHolder partyAPlaceholder, Long amendmentId, Long userId) throws UnsupportedEncodingException {
		partyAPlaceholderDao.updatePartyAPlaceholder(partyAPlaceholder, amendmentId, userId);
	}

}
