package com.markit.ms.rfa.util;

import java.util.Comparator;

import com.markit.ms.rfa.bean.MasterlistDownload;

public class MasterlistDownloadModifiedDateComparator implements Comparator<MasterlistDownload>
{
	@Override
	public int compare(MasterlistDownload o1, MasterlistDownload o2) {
		if(null == o1.getModifiedDate() && null == o2.getModifiedDate()) {
			return 0;
		} else if(null != o1.getModifiedDate() && null == o2.getModifiedDate()) {
			return -1;
		} else if(null == o1.getModifiedDate() && null != o2.getModifiedDate()) {
			return 1;
		} else if(null != o1.getModifiedDate() && null != o2.getModifiedDate()) {
			return o2.getModifiedDate().compareTo(o1.getModifiedDate());
		}
		return 0;
	}
}
