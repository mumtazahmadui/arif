package com.markit.ms.rfa.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseRequest;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.service.IExhibitService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;

@RestController
@RequestMapping(value = "/v1/amendment_letter")
@Api(value = "exhibit" , description = "Exhibit APIs")
public class ExhibitController {
	
	@Autowired
    private IExhibitService exhibitService;
	    
    @RequestMapping(value = "{amendmentId}/exhibit",method = RequestMethod.PUT)
    public CommonBaseResponse<Exhibit> updateExhibit(@PathVariable Long amendmentId
    		, @RequestBody CommonBaseRequest<Exhibit> exhibitRequest, HttpServletRequest request) throws Exception{
    	 Long companyId = CommonUtil.getCompanyIdFromSession(request);
    	 String companyType = CommonUtil.getCompanyTypeFromSession(request);
    	 CommonBaseResponse<Exhibit> response = new  CommonBaseResponse<Exhibit>();
    	 Exhibit exhibit = exhibitService.updateExhibit(companyId, companyType
    			 , exhibitRequest.getUserId(), exhibitRequest.getData());
    	 response.setData(exhibit);
    	return response;              
    }
}
