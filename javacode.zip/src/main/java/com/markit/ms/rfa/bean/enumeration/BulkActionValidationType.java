package com.markit.ms.rfa.bean.enumeration;

public enum BulkActionValidationType {

	EXHIBIT_VALUE("exhibit-value", "Exhibit Value"), 
	
	E_SIGN("e-sign", "E-Sign"),
	
	SEND("send", "Send"),
	
	SIGNATORY_NOTIFICATION("signatory-notification", "Signatory Notification"),
	
	CHASER("chaser", "Chaser Notification"),

	ERROR_NOTIFICATION("error-notification", "Error Notification"),

	SUCCESS_NOTIFICATION("success-notification", "Success Notification"); 

	private String type;

	private String name;

	private BulkActionValidationType(String type, String name) {
		this.type = type;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public static BulkActionValidationType fromType(String type) {
		for (BulkActionValidationType anEnum : BulkActionValidationType.values()) {
			if (anEnum.type.equalsIgnoreCase(type))
				return anEnum;
		}
		return null;
	}
}