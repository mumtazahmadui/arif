package com.markit.ms.rfa.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.EnumMap;
import java.util.Hashtable;
import java.util.Map;

import javax.imageio.ImageIO;

import org.apache.commons.lang.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.ChecksumException;
import com.google.zxing.DecodeHintType;
import com.google.zxing.EncodeHintType;
import com.google.zxing.FormatException;
import com.google.zxing.LuminanceSource;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

public class QRCodeUtil {

	private static BufferedImage createQRImage(String qrCodeText, int qrCodeSize) throws WriterException, IOException {
		
		Hashtable<EncodeHintType, ErrorCorrectionLevel> hintMap = new Hashtable<>();
		hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
		
		QRCodeWriter qrCodeWriter = new QRCodeWriter();
		BitMatrix bitMatrix = qrCodeWriter.encode(qrCodeText, BarcodeFormat.QR_CODE, qrCodeSize, qrCodeSize, hintMap);

		return MatrixToImageWriter.toBufferedImage(bitMatrix);
	}

	/*public static byte[] addQRCodeToByteArray(byte[] content, String qrCodeText) {
		
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			BufferedImage qrImage = createQRImage(qrCodeText, 60);
			PDDocument document = PDDocument.load(new ByteArrayInputStream(content));
			PDXObjectImage pdImage = new PDPixelMap(document, qrImage);

			PDPage page = null;
			PDPageContentStream contentStream = null;
			float width = 0;

			for (int i = 0; i < document.getNumberOfPages(); i++) {
				page = (PDPage) document.getDocumentCatalog().getAllPages().get(i);
				PDRectangle pdRectangle = page.getArtBox();
				
				width = page.getArtBox().getWidth();
				contentStream = new PDPageContentStream(document, page, true, false);
				
				contentStream.drawLine(pdRectangle.getLowerLeftX() + 30, pdRectangle.getLowerLeftY() + 80,
						pdRectangle.getLowerLeftX() + (width-55), pdRectangle.getLowerLeftY() + 80);
				contentStream.drawImage(pdImage, width/2, 15);
				contentStream.close();
			}

			document.save(out);
			document.close();
			content = out.toByteArray();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return content;
	}*/
	
/*	public static byte[] addQRCodeToByteArrayForExhibitPDF(byte[] content, String qrCodeText,int qrCodeSize) {
		
		try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
			BufferedImage qrImage = createQRImage(qrCodeText, qrCodeSize);
			PDDocument document = PDDocument.load(new ByteArrayInputStream(content));
			PDXObjectImage pdImage = new PDPixelMap(document, qrImage);

			PDPage page = null;
			PDPageContentStream contentStream = null;
			float width = 0;

			for (int i = 0; i < document.getNumberOfPages(); i++) {
				page = (PDPage) document.getDocumentCatalog().getAllPages().get(i);
				PDRectangle pdRectangle = page.getArtBox();
				
				width = page.getArtBox().getWidth();
				System.out.println(width);
				contentStream = new PDPageContentStream(document, page, true, false);
				
				contentStream.drawLine(pdRectangle.getLowerLeftX() + 30, pdRectangle.getLowerLeftY() + qrCodeSize + 20,
						pdRectangle.getLowerLeftX() + (width-55), pdRectangle.getLowerLeftY() + qrCodeSize + 20);
				contentStream.drawImage(pdImage, width/2, 15);
				contentStream.close();
			}

			document.save(out);
			document.close();
			content = out.toByteArray();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return content;
	}*/

	public static String getQRCode(String qrCodeText, int qrCodeSize) {
		
		BufferedImage bufferedImage = generateQRCode(qrCodeText, qrCodeSize);
	    final ByteArrayOutputStream os = new ByteArrayOutputStream();
	    try {
			ImageIO.write(bufferedImage, "jpg", os);
			
		} catch (IOException e) {
			System.out.println("Error while creating QR Code");
			e.printStackTrace();
		} finally {
			try {
				os.close();
			} catch (IOException e) {
				System.out.println("Error while creating QR Code");
				e.printStackTrace();
			}
		}
	    return Base64.getEncoder().encodeToString(os.toByteArray());
	   
	}
public static BufferedImage  generateQRCode(String qrCodeText,int qrCodeSize) {
	
			BufferedImage qrImage = null;
			try {
				qrImage = createQRImage(qrCodeText, qrCodeSize);
			} catch (WriterException | IOException e) {
				System.out.println("Error while creating QR Code");
				e.printStackTrace();
			}
			
		return qrImage;
	}

	public static Boolean isPdfWithValidQR(byte[] content, String qrCodeText) throws IOException {

		PDDocument document=null;
		PDPage page=null;
		Boolean validQRpresent = null;

		try{
			document = PDDocument.load(new ByteArrayInputStream(content));

			for (int i = 0; i < document.getNumberOfPages(); i++) {
				page = (PDPage) document.getDocumentCatalog().getAllPages().get(i);
				String textFromPdf = decodeQRCode(page.convertToImage(BufferedImage.TYPE_INT_RGB, 200), i);

				if (StringUtils.isEmpty(textFromPdf)) {
					//QR code couldn't be read
					validQRpresent = false;
					break;
				}else if(StringUtils.equalsIgnoreCase(qrCodeText, textFromPdf)){
					//QR code matches
					validQRpresent = true;
				}else {
					//QR code doesn't match
					validQRpresent = false;
					break;
				}
			}
		}catch(IOException ioException){
			if(document!=null) {
				document.close();
			}
		}
		return validQRpresent;
	}
		
	private static String decodeQRCode(BufferedImage bufferedImage, int i){
		LuminanceSource source = new BufferedImageLuminanceSource(bufferedImage);
		BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

		Map<DecodeHintType,Object> tmpHintsMap = new EnumMap<DecodeHintType, Object>(DecodeHintType.class);
        tmpHintsMap.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
		
		try {
			Result result = new QRCodeReader().decode(bitmap,tmpHintsMap);
			return result.getText();
		} catch (NotFoundException | ChecksumException | FormatException e) {
			System.out.println("QR code not found on page " + (i + 1));
			return null;
		}
	}

	public static Boolean isImageWithValidQR(byte[] pdfContent, String qrCodeText) throws IOException {
		Boolean validQRpresent = null;
		ByteArrayInputStream bais = null;
		try {
			bais = new ByteArrayInputStream(pdfContent);
			String textFromPdf = decodeQRCode(ImageIO.read(bais), 1);
			if (StringUtils.isNotEmpty(textFromPdf) && StringUtils.equalsIgnoreCase(qrCodeText, textFromPdf)) {
				// QR code matched
				validQRpresent = true;
			} else {
				// QR code not matches
				validQRpresent = false;
			}
		} catch (IOException ioException) {
			ioException.getMessage();
		} finally {
			if (null != bais) {
				bais.close();
			}
		}
		return validQRpresent;
	}
    
}
