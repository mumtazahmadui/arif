package com.markit.ms.rfa.security.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.google.common.base.Preconditions;
import com.markit.kyc.commons.util.collections.CollectionUtils;
import com.markit.ms.rfa.security.domain.McpmUser;

public class McpmSecurityUserRepositoryImpl implements McpmSecurityUserRepository {

	private static final String DEFAULT_QUERY_USER_SQL = ""
			+ " select "
			+ "  uid as userId"
			+ " ,username as loginName"
			+ " ,fname as firstName"
			+ " ,lname as lastName"
			+ " ,mname as middleName"
			+ " ,email"
			+ " ,u.companyId"
			+ " ,c.type"
			+ " from mc_users u"
			+ " inner join mc_companies c on (c.companyid = u.companyid and c.deleted = 0)"
			+ " where ufe_user_key = :accountUniqueId";
	
	private static final String DEFAULT_QUERY_USER_PERMISSION = ""
			+ "select distinct p.pname from mc_users u\n"
			+ "inner join mc_companies c on (c.companyid = u.companyid and c.deleted = 0)\n"
			+ "inner join mc_user_roles ur on (u.uid = ur.uid and ur.deleted = 0)\n"
			+ "inner join mc_roles r on (r.id = ur.rid and r.deleted = 0)\n"
			+ "inner join mc_role_to_permissions rp on (rp.rid = r.id and rp.deleted = 0)\n"
			+ "inner join mc_role_permissions p on (p.id = rp.pid)\n"
			+ "where u.deleted = 0 and u.uid = :userId\n"
			+ "and u.uid not in (select uid from mc_user_roles where rid = 7 and deleted = 0 and uid = u.uid)";


	private final static RowMapper<McpmUser> DEFAULT_MCPM_USER_ROWMAPPER = new RowMapper<McpmUser> () {

		@Override
		public McpmUser mapRow(ResultSet rs, int rowNum) throws SQLException {
		
			McpmUser mcpmUser = new McpmUser();
			
			mcpmUser.setId(rs.getLong("userId"));
			mcpmUser.setLoginName(rs.getString("loginName"));
			mcpmUser.setFirstName(rs.getString("firstName"));
			mcpmUser.setLastName(rs.getString("lastName"));
			mcpmUser.setMiddleName(rs.getString("middleName"));
			mcpmUser.setEmail(rs.getString("email"));
			mcpmUser.setCompanyId(rs.getLong("companyId"));
			mcpmUser.setCompanyType(rs.getString("type"));
			
			return mcpmUser;
		}
		
	};
	
	private final static RowMapper<String> DEFAULT_MCPM_USER_PERMISSION = new RowMapper<String> () {

		@Override
		public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		
			return rs.getString("pname");
		}
		
	};
	
	
	@Resource private NamedParameterJdbcTemplate jdbcTemplate;
	
	private String queryUserSql = DEFAULT_QUERY_USER_SQL;
	private String queryUserPermissionSql = DEFAULT_QUERY_USER_PERMISSION;

	private RowMapper<McpmUser> mcpmUserRowMapper = DEFAULT_MCPM_USER_ROWMAPPER;
	private RowMapper<String>	mcpmUserPermissionRowMapper = DEFAULT_MCPM_USER_PERMISSION;
	
	
	@Override
	public McpmUser findByAccountUniqueId(String accountUniqueId) {
	
		List<McpmUser> mcpmUserResultList = jdbcTemplate.query(queryUserSql, CollectionUtils.map("accountUniqueId", accountUniqueId), mcpmUserRowMapper);

		Preconditions.checkArgument(mcpmUserResultList != null);
		Preconditions.checkArgument(mcpmUserResultList.size() == 1);
		
		McpmUser mcpmUser = mcpmUserResultList.get(0);
		
		List<String> permissionList = jdbcTemplate.query(queryUserPermissionSql, CollectionUtils.map("userId", mcpmUser.getId()), mcpmUserPermissionRowMapper);

		Preconditions.checkArgument(permissionList != null);
		
		mcpmUser.setPermissions(permissionList);
		
		return mcpmUser;
	}

}
