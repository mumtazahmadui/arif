package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.rfa.bean.CompanyAmendmentStats;
import com.markit.ms.rfa.bean.MyStatusLegend;

public interface IDashboardDao {

	public CompanyAmendmentStats getAmendmentStats(long companyid);
	
	public List<MyStatusLegend> getMyStatusLegend(Long companyid, Long userId);
	
}
