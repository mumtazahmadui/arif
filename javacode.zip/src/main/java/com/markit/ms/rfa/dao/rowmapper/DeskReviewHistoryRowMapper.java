package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.dto.PartyBDeskReviewDetails;

/**
 * This class maps desk review history data to
 * required details <code>PartyBDeskReviewDetails</code>
 * 
 * @since RFA5.0
 *
 */
public class DeskReviewHistoryRowMapper implements RowMapper<PartyBDeskReviewDetails> {
	@Override
	public PartyBDeskReviewDetails mapRow(ResultSet rs, int rowNum) throws SQLException {

		PartyBDeskReviewDetails data = new PartyBDeskReviewDetails();
		data.setId(rs.getLong("id"));
		data.setDeskStatus(rs.getInt("isReviewed"));
		Date date = rs.getDate("actionedDate");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-YYYY");
		data.setActionDate(sdf.format(date));
		data.setActionedBy(rs.getString("actionedBy"));
		data.setTotalAuditCount(rs.getInt("totalCount"));
		return data;
	}

}
