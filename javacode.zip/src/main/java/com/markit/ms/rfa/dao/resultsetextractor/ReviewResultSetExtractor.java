package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Lookup;

public class ReviewResultSetExtractor implements ResultSetExtractor<List<Lookup>> {

	@Override
	public List<Lookup> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		List<Lookup> lookupList = new ArrayList<Lookup>();
		while (rs.next()){
			Lookup lookup = new Lookup();
			lookup.setId(rs.getLong("RFA_LU_REVIEW_ID"));
			lookup.setValue(rs.getString("NAME"));
			lookupList.add(lookup);			
		}
		return lookupList;
	}
	
}
