package com.markit.ms.rfa.rfabulkupload.command;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Component
public class CommonValidator {

	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	public Boolean checkIfEntityExistingInAnotherRfa(RfaBulkUploadRow rfaBulkUploadRow, Long entityId,
			Long masterAgreementId, Boolean isSleeve, String callingSource) {
		PartyBEntity existingPartyB = amendmentLetterService.isEntityExistingInAnotherRfa(entityId, masterAgreementId,
				null, callingSource);

		Boolean entityExistsInRFA = checkIfExistingForInFlightAmendment(existingPartyB);
		if (entityExistsInRFA) {
			Map<String, String> placeHolderMap = new HashMap<String, String>();
			if (isSleeve)
				placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
			else
				placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());

			if (CommonUtil.isNotNull(existingPartyB.getIsAdded()) && existingPartyB.getIsAdded()
					&& !existingPartyB.getIsModified())
				placeHolderMap.put("requestType", "Addition");
			else if (CommonUtil.isNotNull(existingPartyB.getIsModified()) && existingPartyB.getIsModified()
					&& CommonUtil.isNotNull(existingPartyB.getFundNameChange())
					&& existingPartyB.getFundNameChange().getId() != 0)
				placeHolderMap.put("requestType", "FNC");
			else if (CommonUtil.isNotNull(existingPartyB.getIsModified()) && existingPartyB.getIsModified()
					&& CommonUtil.isNotNull(existingPartyB.getExhibitValueChange())
					&& existingPartyB.getExhibitValueChange().getId() != 0)
				placeHolderMap.put("requestType", "EVC");
			else if (CommonUtil.isNotNull(existingPartyB.getIsAdded()) && !existingPartyB.getIsAdded())
				placeHolderMap.put("requestType", "Removal");

			placeHolderMap.put("rfaId", String.valueOf(existingPartyB.getAmendmentId()));

			rfaBulkUploadRow.addError(RFAConstants.PARTYB_ALREADY_ADDED_IN_ANOTHER_RFA, placeHolderMap);
		}
		return entityExistsInRFA;

	}

	public Boolean checkIfEntityExistingInRemovalTab(RfaBulkUploadRow rfaBulkUploadRow, Long entityId,
			Long masterAgreementId) {
		PartyBEntity existingPartyB = amendmentLetterService.isEntityExistingInAnotherRfa(entityId, masterAgreementId,
				null);
		Boolean entityExistsInRemoveTab = false;
		if (CommonUtil.isNotNull(existingPartyB.getIsAdded()) && !existingPartyB.getIsAdded()
				&& !existingPartyB.getAcknowledgementStatus().equals(PartyBAckStatus.REJECTED_SENT)
				&& (existingPartyB.getAmendmentStatus() == AmendmentStatus.COMPLETED))
			entityExistsInRemoveTab = true;
		return entityExistsInRemoveTab;
	}

	public Boolean checkIfExistingForInFlightAmendment(PartyBEntity partyB) {
		if (CommonUtil.isNotNull(partyB) && (partyB.getAmendmentId() != null) && (partyB.getAmendmentId() > 0)
				&& CommonUtil.isNotNull(partyB.getAcknowledgementStatus())
				&& ((partyB.getAcknowledgementStatus() != PartyBAckStatus.REJECTED_SENT)
						&& (partyB.getAcknowledgementStatus() != PartyBAckStatus.WITHDRAWN)
						&& (partyB.getAcknowledgementStatus() != PartyBAckStatus.ACCEPTED_SENT))
				|| (CommonUtil.isNull(partyB.getAcknowledgementStatus())
						&& ((partyB.getAmendmentStatus() == AmendmentStatus.DRAFT)
								|| partyB.getAmendmentStatus() == AmendmentStatus.SUBMITTED
								|| partyB.getAmendmentStatus() == AmendmentStatus.REJECTED
								|| partyB.getAmendmentStatus() == AmendmentStatus.RECALLED))) {
			return true;
		}

		return false;
	}

	public Boolean checkIfEntityExistInMasterList(RfaBulkUploadRow rfaBulkUploadRow, Long entityId,
			Long masterAgreementId, Boolean isSleeve) {
		Boolean entityAlreadyPresent = false;

		entityAlreadyPresent = amendmentLetterService.isPartyBAlreadyPresent(entityId, masterAgreementId);

		return entityAlreadyPresent;
	}

	public Boolean validateParentSleeveRelation(Long sleeveEntityId, Long parentEntityId, Long companyId) {
		Long mcpmParentEntityId = uploadTemplateDAO.getParentEntityId(sleeveEntityId, companyId);

		if ((CommonUtil.isNotNull(mcpmParentEntityId) && mcpmParentEntityId != 0)
				&& CommonUtil.isNotNull(parentEntityId) && !parentEntityId.equals(mcpmParentEntityId)) {
			return false;

		}
		return true;
	}
	
	public void populateConflictActionErrors(RfaBulkUploadRow rfaBulkUploadRow, String errorMessage) {
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		Boolean sleeveIdentifier = false;
		String requestType = null;
		for (BulkUploadAction action : rfaBulkUploadRow.getRequestIdentified()) {
			requestType = action.getName().toString();
			requestType.concat("/");
			if (action.getType().contains("Sleeve"))
				sleeveIdentifier = true;
		}
		requestType.substring(0, requestType.length() - 1);
		placeHolderMap.put("requestType", requestType);
		if (sleeveIdentifier && rfaBulkUploadRow.getRequestIdentified().size() == 1)
			placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
		else
			placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());
		rfaBulkUploadRow.addError(errorMessage, placeHolderMap);
	}

}
