package com.markit.ms.rfa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.model.CommonBaseSearchRequest;
import com.markit.ms.rfa.dao.IEntityDao;
import com.markit.ms.rfa.service.IEntityService;
@Service
public class EntityServiceImpl implements IEntityService {

	@Autowired
	private IEntityDao entityDao;

	@Override
	public List<Entity> getAllEntities(Long companyId, String filterString, CommonBaseSearchRequest searchRequest) {
		List<Entity> entities = entityDao.getEntities(companyId, filterString, searchRequest);
		return entities;
	}
	
	@Override
	public List<Entity> getAllSleeveEntities(Long companyId, String filterString, Long offSet, Long pageSize) {
		List<Entity> entities = entityDao.getAllSleeveEntities(companyId, filterString, offSet, pageSize);
		return entities;
		
	}
	
	@Override
	public List<Entity> getSleeveAccountsForParentEntities(Long companyId, List<Long> masterlistIds, List<Long> parentEntityIds) {
		List<Entity> entities = entityDao.getSleeveAccountsForParentEntities(companyId, masterlistIds, parentEntityIds);
		return entities;
	}
	
	public List<Entity> getMcpmChildEntities(Long companyId, Long parentEntityId){
		List<Entity> entities = entityDao.getMcpmChildEntities(companyId, parentEntityId);
		return entities;
	}

	@Override
	public Entity getParentEntity(Long entityId) {
		return entityDao.getParentEntity(entityId);
	}

	@Override
	public Entity getPartyAEntity(String legalName) {
		Entity entity = null;
		try {
			entity = entityDao.getPartyAEntity(legalName);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return entity;
	}
}
