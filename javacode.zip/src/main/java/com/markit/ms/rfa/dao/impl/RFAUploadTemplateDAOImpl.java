package com.markit.ms.rfa.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.FundNameChange;
import com.markit.ms.rfa.bean.MCPMClientIdentifier;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.bean.RFAUploadTemplateFile;
import com.markit.ms.rfa.bean.ReviewData;
import com.markit.ms.rfa.bean.RfaUploadTemplateDownload;
import com.markit.ms.rfa.bean.SleeveEntityRequest;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.dao.rowmapper.EntityRowMapper;
import com.markit.ms.rfa.dao.rowmapper.ReviewRowMapper;
import com.markit.ms.rfa.dto.RfaUploadTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAGenericException;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author sucheta.krishali
 *
 */
@Repository
public class RFAUploadTemplateDAOImpl extends BaseDAOImpl implements IRfaUploadTemplateDAO
{
	@Value("${SAVE_UPLOAD_TEMPLATE}")
	private String SAVE_UPLOAD_TEMPLATE;
	
	@Value("${SAVE_UPLOAD_TEMPLATE_FIELD}")
	private String SAVE_UPLOAD_TEMPLATE_FIELD;
	
	@Value("${GET_UPLOAD_TEMPLATE_BY_ID}")
	private String GET_UPLOAD_TEMPLATE_BY_ID;
	
	
	@Value("${GET_COUNT_UPLOAD_TEMPLATE_BY_NAME}")
	private String GET_COUNT_UPLOAD_TEMPLATE_BY_NAME;
	
	@Value("${COUNT_UPLOAD_ID_BY_UPLOADID}")
	private String COUNT_UPLOAD_ID_BY_UPLOADID;
	
	
	@Value("${GET_UPLOAD_TEMPLATE_FIELDS_BY_UPLOAD_ID}")
	private String GET_UPLOAD_TEMPLATE_FIELDS_BY_UPLOAD_ID;
	
	@Value("${DELETE_UPLOAD_TEMPLATE}")
	private String DELETE_UPLOAD_TEMPLATE;
	
	
	@Value("${GET_COUNT_UPLOAD_TEMPLATE_BY_ID}")
	private String GET_COUNT_UPLOAD_TEMPLATE_BY_ID;
	
	@Value("${DELETE_UPLOAD_TEMPLATE_FIELDS}")
	private String DELETE_UPLOAD_TEMPLATE_FIELDS;
	

	@Value("${GET_UPLOAD_TEMPLATES_BY_IDS}")
	private String GET_UPLOAD_TEMPLATES_BY_IDS;
	
	@Value("${GET_UPLOAD_TEMPLATE_COLUMNS}")
	private String GET_UPLOAD_TEMPLATE_COLUMNS;
	
	@Value("${GET_UPLOAD_TEMPLATE_FILE_ID}")
	private String GET_UPLOAD_TEMPLATE_FILE_ID;
	
	@Value("${GET_SLEEVE_ENTITY_ID}")
	private String GET_SLEEVE_ENTITY_ID;
	
	@Value("${LINK_SLEEVE_AND_PARENT}")
	private String LINK_SLEEVE_AND_PARENT;
	
	@Value("${GET_PARENT_ENTITY_RECORD}")
	private String GET_PARENT_ENTITY_RECORD;	

	@Value("${UPDATE_UPLOAD_TEMPLATE_NAME}")
	private String UPDATE_UPLOAD_TEMPLATE_NAME;
	
	@Value("${GET_ENTITY_BY_SLEEVE_CLIENT_IDENTIFER}")
	private String GET_ENTITY_BY_SLEEVE_CLIENT_IDENTIFER;
	
	@Value("${GET_PARENT_ENTITY_ID}")
	private String GET_PARENT_ENTITY_ID;
	
	@Value("${GET_SLEEVE_PARENT_ENTITY_ID}")
	private String GET_SLEEVE_PARENT_ENTITY_ID;

	@Value("${GET_SLEEVE_ENTITY_BY_PARENT_ID}")
	private String GET_SLEEVE_ENTITY_BY_PARENT_ID;
	
	
	
	
	@Transactional
	@Override
	public RFAUploadTemplate saveUploadTemplate(RFAUploadTemplate uploadTemplate) {
		

		SqlParameterSource paramSourceUT = new BeanPropertySqlParameterSource(uploadTemplate);	        	
		KeyHolder keyHolder = new GeneratedKeyHolder();

		namedParameterJdbcTemplate.update(SAVE_UPLOAD_TEMPLATE, paramSourceUT, keyHolder);

		List<SqlParameterSource> paramSourceTF = new ArrayList<SqlParameterSource>();
		List<RFAUploadTemplateField> templateFields = uploadTemplate.getTemplateFields();

		for(RFAUploadTemplateField templateField: templateFields){
			templateField.setUploadTemplateId(keyHolder.getKey().longValue());
			paramSourceTF.add(new BeanPropertySqlParameterSource(templateField));
		}
		namedParameterJdbcTemplate.batchUpdate(SAVE_UPLOAD_TEMPLATE_FIELD, paramSourceTF.toArray(new SqlParameterSource[paramSourceTF.size()])); 	        		

		uploadTemplate.setId(keyHolder.getKey().longValue());
		return  getUploadTemplateById(uploadTemplate.getId());		 
	}
	

	@Override
	public RFAUploadTemplate getUploadTemplateById(Long id)
	{      
		RFAUploadTemplate uploadTemplate = null;
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);

	
		Long countMltExists = namedParameterJdbcTemplate.queryForObject(COUNT_UPLOAD_ID_BY_UPLOADID, paramSource, Long.class);
		if(countMltExists == 0){			
			throw new RFAGenericException(RFAConstants.RFA_UPLOAD_TEMPLATE_DOESNT_EXIST, HttpStatus.NOT_FOUND);
		}else{
			uploadTemplate = namedParameterJdbcTemplate.queryForObject(GET_UPLOAD_TEMPLATE_BY_ID, paramSource, new BeanPropertyRowMapper<RFAUploadTemplate>(RFAUploadTemplate.class));
			List<RFAUploadTemplateField> templateFields = getTemplateFieldsByUploadTemplateId(id);
			uploadTemplate.setTemplateFields(templateFields);
		}
		return uploadTemplate;
	}
	
	@Override
	public Long getCountUploadTemplateByName(String templateName,Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
								.addValue("templateName", templateName)
								.addValue("companyId", companyId);

		Long id = namedParameterJdbcTemplate.queryForObject(GET_COUNT_UPLOAD_TEMPLATE_BY_NAME, paramSource, Long.class);
		return id;
	}
	
	
	@Override
	public Long getCountUploadTemplateById(Long templateId,Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
								.addValue("id", templateId)
								.addValue("companyId", companyId);

		Long id = namedParameterJdbcTemplate.queryForObject(GET_COUNT_UPLOAD_TEMPLATE_BY_ID, paramSource, Long.class);
		return id;
	}
	

	@Override
	public List<RFAUploadTemplateField> getTemplateFieldsByUploadTemplateId(Long uploadTemplateId){        
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("uploadTemplateId", uploadTemplateId);
		List<RFAUploadTemplateField> templateFields = namedParameterJdbcTemplate.query(GET_UPLOAD_TEMPLATE_FIELDS_BY_UPLOAD_ID, paramSource, 
				new RowMapper<RFAUploadTemplateField>() {

					@Override
					public RFAUploadTemplateField mapRow(ResultSet rs, int rowNum) throws SQLException {

						RFAUploadTemplateField rutf = new RFAUploadTemplateField();
						
						rutf.setId(rs.getLong("id"));
						rutf.setFieldIdentifier(rs.getString("field_identifier"));
						rutf.setFieldLabel(rs.getString("field_label"));
						rutf.setRule(rs.getString("rules"));
						rutf.setAliasLabel(rs.getString("alias_label"));
						rutf.setEntityIdentifier(rs.getInt("entity_identifier"));
						rutf.setUploadTemplateId(rs.getLong("upload_template_id"));
						rutf.setIsRequired(rs.getInt("is_required"));
						
					
						return rutf;
					}
				});
		return templateFields;
	}


	@Override
	public Integer deleteUploadTemplateById(Long id) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);
		Integer count = namedParameterJdbcTemplate.update(DELETE_UPLOAD_TEMPLATE, paramSource);
		return count;
	}
	


	
	
	
	@Override
	public RFAUploadTemplate editUploadTemplate(RFAUploadTemplate uploadTemplate) {
		

		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", uploadTemplate.getId());
		Integer count = namedParameterJdbcTemplate.update(DELETE_UPLOAD_TEMPLATE_FIELDS, paramSource);
		if(count == 0){			
			throw new RFAGenericException(RFAConstants.RFA_UPLOAD_TEMPLATE_FIELDS_DONT_EXIST, HttpStatus.NOT_FOUND);
		}

		List<SqlParameterSource> paramSourceTF = new ArrayList<SqlParameterSource>();
		List<RFAUploadTemplateField> templateFields = uploadTemplate.getTemplateFields();

		for(RFAUploadTemplateField templateField: templateFields){
			templateField.setUploadTemplateId(uploadTemplate.getId().longValue());
			paramSourceTF.add(new BeanPropertySqlParameterSource(templateField));			
		}
		namedParameterJdbcTemplate.batchUpdate(SAVE_UPLOAD_TEMPLATE_FIELD, paramSourceTF.toArray(new SqlParameterSource[paramSourceTF.size()])); 	        		
		
		SqlParameterSource paramSourceUpdate = new MapSqlParameterSource().addValue("templateName", uploadTemplate.getTemplateName())
												.addValue("templateId", uploadTemplate.getId())
												.addValue("companyId", uploadTemplate.getCompanyId())
												.addValue("modifiedBy", uploadTemplate.getModifiedBy());

		Integer countUpdate = namedParameterJdbcTemplate.update(UPDATE_UPLOAD_TEMPLATE_NAME, paramSourceUpdate);

			return  getUploadTemplateById(uploadTemplate.getId());		 
	}


	@Override
	public List<RFAUploadTemplate> getUploadTemplateGrid(Long companyId,
			RfaUploadTemplateSearchRequest templateSearchRequest) {
		StringBuilder whereCondition = new StringBuilder();
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId)
				.addValue("offset", templateSearchRequest.getOffSet())
				.addValue("page_size", templateSearchRequest.getPageSize());		
		
		List<Lookup> uploadTemplateNameLookUps =  templateSearchRequest.getUploadTemplateName();
		if(null != uploadTemplateNameLookUps && uploadTemplateNameLookUps.size() > 0) {
			List<Long> uploadTemplateIds = new ArrayList<Long>();
			for (Lookup lookup : uploadTemplateNameLookUps) {
				uploadTemplateIds.add(lookup.getId());
			}
			paramSource.addValue("uploadTemplateIds", uploadTemplateIds);
			whereCondition.append(" and rut.id in (:uploadTemplateIds)");
		}
		
		String gridQuery = GET_UPLOAD_TEMPLATES_BY_IDS.replaceAll("whereCondition", whereCondition.toString());
		
		List<RFAUploadTemplate> uploadTemplates = namedParameterJdbcTemplate.query(gridQuery, paramSource, new BeanPropertyRowMapper<RFAUploadTemplate>(RFAUploadTemplate.class));

		return uploadTemplates;
	}


	@Override
	public List<RfaUploadTemplateDownload> getUploadTemplateColumns(Long templateId) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("templateId", templateId);
		List<RfaUploadTemplateDownload> uploadTemplate = namedParameterJdbcTemplate.query(GET_UPLOAD_TEMPLATE_COLUMNS, paramSource, new BeanPropertyRowMapper<RfaUploadTemplateDownload>(RfaUploadTemplateDownload.class));
		return uploadTemplate;
	}
	
	@Override
		public RFAUploadTemplateFile getUploadedFileId(Long bulkRequestId){
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("bulkRequestId", bulkRequestId);
		RFAUploadTemplateFile templateFiles = namedParameterJdbcTemplate.queryForObject(GET_UPLOAD_TEMPLATE_FILE_ID, paramSource, new BeanPropertyRowMapper<RFAUploadTemplateFile>(RFAUploadTemplateFile.class));
		return templateFiles;
	}
	@Override
	public Long getSleeveEntity(String name,Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
								.addValue("name", name)
								.addValue("companyId", companyId);
		try
		{
		Long id = namedParameterJdbcTemplate.queryForObject(GET_SLEEVE_ENTITY_ID, paramSource, Long.class);
		return id;
	}
	catch(EmptyResultDataAccessException e)
	{
		return null;
	}
	}
    public void linkSleeveAndParent(Long parentEntityId, Long sleeveEntityId, Long companyId) {
    	SqlParameterSource params = new MapSqlParameterSource()
    		.addValue("parentEntityId", parentEntityId)
	    	.addValue("sleeveEntityId", sleeveEntityId)
	    	.addValue("companyId",companyId);
    	namedParameterJdbcTemplate.update(LINK_SLEEVE_AND_PARENT, params);
    }
	@Override
	public SleeveEntityRequest getParentEntityRecord(Long entityId,Long companyId){
	SqlParameterSource paramSource = new MapSqlParameterSource()
	.addValue("entityId", entityId)
	.addValue("companyId", companyId);
	SleeveEntityRequest templateFiles = namedParameterJdbcTemplate.queryForObject(GET_PARENT_ENTITY_RECORD, paramSource, new BeanPropertyRowMapper<SleeveEntityRequest>(SleeveEntityRequest.class));
	return templateFiles;
}

	@Override
	public MCPMClientIdentifier getEntityBySleeveIdentifier(String sleeveClientIdentifier, Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("sleeveClientIdentifier", sleeveClientIdentifier).addValue("companyId", companyId);
		try {
			MCPMClientIdentifier mcpmClientIdentifier = namedParameterJdbcTemplate.queryForObject(GET_ENTITY_BY_SLEEVE_CLIENT_IDENTIFER, paramSource,
					new BeanPropertyRowMapper<MCPMClientIdentifier>(MCPMClientIdentifier.class));
			return mcpmClientIdentifier;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	@Override
	public Long getParentEntityId(Long entityId,Long companyId){
	SqlParameterSource paramSource = new MapSqlParameterSource()
	.addValue("entityId", entityId)
	.addValue("companyId", companyId);
	try
	{
	Long parentEntityId = namedParameterJdbcTemplate.queryForObject(GET_PARENT_ENTITY_ID, paramSource,Long.class);
	return parentEntityId;
	}
	catch(EmptyResultDataAccessException e)
	{
		return null;
	}
	}
	
	@Override
	public Long getSleeveParentEntityId(Long sleeveEntityId,Long companyId){
	SqlParameterSource paramSource = new MapSqlParameterSource()
	.addValue("sleeveEntityId", sleeveEntityId)
	.addValue("companyId", companyId);
	try
	{
	Long parentEntityId = namedParameterJdbcTemplate.queryForObject(GET_SLEEVE_PARENT_ENTITY_ID, paramSource,Long.class);
	return parentEntityId;
	}
	catch(EmptyResultDataAccessException e)
	{
		return null;
	}
	}

	@Override
	public List<Long> getListSleeveEntities(Long entityId, Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyId", companyId)
				.addValue("entityId", entityId);

		List<Long> sleeveEntityIds = namedParameterJdbcTemplate.queryForList(GET_SLEEVE_ENTITY_BY_PARENT_ID,
				paramSource, Long.class);
		return sleeveEntityIds;
	}
}
