package com.markit.ms.rfa.dao.impl;

import java.io.UnsupportedEncodingException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.PartyAPlaceHolder;
import com.markit.ms.rfa.dao.IPartyAPlaceholderDao;
@Repository
public class PartyAPlaceholderDaoImpl extends BaseDAOImpl implements IPartyAPlaceholderDao {
	@Value("${UPDATE_PARTYA_TEXT}")
    private String UPDATE_PARTYA_TEXT;
	
	@Override
	public void updatePartyAPlaceholder(PartyAPlaceHolder partyAPlaceholder, Long amendmentId, Long userId)
			throws UnsupportedEncodingException {
		 SqlParameterSource paramSource = new MapSqlParameterSource()
     	.addValue("TEXT", partyAPlaceholder.getPartyAText().getBytes())
         .addValue("AMENDMENT_ID", amendmentId)
         .addValue("CREATED_BY", userId)
         .addValue("MODIFIED_BY", userId);
     namedParameterJdbcTemplate.update(UPDATE_PARTYA_TEXT, paramSource);
	}

}
