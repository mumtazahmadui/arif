package com.markit.ms.rfa.service;

import com.markit.ms.rfa.bean.RfaErrorFile;

public interface IRfaErrorFileService {

	Long create(String fileName, byte[] bytes, String contentType, long companyId, long userId);

	RfaErrorFile retreive(long fileId);
	
	int deleteFile(long fileId,long companyId);
	
}