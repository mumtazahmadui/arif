package com.markit.ms.rfa.controller.filter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.service.ILetterTemplateFilterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
@RestController
@RequestMapping(value = "v1/company")
@Api(value="LetterTemplateFilter", description= "Letter Template Filter APIs")
public class LetterTemplateFilterController {
	 //TODO-Sajil The null check for filterString should be moved to an intercepter 
	@Autowired
	ILetterTemplateFilterService letterTemplateFilterService;
	
	@RequestMapping(value = "{id}/letter_template_filter/template_name", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on letter template name")
	public CommonBaseResponse<List<Lookup>> templateNameLookup(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = letterTemplateFilterService.nameLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}

	@RequestMapping(value = "{id}/letter_template_filter/last_edited_by", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on letter last edited by")
	public CommonBaseResponse<List<Lookup>> lastEditedByLookup(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = letterTemplateFilterService.lastEditedByLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/letter_template_filter/created_by", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on letter created by")
	public CommonBaseResponse<List<Lookup>> createdByLookup(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = letterTemplateFilterService.createdByLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
}
