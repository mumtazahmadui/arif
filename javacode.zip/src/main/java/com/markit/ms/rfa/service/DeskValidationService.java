package com.markit.ms.rfa.service;

import java.util.List;

/**
 * This class provides method of validation on desk actions
 * 
 * @since RFA5.0
 *
 */
public interface DeskValidationService {

	/**
	 * validates user action on buy side for desk review
	 * 
	 * @return
	 */
	boolean validateBSReviewAction(Long amendmentId, String deskCode, Long userId);

	/**
	 * validates user action on sell side for desk review
	 * 
	 * @return
	 */
	boolean validateSSReviewAction(Long amendmentId, String deskCode, Long userId);

	/**
	 * validates user action on sell side for escalation
	 * 
	 * @return
	 */
	boolean validateEscalateAction(Long amendmentId, String deskType, String deskCode);

	/**
	 * validates user action for notification based on partyb amendment status and
	 * desktype
	 * 
	 * @return
	 */
	boolean validateNotifyAction(List<Long> partyBIds, String deskType, String companyType);

}
