package com.markit.ms.rfa.util;

import com.markit.ms.rs.select.all.domain.BulkRequestParam;
import com.markit.ms.rs.select.all.domain.BulkRequestParamEnum;

public final class RFAUtil {

	private RFAUtil() {
		throw new UnsupportedOperationException();
	}

	public static BulkRequestParam createBulkRequestParam(int index, String paramName, Object paramObject, BulkRequestParamEnum paramType) {
		BulkRequestParam requestParam = new BulkRequestParam();
		requestParam.setParamTypeId(paramType.getId());
		requestParam.setParamIndex(index);
		requestParam.setParamName(paramName);
		requestParam.setParamClass(paramObject.getClass().getName());
		requestParam.setParamObject(paramObject);
		return requestParam;
	}
}