package com.markit.ms.rfa.command.notifier;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.markit.ms.common.service.IRFAMailService;
import com.markit.ms.rfa.bean.BulkNotificationBean;

public abstract class BulkActionEmailNotifier {

	protected String emailBodyTemplate;

	@Autowired
	protected IRFAMailService rfaMailService;

	protected String emailSubjectTemplate;

	protected Map<String, Object> additionalParams;

	public String getEmailBodyTemplate() {
		return emailBodyTemplate;
	}

	public void setEmailBodyTemplate(String emailBodyTemplate) {
		this.emailBodyTemplate = emailBodyTemplate;
	}

	public IRFAMailService getRfaMailService() {
		return rfaMailService;
	}

	public void setRfaMailService(IRFAMailService rfaMailService) {
		this.rfaMailService = rfaMailService;
	}

	public String getEmailSubjectTemplate() {
		return emailSubjectTemplate;
	}

	public void setEmailSubjectTemplate(String emailSubjectTemplate) {
		this.emailSubjectTemplate = emailSubjectTemplate;
	}

	public Map<String, Object> getAdditionalParams() {
		return additionalParams;
	}

	public void setAdditionalParams(Map<String, Object> additionalParams) {
		this.additionalParams = additionalParams;
	}

	public abstract void sendEmailNotification(BulkNotificationBean bulkNotificationBean) throws Exception;
}
