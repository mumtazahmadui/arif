package com.markit.ms.rfa.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.repository.core.StJdbcTemplate;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.bean.ExhibitCell;
import com.markit.ms.rfa.bean.ExhibitCellValue;
import com.markit.ms.rfa.bean.ExhibitColumn;
import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.bean.ExhibitTemplateColumn;
import com.markit.ms.rfa.bean.NewExhibitRequest;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.dao.INewExhibitDao;
import com.markit.ms.rfa.dao.resultsetextractor.ExhibitTemplateResultSetExtractor;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;
@Repository
public class NewExhibitDaoImpl extends BaseDAOImpl implements INewExhibitDao {

	@Value("${UPDATE_EXHIBIT_CONTENT}")
    private String UPDATE_EXHIBIT_CONTENT;
	
	@Value("${BATCH_UPDATE_EXHIBIT_COL_DATA}")
    private String BATCH_UPDATE_EXHIBIT_COL_DATA;
	
	@Value("${UPDATE_AMENDMENT_BS_NEXT_STEP_TASK_PROC}")
	private String UPDATE_AMENDMENT_BS_NEXT_STEP_TASK_PROC; 
	
	@Value("${DELETE_LINE_BREAKS_IF_CONTROL_COLUMN_DATA_CHANGED}")
	private String DELETE_LINE_BREAKS_IF_CONTROL_COLUMN_DATA_CHANGED;
	
	@Value("${GET_EXHIBIT_COL_ID}")
	private String GET_EXHIBIT_COL_ID;
	
	@Value("${VALIDATE_EXHIBIT_DATA}")
	private String VALIDATE_EXHIBIT_DATA;
	
	@Value("${UPDATE_AMENDMENT_DATE}")
	private String UPDATE_AMENDMENT_DATE;
	
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID}")
    private String GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID;	
	
    @Value("${UPDATE_AMENDMENT_WITH_EXHIBIT_TEMPLATE}")
    private String UPDATE_AMENDMENT_WITH_EXHIBIT_TEMPLATE;    
    
    @Value("${SAVE_EXHIBIT}")
    private String SAVE_EXHIBIT;    
    
    @Value("${GET_PLACEHOLDER_AMENDMENT_BY_MASTER_AGREEMENT_ID}")
    private String GET_PLACEHOLDER_AMENDMENT_BY_MASTER_AGREEMENT_ID;    

    @Value("${SAVE_EXHIBIT_COL_DATA}")
    private String SAVE_EXHIBIT_COL_DATA;    
    
    @Value("${CREATE_EXHIBIT_COL}")
    private String CREATE_EXHIBIT_COL;   
    
   
    @Value("${SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG}")
    private String SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG;
    
    @Value("${UPDATE_EXHIBIT_CONTENT_SS}")
    private String UPDATE_EXHIBIT_CONTENT_SS;
    
    @Value("${UPDATE_EXHIBIT_CONTENT_AGREED}")
    private String UPDATE_EXHIBIT_CONTENT_AGREED;
    
	@Resource protected StJdbcTemplate  jdbcTemplate;
	
	@Resource private QueryService<byte[]> selectExhibitTextContent;
	
    @Resource 
    private VelocityEngine velocityEngine;
    
	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public void updateExhibit(Long amendmentId, 
			Long userId,
			Long exhibitId,
			NewExhibitRequest newExhibitRequest,
			boolean isBulkUpdate) {
		if(!isBulkUpdate) {
			// 1. Update Exhibit content
			SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("amendmentId", amendmentId)
			.addValue("exhibitId", exhibitId)
			.addValue("textContent", newExhibitRequest.getTextContent().getBytes())
			.addValue("htmlContent", newExhibitRequest.getHtmlContent().getBytes())
			.addValue("comment",CommonUtil.generateCommentHtml(newExhibitRequest.getCommentlog(),velocityEngine,"Exhibit"))
			.addValue("userId", userId)
			.addValue("partytype", newExhibitRequest.getPartyType());
			if(newExhibitRequest.getChangelog()!=null&&!newExhibitRequest.getChangelog().isEmpty()) {
				namedParameterJdbcTemplate.update(UPDATE_EXHIBIT_CONTENT_AGREED,paramSource);
			}else {
				namedParameterJdbcTemplate.update(UPDATE_EXHIBIT_CONTENT, paramSource);
			}
		}
		
		// 2. Batch update Cell Values
		final List<ExhibitCellValue> cellValues = newExhibitRequest.getCellValues();
		final Set<Long> exhibitColHashSet = new HashSet<Long>();
		if(cellValues != null && cellValues.size() > 0) {
			Map<String, Object>[] paramList = new Map[cellValues.size()];
			for(int index=0; index < paramList.length ; index++) {
				ExhibitCellValue exhibitCellValue = cellValues.get(index);
				paramList[index] = Maps.newHashMap();
				paramList[index].put("partyBId", exhibitCellValue.getPartyBId());
				paramList[index].put("cellValue", exhibitCellValue.getCellValue());
				paramList[index].put("exhibitColumnId", exhibitCellValue.getExhibitColumnId());
				paramList[index].put("userId", userId);
				exhibitColHashSet.add(exhibitCellValue.getExhibitColumnId());
			}
			jdbcTemplate.batchUpdate(BATCH_UPDATE_EXHIBIT_COL_DATA, paramList);
		}
		
		//update Amendment Modified Date
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("amendmentId", amendmentId);
		jdbcTemplate.update(UPDATE_AMENDMENT_DATE, paramSource);
		
		//3. Update Next Step
		SqlParameterSource params = new MapSqlParameterSource()
		.addValue("amendmentId", amendmentId)
		.addValue("action", RFAConstants.ACTION_EXHIBIT_UPDATE);
    	namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_BS_NEXT_STEP_TASK_PROC, params);
    	
    	if(exhibitColHashSet != null && exhibitColHashSet.size() > 0 && !isBulkUpdate) {
    	//4. Delete Line Breaks
    			SqlParameterSource paramsLineBreak = new MapSqlParameterSource()
    			.addValue("exhibitColIds", exhibitColHashSet)
    			.addValue("amendmentId", amendmentId);
    	    	namedParameterJdbcTemplate.update(DELETE_LINE_BREAKS_IF_CONTROL_COLUMN_DATA_CHANGED, paramsLineBreak);
    	}
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public void updateExhibitSS(Long amendmentId, Long userId, Long exhibitId, NewExhibitRequest newExhibitRequest) {
		Map<String, Object> hparams = new HashMap<>();
		hparams.put("exhibitId",exhibitId);
		hparams.put("amendmentId",amendmentId);
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("amendmentId", amendmentId)
				.addValue("exhibitId", exhibitId)
				.addValue("textContent", newExhibitRequest.getTextContent().getBytes())
				.addValue("comment",CommonUtil.generateCommentHtml(newExhibitRequest.getCommentlog(),velocityEngine,"Exhibit"))
				.addValue("userId", userId)
				.addValue("partytype", newExhibitRequest.getPartyType());
		namedParameterJdbcTemplate.update(UPDATE_EXHIBIT_CONTENT_SS, paramSource);
	}
	
	@Override
	public Long getExhibitColId(Long amendmentId, String columnName) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("columnName", columnName).addValue("rfaId", amendmentId);
		return namedParameterJdbcTemplate.queryForObject(GET_EXHIBIT_COL_ID, params, Long.class);
	}

	@Override
	public boolean validateExhibitData(Long rfaId, Set<Long> columnIdList, Set<Long> partybEntityIdList) {
		SqlParameterSource params = new MapSqlParameterSource()
				.addValue("rfaId", rfaId)
				.addValue("columnIdList", columnIdList)
				.addValue("partybEntityIdList", partybEntityIdList)
				.addValue("columnCount", columnIdList.size())
				.addValue("partybEntityCount", partybEntityIdList.size());
		return namedParameterJdbcTemplate.queryForObject(VALIDATE_EXHIBIT_DATA, params, Long.class) == 1 ? true : false;
	}

	@Override
    public void createExhibit(Long masterAgreementId, Long amendmentId, List<PartyBEntity> partyBList, Long userId, Map<Long, Exhibit> rfaBulkUploadExhibit,String partytype)
    {
    	SqlParameterSource paramSource = new MapSqlParameterSource()
    		.addValue("id", masterAgreementId)
    		.addValue("deleted", 0L);
		List<ExhibitTemplate> exhibitTemplateList = namedParameterJdbcTemplate.query(
    			GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID, paramSource, new ExhibitTemplateResultSetExtractor(true));
		
		if(null == amendmentId) {
			paramSource = new MapSqlParameterSource().addValue("id", masterAgreementId);
			amendmentId = namedParameterJdbcTemplate.queryForObject(
    			GET_PLACEHOLDER_AMENDMENT_BY_MASTER_AGREEMENT_ID, paramSource, Long.class);
		}
		
		if(exhibitTemplateList.size() > 0){
			MapSqlParameterSource params = new MapSqlParameterSource()
			.addValue("exhibit_template_id", exhibitTemplateList.get(0).getId())
			.addValue("amendment_id", amendmentId);
			namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_WITH_EXHIBIT_TEMPLATE, params);
			Integer agreed = exhibitTemplateList.get(0).getAgreed();
			params = new MapSqlParameterSource()
				.addValue("amendment_id", amendmentId)
			    .addValue("text_content", exhibitTemplateList.get(0).getTextContent().getBytes())
			    .addValue("html_content", exhibitTemplateList.get(0).getHtmlContent().getBytes())
			    .addValue("created_by", userId)
			    .addValue("partytype", partytype)
			    .addValue("modified_by", userId)
			    .addValue("agreed",agreed==null?1:agreed);
			KeyHolder keyHolder = new GeneratedKeyHolder();
			namedParameterJdbcTemplate.update(SAVE_EXHIBIT, params, keyHolder);
			Long exhibitId = keyHolder.getKey().longValue();
			
			List<ExhibitColumn> exhibitColumns = this.getExhibitColumnList(exhibitTemplateList.get(0).getColumns());
			
			Long exhibitColId = null;
			String colName = "";
			for (ExhibitColumn exhibitColumn : exhibitColumns) {
	    		params = new MapSqlParameterSource()
	    	        .addValue("column_name", exhibitColumn.getColumnName())
	    	        .addValue("column_index", exhibitColumn.getColumnIndex())
	    	        .addValue("column_style", exhibitColumn.getColumnStyle())
	    	        .addValue("modified_by", userId)
	    	        .addValue("created_by", userId)
	    	        .addValue("exhibit_id", exhibitId)
	    			.addValue("exhibit_template_col_id", exhibitColumn.getExhibitTemplateColId())
	    			.addValue("control_column", exhibitColumn.isControlColumn());
    			keyHolder = new GeneratedKeyHolder();
    			namedParameterJdbcTemplate.update(CREATE_EXHIBIT_COL, params, keyHolder);
    			exhibitColId = keyHolder.getKey().longValue();
    			
				if (CommonUtil.isNotNull(rfaBulkUploadExhibit) && rfaBulkUploadExhibit.size() > 0) {
					saveExhibitColumnDataWithValues(exhibitColumn, exhibitColId, rfaBulkUploadExhibit, userId);
    			}
    			else {
    				saveExhibitColumnDataWithoutValues(exhibitColumn, exhibitColId, userId, partyBList);
    			}
			}
		}
	}	

	private List<ExhibitColumn> getExhibitColumnList(List<ExhibitTemplateColumn> exhibitTemplateColumns)
	{
		List<ExhibitColumn> exhibitColumnList = new ArrayList<ExhibitColumn>();
		for(ExhibitTemplateColumn exhibitTemplateColumn: exhibitTemplateColumns){
			ExhibitColumn exhibitCol = new ExhibitColumn();
			exhibitCol.setColumnName(exhibitTemplateColumn.getColumnName());
			exhibitCol.setColumnIndex(exhibitTemplateColumn.getColumnIndex());
			exhibitCol.setColumnStyle(exhibitTemplateColumn.getColumnStyle());
			exhibitCol.setExhibitTemplateColId(exhibitTemplateColumn.getId());
			exhibitCol.setControlColumn(exhibitTemplateColumn.isControlColumn());
			exhibitColumnList.add(exhibitCol);
		}
		return exhibitColumnList;
	}

	/**
	 * Use for bulk uploading RFAs with exhibit values pre-populated.
	 */
	private void saveExhibitColumnDataWithValues(ExhibitColumn exhibitColumn, Long exhibitColId, Map<Long, Exhibit> rfaBulkUploadExhibit, Long userId) {
		for (Long partyBId : rfaBulkUploadExhibit.keySet()) {
			for (ExhibitColumn exhibitCol : rfaBulkUploadExhibit.get(partyBId).getColumns()) {
				if (CommonUtil.isEqual(exhibitColumn.getColumnName(), exhibitCol.getColumnName())
						&& !RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD
								.equalsIgnoreCase(exhibitCol.getColumnName())
						&& !RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD
								.equalsIgnoreCase(exhibitCol.getColumnName())
						&& !RFAConstants.PARTYB_LEI_FIELD.equalsIgnoreCase(exhibitCol.getColumnName())) {
					for (ExhibitCell columnCell : exhibitCol.getCells()) {
						SqlParameterSource params = new MapSqlParameterSource().addValue("exhibit_col_id", exhibitColId)
								.addValue("partyb_entity_id", partyBId)
								.addValue("value",
										columnCell.getValue() != null ? columnCell.getValue() : "")
								.addValue("modified_by", userId).addValue("created_by", userId)
								.addValue("style", "");
						namedParameterJdbcTemplate.update(SAVE_EXHIBIT_COL_DATA, params);
					}
				}
			}
		}
		
	}    
	
	/**
	 * Use for creating RFAs from UI with no exhibit values pre-populated.  
	 */
	private void saveExhibitColumnDataWithoutValues(ExhibitColumn exhibitColumn, Long exhibitColId, Long userId, List<PartyBEntity> partyBList) {

		
		String colName = exhibitColumn.getColumnName();
		if(partyBList != null && !RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD.equalsIgnoreCase(colName)
				&& !RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(colName)
				&& !RFAConstants.PARTYB_LEI_FIELD.equalsIgnoreCase(colName)){
			for(PartyBEntity partyBEntity : partyBList){
				SqlParameterSource params = new MapSqlParameterSource()
	    	        .addValue("exhibit_col_id", exhibitColId)
	    	        .addValue("partyb_entity_id", partyBEntity.getEntity().getId())
	    	        .addValue("value", "")
	    	        .addValue("modified_by", userId)
	    	        .addValue("created_by", userId)
	    	        .addValue("style", "");
    			namedParameterJdbcTemplate.update(SAVE_EXHIBIT_COL_DATA, params);
			}
		}	
	
		
	}
}
