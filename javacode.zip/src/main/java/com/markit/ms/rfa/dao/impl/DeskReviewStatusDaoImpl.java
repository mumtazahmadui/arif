package com.markit.ms.rfa.dao.impl;

import java.util.List;
import java.util.Properties;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.PartyBDeskReviewData;
import com.markit.ms.rfa.dao.DeskReviewStatusDao;

/**
 * This class provides dao operation implementation for Amendment Letter
 * PartyB's desk statuses
 * 
 * @since RFA5.0
 *
 */
@Repository
public class DeskReviewStatusDaoImpl extends BaseDAOImpl implements DeskReviewStatusDao {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeskReviewStatusDaoImpl.class);

	@Autowired
	private Properties deskProperties;

	@Value("${deskReviewStatus#insert}")
	private String INSERT_REVIEW;

	@Value("${deskReviewStatus#update}")
	private String UPDATE_REVIEW;

	@Value("${deskReviewStatus#merge}")
	private String INSERT_UPDATE_REVIEW;

	@Value("${deskReviewLU#deskTypeUserRole}")
	private String DESK_TYPE_FOR_USER_ROLE;
	
	@Override
	public void insert(PartyBDeskReviewData deskReviewData) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("partyBId", deskReviewData.getPartyBId())
				.addValue("createdBy", deskReviewData.getCreatedBy())
				.addValue("isReviewed", deskReviewData.isReviewed());

		LOGGER.debug("insert : INSERT_REVIEW: " + INSERT_REVIEW);
		String sqlQuery = INSERT_REVIEW.replace("#COLUMN_NAME",
				(String) deskProperties.get(deskReviewData.getDeskCode()));
		
		namedParameterJdbcTemplate.update(sqlQuery, params);
	}

	@Override
	public void update(PartyBDeskReviewData deskReviewData) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("partyBId", deskReviewData.getPartyBId())
				.addValue("modifiedBy", deskReviewData.getCreatedBy())
				.addValue("isReviewed", deskReviewData.isReviewed());

		LOGGER.debug("update : UPDATE_REVIEW: " + UPDATE_REVIEW);
		String sqlQuery = UPDATE_REVIEW.replace("#COLUMN_NAME",
				(String) deskProperties.get(deskReviewData.getDeskCode()));
		
		namedParameterJdbcTemplate.update(sqlQuery, params);
	}

	@Override
	public void insertOrUpdate(PartyBDeskReviewData deskReviewData) {
		
		SqlParameterSource params = new MapSqlParameterSource().addValue("partyBId", deskReviewData.getPartyBId())
				.addValue("modifiedBy", deskReviewData.getCreatedBy())
				.addValue("createdBy", deskReviewData.getCreatedBy())
				.addValue("isReviewed", deskReviewData.isReviewed())
				.addValue("amendmentId", deskReviewData.getAmendmentId());

		LOGGER.debug("insertOrUpdate : INSERT_UPDATE_REVIEW: " + INSERT_UPDATE_REVIEW);
		/**
		 * get column name based on desk code provided
		 */
		String sqlQuery = INSERT_UPDATE_REVIEW.replace("#COLUMN_NAME",
				(String) deskProperties.get(deskReviewData.getDeskCode()));
		namedParameterJdbcTemplate.update(sqlQuery, params);

	}
	
	@Override
	public String getDeskType(String deskCode, Long userId) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("deskCode", deskCode)
				.addValue("userId", userId);

		LOGGER.debug("getDeskType : DESK_TYPE_FOR_USER_ROLE: " + DESK_TYPE_FOR_USER_ROLE);
		List<String> list = namedParameterJdbcTemplate.queryForList(DESK_TYPE_FOR_USER_ROLE, params,String.class);
		
		if(CollectionUtils.isNotEmpty(list)) {
			return list.get(0);
		}else {
			return null;
		}
	}
	
}
