package com.markit.ms.rfa.command.validator.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;

@Service
public class NextStepPdfGenerator {

	@Autowired
	private IReportGenerator reportGenerator;

	@Autowired
	private IAmendmentLetterDao amendmentLetterDao;

	public byte[] generatePdf(List<Long> rfaIds, BulkActionValidationType type, Long companyId, Long userId) throws Exception {
		return generatePdf(null, rfaIds, type, companyId, userId);
	}

	public byte[] generatePdf(String errorMessage, List<Long> rfaIds, BulkActionValidationType type, Long companyId, Long userId) throws Exception {
		List<AmendmentLetter> amendmentLetterList = new ArrayList<AmendmentLetter>();
		for (Long rfaId : rfaIds) {
			AmendmentLetter amendmentLetter = amendmentLetterDao.getAmendmentLetterById(rfaId, companyId);
			if (amendmentLetter != null) {
				amendmentLetterList.add(amendmentLetter);
			}
		}
		if (amendmentLetterList.isEmpty()) {
			return null;
		}
		return reportGenerator.generateErrorPDFContent(errorMessage, amendmentLetterList, type);
	}
}
