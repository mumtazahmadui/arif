package com.markit.ms.rfa.service.impl;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.dao.IPartyBDao;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.service.IPartyBService;

@Service
public class PartyBServiceImpl implements IPartyBService {

	@Autowired
	private IPartyBDao partyBDao;

	@Autowired
	private IAmendmentLetterService amendmentLetterService;
	
	@Override
	public List<PartyBEntity> withdrawPartyB(Long userId, List<PartyBEntity> partyBEntityList) {
		List<PartyBEntity> returnedList = new ArrayList<PartyBEntity>();
		for (PartyBEntity partyBEntity : partyBEntityList) {
			returnedList.add(partyBDao.withdrawPartyB(userId, partyBEntity));
			
		}
		return returnedList;
	}
	
	@Override
	public void copyPartyBEntitiesToSnap(Long amendmentId, Long userId) {
		partyBDao.copyPartyBEntitiesToSnap(amendmentId,userId);
	}

	@Override
	public Long getPartyBIdByLegalName(String legalName, Long amendmentId) {
		return partyBDao.getPartyBIdByLegalName(legalName, amendmentId);
	}
	
	@Override
	public Long getPartyBIdByLegalNameAndClientId(String legalName, String clientId, Long amendmentId) {
		return partyBDao.getPartyBIdByLegalNameAndClientId(legalName, clientId, amendmentId);
	}
	
	@Override
	public List<PartyBEntity> getSleevesInProgress(Long parentEntityId, Long masterlistId) {
		return partyBDao.getSleevesInProgress(parentEntityId, masterlistId);
	}
}
