package com.markit.ms.rfa.service;

import com.markit.ms.common.bean.User;

public interface IUserService {

	public User getUser(long id);
	
}
