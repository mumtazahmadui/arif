package com.markit.ms.rfa.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.bean.NewExhibitRequest;
import com.markit.ms.rfa.bean.NewExhibitResponse;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.service.IAmendmentChangeService;
import com.markit.ms.rfa.service.INewExhibitService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PlaceholderUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1/amendmentLetters/{amendmentId}/exhibit/{exhibitId}")
@Api(value = "exhibit" , description = "Exhibit APIs")
public class NewExhibitController {

	@Resource private QueryService<byte[]> selectExhibitTextContent;
	@Resource private QueryService<byte[]> selectExhibitHTMLContent;
	@Resource private QueryService<Integer> selectExhibitAgreed;
	@Resource private QueryService<Grid> selectExhibitColumns;
	@Resource private QueryService<Grid> selectExhibitRows;
	@Resource private INewExhibitService newExhibitService;
	@Resource private QueryService<Long> selectExhibitIdFromAmendment;
	@Autowired
	private IAmendmentChangeService amendmentChangeService;
	
	@Value("${SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG}")
	private String SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG;
	
	@RequestMapping(method = RequestMethod.GET)
    @ApiOperation(value = "Get Exhibit")
    public @ResponseBody NewExhibitResponse getExhibit(@PathVariable Long amendmentId
    		, @PathVariable Long exhibitId
    		, HttpServletRequest request) throws Exception{
			NewExhibitResponse exhibitResponse = new NewExhibitResponse();
			Map<String, Object> params = new HashMap<>();
			Long exhibitIdFromDB = selectExhibitIdFromAmendment.executeQuery("amendmentId",amendmentId);
			if(exhibitIdFromDB == null) { // No exhibit Exists in DB
			    	 exhibitResponse.setExhibitTextContent(CommonUtil.getValueFromBase64("".getBytes()));
			    	 return exhibitResponse;
			}
			params.put("exhibitId",exhibitId);
			params.put("amendmentId",amendmentId);
			exhibitResponse.setExhibitTextContent(CommonUtil.getValueFromBase64(selectExhibitTextContent.executeQuery(params)));
			exhibitResponse.setExhibitHTMLContent(CommonUtil.getValueFromBase64(selectExhibitHTMLContent.executeQuery(params)));
//			exhibitResponse.setAgreed(selectExhibitAgreed.executeQuery(params));
			Grid columns = selectExhibitColumns.executeQuery(params);
			PDFContext pdfContext = new PDFContext();
			pdfContext.setNotAllowPartyBStatuses("Accepted Sent|Rejected Sent|Accepted Signed|Withdrawn");
			params = PlaceholderUtil.preparePlaceholderParamsForExhibitPDF(exhibitId,pdfContext);
		    Grid rows = selectExhibitRows.executeQuery(params);
			exhibitResponse.setColumns(columns.getRows());
			exhibitResponse.setRows(rows.getRows());
			return exhibitResponse;        
    }

	@RequestMapping(method = RequestMethod.PUT, consumes = "application/json")
	@ApiOperation(value = "Update Exhibit")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	@Transactional
	public void updateExhibit(@PathVariable Long amendmentId
			, @PathVariable Long exhibitId
			, HttpServletRequest request
			, @RequestBody NewExhibitRequest newExhibitRequest
			) throws Exception{
		Long userId = CommonUtil.getUserIdFromSession(request);
		Future<Long> future = newExhibitService.updateExhibit(amendmentId, userId,exhibitId, newExhibitRequest, false);
		future.get();
		amendmentChangeService.saveRfaChangeLogAudit(newExhibitRequest.getChangelog(), amendmentId,"EXHIBIT",newExhibitRequest.getPartyType(),SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG);
		amendmentChangeService.saveRfaCommentAudit(newExhibitRequest.getCommentlog(), amendmentId,"EXHIBIT",newExhibitRequest.getPartyType(),SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value = "ss",consumes = "application/json")
	@ApiOperation(value = "Update Exhibit SS")
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	@Transactional
	public void updateExhibitSS(@PathVariable Long amendmentId
			, @PathVariable Long exhibitId
			, HttpServletRequest request
			, @RequestBody NewExhibitRequest newExhibitRequest
			) throws Exception{
		Long userId = CommonUtil.getUserIdFromSession(request);
		Future<Long> future = newExhibitService.updateExhibitSS(amendmentId, userId,exhibitId, newExhibitRequest);
		future.get();
		amendmentChangeService.saveRfaChangeLogAudit(newExhibitRequest.getChangelog(), amendmentId,"EXHIBIT","SS",SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG);
		amendmentChangeService.saveRfaCommentAudit(newExhibitRequest.getCommentlog(), amendmentId,"EXHIBIT","SS",SAVE_RFA_EXHIBIT_AMENDMENT_CHANGE_LOG);
	}
}
