package com.markit.ms.rfa.command.notifier.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.domain.Grid.Row;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.bean.BulkNotificationBean;
import com.markit.ms.rfa.command.notifier.BulkActionEmailNotifier;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.service.IMcsRedirectUrlGenerator;

@Component
public class ChaserEmailNotifier extends BulkActionEmailNotifier {

	@Resource 
	protected QueryService<Grid> getChaserRfaIdsCorrespondingPartyAIds;
	
	@Resource 
	protected QueryService<Grid> getUserEmailsForChaser;	
	
	@Autowired
	private IAmendmentLetterService amendmentLetterService;	

	@Resource(name="chaserEmailUrlGenerator")
	private IMcsRedirectUrlGenerator chaserEmailUrlGenerator;
	
	public void sendEmailNotification(BulkNotificationBean bulkNotificationBean) throws Exception {
		Map<Long, Map<String, Map<String, Map<String, String>>>> partyAToInvestmentManagerEmailMap = new HashMap<Long, Map<String, Map<String,  Map<String, String>>>>();
		Grid grid = getChaserRfaIdsCorrespondingPartyAIds.executeQuery(Maps.newHashMap());
		Map<String, Map<String,  Map<String, String>>> investmentManagerMap = null;
		for (Row row : grid.getRowList()) {
			Long partyACompanyId = new Long(row.get("partyACompanyId"));
			String investmentManagerName = row.get("investmentManagerName");
			String rfaId = row.get("rfaAmendmentId");
			String partyAName=row.get("partyAName");
			partyAToInvestmentManagerEmailMap.putIfAbsent(partyACompanyId, Maps.newHashMap());
			investmentManagerMap = partyAToInvestmentManagerEmailMap.get(partyACompanyId);
			investmentManagerMap.putIfAbsent(investmentManagerName, Maps.newHashMap());
			
			Map<String, Map<String, String> >  partyANameMap=investmentManagerMap.get(investmentManagerName);
			partyANameMap.putIfAbsent(partyAName, Maps.newHashMap());

			Map<String, String> rfaIdUrlMap = partyANameMap.get(partyAName);
			rfaIdUrlMap.put(rfaId, chaserEmailUrlGenerator.generateUrl(ImmutableMap.of("amendment_id", rfaId)));
		}

		for (Long partyACompanyId : partyAToInvestmentManagerEmailMap.keySet()) {
			Grid userEmails = getUserEmailsForChaser.executeQuery("companyId", partyACompanyId);
			List<String> userEmailList = new ArrayList<String>();
			for (Row row : userEmails.getRowList()) {
				userEmailList.add(row.get("email"));
			}
			for (Map.Entry<String, Map<String, Map<String, String>>> entry : partyAToInvestmentManagerEmailMap.get(partyACompanyId).entrySet()) {
				Map<String, Map<String, String>> innerEntry = entry.getValue();
				for (Map.Entry<String,Map<String,String>>  partyAEntry :innerEntry.entrySet() ) {
					
					Map<String, Object> additionalParams = Maps.newHashMapWithExpectedSize(3);
					additionalParams.put("rfaIds", partyAEntry.getValue());
					additionalParams.put("investmentManagerName", entry.getKey());
					additionalParams.put("partyAName", partyAEntry.getKey());
					
					Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
					subjectVariables.put("subj_suffix", entry.getKey());
					
					rfaMailService.sendEmail(userEmailList, additionalParams, emailBodyTemplate, emailSubjectTemplate, subjectVariables);
					
					amendmentLetterService.updateChasers(partyAEntry.getValue().keySet().stream().map(Long::new).collect(Collectors.toList()),
						bulkNotificationBean.getUserId());
				}
			}
		}}

	public QueryService<Grid> getGetChaserRfaIdsCorrespondingPartyAIds() {
		return getChaserRfaIdsCorrespondingPartyAIds;
	}

	public void setGetChaserRfaIdsCorrespondingPartyAIds(QueryService<Grid> getRfaIdsCorrespondingPartyAIds) {
		this.getChaserRfaIdsCorrespondingPartyAIds = getRfaIdsCorrespondingPartyAIds;
	}

	public QueryService<Grid> getGetUserEmailsForChaser() {
		return getUserEmailsForChaser;
	}

	public void setGetUserEmailsForChaser(QueryService<Grid> getUserEmailsForChaser) {
		this.getUserEmailsForChaser = getUserEmailsForChaser;
	}
}