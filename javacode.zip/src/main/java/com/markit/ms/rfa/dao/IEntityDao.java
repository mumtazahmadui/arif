package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.model.CommonBaseSearchRequest;

public interface IEntityDao {
	public List<Entity> getEntities(long companyId, String filterString, CommonBaseSearchRequest commonBaseSearchRequest);
	public List<Entity> getAllSleeveEntities(Long companyId, String filterString, Long offSet, Long pageSize);
	public List<Entity> getSleeveAccountsForParentEntities(Long companyId, List<Long> masterlistIds, List<Long> parentEntityIds);
	public List<Entity> getMcpmChildEntities(Long companyId, Long parentEntityId);
	public Entity getParentEntity(Long entityId);
	public Entity getEntity(Long entityId, Long masterAgreementId);
	public Entity getPartyAEntity(String legalName);
}
