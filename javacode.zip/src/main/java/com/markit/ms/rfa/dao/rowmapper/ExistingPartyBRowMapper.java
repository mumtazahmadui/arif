package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.ExistingPartyB;

public class ExistingPartyBRowMapper implements RowMapper<ExistingPartyB> {

	@Override
	public ExistingPartyB mapRow(ResultSet rs, int rowNum) throws SQLException {
		ExistingPartyB existingPartyB = new ExistingPartyB();
		existingPartyB.setId(rs.getLong("id"));
		existingPartyB.setBelongsToPlaceholderAmendment(rs.getLong("is_placeholder") == 1 ? true : false);
		return existingPartyB;
	}
}
