package com.markit.ms.rfa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.CompanyAmendmentStats;
import com.markit.ms.rfa.dao.IDashboardDao;
import com.markit.ms.rfa.service.IDashboardService;

@Service
public class DashboardServiceImpl extends BaseServiceImpl implements IDashboardService {

	@Autowired
	private IDashboardDao dashboardDao;

	@Override
	public CompanyAmendmentStats getCompanyAmendmentStats(long id) {
		CompanyAmendmentStats companyAmendmentStats = dashboardDao.getAmendmentStats(id);
		return companyAmendmentStats;
	}

}
