package com.markit.ms.rfa.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.CompanyAmendmentStats;
import com.markit.ms.rfa.bean.MyStatusLegend;
import com.markit.ms.rfa.dao.IDashboardDao;
import com.markit.ms.rfa.dao.rowmapper.BuysideStatsRowMapper;
import com.markit.ms.rfa.dao.rowmapper.CompanyTypeRowMapper;
import com.markit.ms.rfa.dao.rowmapper.MyStatusLegendRowMapper;
import com.markit.ms.rfa.dao.rowmapper.SellsideStatsRowMapper;
@Repository
public class DashboardDaoImpl extends BaseDAOImpl implements IDashboardDao {
 
    @Value("${GET_BS_DASHBOARD_STATS}")
    private String GET_BS_DASHBOARD_STATS;
	
    @Value("${GET_COMPANY_TYPE}")
    private String GET_COMPANY_TYPE;
    
    @Value("${GET_SS_DASHBOARD_STATS}")
    private String GET_SS_DASHBOARD_STATS;
    
    @Value("${GET_MY_STATUS_LEGEND}")
    private String GET_MY_STATUS_LEGEND;
    
	@Override
	public CompanyAmendmentStats getAmendmentStats(long companyid) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyid);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, paramSource, new CompanyTypeRowMapper());
		CompanyAmendmentStats companyAmendmentStats = new CompanyAmendmentStats();
		if (companyType.equalsIgnoreCase("SS")){
			companyAmendmentStats = namedParameterJdbcTemplate.queryForObject(GET_SS_DASHBOARD_STATS, paramSource, new SellsideStatsRowMapper());
		}
		else if (companyType.equalsIgnoreCase("BS")){
			companyAmendmentStats = namedParameterJdbcTemplate.queryForObject(GET_BS_DASHBOARD_STATS, paramSource, new BuysideStatsRowMapper());
		}
		return companyAmendmentStats;
	}

	public List<MyStatusLegend> getMyStatusLegend(Long companyId, Long userId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId);
		List<List<MyStatusLegend>> myStatusLegendList = namedParameterJdbcTemplate.query(GET_MY_STATUS_LEGEND, paramSource, new MyStatusLegendRowMapper());
		return myStatusLegendList.get(0);
	}
		
}
