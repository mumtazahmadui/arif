package com.markit.ms.rfa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseRequest;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.CommonBaseSearchResponse;
import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.dto.TemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.IExhibitTemplateService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.wordnik.swagger.annotations.Api;
@RestController
@RequestMapping(value = "v1/company")
@Api(value="Exhibit Template", description= "Exhibit Template API")
public class ExhibitTemplateController {
	
	@Autowired
	private IExhibitTemplateService exhibitTemplateService;
	
	@RequestMapping(value = "{companyId}/exhibit_template", method = RequestMethod.POST)
	public CommonBaseResponse<ExhibitTemplate> createExhibitTemplate(@PathVariable Long companyId
			, @RequestBody CommonBaseRequest<ExhibitTemplate> commonBaseRequest,HttpServletRequest request) throws RFAUIException{
		ExhibitTemplate requestTemplate = updateTemplateWithCompanyId(
				commonBaseRequest, request);
		ExhibitTemplate exhibitTemplate = null;
		Integer areColumnsValid = exhibitTemplateService.validateExhibitTemplateColumns(requestTemplate, true, CommonUtil.getUserIdFromSession(request));
		CommonBaseResponse<ExhibitTemplate> response = new CommonBaseResponse<ExhibitTemplate>();
		if(areColumnsValid == 1){
			exhibitTemplate = exhibitTemplateService.saveExhibitTemplate(requestTemplate);
		} else {
			response.setFailed();
			if(areColumnsValid == 2){
				throw new RFAUIException(RFAConstants.EXHIBIT_INVALID_COLUMN_NAME, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
			}else if(areColumnsValid == 3){
				throw new RFAUIException(RFAConstants.EXHIBIT_TEMPLATE_DUPLICATE_COLUMN, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
			}
		}
		if(null == exhibitTemplate) {
			response.setFailed();
			//response.setMessage(RFAConstants.EXHIBIT_TEMPLATE_ALREADY_EXIST);
			throw new RFAUIException(RFAConstants.EXHIBIT_TEMPLATE_ALREADY_EXIST, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
		}
		response.setData(exhibitTemplate);
		return response;
	}
	private ExhibitTemplate updateTemplateWithCompanyId(
			CommonBaseRequest<ExhibitTemplate> commonBaseRequest,
			HttpServletRequest request) {
		ExhibitTemplate requestTemplate = commonBaseRequest.getData();
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		requestTemplate.setCompanyId(companyIdFromSession);
		return requestTemplate;
	}
	//TODO-Sajil Why update is returning ExhibitTemplate back? This method should return void.
	@RequestMapping(value = "{companyId}/exhibit_template", method = RequestMethod.PUT)
	public CommonBaseResponse<ExhibitTemplate> updateExhibitTemplate(@PathVariable Long companyId
			, @RequestBody CommonBaseRequest<ExhibitTemplate> commonBaseRequest,HttpServletRequest request) throws RFAUIException{
		ExhibitTemplate requestTemplate = updateTemplateWithCompanyId(
				commonBaseRequest, request);
		Integer areColumnsValid = exhibitTemplateService.validateExhibitTemplateColumns(requestTemplate, false, CommonUtil.getUserIdFromSession(request));
		ExhibitTemplate exhibitTemplate = null;
		CommonBaseResponse<ExhibitTemplate> response = new CommonBaseResponse<ExhibitTemplate>();
		if(areColumnsValid == 1){
			exhibitTemplate = exhibitTemplateService.updateExhibitTemplate(requestTemplate);
		} else {
			response.setFailed();
			if(areColumnsValid == 2){
				throw new RFAUIException(RFAConstants.EXHIBIT_INVALID_COLUMN_NAME, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
			}else if(areColumnsValid == 3){
				throw new RFAUIException(RFAConstants.EXHIBIT_TEMPLATE_DUPLICATE_COLUMN, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
			}
		}
		if(null == exhibitTemplate) {
			response.setFailed();
			throw new RFAUIException(RFAConstants.EXHIBIT_TEMPLATE_ALREADY_EXIST, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
		}
		response.setData(exhibitTemplate);
		return response;
	}
	//TODO-Sajil Why returning ExhibitTemplate back? This method should return void.
	@RequestMapping(value = "{companyId}/exhibit_template/{exhibitTemplateId}", method = RequestMethod.DELETE)
	public CommonBaseResponse<ExhibitTemplate> deleteExhibitTemplate(@PathVariable Long companyId, @PathVariable Long exhibitTemplateId,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		ExhibitTemplate deletedExhibitTemplate = exhibitTemplateService.deleteExhibitTemplate(exhibitTemplateId,companyIdFromSession);
		CommonBaseResponse<ExhibitTemplate> response = new CommonBaseResponse<ExhibitTemplate>();
		response.setData(deletedExhibitTemplate);
		return response;
	}
	
	@RequestMapping(value = "{companyId}/exhibit_template/{exhibitTemplateId}", method = RequestMethod.GET)
	public CommonBaseResponse<ExhibitTemplate> getExhibitTemplateById(@PathVariable Long companyId, @PathVariable Long exhibitTemplateId,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		ExhibitTemplate deletedExhibitTemplate = exhibitTemplateService.getExhibitTemplateById(exhibitTemplateId,companyIdFromSession);
		CommonBaseResponse<ExhibitTemplate> response = new CommonBaseResponse<ExhibitTemplate>();
		response.setData(deletedExhibitTemplate);
		return response;
	}
	
	@RequestMapping(value = "{companyId}/exhibit_template", method = RequestMethod.GET)
	public CommonBaseResponse<List<ExhibitTemplate>> getExhibitTemplates(@PathVariable Long companyId,HttpServletRequest request){
		CommonBaseResponse<List<ExhibitTemplate>> commonBaseResponse = new CommonBaseResponse<List<ExhibitTemplate>>();
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		List<ExhibitTemplate> exhibitTemplate = exhibitTemplateService.getAllExhibitTemplatesByCompanyId(companyIdFromSession);
		commonBaseResponse.setData(exhibitTemplate);
		return commonBaseResponse;
	}
	
	@RequestMapping(value="/{companyId}/exhibit_template/search",method = RequestMethod.POST)
	public CommonBaseSearchResponse<ExhibitTemplate> searchExhibitTemplate(@PathVariable Long companyId, @RequestBody TemplateSearchRequest exhibitTemplateSearchRequest,HttpServletRequest request){
			Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
			List<ExhibitTemplate> exhibitTemplateList = exhibitTemplateService.getExhibitTemplateGrid(companyIdFromSession, exhibitTemplateSearchRequest);
			Long totalCount = exhibitTemplateService.getExhibitTemplateGridTotalCount(companyIdFromSession, exhibitTemplateSearchRequest);
	    	CommonBaseSearchResponse<ExhibitTemplate> commonBaseSearchResponse = new CommonBaseSearchResponse<ExhibitTemplate>();
	    	commonBaseSearchResponse.setDataList(exhibitTemplateList);
	    	commonBaseSearchResponse.setTotalCount(totalCount);
	    	return commonBaseSearchResponse;   
	}
	
	@RequestMapping(value="/{companyId}/exhibit_template/{exhibitTemplateId}/masterlist/{masterlistId}", method = RequestMethod.PUT)
	@ResponseStatus(value=HttpStatus.NO_CONTENT)
	public void linkMasterlistToExhibitTemplate(@PathVariable Long exhibitTemplateId, @PathVariable Long masterlistId, HttpServletRequest request) {
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
		exhibitTemplateService.linkMasterlistToExhibitTemplate(exhibitTemplateId, masterlistId, companyIdFromSession, userIdFromSession);
	}
}
