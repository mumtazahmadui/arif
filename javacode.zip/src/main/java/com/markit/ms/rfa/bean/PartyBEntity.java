package com.markit.ms.rfa.bean;


import java.util.Date;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;


public class PartyBEntity {

	private Long id;
	private Boolean isAdded;
	private Boolean autoAdded;
	private Boolean isModified;
	private Entity entity;
	private Long amendmentId;
	private Long masterAgreementId;
	private PartyBAckStatus acknowledgementStatus;
	private AmendmentStatus amendmentStatus;
	private String reason;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Long deleted;
	private FundNameChange fundNameChange;
	private ExhibitValueChange exhibitValueChange;
	private MasterAgreement masterAgreement;
	private String requestType;
	private String dealerAction;
	private PartyBDeskReviewStatus deskStatus;
	private boolean partyBHidden;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Boolean getIsAdded() {
		return isAdded;
	}
	public void setIsAdded(Boolean isAdded) {
		this.isAdded = isAdded;
	}
	public Boolean getAutoAdded() {
		return autoAdded;
	}
	public void setAutoAdded(Boolean autoAdded) {
		this.autoAdded = autoAdded;
	}
	public Boolean getIsModified() {
		return isModified;
	}
	public void setIsModified(Boolean isModified) {
		this.isModified = isModified;
	}
	public Entity getEntity() {
		return entity;
	}
	public void setEntity(Entity entity) {
		this.entity = entity;
	}
	public Long getAmendmentId() {
		return amendmentId;
	}
	public void setAmendmentId(Long amendmentId) {
		this.amendmentId = amendmentId;
	}
	public Long getMasterAgreementId() {
		return masterAgreementId;
	}
	public void setMasterAgreementId(Long masterAgreementId) {
		this.masterAgreementId = masterAgreementId;
	}
	public PartyBAckStatus getAcknowledgementStatus() {
		return acknowledgementStatus;
	}
	public void setAcknowledgementStatus(PartyBAckStatus acknowledgementStatus) {
		this.acknowledgementStatus = acknowledgementStatus;
	}
	public AmendmentStatus getAmendmentStatus() {
		return amendmentStatus;
	}
	public void setAmendmentStatus(AmendmentStatus amendmentStatus) {
		this.amendmentStatus = amendmentStatus;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Long getDeleted() {
		return deleted;
	}
	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}
	public FundNameChange getFundNameChange() {
		return fundNameChange;
	}
	public void setFundNameChange(FundNameChange fundNameChange) {
		this.fundNameChange = fundNameChange;
	}
	public ExhibitValueChange getExhibitValueChange() {
		return exhibitValueChange;
	}
	public void setExhibitValueChange(ExhibitValueChange exhibitValueChange) {
		this.exhibitValueChange = exhibitValueChange;
	}
	public MasterAgreement getMasterAgreement() {
		return masterAgreement;
	}
	public void setMasterAgreement(MasterAgreement masterAgreement) {
		this.masterAgreement = masterAgreement;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getDealerAction() {
		return dealerAction;
	}
	public void setDealerAction(String dealerAction) {
		this.dealerAction = dealerAction;
	}
	public PartyBDeskReviewStatus getDeskStatus() {
		return deskStatus;
	}
	public void setDeskStatus(PartyBDeskReviewStatus deskStatus) {
		this.deskStatus = deskStatus;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PartyBEntity other = (PartyBEntity) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	public boolean isPartyBHidden() {
		return partyBHidden;
	}
	public void setPartyBHidden(boolean partyBHidden) {
		this.partyBHidden = partyBHidden;
	}
}
