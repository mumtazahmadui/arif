package com.markit.ms.rfa.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.service.IMcsRedirectUrlGenerator;

@Service
public class RfaEmailNotificationUrlGenerator implements IMcsRedirectUrlGenerator {

	@Resource
	protected QueryService<String> getConfigProperty;
	protected String emailNotificationType;
		
	protected void checkQueryString(Map<String, String> params) throws Exception{
		if(emailNotificationType.equalsIgnoreCase("sellsideRejectsRfa")
				|| emailNotificationType.equalsIgnoreCase("buysideRecallsRfa")
				|| emailNotificationType.equalsIgnoreCase("buysideWithdrawsPartyb")
				|| emailNotificationType.equalsIgnoreCase("sellsideSendsRfa")
				|| emailNotificationType.equalsIgnoreCase("sellsideSignatoryEsign")) checkForAmendmentId(params);
		else if (emailNotificationType.equalsIgnoreCase("buysideSendsRfa")) checkBuysideSendsRfaParams(params);
	}

	private void checkForAmendmentId(Map<String, String> params) throws Exception{
		if (params.containsKey("amendment_id")){
			return;
		}
		else {
			throw new RFAException("Invalid Parameters passed when generating email notification URL."
					+ " Expecting amendment_id as key to parameter map");
		}
	}
	
	private void checkBuysideSendsRfaParams(Map<String, String> params) throws Exception {
		if (params.containsKey("amendment_id") && params.containsKey("exhibit_id")){
			return;
		}
		else {
			throw new RFAException("Invalid Parameters passed when generating Buyside Sent RFA email notification URL."
					+ " Expecting amendment_id and exhibit_id as keys to parameter map");
		}
	}
	
	// TODO: Add methods to check that parameters meet protocol for McsRedirectionControllerM
	
	/**
	 * @param type specifies the type of notification
	 * @param queryStringParams
	 * @return
	 */
	public String generateUrl(Map<String,String> queryStringParams) throws Exception{
		checkQueryString(queryStringParams);
		StringBuilder url = new StringBuilder();
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("propertyName", "servername");
		String servername = getConfigProperty.executeQuery(parameters);
		url.append(servername);
		url.append("/home/index.jsp#RFA.Dashboard.Default?action=");
		url.append(emailNotificationType);
        for (Map.Entry<String, ?> entry : queryStringParams.entrySet()){
        	url.append("&" + entry.getKey() + "=" + entry.getValue());
        }
		return url.toString();
	}
	
	public void setEmailNotificationType(String emailNotificationtype){
		this.emailNotificationType = emailNotificationtype;
	}
	
	public String getEmailNotificationType(){
		return this.emailNotificationType;
	}
}
