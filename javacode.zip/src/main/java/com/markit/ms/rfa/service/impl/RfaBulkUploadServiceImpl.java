package com.markit.ms.rfa.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IMasterAgreementDao;
import com.markit.ms.rfa.dao.IPartyBDao;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.rfabulkupload.factory.ActionFactory;
import com.markit.ms.rfa.rfabulkupload.factory.FactoryActionChain;
import com.markit.ms.rfa.service.ILetterTemplateService;
import com.markit.ms.rfa.service.IRfaBulkUploadService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFABulkUploadUtil;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author prashant.aggarwal
 *
 */
@Service
public class RfaBulkUploadServiceImpl implements IRfaBulkUploadService {

	@Autowired
	private IMasterAgreementDao masterAgreementDao;

	@Autowired
	private ILetterTemplateService letterTemplateService;

	@Autowired
	private IPartyBDao partyBDao;

	@Autowired
	ActionFactory actionFactory;

	@Autowired
	CommonValidator commonValidator;

	private static final Logger logger = LoggerFactory.getLogger(RfaBulkUploadServiceImpl.class.getName());

	@Override
	public void determineActionOnMl(RfaBulkUploadRow rfaBulkUploadRow) {

		logger.info("Determining Action on Masterlist...");

		String rule = rfaBulkUploadRow.getRfaUploadTemplate().getRule(RFAConstants.ACTION);
		getPartyBEntityId(rfaBulkUploadRow);

		if (CommonUtil.isNull(rfaBulkUploadRow.getPartyBEntityId())) {
			return;
		}

		FactoryActionChain factory = actionFactory.getActionChain(rfaBulkUploadRow.getAction().getType());
		factory.setChainAndProcess(rfaBulkUploadRow);

	}

	private void getPartyBEntityId(RfaBulkUploadRow rfaBulkUploadRow) {

		logger.info("Determining Entity Id from RFA Upload Row...");

		Long entityId;

		for (RFAUploadTemplateField field : rfaBulkUploadRow.getRfaUploadTemplate().getTemplateFields()) {
			switch (field.getFieldIdentifier()) {
			case RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD: {
				if (field.getEntityIdentifier() == 1) {
					entityId = partyBDao.getPartyBIdFromMCPM(field.getFieldIdentifier(),
							rfaBulkUploadRow.getPartyBClientIdentifier(),
							rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());// need to pass companyId
					if (CommonUtil.isNull(entityId)) {
						Map<String, String> placeHolderMap = new HashMap<String, String>();
						placeHolderMap.put("fieldLabel", field.getFieldLabel());
						rfaBulkUploadRow.addError(RFAConstants.NOT_FOUND_IN_MCPM, placeHolderMap);
						return;
					}
					rfaBulkUploadRow.setPartyBEntityId(entityId);
				}
				break;
			}
			case RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD: {
				if (field.getEntityIdentifier() == 1) {
					entityId = partyBDao.getPartyBIdFromMCPM(field.getFieldIdentifier(),
							rfaBulkUploadRow.getPartyBTrueLegalName(),
							rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());// need to pass companyId
					if (CommonUtil.isNull(entityId)) {
						Map<String, String> placeHolderMap = new HashMap<String, String>();
						placeHolderMap.put("fieldLabel", field.getFieldLabel());
						rfaBulkUploadRow.addError(RFAConstants.NOT_FOUND_IN_MCPM, placeHolderMap);
						return;
					}
					rfaBulkUploadRow.setPartyBEntityId(entityId);
				}
				break;
			}
			case RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD: {
				if (field.getEntityIdentifier() == 1) {
					entityId = partyBDao.getPartyBIdFromMCPM(field.getFieldIdentifier(),
							rfaBulkUploadRow.getSleeveClientIdentifier(),
							rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());// need to pass companyId
					rfaBulkUploadRow.setSleeveEntityId(entityId);
				}
				break;
			}
			case RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD: {
				if (field.getEntityIdentifier() == 1) {
					entityId = partyBDao.getPartyBIdFromMCPM(field.getFieldIdentifier(),
							rfaBulkUploadRow.getSleeveTrueLegalName(),
							rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());// need to pass companyId
					rfaBulkUploadRow.setSleeveEntityId(entityId);
				}
				break;
			}
			}
		}

	}

	@Override
	public RfaBulkUploadRow determineMLExhibitLinkage(RfaBulkUploadRow rfaBulkUploadRow) {
		rfaBulkUploadRow = masterAgreementDao.checkMasterListExhibitLinkage(rfaBulkUploadRow);
		return rfaBulkUploadRow;
	}

	@Override
	public RfaBulkUploadRow determineLetterTemplate(RfaBulkUploadRow rfaBulkUploadRow) {

		logger.info("Determining Letter template for RFA Upload Row...");

		if (CommonUtil.isNotNull(rfaBulkUploadRow)) {
			List<String> requestIdentifiedList = new ArrayList<String>();
			RFAUploadTemplateField rfaUploadTemplateField = RFABulkUploadUtil
					.getRFAUploadTemplateField(rfaBulkUploadRow.getRfaUploadTemplate(), RFAConstants.ACTION);

			String actionRule = rfaUploadTemplateField.getRule();

			Long companyId = rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId();

			List<LetterTemplate> letterTemplates = letterTemplateService.getAllLetterTemplatesByCompanyId(companyId);

			StringBuilder letterTemplateName = new StringBuilder();

			Map<BulkUploadAction, LetterTemplate> templateMap = new HashMap<BulkUploadAction, LetterTemplate>();
			BulkUploadAction actionString = null;
			for (BulkUploadAction request : rfaBulkUploadRow.getRequestIdentified()) {

				if (BulkUploadAction.fromType(actionRule).equals(BulkUploadAction.BLANK)) {
					letterTemplateName.append(BulkUploadAction.ALL_ACTIONS.getName()).append("-")
							.append(rfaBulkUploadRow.getMlIdentifier());
				} else {
					letterTemplateName.append(actionRule).append("-").append(rfaBulkUploadRow.getMlIdentifier());
				}

				LetterTemplate letterTemplate = findLetterTemplateByName(letterTemplates,
						letterTemplateName.toString());
				if (CommonUtil.isNull(letterTemplate)) {
					letterTemplateName.setLength(0);
					if (CommonUtil.isEqual(request.getName(), RFAConstants.FNC) || CommonUtil.isEqual(request.getName(), RFAConstants.EVC)) {
						letterTemplateName = new StringBuilder(RFAConstants.MODIFICATIONS).append("-")
								.append(rfaBulkUploadRow.getMlIdentifier());
						letterTemplate = findLetterTemplateByName(letterTemplates, letterTemplateName.toString());
					}
					if (CommonUtil.isNull(letterTemplate)) {
						letterTemplateName.setLength(0);
						letterTemplateName.append(request.getName()).append("-")
								.append(rfaBulkUploadRow.getMlIdentifier());

						letterTemplate = findLetterTemplateByName(letterTemplates, letterTemplateName.toString());
					}
					if (CommonUtil.isNull(letterTemplate)) {
						Map<String, String> placeHolderMap = new HashMap<String, String>();
						placeHolderMap.put("requestType", request.getName());
						rfaBulkUploadRow.addError(RFAConstants.RFA_LETTER_TEMPLATE_DOESNT_EXIST, placeHolderMap);
					}
				}

				templateMap.put(request, letterTemplate);
				letterTemplateName = new StringBuilder();

			}

			rfaBulkUploadRow.setLetterTemplate(templateMap);

		}
		return rfaBulkUploadRow;
	}

	private static LetterTemplate findLetterTemplateByName(List<LetterTemplate> letterTemplates, String name) {

		for (LetterTemplate letterTemplate : letterTemplates) {
			try {
				String ltName = letterTemplate.getName();
				String[] arr = ltName.split("-", 2);
				String ltNameTrimmed = null;
				if (arr.length > 1)
					ltNameTrimmed = arr[0].trim() + "-" + arr[1].trim();
				if (name.equalsIgnoreCase(ltNameTrimmed))
					return letterTemplate;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

}
