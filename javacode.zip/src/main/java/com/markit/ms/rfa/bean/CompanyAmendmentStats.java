package com.markit.ms.rfa.bean;

public class CompanyAmendmentStats {

	private RequestStatus requestStatus;
	private PendingTasks pendingTasks;
	public RequestStatus getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(RequestStatus requestStatus) {
		this.requestStatus = requestStatus;
	}
	public PendingTasks getPendingTasks() {
		return pendingTasks;
	}
	public void setPendingTasks(PendingTasks pendingTasks) {
		this.pendingTasks = pendingTasks;
	}
	
}
