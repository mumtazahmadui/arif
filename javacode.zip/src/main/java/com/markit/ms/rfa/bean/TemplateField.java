package com.markit.ms.rfa.bean;

/**
 * @author prashant.aggarwal
 *
 */
public class TemplateField {
	
	private Long id;
	private String fieldIdentifier;
	private String fieldLabel;
	private Integer fieldVisibility;
	private Integer fieldOrder;	
	private Long mlTemplateId;
	
	public TemplateField() {
	}	
	
	public TemplateField(String fieldIdentifier, String fieldLabel, Integer fieldVisibility, Integer fieldOrder,
			Long mlTemplateId) {
		super();
		this.fieldIdentifier = fieldIdentifier;
		this.fieldLabel = fieldLabel;
		this.fieldVisibility = fieldVisibility;
		this.fieldOrder = fieldOrder;
		this.mlTemplateId = mlTemplateId;
	}
	
	public TemplateField(String fieldIdentifier, String fieldLabel, Integer fieldVisibility, Integer fieldOrder) {
		this.fieldIdentifier = fieldIdentifier;
		this.fieldLabel = fieldLabel;
		this.fieldVisibility = fieldVisibility;
		this.fieldOrder = fieldOrder;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFieldIdentifier() {
		return fieldIdentifier;
	}
	public void setFieldIdentifier(String fieldIdentifier) {
		this.fieldIdentifier = fieldIdentifier;
	}
	public String getFieldLabel() {
		return fieldLabel;
	}
	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}
	public Integer getFieldVisibility() {
		return fieldVisibility;
	}
	public void setFieldVisibility(Integer fieldVisibility) {
		this.fieldVisibility = fieldVisibility;
	}
	public Integer getFieldOrder() {
		return fieldOrder;
	}
	public void setFieldOrder(Integer fieldOrder) {
		this.fieldOrder = fieldOrder;
	}
	public Long getMlTemplateId() {
		return mlTemplateId;
	}
	public void setMlTemplateId(Long mlTemplateId) {
		this.mlTemplateId = mlTemplateId;
	}
	
	
}
