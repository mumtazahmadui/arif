package com.markit.ms.rfa.bean;

import java.util.ArrayList;
import java.util.List;

public class NewExhibitRequest {

	private String textContent;

	private String htmlContent;

	private List<ExhibitCellValue> cellValues;

	private String comment;

	private List<AmendmentCommentAudit> commentlog;

	private List<AmendmentChangeAudit> changelog;

	private Long rfaid;

	private ActionCount changeLogCount;
	private ActionCount commentCount;
	private String partyType;

	public String getTextContent() {
		return textContent;
	}

	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}

	public String getHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}

	public List<ExhibitCellValue> getCellValues() {
		if (cellValues == null) {
			cellValues = new ArrayList<ExhibitCellValue>();
		}
		return cellValues;
	}

	public void setCellValues(List<ExhibitCellValue> cellValues) {
		this.cellValues = cellValues;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public List<AmendmentCommentAudit> getCommentlog() {
		return commentlog;
	}

	public void setCommentlog(List<AmendmentCommentAudit> commentlog) {
		this.commentlog = commentlog;
	}

	public List<AmendmentChangeAudit> getChangelog() {
		return changelog;
	}

	public void setChangelog(List<AmendmentChangeAudit> changelog) {
		this.changelog = changelog;
	}

	public Long getRfaid() {
		return rfaid;
	}

	public void setRfaid(Long rfaid) {
		this.rfaid = rfaid;
	}

	public ActionCount getChangeLogCount() {
		return changeLogCount;
	}

	public void setChangeLogCount(ActionCount changeLogCount) {
		this.changeLogCount = changeLogCount;
	}

	public ActionCount getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(ActionCount commentCount) {
		this.commentCount = commentCount;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

}