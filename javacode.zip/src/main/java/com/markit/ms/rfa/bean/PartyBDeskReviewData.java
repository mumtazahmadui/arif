package com.markit.ms.rfa.bean;

import java.util.Date;
import java.util.List;

/***
 * Holds the reviewed details for each desk of amendment letter partyB.
 * And holds data for desk action also
 * <p>
 * Table (RFA_PARTYB_DESK_REVIEW_HISTORY)
 * </p>
 * 
 * @since RFA5.0
 */
public class PartyBDeskReviewData{
	
	private Long partyBId;
	private Long amendmentId;
	private List<Long> partyBIds;
	private List<Long> amendmentIds;
	private Boolean reviewed;
	private Date createdDate;
	private Long createdBy;
	private String deskCode;
	private Boolean bulkAction;
	private Long companyId;
	private List<Long> userIds;
	private String message;
	private List<String> emailIds;
	private String subject;

	public Long getPartyBId() {
		return partyBId;
	}
	public void setPartyBId(Long partyBId) {
		this.partyBId = partyBId;
	}
	public Boolean isReviewed() {
		return reviewed;
	}
	public void setReviewed(Boolean reviewed) {
		this.reviewed = reviewed;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public String getDeskCode() {
		return deskCode;
	}
	public void setDeskCode(String deskCode) {
		this.deskCode = deskCode;
	}
	public Boolean isBulkAction() {
		return bulkAction;
	}
	public void setBulkAction(Boolean isBulkAction) {
		this.bulkAction = isBulkAction;
	}
	public List<Long> getPartyBIds() {
		return partyBIds;
	}
	public void setPartyBIds(List<Long> partyBIds) {
		this.partyBIds = partyBIds;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public List<Long> getUserIds() {
		return userIds;
	}
	public void setUserIds(List<Long> userIds) {
		this.userIds = userIds;
	}
	public List<Long> getAmendmentIds() {
		return amendmentIds;
	}
	public void setAmendmentIds(List<Long> amendmentIds) {
		this.amendmentIds = amendmentIds;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getAmendmentId() {
		return amendmentId;
	}
	public void setAmendmentId(Long amendmentId) {
		this.amendmentId = amendmentId;
	}
	public List<String> getEmailIds() {
		return emailIds;
	}
	public void setEmailIds(List<String> emailIds) {
		this.emailIds = emailIds;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
}
