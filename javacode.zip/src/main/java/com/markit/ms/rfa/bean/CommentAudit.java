package com.markit.ms.rfa.bean;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class CommentAudit {
	SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");  
	private String id;
	private String userId;
	private String userName;
	private long time;
	private String text;
	private String timeStamp;

	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getTimeStamp() {
		return formatter.format(new Date((long)time*1000));
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
}
