package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.ExhibitValueChange;
import com.markit.ms.rfa.bean.FundNameChange;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;

public class PartyBEntityRowMapper implements RowMapper<PartyBEntity> {
	
	public PartyBEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
		PartyBEntity partyBEntity = new PartyBEntity();
		partyBEntity.setId(rs.getLong("id"));
		partyBEntity.setIsAdded(rs.getLong("is_added") == 1 ? true : false);
		partyBEntity.setIsModified(rs.getLong("added_for_modification") == 1 ? true : false);
		partyBEntity.setAmendmentId(rs.getLong("amendment_id"));
		partyBEntity.setMasterAgreementId(rs.getLong("master_agreement_id"));
		partyBEntity.setAcknowledgementStatus(PartyBAckStatus.fromString(rs.getString("ack_status")));
		partyBEntity.setReason(rs.getString("reason"));
		partyBEntity.setAmendmentStatus(AmendmentStatus.fromString(rs.getString("amendment_status")));
		FundNameChange fundNameChange = new FundNameChange();
		fundNameChange.setId(rs.getLong("rfa_partyb_fund_name_change_id"));
		partyBEntity.setFundNameChange(fundNameChange);
		ExhibitValueChange exhibitValueChange = new ExhibitValueChange();
		exhibitValueChange.setId(rs.getLong("rfa_partyb_exhibit_value_change_id"));
		partyBEntity.setExhibitValueChange(exhibitValueChange);
		Entity entity = new Entity();
		entity.setId(rs.getLong("entity_id"));
		entity.setName(rs.getString("name"));
		entity.setTrueLegalName(rs.getString("legal_name"));
		entity.setClientIdentifier(rs.getString("moniker_name"));
		entity.setLei(rs.getString("lei_name"));
		entity.setIsSleeve(rs.getLong("is_sleeve"));
		entity.setParentTrueLegalName(rs.getString("parentTrueLegalName"));
		entity.setMasterlistTrueLegalName(null != rs.getString("masterlist_true_legal_name") ?
				rs.getString("masterlist_true_legal_name") : "");
		partyBEntity.setEntity(entity);
		return partyBEntity;
	}
}
