package com.markit.ms.rfa.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.MasterAgreementBasic;
import com.markit.ms.rfa.bean.MasterlistTemplate;
import com.markit.ms.rfa.bean.MasterlistTemplateDownload;
import com.markit.ms.rfa.bean.TemplateField;
import com.markit.ms.rfa.dao.IMasterlistTemplateDAO;
import com.markit.ms.rfa.dao.resultsetextractor.MasterAgreementBasicResultSetExtractor;
import com.markit.ms.rfa.dto.MasterlistTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAGenericException;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author prashant.aggarwal
 *
 */
@Repository
public class MasterlistTemplateDAOImpl extends BaseDAOImpl implements IMasterlistTemplateDAO
{
	@Value("${SAVE_MASTERLIST_TEMPLATE}")
	private String SAVE_MASTERLIST_TEMPLATE;

	@Value("${SAVE_MASTERLIST_TEMPLATE_FIELD}")
	private String SAVE_MASTERLIST_TEMPLATE_FIELD;

	@Value("${GET_MASTERLIST_TEMPLATE_BY_ID}")
	private String GET_MASTERLIST_TEMPLATE_BY_ID;

	@Value("${GET_MASTERLIST_TEMPLATE_BY_IDS}")
	private String GET_MASTERLIST_TEMPLATE_BY_IDS;
	
	@Value("${GET_MASTERAGREEMENTBASIC}")
	private String GET_MASTERAGREEMENTBASIC;

	@Value("${GET_COUNT_MLTEMPLATE_BY_NAME}")
	private String GET_COUNT_MLTEMPLATE_BY_NAME;

	@Value("${GET_MLTEMPLATE_FIELDS_BY_MLTID}")
	private String GET_MLTEMPLATE_FIELDS_BY_MLTID;

	@Value("${DELETE_MLTEMPLATE}")
	private String DELETE_MLTEMPLATE;

	@Value("${COUNT_MLS_BY_MLTEMPLATEIDS}")
	private String COUNT_MLS_BY_MLTEMPLATEIDS;
	
	@Value("${COUNT_MLTID_BY_MLTEMPLATEID}")
	private String COUNT_MLTID_BY_MLTEMPLATEID;
	
	@Value("${GET_MASTERLIST_TEMPLATE_COLUMNS}")
	private String GET_MASTERLIST_TEMPLATE_COLUMNS;
	
	@Value("${GET_TEMPLATE_BY_MASTERAGREEMENT}")
	private String GET_TEMPLATE_BY_MASTERAGREEMENT;

	@Override
	public MasterlistTemplate saveMasterlistTemplate(MasterlistTemplate masterlistTemplate) {


		/*SqlParameterSource paramSource = new MapSqlParameterSource()
	        	.addValue("templateName", masterlistTemplate.getTemplateName())
	        	.addValue("companyId", masterlistTemplate.getCompanyId())
	            .addValue("createdBy", masterlistTemplate.getCreatedBy())
	            .addValue("modifiedBy", masterlistTemplate.getModifiedBy());*/

		SqlParameterSource paramSourceMLT = new BeanPropertySqlParameterSource(masterlistTemplate);	        	
		KeyHolder keyHolder = new GeneratedKeyHolder();

		namedParameterJdbcTemplate.update(SAVE_MASTERLIST_TEMPLATE, paramSourceMLT, keyHolder);

		List<SqlParameterSource> paramSourceTF = new ArrayList<SqlParameterSource>();
		List<TemplateField> templateFields = masterlistTemplate.getTemplateFields();

		for(TemplateField templateField: templateFields){
			templateField.setMlTemplateId(keyHolder.getKey().longValue());
			paramSourceTF.add(new BeanPropertySqlParameterSource(templateField));
		}
		namedParameterJdbcTemplate.batchUpdate(SAVE_MASTERLIST_TEMPLATE_FIELD, paramSourceTF.toArray(new SqlParameterSource[paramSourceTF.size()])); 	        		

		masterlistTemplate.setId(keyHolder.getKey().longValue());
		return getMasterlistTemplateById(masterlistTemplate.getId());		 
	}

	@Override
	public MasterlistTemplate getMasterlistTemplateById(Long id)
	{      
		MasterlistTemplate masterlistTemplate = null;
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);

		/*MasterlistTemplate masterlistTemplate = namedParameterJdbcTemplate.queryForObject(
    			GET_MASTERLIST_TEMPLATE_BY_ID, paramSource, new MasterlistTemplateRowMapper());*/

		//namedParameterJdbcTemplate.queryForObject(sql, paramSource, rowMapper)
		Long countMltExists = namedParameterJdbcTemplate.queryForObject(COUNT_MLTID_BY_MLTEMPLATEID, paramSource, Long.class);
		if(countMltExists == 0){			
			throw new RFAGenericException(RFAConstants.MASTERLIST_TEMPLATE_DOESNT_EXIST, HttpStatus.NOT_FOUND);
		}else{
			masterlistTemplate = namedParameterJdbcTemplate.queryForObject(GET_MASTERLIST_TEMPLATE_BY_ID, paramSource, new BeanPropertyRowMapper<MasterlistTemplate>(MasterlistTemplate.class));
			List<TemplateField> templateFields = getTemplateFieldsByMLTemplateId(id);
			masterlistTemplate.setTemplateFields(templateFields);
		}
		return masterlistTemplate;
	}

	@Override
	public List<TemplateField> getTemplateFieldsByMLTemplateId(Long mlTemplateId){        
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("mlTemplateId", mlTemplateId);
		List<TemplateField> templateFields = namedParameterJdbcTemplate.query(GET_MLTEMPLATE_FIELDS_BY_MLTID, paramSource, new BeanPropertyRowMapper<TemplateField>(TemplateField.class));
		return templateFields;
	}

	@Override
	public Long getCountMasterlistTemplateByName(String templateName,Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
								.addValue("templateName", templateName)
								.addValue("companyId", companyId);

		Long id = namedParameterJdbcTemplate.queryForObject(GET_COUNT_MLTEMPLATE_BY_NAME, paramSource, Long.class);
		return id;
	}

	@Override
	public Integer deleteMasterListTemplateById(Long id) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);
		Integer count = namedParameterJdbcTemplate.update(DELETE_MLTEMPLATE, paramSource);
		return count;
	}
	
	@Override
	public List<MasterlistTemplate> getMasterlistTemplateGrid(Long companyId,
			MasterlistTemplateSearchRequest templateSearchRequest) {	

		StringBuilder whereCondition = new StringBuilder();
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId)
				.addValue("offset", templateSearchRequest.getOffSet())
				.addValue("page_size", templateSearchRequest.getPageSize());		
		
		List<Lookup> mlTemplateNameLookUps =  templateSearchRequest.getMlTemplateName();  

		//if mlTemplateNames are selected in search criteria
		if(null != mlTemplateNameLookUps && mlTemplateNameLookUps.size() > 0) {
			List<Long> mlTemplateIds = new ArrayList<Long>();
			for (Lookup lookup : mlTemplateNameLookUps) {
				mlTemplateIds.add(lookup.getId());
			}
			paramSource.addValue("mlTemplateIds", mlTemplateIds);
			whereCondition.append(" and mlt.id in (:mlTemplateIds)");
		}
		
		String gridQuery = GET_MASTERLIST_TEMPLATE_BY_IDS.replaceAll("whereCondition", whereCondition.toString());
		
		List<MasterlistTemplate> masterlistTemplates = namedParameterJdbcTemplate.query(gridQuery, paramSource, new BeanPropertyRowMapper<MasterlistTemplate>(MasterlistTemplate.class));

		List<Long> mlTemplateIdsInGrid = new ArrayList<Long>();
		for(MasterlistTemplate masterlistTemplate : masterlistTemplates){
			mlTemplateIdsInGrid.add(masterlistTemplate.getId());
		}
		
		MapSqlParameterSource queryParamSource = new MapSqlParameterSource().addValue("mlTemplateIds", mlTemplateIdsInGrid);
		Map<Long, List<MasterAgreementBasic>> agreementTemplateIdMap = namedParameterJdbcTemplate.query(GET_MASTERAGREEMENTBASIC, queryParamSource, new MasterAgreementBasicResultSetExtractor());
		
		for(MasterlistTemplate masterlistTemplate : masterlistTemplates){
			masterlistTemplate.setMasterListLinked(agreementTemplateIdMap.get(masterlistTemplate.getId()));
		}
		
		return masterlistTemplates;
	}

	@Override
	public List<MasterlistTemplateDownload> getMasterlistTemplateColumns(Long mlTemplateId) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("mlTemplateId", mlTemplateId);
		List<MasterlistTemplateDownload> mlTemplate = namedParameterJdbcTemplate.query(GET_MASTERLIST_TEMPLATE_COLUMNS, paramSource, new BeanPropertyRowMapper<MasterlistTemplateDownload>(MasterlistTemplateDownload.class));
		return mlTemplate;
	}

	@Override
	public Long getMasterlistTemplateByMasterlist(Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("masterAgreementId", masterAgreementId);
		Long id = namedParameterJdbcTemplate.queryForObject(GET_TEMPLATE_BY_MASTERAGREEMENT, paramSource, Long.class);
		return id;
	}
}
