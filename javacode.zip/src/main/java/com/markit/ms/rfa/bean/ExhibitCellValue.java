package com.markit.ms.rfa.bean;

public class ExhibitCellValue {
private Long partyBId;
public Long getPartyBId() {
	return partyBId;
}
public void setPartyBId(Long partyBId) {
	this.partyBId = partyBId;
}
public Long getExhibitColumnId() {
	return exhibitColumnId;
}
public void setExhibitColumnId(Long exhibitColumnId) {
	this.exhibitColumnId = exhibitColumnId;
}
public String getCellValue() {
	return cellValue;
}
public void setCellValue(String cellValue) {
	this.cellValue = cellValue;
}
private Long exhibitColumnId;
private String cellValue;
}
