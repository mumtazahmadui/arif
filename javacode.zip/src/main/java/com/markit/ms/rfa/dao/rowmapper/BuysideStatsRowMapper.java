package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.CompanyAmendmentStats;
import com.markit.ms.rfa.bean.PendingTasks;
import com.markit.ms.rfa.bean.RequestStatus;

public class BuysideStatsRowMapper implements RowMapper<CompanyAmendmentStats>{

	
	@Override
	public CompanyAmendmentStats mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		CompanyAmendmentStats companyAmendmentStats = new CompanyAmendmentStats();
		RequestStatus requestStatus = new RequestStatus();
		PendingTasks pendingTasks = new PendingTasks();
		
		requestStatus.setDraft(rs.getLong("draft"));
		requestStatus.setDeleted(rs.getLong("Deleted"));
		requestStatus.setCompleted(rs.getLong("Completed"));
		requestStatus.setSubmitted(rs.getLong("Submitted"));
		requestStatus.setPartiallyCompleted(rs.getLong("PartiallyCompleted"));
		requestStatus.setRecalled(rs.getLong("Recalled"));
		requestStatus.setRejected(rs.getLong("Rejected"));
		companyAmendmentStats.setRequestStatus(requestStatus);
		
		pendingTasks.setPendingEsign(rs.getLong("ELECTRONIC_SIGNATURE"));
		pendingTasks.setPendingExhibitComplete(rs.getLong("EXHIBIT_COMPLETION"));
		pendingTasks.setSendRFA(rs.getLong("BS_SEND_RFA"));
		companyAmendmentStats.setPendingTasks(pendingTasks);
		return companyAmendmentStats;
	}
	
}
