package com.markit.ms.rfa.util;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Component;

@Component
public class ErrorMessageBuilder {

    @Autowired
    private MessageSource errorSource;

    public String buildErrorMessage(String errorCode) {
        return buildErrorMessage(errorCode, StringUtils.EMPTY);
    }

    public String buildErrorMessage(String errorCode, Object... params) {
        String message = "";
        try {
            message = errorSource.getMessage(errorCode, params, CommonUtil.getCurrentLocale());
        } catch (NoSuchMessageException nsme) {
            message = "??" + errorCode + "??";
        }
        return message;

    }
}
