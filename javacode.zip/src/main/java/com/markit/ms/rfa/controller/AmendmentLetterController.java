package com.markit.ms.rfa.controller;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.kyc.esign.util.EsignDocUtil;
import com.markit.kyc.security.UserUtils;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.model.CommonBaseRequest;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.CommonBaseSearchResponse;
import com.markit.ms.common.model.CommonFileResponse;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.RFAStatusEnum;
import com.markit.ms.rfa.dto.AmendmentLetterSearchRequest;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.security.McpmUserxsDetails;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.ConsolidateFileUtil;
import com.markit.ms.rfa.util.PDFContextGenerator;
import com.markit.ms.rfa.util.PDFUtil;
import com.markit.ms.rfa.util.QRCodeUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1/company")
@Api(value = "amendment_letter" , description = "Amendment Letter APIs")
public class AmendmentLetterController {
	
	private static final SimpleDateFormat dateTimeSdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
	
    private static final String[] WSIG_FILE_FORMATS = {"jpeg","jpg","pdf","tiff","tif","png"};

	// TODO: Test Git change...
	
	@Autowired
    private IAmendmentLetterService amendmentLetterService;
	
	@Autowired
    private IFileService fileService;
	
	@Resource IReportGenerator reportGenerator;
	
	@Value("${buyside}")
	private String buyside;
	
	@Value("${sellside}")
	private String sellside;
	
	@Autowired
	ConsolidateFileUtil consolidateFileUtil;

	
	@Resource QueryService<Grid> selectHistory;
	//TODO-Sajil rename the method to saveAmendmentLettsers
	@RequestMapping(value = "{companyId}/amendment_letter", method = RequestMethod.POST)
    @ApiOperation(value = "Bulk Save Amendment Letters")
    public CommonBaseResponse<List<AmendmentLetter>> bulkSaveAmendmentLetter(@PathVariable Long companyId
    		, @RequestBody CommonBaseRequest<List<AmendmentLetter>> amendmentLetterRequest
    		, HttpServletRequest request) throws Exception{
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		String ipAddress = CommonUtil.obtainIpAddress(request);
    	List<AmendmentLetter> amendmentLetterList = amendmentLetterService.bulkSaveAmendmentLetters(
    			companyId, companyType, amendmentLetterRequest.getUserId(), amendmentLetterRequest.getData(), ipAddress);
        CommonBaseResponse<List<AmendmentLetter>> commonBaseResponse = new CommonBaseResponse<List<AmendmentLetter>>();
        commonBaseResponse.setData(amendmentLetterList);
        return commonBaseResponse;        
    }
	
	@RequestMapping(value = "{companyId}/amendment_letter/{amendment_id}/{logEvent}/pdf", method = RequestMethod.GET)
    @ApiOperation(value = "Get Amendment Letter PDF")
	@ResponseBody
    public void generatePDF(@PathVariable Long companyId
    		, @PathVariable Boolean logEvent
    		, @PathVariable Long amendment_id,HttpServletRequest request
    		, HttpServletResponse response) throws Exception{
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		long userId = CommonUtil.getUserIdFromSession(request);
		PDFContext pdfContext = null;
		String eventName = null;
		if(companyType.equals(RFAConstants.COMPANY_TYPE_SS)) {
			pdfContext = PDFContextGenerator.getSellSideEsignFrameContext();
			eventName = RFAConstants.EVENT_NAME_PRINT_DOWNLOAD_SS;
		} else {
			pdfContext = PDFContextGenerator.getBuySideEsignFrameContext();
			eventName = RFAConstants.EVENT_NAME_PRINT_DOWNLOAD_BS;
		}
		
		byte[] pdf = reportGenerator.getPDFContent(amendment_id, pdfContext);
		byte[] wSignByte = consolidateFileUtil.consolidateWetSignsByRFAId(amendment_id, companyId, userId);
		if (CommonUtil.isNotNull(wSignByte))
			pdf = PDFUtil.merge(pdf, wSignByte);

		final String FILE_NAME = amendment_id + ".pdf";
	    WebUtils.write2Response(response, pdf, "application/pdf",  FILE_NAME, true);
	    if(logEvent) {
	    	Long downloadId = amendmentLetterService.getNextAvailableDownloadId();
	    	updateLogForPrintNDownloadSinglePDF(amendment_id, request.getRemoteAddr(), companyType, companyId, userId, eventName, downloadId); 
	    }
    }
	
	@RequestMapping(value = "{companyId}/amendment_letter/{amendment_id}/wetSignConsolidatedPdf", method = RequestMethod.GET)
    @ApiOperation(value = "Get Wet Sign Consolidated PDF")
	@ResponseBody
    public void getWetSignConsolidatedPDF(@PathVariable Long companyId
    		, @PathVariable Long amendment_id,HttpServletRequest request
    		, HttpServletResponse response) throws Exception{
		long userId = CommonUtil.getUserIdFromSession(request);
		byte[] wSignByte = consolidateFileUtil.consolidateWetSignsByRFAId(amendment_id, companyId, userId);
		final String FILE_NAME = amendment_id + ".pdf";
	    WebUtils.write2Response(response, wSignByte, "application/pdf",  FILE_NAME, true);
    }
	
	//TODO-Sajil rename the method to updateAmendmentLettsers
	@RequestMapping(value = "{companyId}/amendment_letter", method = RequestMethod.PUT)
    @ApiOperation(value = "Bulk Update Amendment Letter")
    public CommonBaseResponse<List<AmendmentLetter>> bulkUpdateAmendmentLetter(@PathVariable Long companyId
    		, @RequestBody CommonBaseRequest<List<AmendmentLetter>> amendmentLetterRequest, HttpServletRequest request) throws Exception{
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		List<AmendmentLetter> amendmentLetterList = amendmentLetterService.bulkUpdateAmendmentLetter(
				companyIdFromSession, companyType, CommonUtil.getUserIdFromSession(request), amendmentLetterRequest.getData());
    	CommonBaseResponse<List<AmendmentLetter>> response = new CommonBaseResponse<List<AmendmentLetter>>();
    	response.setData(amendmentLetterList);
    	return response;        
    }
	
	@RequestMapping(value = "{companyId}/amendment_letter/{id}", method = RequestMethod.GET)
    @ApiOperation(value = "Get Amendment Letter")
    public CommonBaseResponse<AmendmentLetter> getAmendmentLetter(@PathVariable Long id, @PathVariable Long companyId, HttpServletRequest request) throws Exception {
		 Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
    	 CommonBaseResponse<AmendmentLetter> response = new  CommonBaseResponse<AmendmentLetter>();
    	 AmendmentLetter amendmentLetter = amendmentLetterService.getAmendmentLetterById(id, companyIdFromSession);
    	 response.setData(amendmentLetter);
    	 return response;        
    }
    
	@RequestMapping(value="{companyId}/amendment_letter/search",method = RequestMethod.POST)
    @ApiOperation(value = "Get Amendmentment Letters Grid")
    public CommonBaseSearchResponse<AmendmentLetter> getAmendmentLetters(@PathVariable Long companyId
    		, @RequestBody AmendmentLetterSearchRequest amendmentSearchRequest, HttpServletRequest request) throws Exception{
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
    	List<AmendmentLetter> amendmentLetterList = amendmentLetterService.getAmendmentLetterGrid(companyIdFromSession,amendmentSearchRequest);
//    	Long totalCount = amendmentLetterService.getAmendmentLetterGridTotalCount(companyIdFromSession, amendmentSearchRequest);
    	CommonBaseSearchResponse<AmendmentLetter>  commonBaseSearchResponse = new CommonBaseSearchResponse<AmendmentLetter>();
    	commonBaseSearchResponse.setDataList(amendmentLetterList);
    	commonBaseSearchResponse.setTotalCount(amendmentLetterList.size() > 0 ?amendmentLetterList.get(0).getTotalCount():0);
    	return commonBaseSearchResponse;        
    }
    
	@RequestMapping(value="{companyId}/amendment_letters/validation",method = RequestMethod.POST)
    @ApiOperation(value = "Validate Amendmentment Letters")
    public CommonBaseResponse<CommonFileResponse> validateAmendmentLetters(@PathVariable Long companyId
    		, @RequestBody CommonBaseRequest<List<AmendmentLetter>> amendmentLetterRequest, HttpServletRequest request) throws Exception{
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		CommonFileResponse commonFileResponse = amendmentLetterService.validateAmendmentLetters(
				companyIdFromSession, amendmentLetterRequest.getData(), CommonUtil.getUserIdFromSession(request));
    	CommonBaseResponse<CommonFileResponse> commonBaseResponse = new CommonBaseResponse<CommonFileResponse>();
    	if(null != commonFileResponse) {
    		commonBaseResponse.setFailed();
    	}
    	commonBaseResponse.setData(commonFileResponse);
    	return commonBaseResponse;        
    }
	
	@RequestMapping(value="{companyId}/amendment_letter/{id}/sign",method = RequestMethod.POST)
    @ApiOperation(value = "Sign Amendmentment Letter")
    public CommonBaseResponse<Integer> signAmendmentmentLetter(@PathVariable Long companyId, @PathVariable Long id
    		, @RequestBody CommonBaseRequest<Signature> signature, HttpServletRequest request ) throws Exception{
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String ipAddress = CommonUtil.obtainIpAddress(request);
		Long userId = CommonUtil.getUserIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		signature.getData().setAmendmentId(id);
		signature.getData().setCompanyType(CommonUtil.getCompanyTypeFromSession(request));
		signature.getData().setIpAddress(ipAddress);
		signature.getData().setSignType("E_SIGN");
		
		String eventName = null;
		if (companyType.equals(RFAConstants.COMPANY_TYPE_BS))
			eventName = RFAConstants.EVENT_NAME_E_SIGN_BS;
		else
			eventName = RFAConstants.EVENT_NAME_E_SIGN_SS;
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();		
    	CommonBaseResponse<Integer> commonBaseResponse = new CommonBaseResponse<Integer>();
    	commonBaseResponse.setData(amendmentLetterService.signAmendmentLetter(id,companyIdFromSession,signature.getData(), mcpmUserxsDetails.getUserxUser().getLoginName(),mcpmUserxsDetails.getLoggedInTime(), null));
    	Long fileId = consolidateFileUtil.consolidateAllSigns(id,  companyId,  userId,  companyType);
    	byte[] fileByte = fileService.getFile(fileId, companyId);
		int noOfPages = EsignDocUtil.getNoOfPages(fileByte);
  		amendmentLetterService.addTransitionLogs(userId, null, id, null, eventName,fileId,null,noOfPages,null);

    	return commonBaseResponse;        
    }
	
	@RequestMapping(value="{companyId}/amendment_letter/{id}/wsign",method = RequestMethod.POST)
    @ApiOperation(value = "Wet Sign Amendmentment Letter")
    public CommonBaseResponse<Integer> wetSignAmendmentmentLetter(@PathVariable Long companyId, @PathVariable Long id,
    		@RequestParam String fileName, @RequestParam String overwrite, @RequestParam final MultipartFile file, 
    		HttpServletRequest request ) throws RFAUIException, Exception{
		
		CommonBaseResponse<Integer> commonBaseResponse = new CommonBaseResponse<Integer>();
		String qrCodeText = id.toString();
		Boolean validQRpresent = null;
		
		if (!FilenameUtils.isExtension(fileName.toLowerCase(), WSIG_FILE_FORMATS)) {
			throw new RFAUIException(RFAConstants.INCORRECT_FILE_EXTENSION, HttpStatus.OK.toString());
		}
		
		if(file.getContentType().equals("application/pdf")) {
			validQRpresent = QRCodeUtil.isPdfWithValidQR(file.getBytes(), qrCodeText);
		} else {
			validQRpresent = QRCodeUtil.isImageWithValidQR(file.getBytes(), qrCodeText);
		}
		
		if (Boolean.FALSE.equals(validQRpresent) && CommonUtil.isEqual(overwrite, "false")) {
			commonBaseResponse.setFailed();
			throw new RFAUIException(RFAConstants.WSIG_UPLOAD_MISMATCH,RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
		}		
		
		byte[] fileByteArray = file.getBytes();
		if(!file.getContentType().equals("application/pdf")) {
			fileByteArray = PDFUtil.convertImageToPDF(file.getBytes());
		}
		
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String ipAddress = CommonUtil.obtainIpAddress(request);
		Long userId = CommonUtil.getUserIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		String eventName = null;
		if (companyType.equals(RFAConstants.COMPANY_TYPE_BS))
			eventName = RFAConstants.EVENT_NAME_W_SIGN_BS;
		else
			eventName = RFAConstants.EVENT_NAME_W_SIGN_SS;
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		
		Signature signature = new Signature();
		signature.setAmendmentId(id);
		signature.setCompanyType(CommonUtil.getCompanyTypeFromSession(request));
		signature.setIpAddress(ipAddress);
		signature.setSignType("W_SIGN");
		signature.setSignStyle(-1);
		
		signature.setUserId(userId);
		signature.setName(mcpmUserxsDetails.getUserxUser().getLoginName());
		signature.setCompanyId(companyIdFromSession);
		signature.setEmail(mcpmUserxsDetails.getEffectiveUser().getEmail());
		signature.setCreatedBy(userId);
		signature.setModifiedBy(userId);
		signature.setSignature(mcpmUserxsDetails.getUserxUser().getLoginName());
		
		signature.setSignatureDate(new DateTime().withZone(DateTimeZone.forTimeZone(TimeZone.getTimeZone("GMT"))).toString());
					
    	
    	commonBaseResponse.setData(amendmentLetterService.signAmendmentLetter(id,companyIdFromSession,signature, mcpmUserxsDetails.getUserxUser().getLoginName(),mcpmUserxsDetails.getLoggedInTime(), fileByteArray));
    	Long uploadedFileId=amendmentLetterService.getUploadedFile(id);
    	Long fileId = consolidateFileUtil.consolidateAllSigns(id,  companyId,  userId,  companyType);
    	byte[] fileByte = fileService.getFile(fileId, companyId);
		int noOfPages = EsignDocUtil.getNoOfPages(fileByte);
  		amendmentLetterService.addTransitionLogs(userId, null, id, null, eventName,fileId,uploadedFileId,noOfPages,null);
  		amendmentLetterService.updateStatus(RFAStatusEnum.SIGNED.getName(), id,companyType);

    	return commonBaseResponse;        
    }
	
	@RequestMapping(value = "{companyId}/amendment_letter/{id}/recall", method = RequestMethod.PUT)
    @ApiOperation(value = "Recall Amendment Letter")
    public CommonBaseResponse<AmendmentLetter> recallAmendmentLetter(@PathVariable Long companyId
    		, @PathVariable Long id, @RequestBody CommonBaseRequest<Long> commonBaseRequest, HttpServletRequest request) throws Exception{
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		AmendmentLetter amendmentLetter = amendmentLetterService.recallAmendmentLetter(companyIdFromSession, commonBaseRequest.getUserId(), id);
    	CommonBaseResponse<AmendmentLetter> commonBaseResponse = new CommonBaseResponse<AmendmentLetter>();
    	if(null == amendmentLetter) {
			commonBaseResponse.setFailed();
			throw new RFAException(RFAConstants.AMENDMENT_LETTER_RECALL_FAILURE, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
		}
    	commonBaseResponse.setData(amendmentLetter);
    	return commonBaseResponse;        
    }
	
	@RequestMapping(value = "{companyId}/amendment_letter/{id}/withdraw", method = RequestMethod.PUT)
	@ApiOperation(value = "Withdraw PartyB Accounts")
	public CommonBaseResponse<List<PartyBEntity>> withdrawPartyB(@PathVariable Long companyId
			, @PathVariable Long id, @RequestBody CommonBaseRequest<List<PartyBEntity>> commonBaseRequest, HttpServletRequest request) throws Exception{
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		List<PartyBEntity> partyBList = amendmentLetterService.withdrawPartyB(companyIdFromSession, companyType
				, id, commonBaseRequest.getUserId(), commonBaseRequest.getData());
		CommonBaseResponse<List<PartyBEntity>> commonBaseResponse = new CommonBaseResponse<List<PartyBEntity>>();
		if(null == partyBList) {
			commonBaseResponse.setFailed();
			throw new RFAException(RFAConstants.PARTYB_WITHDRAW_FAILURE, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
    	}
		commonBaseResponse.setData(partyBList);
		return commonBaseResponse;        
	}
	
	@RequestMapping(value = "{companyId}/amendment_letter/{id}/history", method = RequestMethod.GET)
	@ApiOperation(value = "Amendment Letter History")
	public Grid history(@PathVariable Long companyId
			, @PathVariable Long id, HttpServletRequest request) throws Exception{
		return selectHistory.executeQuery("amendmentId", id);        
	}
	
	@RequestMapping(value = "{partyType}/amendment_letter", method = RequestMethod.GET)
	public List<String> getAmendmentEditList(@PathVariable String partyType, HttpServletRequest request) throws Exception{
		if("SS".equalsIgnoreCase(partyType)){
			return Arrays.asList(sellside.split("::"));
		}else if("BS".equalsIgnoreCase(partyType)) {
			return Arrays.asList(buyside.split("::"));
		}
		return Collections.emptyList();
	}
	
	private void updateLogForPrintNDownloadSinglePDF(Long amendmentId,
			String ipAddress, String companyType, Long companyId, Long userIdFromSession, String eventName, Long downloadId) throws Exception {

		Long fileId = consolidateFileUtil.consolidateAllSigns(amendmentId, companyId, userIdFromSession,
				companyType);
		byte[] fileByte = fileService.getFile(fileId, companyId);
		int noOfPages = EsignDocUtil.getNoOfPages(fileByte);

		amendmentLetterService.addTransitionLogs(userIdFromSession, ipAddress,
				Long.valueOf(amendmentId), downloadId, eventName, fileId,null,noOfPages,null);
		amendmentLetterService.updateStatus(RFAStatusEnum.PRINTED.getName(), Long.valueOf(amendmentId),companyType);
	}
}
