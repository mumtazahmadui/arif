package com.markit.ms.rfa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.CommonBaseSearchResponse;
import com.markit.ms.rfa.bean.BulkNotificationBean;
import com.markit.ms.rfa.bean.RFAUploadFile;
import com.markit.ms.rfa.bean.RfaNotificationBean;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.notifier.BulkActionEmailNotificationInvoker;
import com.markit.ms.rfa.dto.RfaUploadFileSearchRequest;
import com.markit.ms.rfa.service.IRfaUploadFileService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

/**
 * @author sucheta.krishali
 *
 */
@RestController
@RequestMapping(value = "/v1/upload_file")
@Api(value = "upload_template", description = "Upload Template APIs")
public class RFAUploadFileController {
	
	@Autowired
	private IRfaUploadFileService fileService;

	@Autowired
	private BulkActionEmailNotificationInvoker bulkEmailNotificationInvoker;


	
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	@ApiOperation(value = "Get Upload File Grid")
	public CommonBaseSearchResponse<RFAUploadFile> getUploadFileGrid(
			@RequestBody RfaUploadFileSearchRequest templateSearchRequest, HttpServletRequest request)
			throws Exception {

		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		List<RFAUploadFile> uploadedFiles = fileService.getUploadFileGrid(companyIdFromSession, templateSearchRequest);

		CommonBaseSearchResponse<RFAUploadFile> commonBaseSearchResponse = new CommonBaseSearchResponse<RFAUploadFile>();
		commonBaseSearchResponse.setDataList(uploadedFiles);

		if (uploadedFiles.size() > 0)
			commonBaseSearchResponse.setTotalCount(uploadedFiles.get(0).getTotalRowCount());
		return commonBaseSearchResponse;
	}

	@RequestMapping(value = "/filter/uploadedBy", method = RequestMethod.GET)
	@ApiOperation(value = "get upload by filter")
	public CommonBaseResponse<List<Lookup>> getFilterUploadedBy(@RequestParam(required = false) String filterString,
			HttpServletResponse response, HttpServletRequest request) throws Exception {
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		if (null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = fileService.getFilterUploadedBy(companyId, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}

	
	@RequestMapping(value = "/filter/processingStatus", method = RequestMethod.GET)
	@ApiOperation(value = "get processing status filter")
	public CommonBaseResponse<List<Lookup>> getFilterProcessingStatus(@RequestParam(required = false) String filterString,
			HttpServletResponse response, HttpServletRequest request) throws Exception {
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		if (null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = fileService.getFilterProcessingStatus(companyId, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "/filter/templateNames", method = RequestMethod.GET)
	@ApiOperation(value = "get template Name By Company")
	public CommonBaseResponse<List<Lookup>> getTemplateNameByCompanyId(
			HttpServletResponse response, HttpServletRequest request) throws Exception {
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> templateList = fileService.getTemplateNamesByCompany(companyId);
		commonBaseResponse.setData(templateList);
		return commonBaseResponse;
	}
	
	
	@RequestMapping(value = "/test/processtemplate", method = RequestMethod.GET)
	@ApiOperation(value = "get processing status filter")
	public String tetsProcessTemplate(HttpServletResponse response, HttpServletRequest request) throws Exception {
		RfaNotificationBean bulkNotificationBean = new RfaNotificationBean();		
		bulkNotificationBean.setUserId(65000000054742L);
		bulkNotificationBean.setUploadId(22L);
		bulkNotificationBean.setBulkActionValidationType(BulkActionValidationType.ERROR_NOTIFICATION);
		bulkEmailNotificationInvoker.invoke(bulkNotificationBean);
		
		bulkNotificationBean.setBulkActionValidationType(BulkActionValidationType.SUCCESS_NOTIFICATION);
		bulkEmailNotificationInvoker.invoke(bulkNotificationBean);

        return "";

	}
}