package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.common.bean.Lookup;

public interface IAmendmentFilterDao {
	public List<String> getAgreementDate(Long companyid, String filterString);
	public List<Lookup> getInvestmentManager(Long companyid, String filterString, String companyType);
	public List<String> getMasterlistIdentifier(Long companyId, String filterString, String companyType);
	public List<Lookup> getPartyA(Long companyid, String filterString);
	public List<Lookup> getPartyB(Long companyid, String filterString, String companyType);
	/*public List<String> getAdditionAction(String filterString);
	public List<String> getRequestStatus(String filterString);*/
	public List<Lookup> getReviewStatus(String filterString);
	public List<String> getPartyBClientIdentifier(Long companyid, String filterString, String companyType);
	public List<String>  getSubmitDate(Long companyid, String filterString);
	public List<String> getPartyBLei(Long companyid, String filterString, String companyType);
	public List<Long> getRfaId(Long companyId, String filterString, String companyType, String amendmentStatus);
	public List<String> getAgreementType(Long companyId, String filterString, String companyType);
	public List<Lookup> getMyStatus(String filterString, String companyType);
}
