package com.markit.ms.rfa.controller;
import static com.markit.ms.rfa.util.PartyBDeskConstants.ESCALATED_DESK_CODES;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.rfa.bean.MyStatusLegend;
import com.markit.ms.rfa.bean.PartyBDeskReviewData;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.dao.IDashboardDao;
import com.markit.ms.rfa.dto.PartyBDeskReviewDetails;
import com.markit.ms.rfa.service.DeskValidationService;
import com.markit.ms.rfa.service.IDeskReviewService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PartyBDeskConstants.DESKTYPES;
import com.markit.ms.rfa.util.RFAConstants;
import com.markit.ms.rfa.util.deskreview.DeskReviewUtil;
import com.wordnik.swagger.annotations.Api;

/**
 * This class handle api calls for amendment letter partyB's due diligence desk
 * actions
 * 
 * @since RFA5.0
 *
 */
@RestController
@RequestMapping(value = "/v1")
@Api(value = "amendment_letter_review", description = "Amendment Letter Review APIs")
public class DeskReviewController {

	@Autowired
	IDeskReviewService deskReviewService;
	
	@Autowired
	DeskValidationService deskValidationService;

	/**
	 * need to change
	 */
	@Autowired
	IDashboardDao dashboardDao;

	/**
	 * handles request to update desk status<br>
	 * <p>
	 * on successful action CREATED(201) status is sent
	 * </p>
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "amendmentLetters/{amendmentId}/review/{deskCode}", method = RequestMethod.POST)
	public ResponseEntity<Object> reviewDesk(HttpServletRequest request, HttpServletResponse response,
			@PathVariable String deskCode, @PathVariable Long amendmentId,
			@RequestBody PartyBDeskReviewData deskReviewData) throws Exception {

		Long userId = CommonUtil.getUserIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);

		/**
		 * validate user action
		 */
		if (CompanyType.isSSCompany(companyType)
				&& !deskValidationService.validateSSReviewAction(amendmentId, deskCode, userId)) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
		}else if (CompanyType.isBSCompany(companyType)
				&& !deskValidationService.validateBSReviewAction(amendmentId, deskCode, userId)) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
		}

		deskReviewData.setCreatedBy(userId);
		deskReviewData.setDeskCode(deskCode);
		deskReviewData.setAmendmentId(amendmentId);

		deskReviewService.updateDeskStatus(deskReviewData);

		return ResponseEntity.status(HttpStatus.CREATED).body(null);

	}

	/**
	 * fetches latest reviewed history at amendment level
	 * 
	 * @return list of <code>PartyBDeskReviewDetails</code> in JSON
	 * @throws Exception
	 */
	@RequestMapping(value = "/amendmentLetters/{amendmentId}/getReviewHistory/{deskCode}", method = RequestMethod.GET)
	public List<PartyBDeskReviewDetails> getAmendmentReviewHistory(HttpServletRequest request,
			HttpServletResponse response, @PathVariable Long amendmentId, @PathVariable("deskCode") String deskCode)
			throws Exception {

		List<PartyBDeskReviewDetails> list = deskReviewService.getAmendmentReviewHistoryDetails(amendmentId, deskCode);
		response.setStatus(HttpStatus.OK.value());
		return list;
	}

	/**
	 * fetches latest reviewed history at partyB level
	 * 
	 * @return map containing data and total count of history details available
	 * @throws Exception
	 */
	@RequestMapping(value = "/partyB/{partyBId}/getReviewHistory/{deskCode}", method = RequestMethod.GET)
	public Map<String, Object> getPartyBReviewHistory(HttpServletRequest request, HttpServletResponse response,
			@PathVariable Long partyBId, @PathVariable("deskCode") String deskCode) throws Exception {

		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);

		/**
		 * validate GET request
		 */
		if (DeskReviewUtil.isInvalidGetRequestForDeskReviewHistory(deskCode, companyType)) {
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			return null;
		}

		PartyBDeskReviewData deskReviewData = new PartyBDeskReviewData();
		deskReviewData.setDeskCode(deskCode);
		deskReviewData.setPartyBId(partyBId);
		deskReviewData.setCompanyId(companyId);

		List<PartyBDeskReviewDetails> list = deskReviewService.getReviewHistoryDetails(deskReviewData);
		int totalCount = 0;
		if (CollectionUtils.isNotEmpty(list)) {
			totalCount = list.get(0).getTotalAuditCount();
		}
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("data", list);
		resultMap.put("totalReviewCount", totalCount);

		response.setStatus(HttpStatus.OK.value());
		return resultMap;

	}

	/**
	 * fetches last escalated at partyB level
	 * 
	 * @return map containing data and total count of escalation history details
	 *         available
	 * @throws Exception
	 */
	@RequestMapping(value = "/partyB/{partyBId}/getEscalateHistory/{deskCode}", method = RequestMethod.GET)
	public Map<String, Object> getEscalatedReviewData(HttpServletRequest request, HttpServletResponse response,
			@PathVariable Long partyBId, @PathVariable String deskCode) throws Exception {

		if (ESCALATED_DESK_CODES.contains(deskCode)) {

			PartyBDeskReviewData deskReviewData = new PartyBDeskReviewData();
			deskReviewData.setDeskCode(deskCode);
			deskReviewData.setPartyBId(partyBId);

			Map<String, Object> resultMap = new HashMap<>();

			PartyBDeskReviewDetails details = deskReviewService.getEscalatedDetail(deskReviewData);
			resultMap.put("data", details);
			resultMap.put("totalReviewCount", details.getTotalAuditCount());
			response.setStatus(HttpStatus.OK.value());
			return resultMap;
		} else {
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
			return null;
		}

	}

	/**
	 * handles request to escalate desk for specific partyB<br>
	 * <p>
	 * on successful action CREATED(201) status is sent
	 * </p>
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "partyB/{partyBId}/deskReview/{deskType}/escalate", method = RequestMethod.POST)
	@Transactional
	public ResponseEntity<Object> escalateDesk(HttpServletRequest request, HttpServletResponse response,
			@PathVariable String deskType, @PathVariable Long partyBId,
			@RequestBody PartyBDeskReviewData deskReviewData) throws Exception {
		Long loggedInUserId = CommonUtil.getUserIdFromSession(request);

		boolean validRequest = deskValidationService.validateEscalateAction(deskReviewData.getAmendmentId(), deskType,
				deskReviewData.getDeskCode());

		if (validRequest) {

			deskReviewData.setCreatedBy(loggedInUserId);
			deskReviewData.setPartyBId(partyBId);

			/**
			 * notify users of escalation
			 */
			if (deskReviewData.isReviewed() && CollectionUtils.isNotEmpty(deskReviewData.getUserIds())) {
				deskReviewService.escalteToUsers(DESKTYPES.fromString(deskType).deskName, deskReviewData);
			}

			deskReviewService.escalateDeskStatus(deskReviewData);
			return ResponseEntity.status(HttpStatus.CREATED).body(null);
		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
		}
	}

	/**
	 * handles request to notify users for specific desk for multiple partyB's<br>
	 * <code>partyBIds</code> holds list of all partyB's which are selected
	 * individually or at amendment level<br>
	 * <p>
	 * on successful action CREATED(201) status is sent
	 * </p>
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/deskReview/{deskType}/notify", method = RequestMethod.POST)
	public ResponseEntity<Object> notifyDesk(HttpServletRequest request, HttpServletResponse response,
			@PathVariable String deskType, @RequestBody PartyBDeskReviewData deskReviewData) throws Exception {

		Long loggedInUserId = CommonUtil.getUserIdFromSession(request);
		deskReviewData.setCreatedBy(loggedInUserId);

		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		
		String deskName = null;
		/**
		 * get the desk name that will be shown to users in email
		 */
		if (CompanyType.isSSCompany(companyType)) {
			deskName = DESKTYPES.fromString(deskType).deskName;
		} else if (CompanyType.isBSCompany(companyType)) {
			deskName = getDeskNameForBS(deskType, companyId, loggedInUserId);
		}
		boolean validRequest = deskValidationService.validateNotifyAction(deskReviewData.getPartyBIds(), deskType, companyType);
		
		if(validRequest) {
			deskReviewService.notifyUsers(deskName, deskReviewData);
			return ResponseEntity.status(HttpStatus.OK).body(null);
		}else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
		}
	}
	
	/**
	 * handles request to notify users for multiple partyB's<br>
	 * <code>partyBIds</code> holds list of all partyB's which are selected
	 * individually or at amendment level<br>
	 * <p>
	 * on successful action CREATED(201) status is sent
	 * </p>
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/dashboard/customNotify", method = RequestMethod.POST)
	public ResponseEntity<Object> customNotify(HttpServletRequest request, HttpServletResponse response,
			@RequestBody PartyBDeskReviewData deskReviewData) throws Exception {

		Long loggedInUserId = CommonUtil.getUserIdFromSession(request);
		deskReviewData.setCreatedBy(loggedInUserId);

		deskReviewService.notifyUsers(null, deskReviewData);
		return ResponseEntity.status(HttpStatus.OK).body(null);
	}

	/**
	 * handles request to return the html content of email that will be send to
	 * users for specific desk for multiple partyB's<br>
	 * <code>amendmentIds</code> holds list of rfa ids for which all partyB's are
	 * selected<br>
	 * <code>partyBIds</code> holds list of all partyB's which are individually
	 * selected<br>
	 * <p>
	 * on successful action CREATED(201) status is sent
	 * </p>
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/deskReview/{deskType}/previewMail", method = RequestMethod.POST, produces = "text/html")
	public ResponseEntity<String> getMailPreview(HttpServletRequest request, HttpServletResponse response,
			@PathVariable String deskType, @RequestBody PartyBDeskReviewData deskReviewData) throws Exception {

		Long loggedInUserId = CommonUtil.getUserIdFromSession(request);
		deskReviewData.setCreatedBy(loggedInUserId);

		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		Long companyId = CommonUtil.getCompanyIdFromSession(request);

		String deskName = null;

		if (CommonUtil.isEqual(deskType, RFAConstants.SIGNATORY)) {
			deskName = deskType;
		} else if (CommonUtil.isNotEqual(deskType, "CUSTOM")) {

			/**
			 * get the desk name that will be shown to users in email
			 */
			if (CompanyType.isSSCompany(companyType)) {
				deskName = DESKTYPES.fromString(deskType).deskName;
			} else if (CompanyType.isBSCompany(companyType)) {
				deskName = getDeskNameForBS(deskType, companyId, loggedInUserId);
			}
		}

		String mailPreview = deskReviewService.getMailPreview(deskName, deskReviewData);

		return ResponseEntity.status(HttpStatus.OK).body(mailPreview);

	}

	/**
	 * gets dynamic desk name based on desk type and companyid of user
	 * 
	 * @param deskType
	 * @return desk name label
	 */
	private String getDeskNameForBS(String deskType, Long companyId, Long userId) {
		List<MyStatusLegend> deskTypeList = dashboardDao.getMyStatusLegend(companyId, userId);
		if (deskTypeList != null) {
			for (MyStatusLegend status : deskTypeList) {
				if (DESKTYPES.fromString(status.getDeskLookupReviewDetail()).name().equalsIgnoreCase(deskType)) {
					return status.getLabel();
				}
			}
		}
		return StringUtils.EMPTY;
	}
}
