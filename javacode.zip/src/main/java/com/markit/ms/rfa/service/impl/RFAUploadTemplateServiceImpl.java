package com.markit.ms.rfa.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.DownloadSheetData;
import com.markit.ms.common.service.impl.DownloadServiceImpl;
import com.markit.ms.rfa.bean.MasterlistTemplateDownload;
import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.bean.RfaUploadTemplateDownload;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.dto.RfaUploadTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAGenericException;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.IRfaUploadTemplateService;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author sucheta.krishali
 *
 */
@Service
public class RFAUploadTemplateServiceImpl implements IRfaUploadTemplateService {

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Override
	public RFAUploadTemplate saveUploadTemplate(RFAUploadTemplate uploadTemplate) throws RFAUIException {
		if (uploadTemplate != null) {
			Long id = uploadTemplateDAO.getCountUploadTemplateByName(uploadTemplate.getTemplateName(),uploadTemplate.getCompanyId());
			if (id > 0)
				throw new RFAUIException(RFAConstants.RFA_UPLOAD_TEMPLATE_EXISTS, HttpStatus.OK.toString());

			uploadTemplate = uploadTemplateDAO.saveUploadTemplate(uploadTemplate);
		}
		return uploadTemplate;
	}

	@Override
	public void deleteUploadTemplateById(Long id) throws RFAException {
		Integer count = uploadTemplateDAO.deleteUploadTemplateById(id);
		if(count<=0)
			throw new RFAGenericException(RFAConstants.RFA_UPLOAD_TEMPLATE_EXISTS, HttpStatus.NOT_FOUND);	
		
	}

	@Override
	public RFAUploadTemplate getUploadTemplate(Long id) {
		RFAUploadTemplate uploadTemplate = uploadTemplateDAO.getUploadTemplateById(id);
		return uploadTemplate;
	}
	
	@Override
	public RFAUploadTemplate editUploadTemplate(RFAUploadTemplate uploadTemplate) throws RFAUIException {
		if (uploadTemplate != null) {
			Long id = uploadTemplateDAO.getCountUploadTemplateById(uploadTemplate.getId(),uploadTemplate.getCompanyId());
			if (id ==0 )
				throw new RFAUIException(RFAConstants.RFA_UPLOAD_TEMPLATE_DOESNT_EXIST, HttpStatus.OK.toString());
			
			RFAUploadTemplate uploadTemplateInDb=uploadTemplateDAO.getUploadTemplateById(uploadTemplate.getId());
			
			if(!uploadTemplateInDb.getTemplateName().equalsIgnoreCase(uploadTemplate.getTemplateName()))
			{
				Long templateNameExists = uploadTemplateDAO.getCountUploadTemplateByName(uploadTemplate.getTemplateName(),uploadTemplate.getCompanyId());
				
				if (templateNameExists > 0)
					throw new RFAUIException(RFAConstants.RFA_UPLOAD_TEMPLATE_EXISTS, HttpStatus.OK.toString());

			}
				

			
			uploadTemplate = uploadTemplateDAO.editUploadTemplate(uploadTemplate);
		}
		return uploadTemplate;
	}

	@Override
	public List<RFAUploadTemplate> getUploadTemplateGrid(Long companyId,
			RfaUploadTemplateSearchRequest templateSearchRequest) {
		List<RFAUploadTemplate> uploadTemplates = uploadTemplateDAO.getUploadTemplateGrid(companyId, templateSearchRequest);
		return uploadTemplates;
	}

	@Override
	public SXSSFWorkbook downloadUploadTemplate(Long templateId) throws Exception {

		List<RfaUploadTemplateDownload> templateFields = new ArrayList<RfaUploadTemplateDownload>();
		templateFields = uploadTemplateDAO.getUploadTemplateColumns(templateId);
		
		List<String> headerList = new ArrayList<String>();
		
		for(RfaUploadTemplateDownload template:templateFields)
		{
			if(null != template.getFieldLabel() && "" != template.getFieldLabel() && !template.getFieldLabel().isEmpty()){
				headerList.add(template.getFieldLabel());
			} else if(null != template.getAliasLabel() && "" != template.getAliasLabel() ){
				headerList.add(template.getAliasLabel());
			}
		}
		
		
		List<DownloadSheetData> dataList = new ArrayList<DownloadSheetData>();
		dataList.add(new DownloadSheetData(0, null, null, 0));
		DownloadServiceImpl downloadService = new DownloadServiceImpl();
		InputStream inputStream = this.getClass().getResourceAsStream("/Upload_Template_Download.xlsx");
		SXSSFWorkbook workbook = downloadService.getSXSSWorkbook(inputStream, headerList);
		
		return workbook;
	}
}
