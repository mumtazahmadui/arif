package com.markit.ms.rfa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.MasterAgreementSearchRequest;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.service.IMasterAgreementService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1/company")
@Api(value = "master_agreement" , description = "Master Agreement APIs")
public class MasterAgreementController {

	@Autowired
    private IMasterAgreementService masterAgreementService;
	
    @RequestMapping(value="{id}/master_agreement",method = RequestMethod.PUT)
    @ApiOperation(value = "Get Party A Relationships")
    public CommonBaseResponse<List<MasterAgreement>> getMasterAgreements(@PathVariable Long id, @RequestBody MasterAgreementSearchRequest searchRequest,HttpServletRequest request){
    	 Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request); 
    	 CommonBaseResponse<List<MasterAgreement>> commonBaseResponse = new  CommonBaseResponse<List<MasterAgreement>>();
    	 List<MasterAgreement> masterAgreementList = masterAgreementService.getMasterAgreements(companyIdFromSession, searchRequest);
    	 commonBaseResponse.setData(masterAgreementList);
    	 return commonBaseResponse;
    }
    
}
