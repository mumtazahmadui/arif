package com.markit.ms.rfa.dao.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.RfaErrorFile;
import com.markit.ms.rfa.dao.IRfaErrorFileDao;
import com.markit.ms.rfa.dao.rowmapper.RfaErrorFileRowMapper;

@Repository
public class RfaErrorFileDaoImpl extends BaseDAOImpl implements IRfaErrorFileDao {

	@Value("${CREATE_RFA_ERROR_FILE}")
	private String CREATE_RFA_ERROR_FILE;

	@Value("${GET_RFA_ERROR_FILE}")
	private String GET_RFA_ERROR_FILE;

	@Value("${DELETE_RFA_ERROR_FILE}")
	private String DELETE_RFA_ERROR_FILE;
	
	
	@Override
	public void create(RfaErrorFile rfaErrorFile) {
		MapSqlParameterSource params = new MapSqlParameterSource()
				.addValue("fileName", rfaErrorFile.getFileName())
				.addValue("contentType", rfaErrorFile.getContentType())
				.addValue("bytes", rfaErrorFile.getBytes())
				.addValue("companyId", rfaErrorFile.getCompanyId())
				.addValue("createdBy", rfaErrorFile.getCreatedBy());

		KeyHolder keyHolder = new GeneratedKeyHolder();
		namedParameterJdbcTemplate.update(CREATE_RFA_ERROR_FILE, params, keyHolder);
		rfaErrorFile.setId(keyHolder.getKey().longValue());
	}

	@Override
	public RfaErrorFile read(long id) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);
		return namedParameterJdbcTemplate.queryForObject(GET_RFA_ERROR_FILE, paramSource, new RfaErrorFileRowMapper());
	}

	@Override
	public int deleteFile(long fileId,long companyId) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue("fileId", fileId)
											.addValue("companyId", companyId);
		return namedParameterJdbcTemplate.update(DELETE_RFA_ERROR_FILE, paramSource);
	}
}