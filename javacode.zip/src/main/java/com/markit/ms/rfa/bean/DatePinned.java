package com.markit.ms.rfa.bean;

public class DatePinned {
private String datePinned;

public String getDatePinned() {
	return datePinned;
}

public void setDatePinned(String datePinned) {
	this.datePinned = datePinned;
}
}
