package com.markit.ms.rfa.bean;

import java.util.Date;

public class MasterlistValidatorBean {

	private Long id;
	
	private Long investmentManagerId;
	
	private Long partyAId;
	
	private Date masterAgreementDate;
	
	private String masterlistIdentifier;
	
	private Long agreementTypeId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getInvestmentManagerId() {
		return investmentManagerId;
	}

	public void setInvestmentManagerId(Long investmentManagerId) {
		this.investmentManagerId = investmentManagerId;
	}

	public Long getPartyAId() {
		return partyAId;
	}

	public void setPartyAId(Long partyAId) {
		this.partyAId = partyAId;
	}

	public Date getMasterAgreementDate() {
		return masterAgreementDate;
	}

	public void setMasterAgreementDate(Date masterAgreementDate) {
		this.masterAgreementDate = masterAgreementDate;
	}

	public String getMasterlistIdentifier() {
		return masterlistIdentifier;
	}

	public void setMasterlistIdentifier(String masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}

	public Long getAgreementTypeId() {
		return agreementTypeId;
	}

	public void setAgreementTypeId(Long agreementTypeId) {
		this.agreementTypeId = agreementTypeId;
	}

}
