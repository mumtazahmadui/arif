package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.RFAUploadTemplate;

public class RfaUploadTemplateRowMapper implements RowMapper<RFAUploadTemplate> {
	
	public RFAUploadTemplate mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		RFAUploadTemplate uploadTemplate = new RFAUploadTemplate();
		uploadTemplate.setId(rs.getLong("id"));
		uploadTemplate.setTemplateName(rs.getString("template_name"));
		uploadTemplate.setCompanyId(rs.getLong("company_id"));		
		uploadTemplate.setCreatedBy(rs.getLong("created_by"));
		uploadTemplate.setModifiedBy(rs.getLong("modified_by"));		
		uploadTemplate.setCreatedDate(rs.getString("created_date"));
		uploadTemplate.setModifiedDate(rs.getString("modified_date"));

		return uploadTemplate;
	}
}
