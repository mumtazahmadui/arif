package com.markit.ms.rfa.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.dao.ILetterTemplateDAO;
import com.markit.ms.rfa.dto.TemplateSearchRequest;
import com.markit.ms.rfa.service.ILetterTemplateService;
import com.markit.ms.rfa.util.CommonUtil;

@Service
public class LetterTemplateServiceImpl implements ILetterTemplateService {
	
	@Autowired
	ILetterTemplateDAO letterTemplateDAO;
	
	@Override
	@Transactional
	public LetterTemplate saveLetterTemplate(LetterTemplate letterTemplate) {
		Long id = letterTemplateDAO.getLetterTemplateByName(letterTemplate.getCompanyId(), letterTemplate.getName());
		if(null != id) {
			letterTemplate = null;
		} else {
			letterTemplate = letterTemplateDAO.saveLetterTemplate(letterTemplate);
		}
		return letterTemplate;
	}
	
	@Override
	@Transactional
	public LetterTemplate updateLetterTemplate(LetterTemplate letterTemplate) {
		Long id = letterTemplateDAO.getLetterTemplateByName(letterTemplate.getCompanyId(), letterTemplate.getName());
		if(null != id && CommonUtil.isNotEqual(String.valueOf(id), String.valueOf(letterTemplate.getId()))) {
			return null;
		}
		return letterTemplateDAO.updateLetterTemplate(letterTemplate);
	}
	
	@Override
	@Transactional
	public LetterTemplate deleteLetterTemplate(Long id, Long companyId) {
		return letterTemplateDAO.deleteLetterTemplate(id,companyId);
	}
	
	@Override
	public List<LetterTemplate> getAllLetterTemplatesByCompanyId(Long companyId) {
		return letterTemplateDAO.getAllLetterTemplatesByCompanyId(companyId);
	}

	@Override
	public List<LetterTemplate> getLetterTemplateGrid(Long companyId, TemplateSearchRequest letterTemplateSearchRequest) {
		return letterTemplateDAO.getLetterTemplateGrid(companyId, letterTemplateSearchRequest);
	}

	@Override
	public Long getLetterTemplateGridTotalCount(Long companyId, TemplateSearchRequest letterTemplateSearchRequest) {
		return letterTemplateDAO.getLetterTemplateGridTotalCount(companyId, letterTemplateSearchRequest);
	}
	
	@Override
	public LetterTemplate getLetterTemplateById(Long letterTemplateId, Long companyId) {
		return letterTemplateDAO.getLetterTemplateById(letterTemplateId, 0L,companyId);
	}

	@Override
	public String getLetterTemplateNameById(Long letterTemplateId) {
		return letterTemplateDAO.getLetterTemplateNameById(letterTemplateId);
	}
}
