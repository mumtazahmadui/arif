package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.bean.MasterlistValidatorBean;

public class MasterlistValidatorBeanRowMapper implements RowMapper<MasterlistValidatorBean> {
	
	public MasterlistValidatorBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		MasterlistValidatorBean masterlistValidatorBean = new MasterlistValidatorBean();
		masterlistValidatorBean.setId(rs.getLong("id"));
		masterlistValidatorBean.setInvestmentManagerId(rs.getLong("im_entity_id"));
		masterlistValidatorBean.setPartyAId(rs.getLong("partya_id"));
		masterlistValidatorBean.setMasterAgreementDate(rs.getDate("agreement_date"));
		masterlistValidatorBean.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
		masterlistValidatorBean.setAgreementTypeId(rs.getLong("agreement_type_id"));
		return masterlistValidatorBean;
	}
}
