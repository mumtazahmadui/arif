package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.PartyBEntity;

public class SleevePartyBResultSetExtractor implements ResultSetExtractor<List<PartyBEntity>> {

	@Override
	public List<PartyBEntity> extractData(ResultSet rs) throws SQLException, DataAccessException {
		Map<Long, PartyBEntity> partyBEntityMap = new LinkedHashMap<Long, PartyBEntity>();
		
		while (rs.next()){
			PartyBEntity partyBEntity = partyBEntityMap.get(rs.getLong("partybId"));
			if (partyBEntity == null){
				partyBEntity = new PartyBEntity();
				Entity entity = new Entity();
				entity.setId(rs.getLong("entityid"));
				entity.setName(rs.getString("legal_name"));
				entity.setClientIdentifier(rs.getString("moniker_name"));
				entity.setTrueLegalName(rs.getString("legal_name"));
				entity.setLei(rs.getString("lei_name"));
				entity.setValue(rs.getString("legal_name"));
				entity.setIsSleeve(null == rs.getString("is_sleeve") ? 0 : rs.getLong("is_sleeve"));
				entity.setParentTrueLegalName(rs.getString("parentTrueLegalName"));
				entity.setParentClientIdentifier(rs.getString("parentClientIdentifier"));
				partyBEntity.setEntity(entity);
				partyBEntity.setIsAdded(rs.getLong("isAdded")==1 ? true : false);
				partyBEntity.setAmendmentId(rs.getLong("amendment_id"));
				partyBEntityMap.put(rs.getLong("entityid"), partyBEntity);
			}
		}
		List<PartyBEntity> list = new ArrayList<PartyBEntity>(partyBEntityMap.values());
		return list;
	}

}
