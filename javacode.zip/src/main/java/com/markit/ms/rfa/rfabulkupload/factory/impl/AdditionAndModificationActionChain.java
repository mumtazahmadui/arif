package com.markit.ms.rfa.rfabulkupload.factory.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.rfabulkupload.chain.impl.AdditionChain;
import com.markit.ms.rfa.rfabulkupload.chain.impl.EvcModificationChain;
import com.markit.ms.rfa.rfabulkupload.chain.impl.FncModificationChain;
import com.markit.ms.rfa.rfabulkupload.factory.FactoryActionChain;

@Service
public class AdditionAndModificationActionChain implements FactoryActionChain {

	@Autowired
	AdditionChain additionChain;
	
	@Autowired
	FncModificationChain fncChain;
	
	@Autowired
	EvcModificationChain evcChain;
	
	@Override
	public void setChainAndProcess(RfaBulkUploadRow rfaBulkUploadRow) {
		additionChain.setNextChain(fncChain);
		fncChain.setNextChain(evcChain);
		additionChain.process(rfaBulkUploadRow);
	}
	
}
