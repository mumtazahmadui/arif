package com.markit.ms.rfa.dao;

public interface IDocumentVersionHistoryDao {
public void sendRFA(Long amendmentId, Long fileId, String companyType, Long userId, String digest, int noOfPages);
}
