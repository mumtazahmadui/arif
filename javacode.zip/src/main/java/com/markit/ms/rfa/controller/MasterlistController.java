package com.markit.ms.rfa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.CommonBaseSearchResponse;
import com.markit.ms.common.util.DownloadUtil;
import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.dto.MasterlistSearchRequest;
import com.markit.ms.rfa.service.masterlist.IMasterlistService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1/company")
@Api(value = "amendment_letter" , description = "Masterlist APIs")
public class MasterlistController {

	@Autowired
    private IMasterlistService masterlistService;
	//TODO-Sajil rename to getMasterlist.
	@RequestMapping(value="/{companyId}/master_list/search",method = RequestMethod.POST)
    @ApiOperation(value = "Get Masterlist Grid")
    public CommonBaseSearchResponse<Masterlist> getMasterlistGrid(@PathVariable Long companyId
    		, @RequestBody MasterlistSearchRequest masterlistSearchRequest,HttpServletRequest request) throws Exception {
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
    	List<Masterlist> masterlists = masterlistService.getMasterlistGrid(companyIdFromSession, masterlistSearchRequest);
//    	Long totalCount = masterlistService.getMasterlistGridTotalCount(companyIdFromSession, masterlistSearchRequest);
    	CommonBaseSearchResponse<Masterlist>  commonBaseSearchResponse = new CommonBaseSearchResponse<Masterlist>();
    	commonBaseSearchResponse.setDataList(masterlists);
    	if(masterlists.size() > 0)
    		commonBaseSearchResponse.setTotalCount(masterlists.get(0).getTotalRowCount());
    	return commonBaseSearchResponse;        
    }
	//TODO- Why are we exposing this method? The count should be part of the getMasterlist.
	@RequestMapping(value="/{companyId}/master_list/count",method = RequestMethod.POST)
	@ApiOperation(value = "Get Masterlist Total Count")
	public CommonBaseResponse<Long> getMasterlistGridCount(@PathVariable Long companyId
			, @RequestBody MasterlistSearchRequest masterlistSearchRequest,HttpServletRequest request) throws Exception {
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		Long totalCount = masterlistService.getMasterlistGridTotalCount(companyIdFromSession, masterlistSearchRequest);
		CommonBaseResponse<Long> commonBaseResponse = new CommonBaseResponse<Long>();
		commonBaseResponse.setData(totalCount);
		return commonBaseResponse;        
	}
	
	//TODO- We need to revisit this method. why the file name is hard coded here? Also, we planned to have a common
	// file download API
	@RequestMapping(value="/{companyId}/master_list/{id}/export", method = RequestMethod.GET)
	@ApiOperation(value = "Download Masterlist")
	public String downloadMasterlist(@PathVariable Long companyId, @PathVariable Long id
			, HttpServletResponse response,HttpServletRequest request) throws Exception {
    	String fileName = "Masterlist.xlsx";
        DownloadUtil.downloadFileBySXSSFWorkbook(response, masterlistService.downloadMasterlist(id), fileName);
        return "";
    }
	
	@RequestMapping(value="/{companyId}/master_list/{id}/mcpm_partyb_mapping/export", method = RequestMethod.GET)
	@ApiOperation(value = "Download Mapping File")
	public String downloadMcpmPartyBMappingFile(@PathVariable Long companyId, @PathVariable Long id
			, HttpServletResponse response,HttpServletRequest request) throws Exception {
		String fileName = "MCPM Party B Mapping.xlsx";
		DownloadUtil.downloadFileBySXSSFWorkbook(response, masterlistService.downloadMcpmPartybMappingFile(id), fileName);
		return "";
	}
	
	@RequestMapping(value="/{companyId}/master_list/{id}", method = RequestMethod.PUT)
	@ApiOperation(value = "Edit Agreement Type")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void editMasterlist(@PathVariable Long companyId, @PathVariable Long id
			, HttpServletResponse response,HttpServletRequest request, @RequestBody Masterlist masterlist) throws Exception {
		masterlistService.updateAgreementType(companyId, id, masterlist);
    }
	
	@RequestMapping(value="/{companyId}/master_list/{id}", method = RequestMethod.DELETE)
	@ApiOperation(value = "Delete Masterlist")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteMasterlist(@PathVariable Long companyId, @PathVariable Long id
			, HttpServletResponse response,HttpServletRequest request) throws Exception {
		masterlistService.deleteMasterlist(companyId, id);
    }
}
