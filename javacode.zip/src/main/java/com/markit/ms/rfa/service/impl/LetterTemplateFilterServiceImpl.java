package com.markit.ms.rfa.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.dao.ILetterTemplateFilterDAO;
import com.markit.ms.rfa.service.ILetterTemplateFilterService;

@Service
public class LetterTemplateFilterServiceImpl implements ILetterTemplateFilterService {
	
	@Autowired
	ILetterTemplateFilterDAO letterTemplateFilterDAO;

	@Override
	public List<Lookup> nameLookup(Long id, String filterString) {
		return letterTemplateFilterDAO.nameLookup(id, filterString);
	}

	@Override
	public List<Lookup> lastEditedByLookup(Long id, String filterString) {
		return letterTemplateFilterDAO.lastEditedByLookup(id, filterString);
	}

	@Override
	public List<Lookup> createdByLookup(Long id, String filterString) {
		return letterTemplateFilterDAO.createdByLookup(id, filterString);
	}
}
