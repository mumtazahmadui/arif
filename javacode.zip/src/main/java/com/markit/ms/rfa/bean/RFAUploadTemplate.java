package com.markit.ms.rfa.bean;

import java.util.List;

import com.markit.ms.rfa.util.CommonUtil;

public class RFAUploadTemplate {

	private Long id;
	private String templateName;
	private Long companyId;
	private String createdDate;
	private String modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Integer deleted;
	private String createdByUsername;
	private String modifiedByUsername;

	// Added extra field to store count of total rows returned for
	// UploadTemplate Grid Search
	private Integer totalRowCount;

	List<RFAUploadTemplateField> templateFields = null;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public List<RFAUploadTemplateField> getTemplateFields() {
		return templateFields;
	}

	public void setTemplateFields(List<RFAUploadTemplateField> templateFields) {
		this.templateFields = templateFields;
	}

	public Integer getDeleted() {
		return deleted;
	}

	public void setDeleted(Integer deleted) {
		this.deleted = deleted;
	}

	public Integer getTotalRowCount() {
		return totalRowCount;
	}

	public void setTotalRowCount(Integer totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedByUsername() {
		return createdByUsername;
	}

	public void setCreatedByUsername(String createdByUsername) {
		this.createdByUsername = createdByUsername;
	}

	public String getModifiedByUsername() {
		return modifiedByUsername;
	}

	public void setModifiedByUsername(String modifiedByUsername) {
		this.modifiedByUsername = modifiedByUsername;
	}

	public String getRule(String fieldIdentifier) {
		for (RFAUploadTemplateField templateField : templateFields) {
			if (templateField.getFieldIdentifier().equalsIgnoreCase(fieldIdentifier)) {
				return templateField.getRule();
			}
		}

		return null;
	}

	public String getFieldLabel(String fieldIdentifier) {
		for (RFAUploadTemplateField templateField : templateFields) {
			if (templateField.getFieldIdentifier().equalsIgnoreCase(fieldIdentifier)) {
				return templateField.getFieldLabel();
			}
			if(templateField.getFieldLabel().equals(fieldIdentifier)) {
				return templateField.getFieldLabel();
			}
			if(CommonUtil.isNotNull(templateField.getAliasLabel()) && templateField.getAliasLabel().equals(fieldIdentifier)) {
				return templateField.getAliasLabel();
			}
		}

		return null;
	}

}
