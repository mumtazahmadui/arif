package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.AmendmentHistory;
import com.markit.ms.rfa.util.CommonUtil;

public class AmendmentLetterHistoryRowMapper implements RowMapper<AmendmentHistory> {
	@Override
	public AmendmentHistory mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		AmendmentHistory amendmentHistory = new AmendmentHistory();
		amendmentHistory.setDateSigned(CommonUtil.getUISignFormat(rs.getTimestamp("date_sign")));		
		amendmentHistory.setFileId(rs.getLong("file_id"));
		amendmentHistory.setName(rs.getString("name"));
		return amendmentHistory;
	}

}
