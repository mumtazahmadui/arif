package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.bean.AmendmentSignData;
import com.markit.ms.rfa.bean.AmendmentSignData.SignHoverData;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

public class RFASignatureHoverRowExtractor implements ResultSetExtractor<Map<Long, AmendmentSignData>> {
	
	@Override
	public Map<Long, AmendmentSignData> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Map<Long, AmendmentSignData> signatureHoverDataForRFAIds = new HashMap<Long, AmendmentSignData>();
		AmendmentSignData amendmentSignData;
		while(rs.next()){
			
			if(signatureHoverDataForRFAIds.containsKey(rs.getLong("amendment_id"))) {
				amendmentSignData = signatureHoverDataForRFAIds.get(rs.getLong("amendment_id"));
				populateSignHover(rs, amendmentSignData);
			} else {
				amendmentSignData = new AmendmentSignData();
				populateSignHover(rs, amendmentSignData);
			}
			signatureHoverDataForRFAIds.put(rs.getLong("amendment_id"), amendmentSignData);
		}
		return signatureHoverDataForRFAIds;
	}

	private void populateSignHover(ResultSet rs, AmendmentSignData amendmentSignData) throws SQLException {
		if("E_SIGN".equals(rs.getString("sign_type")) || rs.getString("sign_type")==null) {
			SignHoverData hoverData = generateHoverMetaData(rs);
			amendmentSignData.geteSignHoverData().add(hoverData);
		} else {
			SignHoverData hoverData = generateHoverMetaData(rs);
			amendmentSignData.getwSignHoverData().add(hoverData);
		}
	}
	
	private SignHoverData generateHoverMetaData(ResultSet rs) throws SQLException {
		SignHoverData hoverData = new SignHoverData();
		try {
			hoverData.setDate(CommonUtil.changeDateFormat(rs.getString("signature_date"), RFAConstants.RFA_T_Z_DATE_FORMAT, RFAConstants.RFA_DD_MMM_YYYY_DATE_TIME_FORMAT));
		} catch (ParseException e) {
			e.getMessage();
		}
		hoverData.setSignatoryName(rs.getString("contact_email"));
		hoverData.setNotifiedBy(rs.getString("email"));
		return hoverData;
	}
}
