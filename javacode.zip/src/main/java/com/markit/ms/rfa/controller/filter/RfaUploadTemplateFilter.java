package com.markit.ms.rfa.controller.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.bean.RfaFilterResponse;
import com.markit.ms.rfa.bean.enumeration.RfaUploadTemplateRulesEnum;
import com.markit.ms.rfa.service.IRfaUploadTemplateFilterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "v1/company")
@Api(value="UploadTemplateFilter", description= "UploadTemplateFilter API")
public class RfaUploadTemplateFilter {

	@Autowired
	private IRfaUploadTemplateFilterService filterService;
	
/*	@RequestMapping(value = "/upload_template_filter/value", method = RequestMethod.GET)
	public CommonBaseResponse<FilterResponse> getFilterValues( @RequestParam(required=false) String filterString, HttpServletRequest request){
		CommonBaseResponse<FilterResponse> commonBaseResponse = new CommonBaseResponse<FilterResponse>();
		List<String> list = filterService.getFilterValues(filterString);
		String defaultValue= filterService.getDefaultValue(filterString);
		
		FilterResponse response=new FilterResponse();
		response.setValues(list);
		response.setDefaultValue(defaultValue);
		commonBaseResponse.setData(response);
		return commonBaseResponse;
		
		
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getFilterValues(filterString);
		
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	*/
	
	
	@RequestMapping(value = "/upload_template_filter/value", method = RequestMethod.GET)
	public CommonBaseResponse<List<RfaFilterResponse>> getFilterValues(HttpServletRequest request) {
		
		CommonBaseResponse<List<RfaFilterResponse>> commonBaseResponse = new CommonBaseResponse<List<RfaFilterResponse>>();

		List<String> list = null;
		String defaultValue = null;
		List<RfaFilterResponse> responseList = new ArrayList<RfaFilterResponse>();
		
		Map<String,List<String>>   filterValuesMap=filterService.getFilterValues();
		
		Map<String,String>   defaultValuesMap=filterService.getDefaultValue();

		
		for (RfaUploadTemplateRulesEnum rule : RfaUploadTemplateRulesEnum.values()) {
			list = filterValuesMap.get(rule.getName()) ; 
			defaultValue = defaultValuesMap.get(rule.getName());        
			RfaFilterResponse response = new RfaFilterResponse();
			response.setFieldIdentifier(rule.toString());
			response.setValues(list);
			response.setDefaultValue(defaultValue);
			responseList.add(response);
		}
		
		commonBaseResponse.setData(responseList);
		return commonBaseResponse;


	}
	

	@RequestMapping(value = "/upload_template_filter/template_name", method = RequestMethod.GET)
	@ApiOperation(value = "Upload Template Name Filter")
	public CommonBaseResponse<List<Lookup>> uploadTemplateLookUp(@RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = filterService.uploadTemplateLookUp(companyId, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
}
