package com.markit.ms.rfa.command.notifier;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.rfa.bean.BulkNotificationBean;
import com.markit.ms.rfa.command.validator.BulkActionValidationInvoker;

@Component
public class BulkActionEmailNotificationInvoker {

	@Resource
	private Map<String, BulkActionEmailNotifier> notifierMap;

	@Autowired
	private BulkActionValidationInvoker bulkActionValidationInvoker;

	public void setBulkActionValidationInvoker(BulkActionValidationInvoker bulkActionValidationInvoker) {
		this.bulkActionValidationInvoker = bulkActionValidationInvoker;
	}

	public void setNotifierMap(Map<String, BulkActionEmailNotifier> notifierMap) {
		this.notifierMap = notifierMap;
	}

	public void invoke(BulkNotificationBean bulkNotificationBean) throws Exception {
		BulkActionEmailNotifier notifier = notifierMap.get(bulkNotificationBean.getBulkActionValidationType().toString());
		notifier.sendEmailNotification(bulkNotificationBean);
	}
}