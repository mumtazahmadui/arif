package com.markit.ms.rfa.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.common.dao.rowmapper.LookupRowMapper;
import com.markit.ms.rfa.dao.ILetterTemplateFilterDAO;

@Repository
public class LetterTemplateFilterDAOImpl extends BaseDAOImpl implements ILetterTemplateFilterDAO
{
	
	@Value("${GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_NAME}")
    private String GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_NAME;
	
	@Value("${GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_LAST_EDITED_BY}")
	private String GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_LAST_EDITED_BY;
	
	@Value("${GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_CREATED_BY}")
	private String GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_CREATED_BY;
	
	@Override
	public List<Lookup> nameLookup(Long id, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_NAME, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<Lookup> lastEditedByLookup(Long id, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_LAST_EDITED_BY, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<Lookup> createdByLookup(Long id, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_LETTER_TEMPLATE_LOOKUP_BY_CREATED_BY, paramSource, new LookupRowMapper());
    	return lookupList;
	}
}
