package com.markit.ms.rfa.placeholders.request;

public class SSResponse {
private Long partyBId;
private Long partyBExhibitValueChangeId;
private Long partyBFundNameChangeId;
private String responseStatus;
private String responseComments;
public Long getPartyBId() {
	return partyBId;
}
public void setPartyBId(Long partyBId) {
	this.partyBId = partyBId;
}
public Long getPartyBExhibitValueChangeId() {
	return partyBExhibitValueChangeId;
}
public void setPartyBExhibitValueChangeId(Long partyBExhibitValueChangeId) {
	this.partyBExhibitValueChangeId = partyBExhibitValueChangeId;
}
public Long getPartyBFundNameChangeId() {
	return partyBFundNameChangeId;
}
public void setPartyBFundNameChangeId(Long partyBFundNameChangeId) {
	this.partyBFundNameChangeId = partyBFundNameChangeId;
}
public String getResponseStatus() {
	return responseStatus;
}
public void setResponseStatus(String responseStatus) {
	this.responseStatus = responseStatus;
}
public String getResponseComments() {
	return responseComments;
}
public void setResponseComments(String responseComments) {
	this.responseComments = responseComments;
}
}
