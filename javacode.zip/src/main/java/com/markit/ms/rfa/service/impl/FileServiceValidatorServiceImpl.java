package com.markit.ms.rfa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.service.IFileServiceValidatorService;
import com.markit.ms.rfa.dao.IFileServiceValidatorDAO;

@Service
public class FileServiceValidatorServiceImpl implements
		IFileServiceValidatorService {

	@Autowired
	IFileServiceValidatorDAO fileServiceValidatorDAO;
	
	@Override
	public boolean validateFileAccess(Long fileId, Long companyId) {
		// TODO Auto-generated method stub
		return fileServiceValidatorDAO.validateFileAccess(fileId,companyId);
	}

}
