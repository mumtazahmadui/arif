package com.markit.ms.rfa.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.rfa.bean.RfaErrorFile;
import com.markit.ms.rfa.service.IRfaErrorFileService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1/company")
@Api(value = "files", description = "File APIs")
public class RfaErrorFileController {

	@Autowired
	private IRfaErrorFileService rfaErrorFileService;

	@ApiOperation(value = "Download File")
	@RequestMapping(value = "{companyId}/rfaErrorFile/{fileId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public @ResponseBody ResponseEntity<byte[]> getFile(@PathVariable Long companyId, @PathVariable Long fileId, HttpServletRequest request) {
		RfaErrorFile rfaErrorFile = rfaErrorFileService.retreive(fileId);
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		headers.add("Content-Type", rfaErrorFile.getContentType());
		headers.add("Content-Disposition", "attachment; filename=" + getAttachmentFileName(rfaErrorFile.getFileName()));
		ResponseEntity<byte[]> responseEntity = new ResponseEntity<>(rfaErrorFile.getBytes(), headers, HttpStatus.OK);
		return responseEntity;
	}

	private String getAttachmentFileName(String filename) {
		if (filename != null && filename.matches(".*\\s+.*")) {
			return "\"" + filename + "\"";
		}
		return filename;
	}

	@ApiOperation(value = "Delete File")
	@RequestMapping(value = "{companyId}/rfaErrorFile/{fileId}", method = RequestMethod.DELETE)
	public @ResponseBody String deleteFile(@PathVariable Long companyId, @PathVariable Long fileId, HttpServletRequest request) {
		
		rfaErrorFileService.deleteFile(fileId,companyId);		
		return "";
	}

}