package com.markit.ms.rfa.dao.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.dao.IDocumentVersionHistoryDao;
import com.markit.ms.rfa.util.RFAConstants;

@Repository
public class DocumentVersionHistoryDaoImpl extends BaseDAOImpl implements
		IDocumentVersionHistoryDao {

	@Value("${INSERT_DOC_VERSION_ON_SEND_RFA}")
    private String INSERT_DOC_VERSION_ON_SEND_RFA;
	
	
	@Override
	public void sendRFA(Long amendmentId, Long fileId, String companyType, Long userId,String digest, int noOfPages) {
		SqlParameterSource params = new MapSqlParameterSource()
		.addValue("is_bs_company", companyType.equalsIgnoreCase(RFAConstants.COMPANY_TYPE_SS) ? 0 : 1)
		.addValue("amendmentId", amendmentId)
		.addValue("file_id", fileId)
		.addValue("userId", userId)
		.addValue("digest", digest)
		.addValue("noOfPages", noOfPages);
		namedParameterJdbcTemplate.update(INSERT_DOC_VERSION_ON_SEND_RFA, params);
	}

}
