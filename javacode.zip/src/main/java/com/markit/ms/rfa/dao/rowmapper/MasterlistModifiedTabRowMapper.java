package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.MasterlistDownload;
import com.markit.ms.rfa.util.CommonUtil;

public class MasterlistModifiedTabRowMapper implements RowMapper<MasterlistDownload> {
	
	public MasterlistDownload mapRow(ResultSet rs, int rowNum) throws SQLException {
		MasterlistDownload masterlistDownload = new MasterlistDownload();
		masterlistDownload.setMasterAgreementId(rs.getBigDecimal("master_agreement_id"));
		masterlistDownload.setModifiedDateString(CommonUtil.getDateForFormat(rs.getDate("modified_date"), "dd-MMM-yyyy"));
		masterlistDownload.setAddedDateString(CommonUtil.getDateForFormat(rs.getDate("added_date"), "dd-MMM-yyyy"));
		masterlistDownload.setModifiedDate(rs.getTimestamp("modified_date"));
		masterlistDownload.setAddedDate(rs.getTimestamp("added_date"));
		masterlistDownload.setModificationType(rs.getString("modification_type"));
		masterlistDownload.setAgreementDate(CommonUtil.getDateForFormat(rs.getDate("agreement_date"), "dd-MMM-yyyy"));
		masterlistDownload.setInvestmentManager(rs.getString("investment_manager"));
		masterlistDownload.setPartyA(rs.getString("partyA"));
		masterlistDownload.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
		masterlistDownload.setAdded(rs.getLong("is_added") == 1 ? true : false);
		masterlistDownload.setEntityId(rs.getLong("entity_id"));
		masterlistDownload.setPartybId(rs.getLong("partyb_id"));
		masterlistDownload.setRfaId(rs.getBigDecimal("rfa_id"));
		masterlistDownload.setOldLegalName(rs.getString("old_legal_name"));
		masterlistDownload.setOldClientIdentifier(rs.getString("old_client_identifier"));
		masterlistDownload.setOldLeiName(rs.getString("old_lei_name"));
		masterlistDownload.setNewLegalName(rs.getString("current_legal_name"));
		masterlistDownload.setNewClientIdentifier(rs.getString("current_client_identifier"));
		masterlistDownload.setNewLeiName(rs.getString("current_lei_name"));
		masterlistDownload.setColumnName(rs.getString("column_name"));
		masterlistDownload.setOldColumnValue(rs.getString("old_value"));
		masterlistDownload.setColumnValue(rs.getString("current_value"));
		masterlistDownload.setControlColumn(rs.getLong("is_control_column") == 1 ? true : false);
		masterlistDownload.setColumnIndex(rs.getLong("column_index"));
		masterlistDownload.setAgreementType(rs.getString("agreement_type"));
		return masterlistDownload;
	}
}
