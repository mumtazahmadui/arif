package com.markit.ms.rfa.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.common.dao.rowmapper.LookupRowMapper;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.dao.IMasterlistFilterDAO;
import com.markit.ms.rfa.dao.rowmapper.CompanyTypeRowMapper;

@Repository
public class MasterlistFilterDAOImpl extends BaseDAOImpl implements IMasterlistFilterDAO
{
	@Value("${AGREEMENT_DATE_LOOKUP}")
    private String AGREEMENT_DATE_LOOKUP;
	
	@Value("${INVESTMENT_MANAGER_LOOKUP}")
	private String INVESTMENT_MANAGER_LOOKUP;
	
	@Value("${PARTYA_LOOKUP}")
	private String PARTYA_LOOKUP;
	
	@Value("${MASTERLIST_IDENTIFIER_LOOKUP}")
	private String MASTERLIST_IDENTIFIER_LOOKUP;
	
	@Value("${GET_COMPANY_TYPE}")
    private String GET_COMPANY_TYPE;
	
	@Value("${GET_AGREEMENT_TYPES}")
    private String GET_AGREEMENT_TYPES;
	
	@Override
	public List<String> agreementDateLookup(Long id, String filterString) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("companyid", id);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, params, new CompanyTypeRowMapper());
		StringBuilder whereCondition = new StringBuilder();
		
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id)
				.addValue("filterString", "%"+filterString+"%")
				.addValue("is_bs_company", "BS".equals(companyType) ? 1 : 0);
		if("SS".equalsIgnoreCase(companyType)) {
			whereCondition.append(" and e2.companyid=:companyid");
		} else {
			whereCondition.append(" and e1.companyid=:companyid");
		}
		String query = AGREEMENT_DATE_LOOKUP.replaceAll("whereCondition", whereCondition.toString());
		
		List<String> lookupList = namedParameterJdbcTemplate.queryForList(query, paramSource, String.class);
    	return lookupList;
	}

	@Override
	public List<Lookup> investmentManagerLookup(Long id, String filterString) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("companyid", id);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, params, new CompanyTypeRowMapper());
		StringBuilder whereCondition = new StringBuilder();
		
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyid", id)
				.addValue("filterString", "%"+filterString+"%")
				.addValue("is_bs_company", "BS".equals(companyType) ? 1 : 0);
		if("SS".equalsIgnoreCase(companyType)) {
			whereCondition.append(" and e2.companyid=:companyid");
		} else {
			whereCondition.append(" and e1.companyid=:companyid");
		}
		String query = INVESTMENT_MANAGER_LOOKUP.replaceAll("whereCondition", whereCondition.toString());
		
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(query, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<Lookup> partyALookup(Long id, String filterString) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("companyid", id);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, params, new CompanyTypeRowMapper());
		StringBuilder whereCondition = new StringBuilder();
		
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyid", id)
				.addValue("filterString", "%"+filterString+"%")
				.addValue("is_bs_company", "BS".equals(companyType) ? 1 : 0);
		if("SS".equalsIgnoreCase(companyType)) {
			whereCondition.append(" and e2.companyid=:companyid");
		} else {
			whereCondition.append(" and e1.companyid=:companyid");
		}
		String query = PARTYA_LOOKUP.replaceAll("whereCondition", whereCondition.toString());
		
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(query, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<String> masterlistIdentifierLookup(Long id, String filterString) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("companyid", id);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, params, new CompanyTypeRowMapper());
		StringBuilder whereCondition = new StringBuilder();
		
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyid", id)
				.addValue("filterString", "%"+filterString+"%")
				.addValue("is_bs_company", "BS".equals(companyType) ? 1 : 0);
		if("SS".equalsIgnoreCase(companyType)) {
			whereCondition.append(" and e2.companyid=:companyid");
		} else {
			whereCondition.append(" and e1.companyid=:companyid");
		}
		String query = MASTERLIST_IDENTIFIER_LOOKUP.replaceAll("whereCondition", whereCondition.toString());
		
		List<String> lookupList = namedParameterJdbcTemplate.queryForList(query, paramSource, String.class);
    	return lookupList;
	}
	
	@Override
	public List<Lookup> agreementTypeLookup(String filterString) {
		if (filterString == null) filterString = "";
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("fieldName", "AGREEMENT TYPE")
		.addValue("filterString", "%"+ filterString + "%");
		List<Map<String, Object>> agreementTypes  = namedParameterJdbcTemplate.queryForList(GET_AGREEMENT_TYPES, paramSource);
		
		List<Lookup> lookupList = new ArrayList<Lookup>();
		for(Map<String, Object> agreementType : agreementTypes){
			Lookup lookup = new Lookup();
			lookup.setId(new Long(((BigDecimal)agreementType.get("id")).longValue()));
			lookup.setValue((String)agreementType.get("field_value"));			
			lookupList.add(lookup);
		}
		
		return lookupList;
	}
}
