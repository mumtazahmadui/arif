package com.markit.ms.rfa.dao.impl;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;


import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.repository.core.StJdbcTemplate;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.common.util.LookupUtil;
import com.markit.ms.rfa.bean.AmendmentContent;
import com.markit.ms.rfa.bean.AmendmentDownloadTransitionLog;
import com.markit.ms.rfa.bean.AmendmentHistory;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.AmendmentSignData;
import com.markit.ms.rfa.bean.BulkActionBean;
import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.bean.ExhibitCell;
import com.markit.ms.rfa.bean.ExhibitColumn;
import com.markit.ms.rfa.bean.ExistingPartyB;
import com.markit.ms.rfa.bean.FundNameChange;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.bean.ReviewData;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.RfaBulkUploadedData;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;
import com.markit.ms.rfa.bean.report.AmendmentLetterPDFBean;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;
import com.markit.ms.rfa.dao.IEntityDao;
import com.markit.ms.rfa.dao.IMasterAgreementDao;
import com.markit.ms.rfa.dao.INewExhibitDao;
import com.markit.ms.rfa.dao.resultsetextractor.AmendmentGridResultSetExtractor;
import com.markit.ms.rfa.dao.resultsetextractor.AmendmentLetterResultSetExtractor;
import com.markit.ms.rfa.dao.rowmapper.AmendmentLetterHistoryRowMapper;
import com.markit.ms.rfa.dao.rowmapper.CompanyTypeRowMapper;
import com.markit.ms.rfa.dao.rowmapper.EntityRowMapper;
import com.markit.ms.rfa.dao.rowmapper.ExistingPartyBRowMapper;
import com.markit.ms.rfa.dao.rowmapper.RFASignatureCountRowExtractor;
import com.markit.ms.rfa.dao.rowmapper.RFASignatureHoverRowExtractor;
import com.markit.ms.rfa.dao.rowmapper.ReviewRowMapper;
import com.markit.ms.rfa.dto.AmendmentLetterSearchRequest;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFABulkUploadUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Repository
public class AmendmentLetterDaoImpl extends BaseDAOImpl implements IAmendmentLetterDao {
	
	private static final Logger logger = LoggerFactory.getLogger(AmendmentLetterDaoImpl.class.getName());

	@Value("${UPDATE_NOTIFIED_BY_FOR_ALL_RFAIDS}")
	private String UPDATE_NOTIFIED_BY_FOR_ALL_RFAIDS;
	
	@Value("${FETCH_NEXT_AVAILABLE_DOC_ID}")
	private String FETCH_NEXT_AVAILABLE_DOC_ID;
	
	@Value("${ADD_RFA_DOWNLOAD_TRANSITION_LOG}")
	private String ADD_RFA_DOWNLOAD_TRANSITION_LOG;

	@Value("${ADD_TRANSITION_LOG}")
	private String ADD_TRANSITION_LOG;

	@Value("${GET_SIGN_HOVER_DATA_BS}")
	private String GET_SIGN_HOVER_DATA_BS;
	
	@Value("${GET_SIGN_HOVER_DATA_SS}")
	private String GET_SIGN_HOVER_DATA_SS;

	@Value("${GET_SIGN_COUNT_BS}")
	private String GET_SIGN_COUNT_BS;
	
	@Value("${GET_SIGN_COUNT_SS}")
	private String GET_SIGN_COUNT_SS;
	
	@Value("${UPDATE_AMENDMENT_BS_NEXT_STEP_TASK_PROC}")
	private String UPDATE_AMENDMENT_BS_NEXT_STEP_TASK_PROC;
	
	@Value("${UPDATE_AMENDMENT_SS_NEXT_STEP_TASK_PROC}")
	private String UPDATE_AMENDMENT_SS_NEXT_STEP_TASK_PROC;
	
	@Value("${ADD_REVIEW_IN_AMENDMENT}")
	private String ADD_REVIEW_IN_AMENDMENT;
	
	@Value("${UPDATE_AMENDMENT_CONTENT}")
	private String UPDATE_AMENDMENT_CONTENT;
	
	@Value("${GET_REVIEW_IN_AMENDMENT}")
	private String GET_REVIEW_IN_AMENDMENT;
	
	@Value("${DELETE_REVIEW_IN_AMENDMENT}")
	private String DELETE_REVIEW_IN_AMENDMENT;
	
	@Value("${GET_AMENDMENT_LETTER_HISTORY_BS}")
    private String GET_AMENDMENT_LETTER_HISTORY_BS;
	
	@Value("${GET_AMENDMENT_LETTER_HISTORY_SS}")
    private String GET_AMENDMENT_LETTER_HISTORY_SS;
	
	@Value("${GET_AMENDMENT_LETTER}")
    private String GET_AMENDMENT_LETTER;
	
    @Value("${SAVE_AMENDMENT_LETTER}")
    private String SAVE_AMENDMENT_LETTER;
    
    @Value("${UPDATE_STATE_TRANSITION_FOR_BS}")
    private String UPDATE_STATE_TRANSITION_FOR_BS;
    
    @Value("${UPDATE_STATE_TRANSITION_FOR_SS}")
    private String UPDATE_STATE_TRANSITION_FOR_SS;
    
    @Value("${UPDATE_STATE_TRANSITION_FOR_BOTH_BS_AND_SS}")
    private String UPDATE_STATE_TRANSITION_FOR_BOTH_BS_AND_SS;
    
    @Value("${SAVE_EXHIBIT}")
    private String SAVE_EXHIBIT;
    
    @Value("${SAVE_PARTYB_ENTITY}")
    private String SAVE_PARTYB_ENTITY;
    
    @Value("${SAVE_RFA_PARTYB_FUND_NAME_CHANGE}")
    private String SAVE_RFA_PARTYB_FUND_NAME_CHANGE;
    
    @Value("${UPDATE_RFA_PARTYB_FUND_NAME_CHANGE}")
    private String UPDATE_RFA_PARTYB_FUND_NAME_CHANGE;
    
    @Value("${SAVE_RFA_PARTYB_EXHIBIT_VALUE_CHANGE}")
    private String SAVE_RFA_PARTYB_EXHIBIT_VALUE_CHANGE;
    
    @Value("${UPDATE_AMENDMENT_LETTER}")
    private String UPDATE_AMENDMENT_LETTER;
    
    @Value("${UPDATE_EXHIBIT}")
    private String UPDATE_EXHIBIT;
    
    @Value("${UPDATE_EXHIBIT_COL}")
    private String UPDATE_EXHIBIT_COL;
    
    @Value("${UPDATE_EXHIBIT_COL_DATA}")
    private String UPDATE_EXHIBIT_COL_DATA;
    
    @Value("${DELETE_EXHIBIT_COL_DATA}")
    private String DELETE_EXHIBIT_COL_DATA;
    
    @Value("${UPDATE_PARTYB_ENTITY}")
    private String UPDATE_PARTYB_ENTITY;

    @Value("${GET_AMENDMENT_LETTER_GRID}")
    private String GET_AMENDMENT_LETTER_GRID;
    
    @Value("${GET_AMENDMENT_LETTER_GRID_COUNT}")
    private String GET_AMENDMENT_LETTER_GRID_COUNT;
    
    @Value("${GET_SS_AMENDMENT_LETTER_GRID}")
    private String GET_SS_AMENDMENT_LETTER_GRID;
    
    @Value("${GET_SS_AMENDMENT_LETTER_GRID_COUNT}")
    private String GET_SS_AMENDMENT_LETTER_GRID_COUNT;

    @Value("${SIGN_SELL_SIDE}")
    private String SIGN_SELL_SIDE;

    @Value("${SIGN_BUY_SIDE}")
    private String SIGN_BUY_SIDE;
    
    @Value("${SEND_RFA_BUY_SIDE}")
    private String SEND_RFA_BUY_SIDE;
    
    @Value("${SAVE_MASTERLIST_DATA}")
    private String SAVE_MASTERLIST_DATA;
    
    @Value("${SEND_RFA_SELL_SIDE}")
    private String SEND_RFA_SELL_SIDE;
    
    @Value("${GET_AMENDMENT_LETTER_PDF_DATA}")
    private String GET_AMENDMENT_LETTER_PDF_DATA;
    
    @Value("${RECALL_AMENDMENT_LETTER}")
    private String RECALL_AMENDMENT_LETTER;
    
    @Value("${GET_MASTER_AGREEMENT_DATE_BY_ID}")
    private String GET_MASTER_AGREEMENT_DATE_BY_ID;
    
    @Value("${GET_BS_SS_AMENDMENT_LETTER_GRID_TASK_COUNT}")
    private String GET_BS_SS_AMENDMENT_LETTER_GRID_TASK_COUNT;
    
    @Value("${GET_SIGN_FILE_ID_SS}")
    private String GET_SIGN_FILE_ID_SS;

    @Value("${GET_SIGN_FILE_ID_BS}")
    private String GET_SIGN_FILE_ID_BS;
    
    @Value("${GET_COMPANY_TYPE}")
    private String GET_COMPANY_TYPE;
    
    @Value("${EDIT_REJECTED_AMENDMENT_LETTER}")
    private String EDIT_REJECTED_AMENDMENT_LETTER;
    
    @Value("${REJECT_AMENDMENT_LETTER}")
    private String REJECT_AMENDMENT_LETTER;
    
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID}")
    private String GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID;
    
    @Value("${GET_PLACEHOLDER_AMENDMENT_BY_MASTER_AGREEMENT_ID}")
    private String GET_PLACEHOLDER_AMENDMENT_BY_MASTER_AGREEMENT_ID;
    
    @Value("${CREATE_EXHIBIT_COL}")
    private String CREATE_EXHIBIT_COL;
    
    @Value("${UPDATE_AMENDMENT_WITH_EXHIBIT_TEMPLATE}")
    private String UPDATE_AMENDMENT_WITH_EXHIBIT_TEMPLATE;
    
    @Value("${GET_EXISTING_PARTYB_FOR_MODIFICATION}")
    private String GET_EXISTING_PARTYB_FOR_MODIFICATION;
    
    @Value("${GET_MASTERLIST_ENTITY}")
    private String GET_MASTERLIST_ENTITY;
    
    @Value("${SAVE_BLANK_EXHIBIT_VALUES_FOR_PLACEHOLDER_AMENDMENT}")
    private String SAVE_BLANK_EXHIBIT_VALUES_FOR_PLACEHOLDER_AMENDMENT;
    
    @Value("${GET_SS_AMEDMENT_TASKS_GRID}")
    private String GET_SS_AMEDMENT_TASKS_GRID;
   
    @Value("${GET_BS_AMEDMENT_TASKS_GRID}")
    private String GET_BS_AMEDMENT_TASKS_GRID;
    
    @Value("${GET_RFA_BULK_NOTIFICATION}")
    private String GET_RFA_BULK_NOTIFICATION;
    
    @Value("${SAVE_EXHIBIT_COL_DATA}")
    private String SAVE_EXHIBIT_COL_DATA;
    
    @Value("${GET_EXHIBIT_COLUMNS_BY_AMENDMENT_ID}")
    private String GET_EXHIBIT_COLUMNS_BY_AMENDMENT_ID;
    
    @Value("${SAVE_ERROR_MESSAGE}")
    private String SAVE_ERROR_MESSAGE;
    
    @Value("${SAVE_CHASER}")
    private String SAVE_CHASER;
    
    @Value("${UPDATE_CHASER}")
    private String UPDATE_CHASER;
    
    @Value("${GET_EXISTING_PARENT_PARTYB}")
    private String GET_EXISTING_PARENT_PARTYB;
    
    @Value("${SAVE_SLEEVE_EXHIBIT_VALUES}")
    private String SAVE_SLEEVE_EXHIBIT_VALUES;
    
    @Value("${GET_LEGACY_MLTEMPLATE_BY_NAME}")
    private String GET_LEGACY_MLTEMPLATE_BY_NAME;
    
    @Value("${GET_CUSTOM_MLTEMPLATE_BY_NAME}")
    private String GET_CUSTOM_MLTEMPLATE_BY_NAME;
    
    @Value("${GET_AMENDMENT_ML_TEMPLATE}")
    private String GET_AMENDMENT_ML_TEMPLATE;
    
    @Value("${SAVE_BULK_UPLOAD_FILE_TEMPLATE}")
    private String SAVE_BULK_UPLOAD_FILE_TEMPLATE;
    
    @Value("${GET_RFA_BULK_UPLOAD_FILE_TEMPLATE}")
    private String GET_RFA_BULK_UPLOAD_FILE_TEMPLATE;
    
    @Value("${UPDATE_BULK_UPLOAD_FILE_TEMPLATE}")
    private String UPDATE_BULK_UPLOAD_FILE_TEMPLATE;
    
    @Value("${UPDATE_BULK_REQUEST}")
    private String UPDATE_BULK_REQUEST;
    
    @Value("${UPDATE_AMENDMENT_CONTENT_AGREED}")
    private String UPDATE_AMENDMENT_CONTENT_AGREED;
    
    @Value("${GET_ALL_WET_SIGN_BY_RFA_ID}")
    private String GET_ALL_WET_SIGN_BY_RFA_ID;
    
    @Value("${GET_LATEST_E_SIGN_BY_RFA_ID}")
    private String GET_LATEST_E_SIGN_BY_RFA_ID;
    
    @Value("${GET_LATEST_W_SIGN_BY_RFA_ID}")
    private String GET_LATEST_W_SIGN_BY_RFA_ID;
    
    @Value("${UPDATE_RFA_LETTER_CHANGES_COUNT}")
    private String UPDATE_RFA_LETTER_CHANGES_COUNT;
    
    @Value("${UPDATE_RFA_EXHIBIT_CHANGES_COUNT}")
    private String UPDATE_RFA_EXHIBIT_CHANGES_COUNT;
    
    @Value("${UPDATE_RFA_CHANGES_RESPONDED_COUNT}")
    private String UPDATE_RFA_CHANGES_RESPONDED_COUNT;
    
    @Value("${UPDATE_RFA_SS_COMMENTS_COUNT}")
    private String UPDATE_RFA_SS_COMMENTS_COUNT;
    
    @Value("${UPDATE_RFA_EXHIBIT_COMMENTS_COUNT}")
    private String UPDATE_RFA_EXHIBIT_COMMENTS_COUNT;
    
    @Value("${UPDATE_RFA_LETTER_COMMENTS_COUNT}")
    private String UPDATE_RFA_LETTER_COMMENTS_COUNT;
    
    @Value("${UPDATE_RFA_RESOLVED_COMMENTS_COUNT}")
    private String UPDATE_RFA_RESOLVED_COMMENTS_COUNT;
    
    @Resource
	QueryService<Long> selectNextAvailableDownloadId;
    
    @Resource
    QueryService<List<AmendmentLetter>> getAmendmentLetterBuysideGrid;
    
    @Resource
    QueryService<Long> getAmendmentLetterBuysideGridTotalCount;
    
    @Resource
    QueryService<List<AmendmentLetter>> getAmendmentLetterSellsideGrid;
    
    @Resource
    QueryService<Long> getAmendmentLetterSellsideGridTotalCount;    
    
	@Resource
	protected StJdbcTemplate jdbcTemplate;
	
    @Autowired
    IMasterAgreementDao masterAgreementDao;
    
    @Autowired
    IEntityDao entityDao;
    
    @Autowired
    INewExhibitDao exhibitDao;
    
  
  @Value("${BS_UPDATE_RFA_STATUS}")
  private String BS_UPDATE_RFA_STATUS;
  
  @Value("${SS_UPDATE_RFA_STATUS}")
  private String SS_UPDATE_RFA_STATUS;
  
  @Value("${UPDATE_RFA_AMENDMENT}")
  private String UPDATE_RFA_AMENDMENT;
  
  
  
    
	@Resource
	private QueryService<Integer> selectAmendmentAgreed;
	
    @Resource 
    private VelocityEngine velocityEngine;

    @Value("${SAVE_BULK_UPLOADED_DATA}")
    private String SAVE_BULK_UPLOADED_DATA;

    @Override
	public AmendmentLetter saveAmendmentLetter(Long companyId, String companyType
			, AmendmentLetter amendmentLetter, Date agreementDate, String ipAddress) throws Exception{
    	Map<Long, Long> parentPartybMap = new LinkedHashMap<>();
    	MapSqlParameterSource params = new MapSqlParameterSource()
    	    .addValue("letter_template_id", amendmentLetter.getLetterTemplateId())
    	    .addValue("content", amendmentLetter.getContent().getBytes())
    	    .addValue("is_placeholder", 0L)
    	    .addValue("file_id", amendmentLetter.getFileId())
    	    .addValue("sign_file_id",amendmentLetter.getSignFileId())
    	    .addValue("created_by", amendmentLetter.getCreatedBy())
    	    .addValue("modified_by", amendmentLetter.getCreatedBy())
    	    .addValue("bsPlaceholderCount", amendmentLetter.getBsSignPlaceholderCount())//need content
    	    .addValue("ssPlaceholderCount", amendmentLetter.getSsSignPlaceholderCount())//need content
    		.addValue("CREATED_BY_IP", ipAddress)//decide on this
    		.addValue("creationFlow", amendmentLetter.getCreationFlow())//decide on this, may be add new flow
    		.addValue("companyId", companyId)
    		.addValue("mlTemplateName", amendmentLetter.getMlTemplatename())
    	    .addValue("agreed", amendmentLetter.isAgreed())
    	    .addValue("partytype",StringUtils.isEmpty(companyType)?"BS":companyType);
    	
    	Long mlTemplateId = null;
    	if(null != amendmentLetter.getMlCompanyID()){
    		mlTemplateId = namedParameterJdbcTemplate.queryForObject(GET_CUSTOM_MLTEMPLATE_BY_NAME, params, Long.class);
    	} else {
    		mlTemplateId = namedParameterJdbcTemplate.queryForObject(GET_LEGACY_MLTEMPLATE_BY_NAME, params, Long.class);
    	}
    	params.addValue("mlTemplateId", mlTemplateId);
		if(null != amendmentLetter.getMasterAgreement()) {
        	MasterAgreement masterAgreement = amendmentLetter.getMasterAgreement();
        	params.addValue("master_agreement_id", masterAgreement.getId());
        	String formattedAgreementDate = CommonUtil.getDateForFormat(agreementDate, "dd-MMM-yyyy");

        	String companyA = masterAgreement.getPartyA().getTrueLegalName();
        	String masterlistIdentifier = masterAgreement.getMasterlistIdentifier();
        	if(masterlistIdentifier!=null && masterlistIdentifier != "") {
        		params.addValue("master_agreement_id", masterAgreement.getId())
    			.addValue("name", formattedAgreementDate + "-" + masterlistIdentifier + "-" + companyA + "-" + "DRAFT");
        	} else {
        		params.addValue("master_agreement_id", masterAgreement.getId())
    			.addValue("name", formattedAgreementDate + "-" + companyA + "-" + "DRAFT");
        	}
        	
		}
        KeyHolder keyHolder = new GeneratedKeyHolder();
        namedParameterJdbcTemplate.update(SAVE_AMENDMENT_LETTER, params, keyHolder);
        amendmentLetter.setId(keyHolder.getKey().longValue());
        
        params = new MapSqlParameterSource()
        	.addValue("amendment_id", amendmentLetter.getId())
        	.addValue("amendmentStatus", "Draft")
        	.addValue("created_by", amendmentLetter.getCreatedBy());
    	  //  .addValue("is_bs_company", RFAConstants.COMPANY_TYPE_SS.equalsIgnoreCase(companyType) ? 0 : 1);
        if(RFAConstants.COMPANY_TYPE_SS.equalsIgnoreCase(companyType)) {
        	namedParameterJdbcTemplate.update(UPDATE_STATE_TRANSITION_FOR_SS, params);
        }
        else {
        	namedParameterJdbcTemplate.update(UPDATE_STATE_TRANSITION_FOR_BS, params);
        }
        
        if(null != amendmentLetter.getPartyBEntities()) {
        	amendmentLetter.sortSleevesForInsertion();
        	List<PartyBEntity> partyBEntityList = amendmentLetter.getPartyBEntities();
        	for (PartyBEntity partyBEntity : partyBEntityList) {
        		if (partyBEntity.getAutoAdded() != null && partyBEntity.getAutoAdded()) continue;
        		boolean isModified = null != partyBEntity.getIsModified() &&  partyBEntity.getIsModified();
        		boolean isAdded =  null != partyBEntity.getIsAdded() && partyBEntity.getIsAdded();
        		Long parentPartybId = null;
        		Long isSleeve = partyBEntity.getEntity().getIsSleeve();
        		if(null != isSleeve && isSleeve == 1) {
        			List<Long> parentEntityIds = new ArrayList<>();
        			Long parentEntityId = entityDao.getParentEntity(partyBEntity.getEntity().getId()).getId();
        			parentEntityIds.add(parentEntityId);
        			parentPartybId = parentPartybMap.get(parentEntityId);
        			if(null == parentPartybId) {
        				List<PartyBEntity> existingPartyBList = masterAgreementDao.getExistingPartyBListForValidation(
                				amendmentLetter.getMasterAgreement().getId(), parentEntityIds, amendmentLetter.getId());
                		if(null != existingPartyBList && existingPartyBList.size() == 1) {
                			parentPartybId = existingPartyBList.get(0).getId();
                		}
        			}
        		}
        		List<Long> parentEntityIds = new ArrayList<Long>();
        		parentEntityIds.add(partyBEntity.getEntity().getId());
        		List<Long> masterAgreementIds = new ArrayList<Long>();
        		masterAgreementIds.add(amendmentLetter.getMasterAgreement().getId());
        		List<Entity> sleeveEntities = new ArrayList<>();
        		if (partyBEntity.getEntity().getIsSleeve() == 0) sleeveEntities = entityDao.getSleeveAccountsForParentEntities(companyId, masterAgreementIds, parentEntityIds);
        		
        		params = new MapSqlParameterSource()
	    			.addValue("master_agreement_id", amendmentLetter.getMasterAgreement().getId())
	    			.addValue("amendment_id", amendmentLetter.getId())
	    			.addValue("entity_id", partyBEntity.getEntity().getId())
	    	        .addValue("is_added", isAdded || isModified? 1 : 0)
	    	        .addValue("added_for_modification", isModified ? 1 : 0)
	    	        .addValue("fund_name_change_comment", null != partyBEntity.getFundNameChange() ?
        	        		partyBEntity.getFundNameChange().getComment() : null)
        	        .addValue("exhibit_value_change_comment", null != partyBEntity.getExhibitValueChange() ?
        	        		partyBEntity.getExhibitValueChange().getComment() : null)
	    	        .addValue("created_by", amendmentLetter.getCreatedBy())
	    	        .addValue("modified_by", amendmentLetter.getCreatedBy())
	    	        .addValue("is_sleeve", isSleeve)
	    	        .addValue("parent_partyb_id", parentPartybId);
	    		keyHolder = new GeneratedKeyHolder();
	            namedParameterJdbcTemplate.update(SAVE_PARTYB_ENTITY, params, keyHolder);
	            partyBEntity.setId(keyHolder.getKey().longValue());
	            
				if (CommonUtil.isNotNull(amendmentLetter.getRfaBulkUploadRows()) && CommonUtil
						.isNotNull(amendmentLetter.getRfaBulkUploadRows().get(partyBEntity.getEntity().getId()))) {
					// method to save in rfa_bulk_uploaded_data
					populateRFABulkUploadData(
							amendmentLetter.getRfaBulkUploadRows().get(partyBEntity.getEntity().getId()),
							amendmentLetter.getBulkRequestId(), partyBEntity.getId());
			    	
				}
	            
	            if (sleeveEntities != null && sleeveEntities.size() > 0 
	            		&& (partyBEntity.getEntity().getIsSleeve() == 0) && !partyBEntity.getIsAdded()){
	            	removeSleevesOfParent(partyBEntity, sleeveEntities, amendmentLetter);
	            }
	            if(null == partyBEntity.getEntity().getIsSleeve() || partyBEntity.getEntity().getIsSleeve() == 0) {
					if (parentPartybMap.containsKey(partyBEntity.getEntity().getId())) {
						if (CommonUtil.isNotNull(partyBEntity.getFundNameChange()))
							parentPartybMap.put(partyBEntity.getEntity().getId(), partyBEntity.getId());
					} else {
						parentPartybMap.put(partyBEntity.getEntity().getId(), partyBEntity.getId());
					}
				}

		}
		}
        Long userId = amendmentLetter.getCreatedBy();
        AmendmentLetter amendmentLetterObj = getAmendmentLetterById(amendmentLetter.getId(), companyId);
        
        exhibitDao.createExhibit(amendmentLetterObj.getMasterAgreement().getId(), amendmentLetterObj.getId()
        		, amendmentLetter.getPartyBEntities(), userId, amendmentLetter.getPartyBExhibitMap(),companyType);
        
        if(null != amendmentLetter.getPartyBEntities()) {
        	List<PartyBEntity> partyBEntityList = amendmentLetter.getPartyBEntities();
        	for (PartyBEntity partyBEntity : partyBEntityList) {
        		if(null != partyBEntity.getIsModified() && partyBEntity.getIsModified()) {
                	if(null != partyBEntity.getFundNameChange()) {
                    	saveFundNameChangeDetails(partyBEntity, amendmentLetter.getMasterAgreement().getId()
                    			, amendmentLetter.getCreatedBy());
                    }
                    if(null != partyBEntity.getExhibitValueChange()) {
                    	params = new MapSqlParameterSource()
                    		.addValue("entity_id", partyBEntity.getEntity().getId())
                    		.addValue("amendment_id", amendmentLetter.getId())
                    		.addValue("master_agreement_id", amendmentLetter.getMasterAgreement().getId());
                    	
                    	ExistingPartyB existingPartyB = namedParameterJdbcTemplate.queryForObject(
                    			GET_EXISTING_PARTYB_FOR_MODIFICATION, params, new ExistingPartyBRowMapper());
                    	
                    	/*Boolean belongsToPlaceholderAmendment = existingPartyB.getBelongsToPlaceholderAmendment();
                    	if(belongsToPlaceholderAmendment) {
                    		saveBlankExhibitValuesForPlaceholderAmendment(existingPartyB.getId()
                    				, partyBEntity.getEntity().getId(), amendmentLetter.getCreatedBy());
                    	}*/
                    	
                    	saveExhibitValueChangeDetails(existingPartyB.getId(), partyBEntity.getId(), amendmentLetter.getCreatedBy());
                    }
                }
        		if(null != partyBEntity.getEntity().getIsSleeve() && partyBEntity.getEntity().getIsSleeve() == 1) {
        			params = new MapSqlParameterSource()
	            		.addValue("entity_id", partyBEntity.getEntity().getId())
	            		.addValue("amendment_id", amendmentLetter.getId())
	            		.addValue("master_agreement_id", amendmentLetter.getMasterAgreement().getId());
        			try {
        				ExistingPartyB existingParentPartyB = namedParameterJdbcTemplate.queryForObject(
                    			GET_EXISTING_PARENT_PARTYB, params, new ExistingPartyBRowMapper());
        				saveSleeveExhibitValues(existingParentPartyB.getId(), partyBEntity.getId(), userId);
        			} catch(EmptyResultDataAccessException error){
        				// If no Parent PartyB found in the Masterlist for a particular sleeve account,
        				// then don't do anything i.e. keep the exhibit cell blanks and move to the next PartyB
        			}
                }
        	}
        }
        
        if(null != amendmentLetter.getExhibitValued()) {
        	updateBSTaskAndNextSteps(amendmentLetter.getId(), RFAConstants.ACTION_EXHIBIT_UPDATE);
        } else {
        	updateBSTaskAndNextSteps(amendmentLetter.getId(), RFAConstants.ACTION_SAVE);
        }
    	return amendmentLetterObj;
	}

    private void removeSleevesOfParent(PartyBEntity parentPartyB, List<Entity> sleeveEntities, AmendmentLetter amendmentLetter){
    	MapSqlParameterSource sleeveParams;
    	for (Entity sleeveEntity : sleeveEntities){
    		sleeveParams = new MapSqlParameterSource()
	    			.addValue("master_agreement_id", amendmentLetter.getMasterAgreement().getId())
	    			.addValue("amendment_id", amendmentLetter.getId())
	    			.addValue("entity_id", sleeveEntity.getId())
	    	        .addValue("is_added", 0)
	    	        .addValue("added_for_modification", 0)
	    	        .addValue("fund_name_change_comment", null)
        	        .addValue("exhibit_value_change_comment", null)
	    	        .addValue("created_by", amendmentLetter.getCreatedBy())
	    	        .addValue("modified_by", amendmentLetter.getCreatedBy())
	    	        .addValue("is_sleeve", 1)
	    	        .addValue("parent_partyb_id", parentPartyB.getId());
    		namedParameterJdbcTemplate.update(SAVE_PARTYB_ENTITY, sleeveParams);
    	}
    }
    
	public void updateBSTaskAndNextSteps(Long amendmentLetterId, String action) {
		MapSqlParameterSource params;
		params = new MapSqlParameterSource()
		.addValue("amendmentId", amendmentLetterId)
        .addValue("action", action);
        namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_BS_NEXT_STEP_TASK_PROC, params);
	}
	
	private void updateSSTaskAndNextSteps(Long amendmentLetterId, String action) {
		MapSqlParameterSource params;
		params = new MapSqlParameterSource()
		.addValue("amendmentId", amendmentLetterId)
        .addValue("action", action);
		logger.info("Executing UPDATE_AMENDMENT_SS_NEXT_STEP_TASK_PROC for " + amendmentLetterId);
        namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_SS_NEXT_STEP_TASK_PROC, params);
	}
    
    private void saveFundNameChangeDetails(PartyBEntity partyBEntity, Long masterAgreementId, Long userId) {
    	//Please don't remove the below commented code, as we might need to use this code if Business wants
    	//to change the logic to display Fund Name changed old values
    	
    	Entity masterlistEntity = null;
    	MapSqlParameterSource params = new MapSqlParameterSource()
    		.addValue("master_agreement_id", masterAgreementId)
    		.addValue("entity_id", partyBEntity.getEntity().getId());
    	masterlistEntity = namedParameterJdbcTemplate.queryForObject(GET_MASTERLIST_ENTITY, params, new EntityRowMapper());
    		
		FundNameChange fundNameChange = partyBEntity.getFundNameChange();
		params = new MapSqlParameterSource()
			.addValue("partyb_id", partyBEntity.getId())
	        .addValue("old_lei", masterlistEntity.getLei())
	        //.addValue("old_lei", fundNameChange.getOldLei())
	        .addValue("current_lei", fundNameChange.getCurrentLei())
	        .addValue("old_true_legal_name", masterlistEntity.getTrueLegalName())
	        //.addValue("old_true_legal_name", fundNameChange.getOldTrueLegalName())
	        .addValue("current_true_legal_name", fundNameChange.getCurrentTrueLegalName())
	        .addValue("old_client_identifier", masterlistEntity.getClientIdentifier())
	        //.addValue("old_client_identifier", fundNameChange.getOldClientIdentifier())
	        .addValue("current_client_identifier", fundNameChange.getCurrentClientIdentifier())
	        .addValue("update_mcpm_lei", fundNameChange.getUpdateMcpmLei() ? 1 : 0)
	        .addValue("update_mcpm_legal_name", fundNameChange.getUpdateMcpmLegalName() ? 1 : 0)
	        .addValue("update_mcpm_client_identifier", fundNameChange.getUpdateMcpmClientIdentifier() ? 1 : 0)
	        .addValue("created_by", userId)
	        .addValue("modified_by", userId);
	    namedParameterJdbcTemplate.update(SAVE_RFA_PARTYB_FUND_NAME_CHANGE, params);
	}
    
    private void updateFundNameChangeDetails(PartyBEntity partyBEntity, Long masterAgreementId, Long userId) {
    	//Please don't remove the below commented code, as we might need to use this code if Business wants
    	//to change the logic to display Fund Name changed old values
    	Entity masterlistEntity = null;
    	MapSqlParameterSource params = new MapSqlParameterSource()
    		.addValue("master_agreement_id", masterAgreementId)
    		.addValue("entity_id", partyBEntity.getEntity().getId());
    	masterlistEntity = namedParameterJdbcTemplate.queryForObject(GET_MASTERLIST_ENTITY, params, new EntityRowMapper());
    	
    	FundNameChange fundNameChange = partyBEntity.getFundNameChange();
    	
    	if(fundNameChange.getId() == null || fundNameChange.getId() == 0) {
   		saveFundNameChangeDetails(partyBEntity, masterAgreementId, userId);
   		return;
    	} 
    	
    	params = new MapSqlParameterSource()
    		.addValue("id", fundNameChange.getId())
	    	.addValue("partyb_id", partyBEntity.getId())
	    	.addValue("old_lei", masterlistEntity.getLei())
	    	//.addValue("old_lei", fundNameChange.getOldLei())
	    	.addValue("current_lei", fundNameChange.getCurrentLei())
	    	.addValue("old_true_legal_name", masterlistEntity.getTrueLegalName())
	    	//.addValue("old_true_legal_name", fundNameChange.getOldTrueLegalName())
	    	.addValue("current_true_legal_name", fundNameChange.getCurrentTrueLegalName())
	    	.addValue("old_client_identifier", masterlistEntity.getClientIdentifier())
	    	//.addValue("old_client_identifier", fundNameChange.getOldClientIdentifier())
	    	.addValue("current_client_identifier", fundNameChange.getCurrentClientIdentifier())
	    	.addValue("update_mcpm_lei", fundNameChange.getUpdateMcpmLei() ? 1 : 0)
	    	.addValue("update_mcpm_legal_name", fundNameChange.getUpdateMcpmLegalName() ? 1 : 0)
	    	.addValue("update_mcpm_client_identifier", fundNameChange.getUpdateMcpmClientIdentifier() ? 1 : 0)
    		.addValue("userId", userId);
    	namedParameterJdbcTemplate.update(UPDATE_RFA_PARTYB_FUND_NAME_CHANGE, params);
    }

	private void saveExhibitValueChangeDetails(Long existingPartybId, Long currentPartybId, Long userId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
			.addValue("existing_partyb_id", existingPartybId)
			.addValue("current_partyb_id", currentPartybId)
			.addValue("created_by", userId);
		int i = namedParameterJdbcTemplate.update(SAVE_RFA_PARTYB_EXHIBIT_VALUE_CHANGE, params);
		System.out.println("Number of rows impacted: " + i);
	}
	
	private void saveSleeveExhibitValues(Long existingPartybId, Long currentPartybId, Long userId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
			.addValue("existing_partyb_id", existingPartybId)
			.addValue("current_partyb_id", currentPartybId)
			.addValue("created_by", userId);
		namedParameterJdbcTemplate.update(SAVE_SLEEVE_EXHIBIT_VALUES, params);
	}

	@Override
	public AmendmentLetter updateAmendmentLetter(Long companyId, String companyType
			, AmendmentLetter amendmentLetter, Long modifiedBy) {
		Map<Long, Long> parentPartybMap = new LinkedHashMap<>();
    	MapSqlParameterSource params = new MapSqlParameterSource()
	    	.addValue("id", amendmentLetter.getId())
		    .addValue("modified_by", modifiedBy);
	
    	namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_LETTER, params);

	    if(null != amendmentLetter.getPartyBEntities()) {
	    	amendmentLetter.sortSleevesForInsertion();
	    	List<PartyBEntity> partyBEntityList = amendmentLetter.getPartyBEntities();
	    	for (PartyBEntity partyBEntity : partyBEntityList) {
	    		boolean isModified = null != partyBEntity.getIsModified() &&  partyBEntity.getIsModified();
        		boolean isAdded =  null != partyBEntity.getIsAdded() && partyBEntity.getIsAdded();
        		Long parentPartybId = null;
        		Long isSleeve = partyBEntity.getEntity().getIsSleeve();
        		if(null != isSleeve && isSleeve == 1) {
        			List<Long> parentEntityIds = new ArrayList<>();
        			Long parentEntityId = entityDao.getParentEntity(partyBEntity.getEntity().getId()).getId();
        			parentEntityIds.add(parentEntityId);
        			parentPartybId = parentPartybMap.get(parentEntityId);
        			if(null == parentPartybId) {
        				List<PartyBEntity> existingPartyBList = masterAgreementDao.getExistingPartyBListForValidation(
                				amendmentLetter.getMasterAgreement().getId(), parentEntityIds, amendmentLetter.getId());
                		if(null != existingPartyBList && existingPartyBList.size() == 1) {
                			parentPartybId = existingPartyBList.get(0).getId();
                		}
        			}
        		}
	    		params = new MapSqlParameterSource()
	    			.addValue("entity_id", partyBEntity.getEntity().getId())
	    	        .addValue("is_added", isAdded || isModified ? 1 : 0)
	    	        .addValue("added_for_modification", isModified ? 1 : 0)
	    	        .addValue("ack_status", partyBEntity.getAcknowledgementStatus() == null? null: partyBEntity.getAcknowledgementStatus().getName())
	    	        .addValue("reason", partyBEntity.getReason())
	    	        .addValue("fund_name_change_comment", null != partyBEntity.getFundNameChange() ?
							partyBEntity.getFundNameChange().getComment() : null)
					.addValue("exhibit_value_change_comment", null != partyBEntity.getExhibitValueChange() ?
							partyBEntity.getExhibitValueChange().getComment() : null)
	    	        .addValue("modified_by", modifiedBy)
	    	        .addValue("is_sleeve", null == isSleeve ? 0 : isSleeve)
	    	        .addValue("parent_partyb_id", parentPartybId);
	            
	            if(null != partyBEntity.getId() 
	            		&& partyBEntity.getId() > 0 ) {
        			params.addValue("id", partyBEntity.getId())
        					.addValue("deleted", partyBEntity.getDeleted());
        			namedParameterJdbcTemplate.update(UPDATE_PARTYB_ENTITY, params);
        			if(null == partyBEntity.getEntity().getIsSleeve() || partyBEntity.getEntity().getIsSleeve() == 0) {
    	            	parentPartybMap.put(partyBEntity.getEntity().getId(), partyBEntity.getId());
    	            }
        			if(null != partyBEntity.getDeleted() && partyBEntity.getDeleted() == 1) {
        				if(null != amendmentLetter.getExhibit()) {
        					Exhibit exhibit = amendmentLetter.getExhibit();
        					if(null != exhibit.getColumns()) {
        						List<ExhibitColumn> exhibitColumnList = exhibit.getColumns();
        			        	for (ExhibitColumn exhibitColumn : exhibitColumnList) {
        			        		if(null != exhibitColumn.getCells()) {
        			    	        	List<ExhibitCell> exhibitCellList = exhibitColumn.getCells();
        			    	        	for (ExhibitCell exhibitCell : exhibitCellList) {
        			    	        		if(null != exhibitCell.getId() && exhibitCell.getId() > 0 
        			    	        				&& exhibitCell.getPartyBEntityId() != null 
        			    	        				&& exhibitCell.getPartyBEntityId() != 0
        			    	        				&& partyBEntity.getEntity().getId() == exhibitCell.getPartyBEntityId()) {
        				    	        			params = new MapSqlParameterSource()
        				    	        				.addValue("id", exhibitCell.getId())
	        				    	        			.addValue("modified_by", modifiedBy);
        				    	        			namedParameterJdbcTemplate.update(DELETE_EXHIBIT_COL_DATA, params);
        			    	        		}
        			    	    		}
        			        		}
        			        	}
        					}
        				}
        			}
        			if(partyBEntity.getIsAdded() && partyBEntity.getIsModified()) {
    	            	if(null != partyBEntity.getFundNameChange()) {
    	            		updateFundNameChangeDetails(partyBEntity, amendmentLetter.getMasterAgreement().getId()
    	            				,  amendmentLetter.getCreatedBy());
    	                }
    	            }
        			
        		} else {
        			params.addValue("amendment_id", amendmentLetter.getId())
        					.addValue("master_agreement_id", amendmentLetter.getMasterAgreement().getId())
        					.addValue("created_by", modifiedBy);
        			KeyHolder keyHolder = new GeneratedKeyHolder();
        			namedParameterJdbcTemplate.update(SAVE_PARTYB_ENTITY, params, keyHolder);
        			partyBEntity.setId(keyHolder.getKey().longValue());
    	            if(null == partyBEntity.getEntity().getIsSleeve() || partyBEntity.getEntity().getIsSleeve() == 0) {
    	            	parentPartybMap.put(partyBEntity.getEntity().getId(), partyBEntity.getId());
    	            }
        			if(partyBEntity.getIsModified() == null) partyBEntity.setIsModified(false);
        			if(partyBEntity.getIsModified()) {
        				partyBEntity.setIsAdded(true);
        			}
        			
        			createExhibitColData(amendmentLetter.getId(), partyBEntity.getEntity().getId(), modifiedBy);
        			
        			if(partyBEntity.getIsAdded() && partyBEntity.getIsModified()) {
        				if(null != partyBEntity.getFundNameChange()) {
    	                	saveFundNameChangeDetails(partyBEntity, amendmentLetter.getMasterAgreement().getId()
    	                			, amendmentLetter.getCreatedBy());
    	                }
            			if(null != partyBEntity.getExhibitValueChange()) {
    		            	params = new MapSqlParameterSource()
        		            	.addValue("entity_id", partyBEntity.getEntity().getId())
    		            		.addValue("amendment_id", amendmentLetter.getId())
    		            		.addValue("master_agreement_id", amendmentLetter.getMasterAgreement().getId());
    		            	
    		            	ExistingPartyB existingPartyB = namedParameterJdbcTemplate.queryForObject(
                        			GET_EXISTING_PARTYB_FOR_MODIFICATION, params, new ExistingPartyBRowMapper());
                        	
                        /*	Boolean belongsToPlaceholderAmendment = existingPartyB.getBelongsToPlaceholderAmendment();
                        	if(belongsToPlaceholderAmendment) {
                        		saveBlankExhibitValuesForPlaceholderAmendment(existingPartyB.getId()
                        				, partyBEntity.getEntity().getId(), amendmentLetter.getCreatedBy());
                        	}*/
                        	
                        	saveExhibitValueChangeDetails(existingPartyB.getId(), partyBEntity.getId(), amendmentLetter.getCreatedBy());
    	                }
            			if(null != partyBEntity.getEntity().getIsSleeve() && partyBEntity.getEntity().getIsSleeve() == 1) {
                			params = new MapSqlParameterSource()
        	            		.addValue("entity_id", partyBEntity.getEntity().getId())
        	            		.addValue("amendment_id", amendmentLetter.getId())
        	            		.addValue("master_agreement_id", amendmentLetter.getMasterAgreement().getId());
                			try {
                				ExistingPartyB existingParentPartyB = namedParameterJdbcTemplate.queryForObject(
                            			GET_EXISTING_PARENT_PARTYB, params, new ExistingPartyBRowMapper());
                				saveSleeveExhibitValues(existingParentPartyB.getId(), partyBEntity.getId(), modifiedBy);
                			} catch(EmptyResultDataAccessException error){
                				// If no Parent PartyB found in the Masterlist for a particular sleeve account,
                				// then don't do anything i.e. keep the exhibit cell blanks and move to the next PartyB
                			}
                        }
        			}
        		}
			}
	    }
	    updateBSTaskAndNextSteps(amendmentLetter.getId(),RFAConstants.ACTION_UPDATE);
	 
		return amendmentLetter;
	}

	private void createExhibitColData(Long amendmentLetterId, Long partyBEntityId, Long userId)
	{
    	MapSqlParameterSource params = new MapSqlParameterSource()
    		.addValue("amendmentId", amendmentLetterId);
    	String colName = "";
    	List<ExhibitColumn> exhibitColumns = namedParameterJdbcTemplate.query(
    			GET_EXHIBIT_COLUMNS_BY_AMENDMENT_ID, params, new RowMapper<ExhibitColumn>(){
			@Override
			public ExhibitColumn mapRow(ResultSet rs, int rowNum) throws SQLException {
				ExhibitColumn exhibitColumn = new ExhibitColumn();
				exhibitColumn.setId(rs.getLong("column_id"));
				exhibitColumn.setColumnName(rs.getString("column_name"));
				return exhibitColumn;
			}
		});
    	if(exhibitColumns != null && exhibitColumns.size() > 0){
			for (ExhibitColumn exhibitColumn : exhibitColumns) {
	    		colName = exhibitColumn.getColumnName();
				if(!RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD.equalsIgnoreCase(colName)
						&& !RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(colName)
						&& !RFAConstants.PARTYB_LEI_FIELD.equalsIgnoreCase(colName)){
		    			params = new MapSqlParameterSource()
			    	        .addValue("exhibit_col_id", exhibitColumn.getId())
			    	        .addValue("partyb_entity_id", partyBEntityId)
			    	        .addValue("value", "")
			    	        .addValue("modified_by", userId)
			    	        .addValue("created_by", userId)
			    	        .addValue("style", "");
		    			namedParameterJdbcTemplate.update(SAVE_EXHIBIT_COL_DATA, params);
				}
			}
    	}
	}

	@Override
	public AmendmentLetter getAmendmentLetterById(Long amendmentId, Long companyId) {		
		MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource()
		.addValue("id", amendmentId);
		
		AmendmentLetter amendment= namedParameterJdbcTemplate.query(
				GET_AMENDMENT_LETTER, mapSqlParameterSource, new AmendmentLetterResultSetExtractor());
		
		return amendment;
	}

	@Override
	public AmendmentLetter getAmendmentLetterById(Long amendmentId) {		
		MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource()
		.addValue("id", amendmentId);
		
		AmendmentLetter amendment= namedParameterJdbcTemplate.query(
				GET_AMENDMENT_LETTER, mapSqlParameterSource, new AmendmentLetterResultSetExtractor());
		
		return amendment;
	}	

	@Override
	public List<AmendmentLetter> getBSAmendmentLetterGrid(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		params.put("offset", amendmentLetterSearchRequest.getOffSet());
		params.put("page_size", amendmentLetterSearchRequest.getPageSize());
		
		if (amendmentLetterSearchRequest.getTask() != null){
			String taskStatus = "";
			String task = amendmentLetterSearchRequest.getTask();
			if(task.equalsIgnoreCase("Signature")){
				taskStatus = "BS ESIGN";
			} else if(task.equalsIgnoreCase("Exhibit Completion")){
				taskStatus = "BS EXHIBIT COMPLETION";
			} else if(task.equalsIgnoreCase("BS_SEND_RFA")){
				taskStatus = "BS SEND RFA";
			}
			SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValues(params)
			.addValue("taskStatus",taskStatus);
			
			String query  = GET_BS_AMEDMENT_TASKS_GRID;
			List<AmendmentLetter> letters = namedParameterJdbcTemplate.query(query, paramSource, new AmendmentGridResultSetExtractor(true));
			return letters;
		} 
	    
		Map<String, Object> paramSource = new HashMap<>();
		paramSource.putAll(params);
		paramSource.put("reviewIds", amendmentLetterSearchRequest.getReviewData());
		paramSource.put("agreementDate", amendmentLetterSearchRequest.getAgreementDate());
		paramSource.put("partyACompIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyA()));
		paramSource.put("investmentManagerIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getInvestmentManager()));
		paramSource.put("masterlistIdentifiers", amendmentLetterSearchRequest.getMasterlistIdentifier());
		paramSource.put("partyBIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyBAccount()));
		paramSource.put("bsRequestStatuses", amendmentLetterSearchRequest.getRequestStatus());
		paramSource.put("acknowledgementStatuses",
				getPartyBActionedList(amendmentLetterSearchRequest.getActionOnPartyB(), CompanyType.BS));
		paramSource.put("submittedDates", amendmentLetterSearchRequest.getSubmitDate());
		paramSource.put("monikerNames", amendmentLetterSearchRequest.getPartyBClientIdentifier());
		paramSource.put("leiNames", amendmentLetterSearchRequest.getPartyBLei());		
		paramSource.put("rfaIdList", amendmentLetterSearchRequest.getRfaIds());	
		paramSource.put("agreementTypes", amendmentLetterSearchRequest.getAgreementType());
		
		List<AmendmentLetter> amendmentLetters = getAmendmentLetterBuysideGrid.executeQuery(paramSource);
		return amendmentLetters;
	}
	
	@Override
	public List<AmendmentLetter> getSSAmendmentLetterGrid(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
		params.put("offset", amendmentLetterSearchRequest.getOffSet());
		params.put("page_size", amendmentLetterSearchRequest.getPageSize());
		if (amendmentLetterSearchRequest.getTask() != null){
			String taskStatus = "";
			String task = amendmentLetterSearchRequest.getTask();
			if(task.equalsIgnoreCase("Response")){
				taskStatus = "SS RESPONSE COMPLETION";
				List<String> statuses = new ArrayList<String>();
				statuses.add("Rejected");
				statuses.add("Recalled");
				statuses.add("Completed");
				statuses.add("Partially Completed");
				params.put("ignoreStatus", statuses);
			} else if(task.equalsIgnoreCase("Signature")){
				taskStatus = "SS ESIGN";
				List<String> statuses = new ArrayList<String>();
				statuses.add("Rejected");
				statuses.add("Recalled");
				statuses.add("Completed");
				params.put("ignoreStatus", statuses);
			} else if(task.equalsIgnoreCase("SS_SEND_RFA")){
				taskStatus = "SS SEND RFA";
				List<String> statuses = new ArrayList<String>();
				statuses.add("Rejected");
				statuses.add("Recalled");
				statuses.add("Completed");
				params.put("ignoreStatus", statuses);
			}
			SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValues(params)
			.addValue("taskStatus",taskStatus);
			
			String query  = GET_SS_AMEDMENT_TASKS_GRID;
			List<AmendmentLetter> letters = namedParameterJdbcTemplate.query(query, paramSource, new AmendmentGridResultSetExtractor(false));
			return letters;
		}
		Map<String, Object> paramSource = new HashMap<>();
		paramSource.putAll(params);
		paramSource.put("reviewIds", amendmentLetterSearchRequest.getReviewData());
		paramSource.put("agreementDate", amendmentLetterSearchRequest.getAgreementDate());
		paramSource.put("partyACompIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyA()));
		paramSource.put("investmentManagerIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getInvestmentManager()));
		paramSource.put("masterlistIdentifiers", amendmentLetterSearchRequest.getMasterlistIdentifier());
		paramSource.put("partyBIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyBAccount()));
		paramSource.put("ssRequestStatuses", amendmentLetterSearchRequest.getRequestStatus());
		paramSource.put("acknowledgementStatuses",
				getPartyBActionedList(amendmentLetterSearchRequest.getActionOnPartyB(), CompanyType.SS));
		paramSource.put("submittedDates", amendmentLetterSearchRequest.getSubmitDate());
		paramSource.put("monikerNames", amendmentLetterSearchRequest.getPartyBClientIdentifier());
		paramSource.put("leiNames", amendmentLetterSearchRequest.getPartyBLei());			
		paramSource.put("rfaIdList", amendmentLetterSearchRequest.getRfaIds());	
		paramSource.put("agreementTypes", amendmentLetterSearchRequest.getAgreementType());		
		
		List<String> myStatus = amendmentLetterSearchRequest.getMyStatus();
		if(myStatus!=null && myStatus.size()>0) {
			paramSource.put("deskStatus", true);

			for(int i=0;i<myStatus.size();i++) {
				paramSource.put(myStatus.get(i).replace("-", ""), myStatus.get(i));
			}			
		}
		
		List<AmendmentLetter> amendmentLetters = getAmendmentLetterSellsideGrid.executeQuery(paramSource);
		return amendmentLetters;
	}

	@Override
	public Long getBSAmendmentLetterGridTotalCount(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);
			
		if(amendmentLetterSearchRequest.getTask() != null) { // TODO: Incorporate into new query...
			if("Signature".equals(amendmentLetterSearchRequest.getTask())) {
				params.put("task", "ELECTRONIC_SIGNATURE");
			} else if("Exhibit Completion".equals(amendmentLetterSearchRequest.getTask())) {
				params.put("task", "EXHIBIT_COMPLETION");
			} else if("BS_SEND_RFA".equals(amendmentLetterSearchRequest.getTask())) {
				params.put("task", "BS_SEND_RFA");
			}
			SqlParameterSource paramSource = new MapSqlParameterSource().addValues(params);
			return namedParameterJdbcTemplate.queryForObject(GET_BS_SS_AMENDMENT_LETTER_GRID_TASK_COUNT, paramSource,
					Long.class);
		}
		Map<String, Object> paramSource = new HashMap<>();
		paramSource.putAll(params);
		paramSource.put("reviewIds", amendmentLetterSearchRequest.getReviewData());
		paramSource.put("agreementDate", amendmentLetterSearchRequest.getAgreementDate());
		paramSource.put("partyACompIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyA()));
		paramSource.put("investmentManagerIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getInvestmentManager()));
		paramSource.put("masterlistIdentifiers", amendmentLetterSearchRequest.getMasterlistIdentifier());
		paramSource.put("partyBIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyBAccount()));
		paramSource.put("bsRequestStatuses", amendmentLetterSearchRequest.getRequestStatus());
		paramSource.put("acknowledgementStatuses",
				getPartyBActionedList(amendmentLetterSearchRequest.getActionOnPartyB(), CompanyType.BS));
		paramSource.put("submittedDates", amendmentLetterSearchRequest.getSubmitDate());
		paramSource.put("monikerNames", amendmentLetterSearchRequest.getPartyBClientIdentifier());
		paramSource.put("leiNames", amendmentLetterSearchRequest.getPartyBLei());			
		paramSource.put("rfaIdList", amendmentLetterSearchRequest.getRfaIds());	
		paramSource.put("agreementTypes", amendmentLetterSearchRequest.getAgreementType());
	    return getAmendmentLetterBuysideGridTotalCount.executeQuery(paramSource);
	}
	
	@Override
	public Long getSSAmendmentLetterGridTotalCount(Long companyId,
			AmendmentLetterSearchRequest amendmentLetterSearchRequest) {
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("companyId", companyId);

		if(amendmentLetterSearchRequest.getTask() != null) {
			if("Response".equals(amendmentLetterSearchRequest.getTask())) {
				params.put("task", "PENDING_RESPONSE");
			} else if("Signature".equals(amendmentLetterSearchRequest.getTask())) {
				params.put("task", "ELECTRONIC_SIGNATURE");
			} else if("SS_SEND_RFA".equals(amendmentLetterSearchRequest.getTask())) {
				params.put("task", "SS_SEND_RFA");
			}
			SqlParameterSource paramSource = new MapSqlParameterSource().addValues(params);
			return namedParameterJdbcTemplate.queryForObject(GET_BS_SS_AMENDMENT_LETTER_GRID_TASK_COUNT, paramSource,
					Long.class);
		}
		Map<String, Object> paramSource = new HashMap<>();
		paramSource.putAll(params);
		paramSource.put("reviewIds", amendmentLetterSearchRequest.getReviewData());
		paramSource.put("agreementDate", amendmentLetterSearchRequest.getAgreementDate());
		paramSource.put("partyACompIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyA()));
		paramSource.put("investmentManagerIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getInvestmentManager()));
		paramSource.put("masterlistIdentifiers", amendmentLetterSearchRequest.getMasterlistIdentifier());
		paramSource.put("partyBIds", LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyBAccount()));
		paramSource.put("ssRequestStatuses", amendmentLetterSearchRequest.getRequestStatus());
		paramSource.put("acknowledgementStatuses",
				getPartyBActionedList(amendmentLetterSearchRequest.getActionOnPartyB(), CompanyType.SS));
		paramSource.put("submittedDates", amendmentLetterSearchRequest.getSubmitDate());
		paramSource.put("monikerNames", amendmentLetterSearchRequest.getPartyBClientIdentifier());
		paramSource.put("leiNames", amendmentLetterSearchRequest.getPartyBLei());			
		paramSource.put("rfaIdList", amendmentLetterSearchRequest.getRfaIds());	
		paramSource.put("agreementTypes", amendmentLetterSearchRequest.getAgreementType());
		List<String> myStatus = amendmentLetterSearchRequest.getMyStatus();
		if(myStatus!=null && myStatus.size()>0) {
			paramSource.put("deskStatus", true);

			for(int i=0;i<myStatus.size();i++) {
				paramSource.put(myStatus.get(i).replace("-", ""), myStatus.get(i));
			}			
		}
		
	    return getAmendmentLetterSellsideGridTotalCount.executeQuery(paramSource);
	}
	
	
	@Deprecated
	private String conditionQueryFromRequest(AmendmentLetterSearchRequest amendmentLetterSearchRequest, Map<String, Object> params) {
		StringBuilder sb = new StringBuilder();
		
		if(amendmentLetterSearchRequest.getReviewData() != null && amendmentLetterSearchRequest.getReviewData().size() > 0) {
			sb.append("and (rev_legal_type_id in (:reviewIds) or rev_onboarding_type_id in (:reviewIds)) ");
			params.put("reviewIds", amendmentLetterSearchRequest.getReviewData());
		}
		if(amendmentLetterSearchRequest.getAgreementDate() != null && amendmentLetterSearchRequest.getAgreementDate().size() > 0) {
			sb.append(" and master_agreement_date in (:agreementDate) ");
			params.put("agreementDate", amendmentLetterSearchRequest.getAgreementDate());
    	}
		if(amendmentLetterSearchRequest.getPartyA() != null && amendmentLetterSearchRequest.getPartyA().size() > 0) {
			List<Long> partyAIds = new ArrayList<Long>();
			partyAIds = LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getPartyA());
			if (!partyAIds.isEmpty()){
				params.put("partyACompIds", partyAIds);
				sb.append(" and partyA_entityid in (:partyACompId) ");
			}
    	}
		if(amendmentLetterSearchRequest.getInvestmentManager() != null && amendmentLetterSearchRequest.getInvestmentManager().size() > 0) {
			List<Long> investmentManagerIds = new ArrayList<Long>();
			investmentManagerIds = LookupUtil.getIdsFromLookup(amendmentLetterSearchRequest.getInvestmentManager());

			if (investmentManagerIds.size() > 0 && amendmentLetterSearchRequest.getCompanyType().getName().equals(RFAConstants.COMPANY_TYPE_SS)){
				params.put("investmentManagerIds", investmentManagerIds);
				sb.append(" and im_entity_id in (:investmentManagerIds) ");
			}
    	}
		if(amendmentLetterSearchRequest.getMasterlistIdentifier() != null && amendmentLetterSearchRequest.getMasterlistIdentifier().size() > 0) {
			List<String> searchStrings = new ArrayList<>();
			searchStrings.addAll(amendmentLetterSearchRequest.getMasterlistIdentifier());
			if(!amendmentLetterSearchRequest.getCompanyType().getName().equals(RFAConstants.COMPANY_TYPE_SS)) {
				sb.append(" and masterlistIdentifier in (:masterlistIdentifier) ");
			}
			params.put("masterlistIdentifiers", searchStrings);
		}
		if(amendmentLetterSearchRequest.getPartyBAccount() != null && amendmentLetterSearchRequest.getPartyBAccount().size() > 0) {
			List<Long> partyBIds = new ArrayList<Long>();
			for (Lookup lookup : amendmentLetterSearchRequest.getPartyBAccount()){
				if (lookup.getId() != null){
					partyBIds.add(lookup.getId());
				}
			}
			if (partyBIds.size() > 0){
				params.put("partyBIds", partyBIds);	
				sb.append(" and exists (select pbent.id from rfa_partyb_entities pbent where pbent.entity_id in (:partyBIds) and pbent.deleted=0 and pbent.amendment_id=amendmentId)");
			}
    	}
		if(amendmentLetterSearchRequest.getActionOnPartyB() != null && amendmentLetterSearchRequest.getActionOnPartyB().size() > 0) {
			sb.append(" and exists "
					+ "(select pbe.id from RFA_PARTYB_ENTITIES pbe" +
						" join RFA_LU_ACK_STATUS ack on pbe.ack_status = ack.id and ack.name in (:ActionOnPartyBs)" +
						 " where pbe.AMENDMENT_ID =  amendmentId and pbe.DELETED = 0)");
			List<String> acknowledgementStatus = new ArrayList<String>();
			if(amendmentLetterSearchRequest.getActionOnPartyB().get(0).equalsIgnoreCase("Rejected")) {	// TODO: need to handle this case in new implementation
				acknowledgementStatus.add("Rejected");
				acknowledgementStatus.add("Rejected Sent");
			} else {
				acknowledgementStatus.add(amendmentLetterSearchRequest.getActionOnPartyB().get(0));
			}
			/*params.put("ActionOnPartyBs",acknowledgementStatus);*/
			params.put("acknowledgementStatuses",acknowledgementStatus);
    	}
		if(amendmentLetterSearchRequest.getRequestStatus() != null && amendmentLetterSearchRequest.getRequestStatus().size() > 0) {
			List<String> searchStrings = new ArrayList<String>();
			searchStrings.addAll(amendmentLetterSearchRequest.getRequestStatus());
			if(amendmentLetterSearchRequest.getCompanyType().getName().equals(RFAConstants.COMPANY_TYPE_SS))
				sb.append(" and amendmentStatus_SS in (:RequestStatus) ");
			else
				sb.append(" and amendmentStatus in (:RequestStatus) ");
			params.put("RequestStatus", searchStrings);
    	}
		if(amendmentLetterSearchRequest.getSubmitDate() != null && amendmentLetterSearchRequest.getSubmitDate().size() > 0) {
			List<String> searchStrings = new ArrayList<String>();
			searchStrings.addAll(amendmentLetterSearchRequest.getSubmitDate());
			sb.append(" and replace(convert(char(11),submit_date,113),' ','-') in (:submitDate) ");
			params.put("submittedDates",searchStrings);
    	}
		if(amendmentLetterSearchRequest.getPartyBClientIdentifier() != null && amendmentLetterSearchRequest.getPartyBClientIdentifier().size() > 0) {
			List<String> searchStrings = new ArrayList<String>();
			searchStrings.addAll(amendmentLetterSearchRequest.getPartyBClientIdentifier());
			sb.append(" and moniker_name in (:monikerName) ");
			params.put("monikerNames", searchStrings);
    	}
		if (amendmentLetterSearchRequest.getRfaIds() != null && amendmentLetterSearchRequest.getRfaIds().size() > 0) {
			sb.append(" and amendmentId in (:rfaIdList) ");
			params.put("rfaIdList", amendmentLetterSearchRequest.getRfaIds());
		}
		return sb.toString();
	}

	@Override
	public int signSellSide(Signature signature, AmendmentLetter amendmentLetter) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("id", amendmentLetter.getId())
		.addValue("signatureId", signature.getId())
		//.addValue("fileId", signature.getFileId())
		.addValue("modifiedBy", signature.getUserId());
		//.addValue("dateSigned",signature.getCreatedDate());
		
		int result = 0;
		if(signature.isSellSide()) {
			paramSource.addValue("status", getStatusFromAmendmentLetter(amendmentLetter));
			result = namedParameterJdbcTemplate.update(SIGN_SELL_SIDE, paramSource);
			updateSSTaskAndNextSteps(amendmentLetter.getId(), RFAConstants.ACTION_SS_SIGN);
		} else {
			String amendmentName = amendmentLetter.getName();
			if(null != amendmentName) {
				amendmentName = amendmentName.replaceAll("-DRAFT", "");
			}
			paramSource.addValue("name", amendmentName);
			result = namedParameterJdbcTemplate.update(SIGN_BUY_SIDE, paramSource);
			updateBSTaskAndNextSteps(amendmentLetter.getId(), RFAConstants.ACTION_SIGN);
		}
		return result;
	}

	private Object getStatusFromAmendmentLetter(AmendmentLetter amendmentLetter) {
		for ( PartyBEntity partyB : amendmentLetter.getPartyBEntities()){
			if(partyB.getAcknowledgementStatus() == PartyBAckStatus.PENDING){
				return AmendmentStatus.PARTIALLY_COMPLETED.getTrueName();
			}
		}
		return  AmendmentStatus.COMPLETED.getTrueName();
	}

	@Override
	public AmendmentLetterPDFBean getAmendmentLetterPDFBean(
			Long amendmentletterId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("id", amendmentletterId);
		AmendmentLetterPDFBean amendmentLetterPDFBean= namedParameterJdbcTemplate.queryForObject(GET_AMENDMENT_LETTER_PDF_DATA, paramSource, new AmendmentLetterPDFRowMapper());
		return amendmentLetterPDFBean;
	}
	private class AmendmentLetterPDFRowMapper implements RowMapper<AmendmentLetterPDFBean> {

		@Override
		public AmendmentLetterPDFBean mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			AmendmentLetterPDFBean amendmentLetterPDFBean = new AmendmentLetterPDFBean();
			amendmentLetterPDFBean.setAmendmentLetterContent(rs.getBytes("CONTENT"));
			amendmentLetterPDFBean.setExhibitTextContent(rs.getBytes("TEXT_CONTENT"));
			amendmentLetterPDFBean.setExhibitHTMLContent(rs.getBytes("HTML_CONTENT"));
			amendmentLetterPDFBean.setNoOfColumns(rs.getInt("NUMBER_OF_COLUMNS"));
			amendmentLetterPDFBean.setImSignatureID(rs.getLong("BUY_SIDE_SIGNATORY"));
			return amendmentLetterPDFBean;
		}
		
	}
	
	@Override
	public AmendmentLetter recallAmendmentLetter(Long companyId, Long userId, Long amendmentLetterId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
	    	.addValue("id", amendmentLetterId)
	    	.addValue("modified_by", userId)
		    .addValue("amendmentStatus", AmendmentStatus.RECALLED.getTrueName());

		namedParameterJdbcTemplate.update(RECALL_AMENDMENT_LETTER, params);
		updateBSTaskAndNextSteps(amendmentLetterId, RFAConstants.ACTION_RECALL);
		updateSSTaskAndNextSteps(amendmentLetterId, RFAConstants.ACTION_RECALL);
		AmendmentLetter amendmentLetter = getAmendmentLetterById(amendmentLetterId, companyId);
    	return amendmentLetter;
	}

	@Override
	public List<AmendmentHistory> history(Long amendmentLetterId, Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("id", amendmentLetterId).addValue("companyid", companyId);
		String query = null;
		SqlParameterSource paramSourceCompanyType = new MapSqlParameterSource()
		.addValue("companyid", companyId);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, paramSourceCompanyType, new CompanyTypeRowMapper());
		if("SS".equals(companyType)) {
			query = GET_AMENDMENT_LETTER_HISTORY_SS;
		} else {
			query = GET_AMENDMENT_LETTER_HISTORY_BS;
		}
		List<AmendmentHistory> history= namedParameterJdbcTemplate.query(query, paramSource, new AmendmentLetterHistoryRowMapper());
		return history;
	}

	@Override
	public Long getSignFileId(Long amendment_id, Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("id", amendment_id).addValue("companyid", companyId);		
		SqlParameterSource paramSourceCompanyType = new MapSqlParameterSource()
		.addValue("companyid", companyId);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, paramSourceCompanyType, new CompanyTypeRowMapper());
		String query = null;
		if("SS".equals(companyType)) {
			query = GET_SIGN_FILE_ID_SS;
		} else {
			query = GET_SIGN_FILE_ID_BS;
		}
		Long signFileId= namedParameterJdbcTemplate.queryForObject(query, paramSource, new RowMapper<Long>(){
			@Override
			public Long mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getLong("signFileId");
			}
		});
		return signFileId;
		
	}

	@Override
	public void rejectAmendmentLetter(Long amendmentId, Long userId, Long companyId, String reason) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("amendmentId", amendmentId)
			.addValue("userId", userId)
			.addValue("reason", reason);
		namedParameterJdbcTemplate.update(REJECT_AMENDMENT_LETTER, paramSource);
		updateBSTaskAndNextSteps(amendmentId, RFAConstants.ACTION_REJECT);
		updateSSTaskAndNextSteps(amendmentId, RFAConstants.ACTION_REJECT);
	}
	
	@Override
	public void deleteAmendmentLetter(Long amendmentId, Long userId) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("amendmentId", amendmentId)
			.addValue("userId", userId);
		namedParameterJdbcTemplate.update(UPDATE_RFA_AMENDMENT, paramSource);
	}
	
	@Override
	public void editRejectedAmendmentLetter(Long amendmentId, Long userId) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("amendmentId", amendmentId)
			.addValue("userId", userId);
		namedParameterJdbcTemplate.update(EDIT_REJECTED_AMENDMENT_LETTER, paramSource);
		updateBSTaskAndNextSteps(amendmentId, RFAConstants.ACTION_EDIT_DRAFT);	
	}


	@Override
	public Long addReview(int reviewId, long userId, long amendmentId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
		.addValue("RFA_LU_REVIEW_ID", reviewId)
		.addValue("TRANSITION_BY", userId)
		.addValue("AMENDMENT_ID", amendmentId);

		KeyHolder keyHolder = new GeneratedKeyHolder();
		namedParameterJdbcTemplate.update(ADD_REVIEW_IN_AMENDMENT, params, keyHolder);
		return keyHolder.getKey().longValue();
	}

	@Override
	public void deleteReview(long reviewId, long userId, Long amendmentId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
		.addValue("RFA_AMENDMENT_REVIEW_ID", reviewId)
		.addValue("DELETED_BY", userId)
		.addValue("AMENDMENT_ID", amendmentId);
	
		namedParameterJdbcTemplate.update(DELETE_REVIEW_IN_AMENDMENT, params);
		 
		
	}

	@Override
	public ReviewData getReview(Long reviewId, int reviewType, Long amendmentId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("reviewId", reviewId).
		addValue("reviewType", reviewType).
		addValue("amendmentId", amendmentId);
		return namedParameterJdbcTemplate.query(GET_REVIEW_IN_AMENDMENT, paramSource, new ReviewRowMapper(reviewType));
	}

	@Override
	public void updateContent(Long amendmentId, Long userId,
			AmendmentContent amendmentContent) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("content", amendmentContent.getContent().getBytes())
				.addValue("comment", CommonUtil.generateCommentHtml(amendmentContent.getCommentlog(),velocityEngine,"Amendment Letter"))
				.addValue("userId", userId)
				.addValue("partytype", amendmentContent.getPartyType())
				.addValue("amendmentID", amendmentId);
		if(amendmentContent.getChangelog()!=null&&!amendmentContent.getChangelog().isEmpty()&&"BS".equals(amendmentContent.getPartyType())) {
			namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_CONTENT_AGREED,paramSource);
		}else {
			namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_CONTENT,paramSource);
		}
	}
	
	
	@Override
	public void sendRFA(Long amendmentId, Long userId, String companyType) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("userId", userId)
			.addValue("amendmentId", amendmentId);
			//.addValue("digest", digest)
			//.addValue("noOfPages",noOfPages);
		
		if(RFAConstants.COMPANY_TYPE_SS.equalsIgnoreCase(companyType)) {
			logger.info("Executing SAVE_MASTERLIST_DATA for " + amendmentId); 
			namedParameterJdbcTemplate.update(SAVE_MASTERLIST_DATA, paramSource);
			logger.info("Executing SEND_RFA_SELL_SIDE for " + amendmentId);
			namedParameterJdbcTemplate.update(SEND_RFA_SELL_SIDE, paramSource);
			updateSSTaskAndNextSteps(amendmentId, RFAConstants.ACTION_SS_SEND_RFA);
		} else {
			namedParameterJdbcTemplate.update(SEND_RFA_BUY_SIDE, paramSource);
			updateBSTaskAndNextSteps(amendmentId, RFAConstants.ACTION_SEND_RFA);
			updateSSTaskAndNextSteps(amendmentId, RFAConstants.ACTION_SEND_RFA);
		}
	}
	
	@Override
	public void createRFAStateTransitionLog(Long amendmentId, String amendmentStatus
			, Long userId, Boolean isBSCompany) {
		MapSqlParameterSource params = new MapSqlParameterSource()
	    	.addValue("amendment_id", amendmentId)
	    	.addValue("amendmentStatus", amendmentStatus)
	    	.addValue("created_by", userId);
		   // .addValue("is_bs_company", isBSCompany ? 1 : 0);
		if(isBSCompany) {
			namedParameterJdbcTemplate.update(UPDATE_STATE_TRANSITION_FOR_BS, params);
		}
		else {
			namedParameterJdbcTemplate.update(UPDATE_STATE_TRANSITION_FOR_SS, params);
		}
		
	}
	
	@Override
	public void createRFAStateTransitionLogForBothBSAndSS(Long amendmentId, String amendmentStatus
			, Long userId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
			.addValue("amendment_id", amendmentId)
			.addValue("amendmentStatus", amendmentStatus)
			.addValue("created_by", userId);
		namedParameterJdbcTemplate.update(UPDATE_STATE_TRANSITION_FOR_BOTH_BS_AND_SS, params);
	}
	
	@Override
	public List<Long> getBulkNotificationRFA(Long companyId, String filterString, Long offset, Long pageSize) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("filterString", "%"+filterString+"%")
			.addValue("offset", offset)
			.addValue("page_size", pageSize);
		
		List<Long> amendmentIds = namedParameterJdbcTemplate.queryForList(GET_RFA_BULK_NOTIFICATION, paramSource, Long.class);		
		return amendmentIds;
	}
	
	@Override
	public void saveErrorMessage(String actionName, Long rfaId, String errorMessage, Long userId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("actionName", actionName)
			.addValue("rfaId", rfaId)
			.addValue("errorMessage", errorMessage)
			.addValue("userId", userId);
		namedParameterJdbcTemplate.update(SAVE_ERROR_MESSAGE,paramSource);
	}
	
	@Override
	public void saveChaser(BulkActionBean bulkActionBean){
		SqlParameterSource paramSource;
		for (Long rfaId : bulkActionBean.getRfaIdList()){
			paramSource = new MapSqlParameterSource()
			.addValue("rfaId", rfaId)
			.addValue("userId", bulkActionBean.getUserId());
			namedParameterJdbcTemplate.update(SAVE_CHASER, paramSource);
		}
	}
	
	@Override
	public void updateChasers(List<Long> rfaIds, Long userId){
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("rfaIds", rfaIds).addValue("userId", userId);
		namedParameterJdbcTemplate.update(UPDATE_CHASER, paramSource);
	}

	@Override
	public String getAmendmentMlTemplateWithSleeve(Long amendmentId)
	{
		String mlTemplateSleeve = null;
    	MapSqlParameterSource params = null;
    	if(null != amendmentId) {
    		params = new MapSqlParameterSource().addValue("amendmentId", amendmentId);
    		try{
    			mlTemplateSleeve = namedParameterJdbcTemplate.queryForObject(GET_AMENDMENT_ML_TEMPLATE, params, String.class);
    		}
    		catch(EmptyResultDataAccessException e){
    			return null;
    		}
    	}
    	return mlTemplateSleeve;
	}

	@Override
	public void saveBulkUploadFileTemplate(Long templateId, Long createdBy, Long companyId,Long bulkRequestId) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("templateId", templateId)
				.addValue("createdBy", createdBy).addValue("companyId", companyId).addValue("bulkRequestId", bulkRequestId)
				.addValue("bulkUploadStatus", RFAConstants.BULK_UPLOAD_STATUS_INPROGRESS);
		namedParameterJdbcTemplate.update(SAVE_BULK_UPLOAD_FILE_TEMPLATE, params);
	}

	@Override
	public Long getBulkRFAUploadId(Long bulkRequestId) {
		MapSqlParameterSource params = null;
		Long bulkRFAUploadId = null;
		if(null != bulkRequestId) {
    		params = new MapSqlParameterSource().addValue("bulkRequestId", bulkRequestId);
    		try{
    			bulkRFAUploadId = namedParameterJdbcTemplate.queryForObject(GET_RFA_BULK_UPLOAD_FILE_TEMPLATE, params, Long.class);
    		}
    		catch(EmptyResultDataAccessException e){
    			return null;
    		}
    	}
		return bulkRFAUploadId;
	}

	@Override
	public void updateBulkUploadFileTemplate(Long fileId, Long bulkRequestId, String status) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("fileId", fileId)
				.addValue("bulkRequestId", bulkRequestId)
				.addValue("bulkUploadStatus", status);
				
		namedParameterJdbcTemplate.update(UPDATE_BULK_UPLOAD_FILE_TEMPLATE, params);
		
	}
	private void populateRFABulkUploadData(RfaBulkUploadRow rfaBulkUploadRow,Long bulkRequestId, Long partyBId) {
		List<SqlParameterSource> paramSourceTF = new ArrayList<SqlParameterSource>();
			RfaBulkUploadedData rfaBulkUploadedData = new RfaBulkUploadedData();

			String partyBClientIdentifier = rfaBulkUploadRow.getPartyBClientIdentifier();
			String partyBLEI = rfaBulkUploadRow.getPartyBLEI();
			String partyBTrueLegalName = rfaBulkUploadRow.getPartyBTrueLegalName();
			String sleeveClientIdentifier = rfaBulkUploadRow.getSleeveClientIdentifier();
			String sleeveTrueLegalName = rfaBulkUploadRow.getSleeveTrueLegalName();
			
			rfaBulkUploadedData.setPartyBId(partyBId);
			rfaBulkUploadedData.setBulkRequestId(bulkRequestId);
			rfaBulkUploadedData.setRawPartyBClientIdentifier(partyBClientIdentifier);
			rfaBulkUploadedData.setRawPartyBLEI(partyBLEI);
			rfaBulkUploadedData.setRawPartyBTrueLegalName(partyBTrueLegalName);
			rfaBulkUploadedData.setRawSleeveClientIdentifier(sleeveClientIdentifier);
			rfaBulkUploadedData.setRawSleeveTrueLegalName(sleeveTrueLegalName);

			RFAUploadTemplateField rfaUploadTemplateField = RFABulkUploadUtil.getRFAUploadTemplateField(
					rfaBulkUploadRow.getRfaUploadTemplate(), RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD);
			if (CommonUtil.isNotNull(rfaUploadTemplateField) && rfaUploadTemplateField.getRule().equals(RFAConstants.RULES_PARTYB_CLIENT_IDENTIFIER))
				rfaBulkUploadedData.setPartyBClientIdentifier(partyBClientIdentifier);

			rfaUploadTemplateField = RFABulkUploadUtil.getRFAUploadTemplateField(
					rfaBulkUploadRow.getRfaUploadTemplate(), RFAConstants.PARTY_B_LEI);
			if (CommonUtil.isNotNull(rfaUploadTemplateField) && rfaUploadTemplateField.getRule().equals(RFAConstants.RULES_PARTYB_LEI))
				rfaBulkUploadedData.setPartyBLEI(partyBLEI);

			rfaUploadTemplateField = RFABulkUploadUtil.getRFAUploadTemplateField(
					rfaBulkUploadRow.getRfaUploadTemplate(), RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD);
			if (CommonUtil.isNotNull(rfaUploadTemplateField) && rfaUploadTemplateField.getRule().equals(RFAConstants.RULES_PARTYB_TRUE_LEGAL_NAME))
				rfaBulkUploadedData.setPartyBTrueLegalName(partyBTrueLegalName);
			rfaUploadTemplateField = RFABulkUploadUtil.getRFAUploadTemplateField(
					rfaBulkUploadRow.getRfaUploadTemplate(), RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD);
			if (CommonUtil.isNotNull(rfaUploadTemplateField) && rfaUploadTemplateField.getRule().equals(RFAConstants.RULES_SLEEVE_CLIENT_IDENTIFIER))
				rfaBulkUploadedData.setSleeveClientIdentifier(sleeveClientIdentifier);
			rfaUploadTemplateField = RFABulkUploadUtil.getRFAUploadTemplateField(
					rfaBulkUploadRow.getRfaUploadTemplate(), RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD);
			if (CommonUtil.isNotNull(rfaUploadTemplateField) && rfaUploadTemplateField.getRule().equals(RFAConstants.RULES_SLEEVE_TRUE_LEGAL_NAMES))
				rfaBulkUploadedData.setSleeveTrueLegalName(sleeveTrueLegalName);

			paramSourceTF.add(new BeanPropertySqlParameterSource(rfaBulkUploadedData));
		
		namedParameterJdbcTemplate.batchUpdate(SAVE_BULK_UPLOADED_DATA,
				paramSourceTF.toArray(new SqlParameterSource[paramSourceTF.size()]));

	}

	@Override
	public void updateBulkRequest(Long bulkRequestId, String status) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("bulkUploadStatus", status)
				.addValue("bulkRequestId", bulkRequestId);
				
		namedParameterJdbcTemplate.update(UPDATE_BULK_REQUEST, params);
	}

	@Override
	public Entity getMasterlistEntity(Long partyBEntityId, Long masterAgreementId) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("master_agreement_id", masterAgreementId)
				.addValue("entity_id", partyBEntityId);
		Entity masterlistEntity = namedParameterJdbcTemplate.queryForObject(GET_MASTERLIST_ENTITY, params,
				new EntityRowMapper());
		return masterlistEntity;
	}
	
	@Override
	public List<Long> getWetSignData(Long amendmentId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentId", amendmentId);
		try {
			return namedParameterJdbcTemplate.queryForList(GET_ALL_WET_SIGN_BY_RFA_ID, paramSource, Long.class);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}

	}
	
	@Override
	public Long getLatestESignData(Long amendmentId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentId", amendmentId);
		try {
			return namedParameterJdbcTemplate.queryForObject(GET_LATEST_E_SIGN_BY_RFA_ID, paramSource, Long.class);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public void addTransitionLogs(Long userId, String ipAddress, Long amendmentLetterId, Long downloadId, String eventName,Long fileId,Long uploadedFileId,int noOfPages,String reason) {
		MapSqlParameterSource params = new MapSqlParameterSource()
		.addValue("RFA_AMENDMENT_ID", amendmentLetterId)
		.addValue("TRANSITION_BY", userId)
		.addValue("IP_ADDRESS", ipAddress)
		.addValue("EVENT_NAME", eventName)
		.addValue("DOWNLOAD_ID", downloadId)
		.addValue("FILE_ID", fileId)
		.addValue("uploadedFileId", uploadedFileId)
		.addValue("noOfPages", noOfPages)
		.addValue("reason", reason);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		namedParameterJdbcTemplate.update(ADD_TRANSITION_LOG, params, keyHolder);
		
	}

	@Override
	public Long getUploadedFile(Long amendmentLetterId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentId", amendmentLetterId);
		try {
			return namedParameterJdbcTemplate.queryForObject(GET_LATEST_W_SIGN_BY_RFA_ID, paramSource, Long.class);
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public Map<Long, AmendmentSignData> getSignCountData(Long companyId, List<Long> rfaIds, String companyType) {
		Map<Long, AmendmentSignData> signatureCountMetadata = null;
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("companyId", companyId).addValue("rfaIds",
				rfaIds);
		if (CommonUtil.isEqual(companyType, "BS"))
			signatureCountMetadata = namedParameterJdbcTemplate.query(GET_SIGN_COUNT_BS, params,
					new RFASignatureCountRowExtractor());
		else
			signatureCountMetadata = namedParameterJdbcTemplate.query(GET_SIGN_COUNT_SS, params,
					new RFASignatureCountRowExtractor());
		return signatureCountMetadata;

	}

	@Override
	public Map<Long, AmendmentSignData> getSignHoverData(Long companyId, List<Long> rfaIds, String companyType) {
		Map<Long, AmendmentSignData> signatureHoverMetadata = null;
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("companyId", companyId).addValue("rfaIds",
				rfaIds);
		if (CommonUtil.isEqual(companyType, "BS"))
			signatureHoverMetadata = namedParameterJdbcTemplate.query(GET_SIGN_HOVER_DATA_BS, params,
					new RFASignatureHoverRowExtractor());
		else
			signatureHoverMetadata = namedParameterJdbcTemplate.query(GET_SIGN_HOVER_DATA_SS, params,
					new RFASignatureHoverRowExtractor());
		return signatureHoverMetadata;

	}

	@Override
	public Long getNextAvailableDownloadId() {
		
		Long downloadId = selectNextAvailableDownloadId.executeQuery(new HashMap<>());
		return downloadId;
		
		
	}

	@Override
	public void addDownloadTransitionLogs(List<AmendmentDownloadTransitionLog> amendmentDownloadTransitionLogs) {
		Map<String, Object>[] paramList = new Map[amendmentDownloadTransitionLogs.size()];
		for (int index = 0; index < paramList.length; index++) {
			paramList[index] = Maps.newHashMap();
			AmendmentDownloadTransitionLog signature = amendmentDownloadTransitionLogs.get(index);
			paramList[index].put("amendmentId", signature.getAmendmentId());
			paramList[index].put("downloadId", signature.getDownloadId());
			paramList[index].put("eventName", signature.getEventName());
			paramList[index].put("fileId", signature.getFileId());
			paramList[index].put("ipAddress", signature.getIpAddress());
			paramList[index].put("noOfPages", signature.getNoOfPages());
			paramList[index].put("userId", signature.getUserId());
			paramList[index].put("docId", signature.getDocId());
		}
		if(paramList!=null)
			jdbcTemplate.batchUpdate(ADD_RFA_DOWNLOAD_TRANSITION_LOG, paramList);
	}

	@Override
	public void updatNotifiedByfor(List<Long> rfaIds, Long notifiedByUserId) {
		
		MapSqlParameterSource params = new MapSqlParameterSource()
		.addValue("notifiedBy", notifiedByUserId)
		.addValue("rfaIds", rfaIds);
		namedParameterJdbcTemplate.update(UPDATE_NOTIFIED_BY_FOR_ALL_RFAIDS, params);
		
		
	}

	@Override
	public String getNextAvailableDocId(Long amendmentId) {
		MapSqlParameterSource params = new MapSqlParameterSource()
	    	    .addValue("rfaId", amendmentId);
		String docId = namedParameterJdbcTemplate.queryForObject(FETCH_NEXT_AVAILABLE_DOC_ID, params, String.class);
		return docId;
	}
	
	
	@Override
	public void updateStatus(String status, Long amendmentId, String companyType) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("id", amendmentId).addValue("status",
				status);
		if (companyType.equals(RFAConstants.COMPANY_TYPE_BS))
			namedParameterJdbcTemplate.update(BS_UPDATE_RFA_STATUS, params);
		else
			namedParameterJdbcTemplate.update(SS_UPDATE_RFA_STATUS, params);

	}
	
	/**
	 * @return
	 * all statuses based on partyb action selected by user 
	 */
	private List<String> getPartyBActionedList(List<String> partyBActionedSelected, CompanyType companyType) {
		List<String> partyBAckStatusList = null;

		if (CollectionUtils.isNotEmpty(partyBActionedSelected)) {

			partyBAckStatusList = new ArrayList<>();
			for (int i = 0; i < partyBActionedSelected.size(); i++) {

				if (partyBActionedSelected.get(i).equalsIgnoreCase(PartyBAckStatus.REJECTED.getName())) {
					partyBAckStatusList.add(PartyBAckStatus.REJECTED.getName());
					partyBAckStatusList.add(PartyBAckStatus.REJECTED_SENT.getName());
				} else if (partyBActionedSelected.get(i).equalsIgnoreCase(PartyBAckStatus.ACCEPTED.getName())) {
					partyBAckStatusList.add(PartyBAckStatus.ACCEPTED_SENT.getName());

					if (companyType.equals(CompanyType.SS)) {
						partyBAckStatusList.add(PartyBAckStatus.ACCEPTED.getName());
						partyBAckStatusList.add(PartyBAckStatus.ACCEPTED_SIGNED.getName());
					}

				} else {
					partyBAckStatusList.add(partyBActionedSelected.get(i));
				}
			}
		}

		return partyBAckStatusList;
	}

	@Override
	public void updateChangesCount(Long amendmentId, int changeCount, String source) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("amendmentId", amendmentId)
				.addValue("changeCount", changeCount);
		if (CommonUtil.isEqual(source, "EXHIBIT")) {
			namedParameterJdbcTemplate.update(UPDATE_RFA_EXHIBIT_CHANGES_COUNT, params);
		} else if (CommonUtil.isEqual(source, "LETTER")) {
			namedParameterJdbcTemplate.update(UPDATE_RFA_LETTER_CHANGES_COUNT, params);
		}
	}

	@Override
	public void updateChangesRespondedCount(Long amendmentId, int respondedCount) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("amendmentId", amendmentId)
				.addValue("respondedCount",respondedCount);
			namedParameterJdbcTemplate.update(UPDATE_RFA_CHANGES_RESPONDED_COUNT, params);
		
	}

	@Override
	public void updateCommentsCount(int totalComments, Long amendmentId, String source, String partyType) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("amendmentId", amendmentId)
				.addValue("totalComments",totalComments);
		if(CommonUtil.isEqual(partyType, "SS") && CommonUtil.isEqual(source, "LETTER")) {
			namedParameterJdbcTemplate.update(UPDATE_RFA_SS_COMMENTS_COUNT, params);
		} else if (CommonUtil.isEqual(source, "EXHIBIT")) {
			namedParameterJdbcTemplate.update(UPDATE_RFA_EXHIBIT_COMMENTS_COUNT, params);
		} else if (CommonUtil.isEqual(source, "LETTER")) {
			namedParameterJdbcTemplate.update(UPDATE_RFA_LETTER_COMMENTS_COUNT, params);
		}
	}

	@Override
	public void updateResolvedCommentsCount(int resolvedCommentsCount, Long amendmentId) {
		MapSqlParameterSource params = new MapSqlParameterSource().addValue("amendmentId", amendmentId)
				.addValue("resolvedCommentsCount",resolvedCommentsCount);
			namedParameterJdbcTemplate.update(UPDATE_RFA_RESOLVED_COMMENTS_COUNT, params);
	}

}