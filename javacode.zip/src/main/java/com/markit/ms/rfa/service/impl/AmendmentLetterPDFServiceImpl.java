package com.markit.ms.rfa.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.markit.ms.common.model.CommonFileResponse;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFASystemException;
import com.markit.ms.rfa.service.IAmendmentLettterPDFService;
@Service
public class AmendmentLetterPDFServiceImpl implements IAmendmentLettterPDFService {
	
	@Autowired
	IAmendmentLetterDao amendmentLetterDAO;
	
	@Autowired
	IFileService fileService;
	
	@Autowired
	IReportGenerator reportGenerator;
	
	@Override
	@Transactional
	public CommonFileResponse generateErrorPDF(Long companyId, Map<String, List<PartyBEntity>> addPartyBErrorMap
			, Map<String, List<PartyBEntity>> removePartyBErrorMap, Map<String, List<PartyBEntity>> modifiedPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveRequestedOnAnotherRfaErrorMap, Map<String, List<PartyBEntity>> sleeveRemovalPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveExistsOnActiveTabErrorMap, Map<String, List<PartyBEntity>> sleeveParentNotOnActiveTabErrorMap
			, Map<String, List<PartyBEntity>> sleevesInProgressErrorMap
			, List<PartyBEntity> rejectedRecalledPartybList, Map<Long, AmendmentLetter> additionPlaceholderErrorMap
			, Map<Long, AmendmentLetter> removalPlaceholderErrorMap, Map<Long, AmendmentLetter> modificationPlaceholderErrorMap
			, Map<String, String> letterTemplateMap, Long userId) throws Exception {
		try{
			byte[] pdfContent = reportGenerator.getValidationErrorPDFContent(addPartyBErrorMap, removePartyBErrorMap
					, modifiedPartyBErrorMap, sleeveRequestedOnAnotherRfaErrorMap, sleeveRemovalPartyBErrorMap 
					, sleeveExistsOnActiveTabErrorMap, sleeveParentNotOnActiveTabErrorMap, sleevesInProgressErrorMap,rejectedRecalledPartybList 
					, additionPlaceholderErrorMap, removalPlaceholderErrorMap, modificationPlaceholderErrorMap, letterTemplateMap);
			Long fileId = fileService.saveFile(pdfContent, companyId, "amendmentValidationError", userId).getFileId();
			CommonFileResponse commonFileResponse = new CommonFileResponse();
			commonFileResponse.setFileId(fileId);
			commonFileResponse.setFileType("pdf");
			return commonFileResponse;
		} catch (RFASystemException e){
			e.printStackTrace();
			throw new RFAException();
		}
	}
}
