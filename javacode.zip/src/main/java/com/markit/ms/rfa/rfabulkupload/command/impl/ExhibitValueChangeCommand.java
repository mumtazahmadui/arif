package com.markit.ms.rfa.rfabulkupload.command.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.common.dao.IRfaLookupDao;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.ActionCommand;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Component
public class ExhibitValueChangeCommand implements ActionCommand {

	@Autowired
	private CommonValidator commonValidator;

	@Autowired
	private IRfaLookupDao rfaLookupDao;

	public void execute(RfaBulkUploadRow rfaBulkUploadRow, ActionChain nextChain) {
		
		boolean entityExistsForInFlightRfa = commonValidator.checkIfEntityExistingInAnotherRfa(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false, RFAConstants.EVC);

		if (entityExistsForInFlightRfa) {
			rfaBulkUploadRow.setPartyBExistsInAnotherRfa(entityExistsForInFlightRfa);
			return;
		}

		boolean entityExistsInMasterlist = commonValidator.checkIfEntityExistInMasterList(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false);
//TODO: Need to discuss this condition
		if (!entityExistsInMasterlist && rfaBulkUploadRow.getRequestIdentified().size() == 0) {
			Map<String, String> placeHolderMap = new HashMap<String, String>();
			placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());
			placeHolderMap.put("requestType", "EVC");
			rfaBulkUploadRow.addError(RFAConstants.PARTYB_DOESNT_EXIST_IN_MASTERLIST, placeHolderMap);
		}

		if (entityExistsInMasterlist && !entityExistsForInFlightRfa)
			checkForExhibitValueChange(rfaBulkUploadRow);

	}

	protected void checkForExhibitValueChange(RfaBulkUploadRow rfaBulkUploadRow) {

		if (CommonUtil.isNotNull(rfaBulkUploadRow.getExhibitData()) && !rfaBulkUploadRow.getExhibitData().isEmpty()) {

			Map<String, String> existingExhibit = rfaLookupDao.getExhibitByPartBAndML(
					rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId());

			if (!existingExhibit.isEmpty())
				compareExhibits(existingExhibit, rfaBulkUploadRow);
			else
				rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.EVC);

		}

	}

	protected void compareExhibits(Map<String, String> existingExhibit, RfaBulkUploadRow rfaBulkUploadRow) {

		for (String colName : existingExhibit.keySet()) {

			if (CommonUtil.isNotEqual(rfaBulkUploadRow.getExhibitData().get(colName), existingExhibit.get(colName))) {
				rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.EVC);
				break;

			}
		}
	}

}
