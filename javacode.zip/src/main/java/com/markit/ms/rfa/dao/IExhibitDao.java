package com.markit.ms.rfa.dao;

import com.markit.ms.rfa.bean.Exhibit;

public interface IExhibitDao {
	public Exhibit getExhibitById(Long exhibitId);
	public Exhibit createExhibit(Exhibit exhibit);
	public Exhibit updateExhibit(Exhibit exhibit);
}
