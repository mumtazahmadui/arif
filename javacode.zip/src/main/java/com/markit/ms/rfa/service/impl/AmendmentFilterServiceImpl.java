package com.markit.ms.rfa.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.dao.IAmendmentFilterDao;
import com.markit.ms.rfa.service.IAmendmentFilterService;

@Service
public class AmendmentFilterServiceImpl implements IAmendmentFilterService {

	@Autowired
	private IAmendmentFilterDao filterDao;
	
	@Override
	public List<String> getAgreementDate(long companyid, String filterString) {
		List<String> filteredDates = filterDao.getAgreementDate(companyid, filterString);
		return filteredDates;
	}

	@Override
	public List<Lookup> getInvestmentManager(long companyid, String filterString, String companyType) {
		List<Lookup> filteredInvestManagers = filterDao.getInvestmentManager(companyid, filterString, companyType);
		return filteredInvestManagers;
	}
	
	@Override
	public List<String> getMasterlistIdentifier(Long companyId, String filterString, String companyType) {
		List<String> filteredMasterlistIdentifiers = filterDao.getMasterlistIdentifier(companyId, filterString, companyType);
		return filteredMasterlistIdentifiers;
	}

	@Override
	public List<Lookup> getPartyA(long companyid, String filterString) {
		List<Lookup> filteredPartyAs = filterDao.getPartyA(companyid, filterString);
		return filteredPartyAs;
	}

	@Override
	public List<Lookup> getPartyB(long companyid, String filterString, String companyType) {
		List<Lookup> filteredPartyBs = filterDao.getPartyB(companyid, filterString, companyType);
		return filteredPartyBs;
	}

	@Override
	public List<String> getAdditionAction(String filterString) {
		
		List<String> additionActions = new ArrayList<String>();
		additionActions.add("Rejected");
		additionActions.add("Pending");
		additionActions.add("Accepted");
		additionActions.add("Withdrawn");
		
		return additionActions;
	}
	
	@Override
	public List<String> getRequestStatus(String filterString) {
		
		List<String> requestStatuses = new ArrayList<String>();
		requestStatuses.add("Draft");
		requestStatuses.add("Submitted");
		requestStatuses.add("Partially Completed");
		requestStatuses.add("Completed");
		requestStatuses.add("Recalled");
		requestStatuses.add("Rejected");
		requestStatuses.add("Deleted");
		
		return requestStatuses;
	}

	@Override
	public List<String> getSellsideRequestStatus(String filterString) {
		List<String> requestStatuses = new ArrayList<String>();
		requestStatuses.add("Received");
		requestStatuses.add("Partially Completed");
		requestStatuses.add("Completed");
		requestStatuses.add("Recalled");
		requestStatuses.add("Rejected");
		requestStatuses.add("Deleted");
		
		return requestStatuses;
	}

	@Override
	public List<Lookup> getReviewStatus(String filterString) {
		List<Lookup> reviewStatus = filterDao.getReviewStatus(filterString);
		return reviewStatus;
	}

	@Override
	public List<String> getPartyBClientIdentifier(long companyid, String filterString, String companyType) {
		List<String> filteredPartyBsClientIdentifier = filterDao.getPartyBClientIdentifier(companyid, filterString, companyType);
		return filteredPartyBsClientIdentifier;
	}

	@Override
	public List<String>  getSubmitdate(long companyid, String filterString) {
		List<String>  filteredSubmitDate = filterDao.getSubmitDate(companyid, filterString);
		return filteredSubmitDate;
	}

	@Override
	public List<Long> getRfaId(Long companyId, String filterString, String companyType, String amendmentStatus) {
		return filterDao.getRfaId(companyId, filterString, companyType, amendmentStatus);
	}
	
	public List<String> getAgreementType(Long companyId, String filterString, String companyType) {
		return filterDao.getAgreementType(companyId, filterString, companyType);
	}

	@Override
	public List<String> getPartyBLei(Long companyId, String filterString, String companyType) {
		return filterDao.getPartyBLei(companyId, filterString, companyType);
	}

	@Override
	public List<Lookup> getMyStatus(String filterString, String companyType) {
		return filterDao.getMyStatus(filterString, companyType);
	}
	
}
