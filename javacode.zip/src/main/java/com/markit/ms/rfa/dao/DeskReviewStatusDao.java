package com.markit.ms.rfa.dao;

import com.markit.ms.rfa.bean.PartyBDeskReviewData;

/**
 * This class provides dao operation methods for Amendment Letter PartyB's desk
 * statuses
 * 
 * @since RFA5.0
 *
 */
public interface DeskReviewStatusDao {

	/**
	 * inserts desk status details for partyB
	 * 
	 * @param deskReviewData
	 */
	void insert(PartyBDeskReviewData deskReviewData);

	/**
	 * updates desk status details for partyB
	 * 
	 * @param deskReviewData
	 */
	void update(PartyBDeskReviewData deskReviewData);

	/**
	 * inserts or updates desk status details for partyB
	 * 
	 * @param deskReviewData
	 */
	void insertOrUpdate(PartyBDeskReviewData deskReviewData);

	/**
	 * gets desk type based on desk code if valid role for respective desk is
	 * assigned to user
	 * 
	 * @param deskCode desk code for each checkbox
	 * @param userId   user id
	 * @return desk type value
	 */
	String getDeskType(String deskCode, Long userId);
}
