package com.markit.ms.rfa.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseRequest;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.service.ISignatureService;
import com.wordnik.swagger.annotations.Api;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.kyc.esign.util.SignatureGenerator;

@RestController
@RequestMapping("/v1/signature")
@Api(value = "Signature", description = "Signature API")
public class SignatureController {

	@Autowired
	ISignatureService signatureService;
	@Resource
	private SignatureGenerator signatureGenerator;
	
	public static final String CONTENT_TYPE_PNG = "image/png";
	
	/*@RequestMapping(method = RequestMethod.POST)
	public CommonBaseResponse<Signature> saveSignature(@RequestBody CommonBaseRequest<Signature> signatureRequest){
		CommonBaseResponse<Signature> commonBaseResponse = new CommonBaseResponse<Signature>();
		Signature signature = signatureService.saveSignature(signatureRequest.getData(),30000000001837L,"ABC");
		commonBaseResponse.setData(signature);
		return commonBaseResponse;
	}*/
	@RequestMapping(method = RequestMethod.GET, value = "/image")
	public @ResponseBody void getSignatureImage( @RequestParam(required=false) String signatureStamp, 
												 @RequestParam String certifierName, 
												  @RequestParam(required=false) String title, 
												  @RequestParam(required=false) String emailId, 
	                                              @RequestParam Integer signatureStyle,
	                                              HttpServletRequest request,
	                                              HttpServletResponse response) {

	    byte[] signatureImage = signatureGenerator.generateSignatureImage(signatureStamp, certifierName, certifierName, title, emailId, signatureStyle, null); 
	    WebUtils.write2Response(response, signatureImage, CONTENT_TYPE_PNG, "signature.png");

	  }
	
}
