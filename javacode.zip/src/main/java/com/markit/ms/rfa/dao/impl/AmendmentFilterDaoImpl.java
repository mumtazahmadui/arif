package com.markit.ms.rfa.dao.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.dao.IAmendmentFilterDao;
import com.markit.ms.rfa.dao.resultsetextractor.AgreementDateResultSetExtractor;
import com.markit.ms.rfa.dao.resultsetextractor.EntityResultSetExtractor;
import com.markit.ms.rfa.dao.resultsetextractor.PartyAResultSetExtractor;
import com.markit.ms.rfa.dao.resultsetextractor.ReviewResultSetExtractor;
import com.markit.ms.rfa.dao.rowmapper.CompanyTypeRowMapper;

@Repository
public class AmendmentFilterDaoImpl extends BaseDAOImpl implements IAmendmentFilterDao {

    @Value("${GET_AMENDMENT_DATE_FILTER}")
    private String GET_AMENDMENT_DATE_FILTER;
    
    @Value("${GET_INVEST_MANAGER_FILTER}")
    private String GET_INVEST_MANAGER_FILTER;
    
    @Value("${GET_MASTERLIST_IDENTIFIER_FILTER}")
    private String GET_MASTERLIST_IDENTIFIER_FILTER;

    @Value("${GET_PARTY_A_FILTER}")
    private String GET_PARTY_A_FILTER;
    
    @Value("${GET_PARTY_B_FILTER}")
    private String GET_PARTY_B_FILTER;
    
    @Value("${GET_ADDITION_ACTION_FILTER}")
    private String GET_ADDITION_ACTION_FILTER;
    
    @Value("${GET_REQUEST_STATUS_FILTER}")
    private String GET_REQUEST_STATUS_FILTER;
	
    @Value("${GET_COMPANY_TYPE}")
    private String GET_COMPANY_TYPE;
    
    @Value("${GET_REVIEW_FILTER}")
    private String GET_REVIEW_FILTER;
    
    @Value("${GET_PARTY_B_CLIENT_IDENTIFIER_FILTER}")
    private String GET_PARTY_B_CLIENT_IDENTIFIER_FILTER;
    
    @Value("${GET_PARTY_B_LEI_FILTER}")
    private String GET_PARTY_B_LEI_FILTER;
    
    @Value("${GET_SUBMIT_DATE_FILTER}")
    private String GET_SUBMIT_DATE_FILTER;
  
    @Value("${GET_RFA_ID_FILTER}")
    private String GET_RFA_ID_FILTER;
    
    @Value("${GET_AGREEMENT_TYPE_FILTER}")
    private String GET_AGREEMENT_TYPE_FILTER;
    
    @Value("${GET_MY_STATUS}")
    private String GET_MY_STATUS;
    
    
	@Override
	public List<String> getAgreementDate(Long companyid, String filterString) {
		if (filterString == null) filterString = "";
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyid);
		
		String type = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, paramSource, new CompanyTypeRowMapper());
		CompanyType companyType = CompanyType.fromString(type);
		String where = conditionalWhere(companyType);
		String query = GET_AMENDMENT_DATE_FILTER.replace("#where", where);
		DateFormat formatter  = new SimpleDateFormat("dd-MMM-yyyy");
		List<Date> dates = namedParameterJdbcTemplate.query(query, paramSource, new AgreementDateResultSetExtractor());		
		List<String> filteredDates = new ArrayList<String>();
		String currentDate;
		for (Date date : dates){
			currentDate = formatter.format(date);
			if(currentDate.contains(filterString) && !filteredDates.contains(currentDate)){
				filteredDates.add(currentDate);
			}
		}		
		return filteredDates;
	}

	@Override
	public List<Lookup> getInvestmentManager(Long companyid, String filterString, String companyType) {
		if (filterString == null) filterString = "";
		CompanyType companyTypeObj = CompanyType.fromString(companyType);
		String where = conditionalWhere(companyTypeObj);
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyid)
			.addValue("im_legal_name", "%" +filterString + "%")
			.addValue("is_bs_company", companyTypeObj.equals(CompanyType.BS) ? 1 : 0);
		String query = GET_INVEST_MANAGER_FILTER.replace("#where", where);
		List<Entity> entities = namedParameterJdbcTemplate.query(query, paramSource, new EntityResultSetExtractor());
		List<Lookup> investManagerNames = new ArrayList<Lookup>();
		for (Entity entity : entities){
			Lookup entry = new Lookup();
			entry.setId(entity.getId());
			entry.setValue(entity.getName());
			investManagerNames.add(entry);
		}
		
		return investManagerNames;
	}
	
	@Override
	public List<String> getMasterlistIdentifier(Long companyId, String filterString, String companyType) {
		StringBuilder whereCondition = new StringBuilder();
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("filterString", "%"+filterString+"%");
		if(CompanyType.isSSCompany(companyType)) {
			paramSource.addValue("is_bs_company", 0);
			whereCondition.append(" and e2.companyid=:companyid");
		} else {
			paramSource.addValue("is_bs_company", 1);
			whereCondition.append(" and e1.companyid=:companyid");
		}
		String query = GET_MASTERLIST_IDENTIFIER_FILTER.replaceAll("whereCondition", whereCondition.toString());
		
		List<String> lookupList = namedParameterJdbcTemplate.queryForList(query, paramSource, String.class);
    	return lookupList;
	}

	@Override
	public List<Lookup> getPartyA(Long companyid, String filterString) {
		if (filterString == null) filterString = "";
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyid)
		.addValue("party_a_name", "%"+ filterString + "%");
	
		List<Entity> entityList = namedParameterJdbcTemplate.query(GET_PARTY_A_FILTER, paramSource, new PartyAResultSetExtractor());
		List<Lookup> partyANames = new ArrayList<Lookup>();
		for (Entity entity : entityList){
			Lookup entry = new Lookup();
			entry.setId(entity.getId());
			entry.setValue(entity.getName());
			partyANames.add(entry);
		}
		return partyANames;
	}

	@Override
	public List<Lookup> getPartyB(Long companyid, String filterString, String companyType) {
		if (filterString == null) filterString = "";
		CompanyType companyTypeObj = CompanyType.fromString(companyType);
		String where = conditionalWhere(companyTypeObj);
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyid)
		.addValue("partyb_name", "%" +filterString + "%")
		.addValue("is_bs_company", companyTypeObj.equals(CompanyType.BS) ? 1 : 0);
		String query = GET_PARTY_B_FILTER.replace("#where", where);
		List<Entity> entities = namedParameterJdbcTemplate.query(query, paramSource, new EntityResultSetExtractor());
		List<Lookup> partyBNames = new ArrayList<Lookup>();
		for(Entity entity : entities){
			Lookup entry = new Lookup();
			entry.setId(entity.getId());
			entry.setValue(entity.getName());
			partyBNames.add(entry);
		}
		return partyBNames;
	}

	@Override
	public List<Lookup> getReviewStatus(String filterString) {
		if (filterString == null) filterString = "";
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("name", "%"+ filterString + "%");
	
		List<Lookup> lookUpList = namedParameterJdbcTemplate.query(GET_REVIEW_FILTER, paramSource, new ReviewResultSetExtractor());
		return lookUpList;
	}

	private String conditionalWhere(CompanyType companyType) {
		String where = "";
		
		if (companyType == CompanyType.BS){
			where = " and e.companyId=:companyid ";
		}
		else {
			where = " and pa.companyId=:companyid";
		}
		return where;
	}

	@Override
	public List<String> getPartyBClientIdentifier(Long companyid, String filterString, String companyType) {
		if (filterString == null) filterString = "";
		CompanyType companyTypeObj = CompanyType.fromString(companyType);
		String where = conditionalWhere(companyTypeObj);
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyid)
		.addValue("partyb_client_identifier", "%" +filterString + "%")
		.addValue("is_bs_company", companyTypeObj.equals(CompanyType.BS) ? 1 : 0);
		String query = GET_PARTY_B_CLIENT_IDENTIFIER_FILTER.replace("#where", where);
		List<String> partyBClientIdentifiers = namedParameterJdbcTemplate.queryForList(query, paramSource, String.class);
		/*List<String> partyBClientIdentifiers = new ArrayList<String>();
		for(Entity entity : entities){
			Lookup entry = new Lookup();
			entry.setId(entity.getId());
			entry.setValue(entity.getClientIdentifier());
			partyBClientIdentifiers.add(entry);
		}*/
		return partyBClientIdentifiers;
	}

	@Override
	public List<String> getSubmitDate(Long companyid, String filterString) {
		if (filterString == null) filterString = "";
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyId", + companyid )
		.addValue("date", "%"+ filterString + "%");
	
		List<String> lookUpList = namedParameterJdbcTemplate.queryForList(GET_SUBMIT_DATE_FILTER, paramSource, String.class);
		return lookUpList;
	}

	@Override
	public List<String> getPartyBLei(Long companyid, String filterString, String companyType) {
		if (filterString == null) filterString = "";
		CompanyType companyTypeObj = CompanyType.fromString(companyType);
		String where = conditionalWhere(companyTypeObj);
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyid)
		.addValue("partyb_lei", "%" +filterString + "%")
		.addValue("is_bs_company", companyTypeObj.equals(CompanyType.BS) ? 1 : 0);
		String partyBDetailsView = companyTypeObj.equals(CompanyType.SS) ? "V_RFA_PARTYB_DETAILS_SS":"V_RFA_PARTYB_DETAILS";
		String query = GET_PARTY_B_LEI_FILTER.replace("#where", where).replace("#VIEW_RFA_PARTYB_DETAILS", partyBDetailsView);
		List<String> partyBClientIdentifiers = namedParameterJdbcTemplate.queryForList(query, paramSource, String.class);
		return partyBClientIdentifiers;
	}

	@Override
	public List<Long> getRfaId(Long companyId, String filterString, String companyType, String amendmentStatus) {
		if (filterString == null) filterString = "";
		CompanyType companyTypeObj = CompanyType.fromString(companyType);
		String where = conditionalWhere(companyTypeObj);
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyId)
		.addValue("amendmentId", "%" +filterString + "%")
		.addValue("is_bs_company", companyTypeObj.equals(CompanyType.BS) ? 1 : 0);
		String query = GET_RFA_ID_FILTER.replace("#where", where);
		List<Long> rfaIds = namedParameterJdbcTemplate.queryForList(query, paramSource, Long.class);
		return rfaIds;
	}

	@Override
	public List<String> getAgreementType(Long companyId, String filterString, String companyType) {
		if (filterString == null) filterString = "";
		CompanyType companyTypeObj = CompanyType.fromString(companyType);
		String where = conditionalWhere(companyTypeObj);
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyId)
		.addValue("filterString", "%" +filterString + "%")
		.addValue("is_bs_company", companyTypeObj.equals(CompanyType.BS) ? 1 : 0);
		String query = GET_AGREEMENT_TYPE_FILTER.replace("#where", where);
		List<String> agreementTypes = namedParameterJdbcTemplate.queryForList(query, paramSource, String.class);
		return agreementTypes;
	}

	@Override
	public List<Lookup> getMyStatus(String filterString, String companyType) {
		if (filterString == null) filterString = "";
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("filterString", "%" + filterString + "%")
				.addValue("companyType", companyType);
		List<Lookup> myStatusList = namedParameterJdbcTemplate.query(GET_MY_STATUS, paramSource, (rs,rownum)->{
			Lookup lookup = new Lookup();
			lookup.setId(rs.getLong("id"));
			lookup.setCode(rs.getString("code"));
			lookup.setValue(rs.getString("value"));
			return lookup;
		}); 
		return myStatusList;
	}
	
	
	
}
