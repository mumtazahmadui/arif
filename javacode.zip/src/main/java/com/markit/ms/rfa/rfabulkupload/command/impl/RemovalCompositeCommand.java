package com.markit.ms.rfa.rfabulkupload.command.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.ActionCommand;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.RFAConstants;

@Component
public class RemovalCompositeCommand implements ActionCommand {

	@Autowired
	CommonValidator commonValidator;

	@Autowired
	SleeveRemoval sleeveRemoval;
	
	@Autowired
	IRfaUploadTemplateDAO rfaUploadTemplate;
	
	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	@Override
	public void execute(RfaBulkUploadRow rfaBulkUploadRow, ActionChain nextChain) {
		Boolean partyBExistsInRFA = commonValidator.checkIfEntityExistingInAnotherRfa(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false, null);
			if (partyBExistsInRFA) {
				rfaBulkUploadRow.setPartyBExistsInAnotherRfa(partyBExistsInRFA);
				return;
			}
		
		List<Long> listSleeveEntities = rfaUploadTemplate.getListSleeveEntities(rfaBulkUploadRow.getPartyBEntityId(),
				rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());

		for (Long sleeveEntityId : listSleeveEntities) {
			PartyBEntity existingPartyB = amendmentLetterService.isEntityExistingInAnotherRfa(sleeveEntityId,
					rfaBulkUploadRow.getMasterAgreementId(), null, null);

			Boolean entityExistsInRFA = commonValidator.checkIfExistingForInFlightAmendment(existingPartyB);
			if (entityExistsInRFA) {
				populatePartyBRemovaleErrors(rfaBulkUploadRow, RFAConstants.SLEEVE_IN_PROGRESS);
				break;
			}
		}

		Boolean parentEntityAlreadyPresentInML = commonValidator.checkIfEntityExistInMasterList(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false);

		Boolean entityExistsInRemoveTab = commonValidator.checkIfEntityExistingInRemovalTab(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId());

		if (entityExistsInRemoveTab && rfaBulkUploadRow.getRequestIdentified().size() == 0) {
			populatePartyBRemovaleErrors(rfaBulkUploadRow,RFAConstants.PARTYB_EXIST_IN_REMOVE_TAB_IN_MASTERLIST);
		} else if (!parentEntityAlreadyPresentInML && rfaBulkUploadRow.getRequestIdentified().size() == 0 && !entityExistsInRemoveTab) {
			populatePartyBRemovaleErrors(rfaBulkUploadRow,RFAConstants.PARTYB_DOESNT_EXIST_IN_MASTERLIST);
		}

		sleeveRemoval.process(rfaBulkUploadRow);

		// we need to ensure that if we are removing sleeve we dont remove party
		// B
		if (!rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.SLEEVE_REMOVAL)
				&& parentEntityAlreadyPresentInML && rfaBulkUploadRow.getRequestIdentified().size() == 0 && !entityExistsInRemoveTab) {
			rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.REMOVAL);
		}
	}
	private void populatePartyBRemovaleErrors(RfaBulkUploadRow rfaBulkUploadRow,String errorMessage){
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());
		placeHolderMap.put("requestType", "Removal");
		rfaBulkUploadRow.addError(errorMessage, placeHolderMap);
	}

}
