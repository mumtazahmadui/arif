package com.markit.ms.rfa.dto;


/*
 * 	This class allows us to pass back a JSON friendly
 *  list of key value pairs.
 */

public class KeyValueResponse {
	
	private Long key;
	private String value;
	
	public Long getKey() {
		return key;
	}
	public void setKey(Long key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
		
}
