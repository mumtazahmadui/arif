package com.markit.ms.rfa.bean;

public class FundNameChange {
	private Long id;
	private String oldLei;
	private String oldTrueLegalName;
	private String oldClientIdentifier;
	private String currentLei;
	private String currentTrueLegalName;
	private String currentClientIdentifier;
	private Boolean updateMcpmLei;
	private Boolean updateMcpmLegalName;
	private Boolean updateMcpmClientIdentifier;
	private String comment;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getOldLei() {
		return oldLei;
	}
	public void setOldLei(String oldLei) {
		this.oldLei = oldLei;
	}
	public String getOldTrueLegalName() {
		return oldTrueLegalName;
	}
	public void setOldTrueLegalName(String oldTrueLegalName) {
		this.oldTrueLegalName = oldTrueLegalName;
	}
	public String getOldClientIdentifier() {
		return oldClientIdentifier;
	}
	public void setOldClientIdentifier(String oldClientIdentifier) {
		this.oldClientIdentifier = oldClientIdentifier;
	}
	public String getCurrentLei() {
		return currentLei;
	}
	public void setCurrentLei(String currentLei) {
		this.currentLei = currentLei;
	}
	public String getCurrentTrueLegalName() {
		return currentTrueLegalName;
	}
	public void setCurrentTrueLegalName(String currentTrueLegalName) {
		this.currentTrueLegalName = currentTrueLegalName;
	}
	public String getCurrentClientIdentifier() {
		return currentClientIdentifier;
	}
	public void setCurrentClientIdentifier(String currentClientIdentifier) {
		this.currentClientIdentifier = currentClientIdentifier;
	}
	public Boolean getUpdateMcpmLei() {
		return updateMcpmLei;
	}
	public void setUpdateMcpmLei(Boolean updateMcpmLei) {
		this.updateMcpmLei = updateMcpmLei;
	}
	public Boolean getUpdateMcpmLegalName() {
		return updateMcpmLegalName;
	}
	public void setUpdateMcpmLegalName(Boolean updateMcpmLegalName) {
		this.updateMcpmLegalName = updateMcpmLegalName;
	}
	public Boolean getUpdateMcpmClientIdentifier() {
		return updateMcpmClientIdentifier;
	}
	public void setUpdateMcpmClientIdentifier(Boolean updateMcpmClientIdentifier) {
		this.updateMcpmClientIdentifier = updateMcpmClientIdentifier;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
}