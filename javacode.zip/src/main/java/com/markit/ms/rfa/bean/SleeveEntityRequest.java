package com.markit.ms.rfa.bean;

public class SleeveEntityRequest {

	private Long userId;
	private Long companyId;
	private String name;
	private String legalName;
	private String nameToUse;
	private String legalType;
	private String domicileCountryCd;
	private String parentEntity;
	private String parentLevelEntity;
	private Long parentEntityId;
	private String monikerName;
	private String entitySubtype;
	
    public String getEntitySubtype() {
		return entitySubtype;
	}

	public void setEntitySubtype(String entitySubtype) {
		this.entitySubtype = entitySubtype;
	}

	public String getMonikerName() {
		return monikerName;
	}

	public void setMonikerName(String monikerName) {
		this.monikerName = monikerName;
	}	
	
	public Long getParentEntityId() {
		return parentEntityId;
	}

	public void setParentEntityId(Long parentEntityId) {
		this.parentEntityId = parentEntityId;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public String getNameToUse() {
		return nameToUse;
	}

	public void setNameToUse(String nameToUse) {
		this.nameToUse = nameToUse;
	}

	public String getLegalType() {
		return legalType;
	}

	public void setLegalType(String legalType) {
		this.legalType = legalType;
	}

	public String getDomicileCountryCd() {
		return domicileCountryCd;
	}

	public void setDomicileCountryCd(String domicileCountryCd) {
		this.domicileCountryCd = domicileCountryCd;
	}

	public String getParentEntity() {
		return parentEntity;
	}

	public void setParentEntity(String parentEntity) {
		this.parentEntity = parentEntity;
	}

	public String getParentLevelEntity() {
		return parentLevelEntity;
	}

	public void setParentLevelEntity(String parentLevelEntity) {
		this.parentLevelEntity = parentLevelEntity;
	}

}
