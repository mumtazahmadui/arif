package com.markit.ms.rfa.dao;

import java.util.List;

public interface IRfaFileDao {
	
	public void saveRfaFile(Long fileId, String action, Long userId);

	public void saveRfaFileToAmendment(Long fileId, Long rfaId);

	public List<Long> getRfaIdByFileId(Long fileId);
}
