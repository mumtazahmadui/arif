package com.markit.ms.rfa.security;

import java.util.concurrent.Callable;

import com.markit.kyc.security.UserUtils;
import com.markit.ms.rfa.security.domain.McpmUser;

public class UserIdRetriever implements Callable<Object> {

	@Override
	public Object call() throws Exception {
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		McpmUser mcpmUser = mcpmUserxsDetails.getEffectiveUser();
		return mcpmUser.getId();
	}

}
