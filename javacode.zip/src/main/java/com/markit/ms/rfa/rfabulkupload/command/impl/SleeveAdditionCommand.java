package com.markit.ms.rfa.rfabulkupload.command.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.rfa.bean.MCPMClientIdentifier;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.ActionCommand;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Component
public class SleeveAdditionCommand implements ActionCommand {

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Autowired
	CommonValidator commonValidator;

	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	public void execute(RfaBulkUploadRow rfaBulkUploadRow, ActionChain nextChain) {

		if (CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveEntityId())) {

			Boolean sleeveExistsInRFA = commonValidator.checkIfEntityExistingInAnotherRfa(rfaBulkUploadRow,
					rfaBulkUploadRow.getSleeveEntityId(), rfaBulkUploadRow.getMasterAgreementId(), true, null);
			if (sleeveExistsInRFA) {
				rfaBulkUploadRow.setPartyBExistsInAnotherRfa(sleeveExistsInRFA);
				return;
			}
			Boolean sleeveAlreadyPresentInML = commonValidator.checkIfEntityExistInMasterList(rfaBulkUploadRow,
					rfaBulkUploadRow.getSleeveEntityId(), rfaBulkUploadRow.getMasterAgreementId(), true);

			PartyBEntity existingSleeve = amendmentLetterService.isEntityExistingInAnotherRfa(
					rfaBulkUploadRow.getSleeveEntityId(), rfaBulkUploadRow.getMasterAgreementId(), null);

			if (addingParentAsSleeve(existingSleeve)) {
				populateAlreadyInMasterlistError(rfaBulkUploadRow);
			}

			Boolean validSleeveParentRelation = commonValidator.validateParentSleeveRelation(rfaBulkUploadRow.getSleeveEntityId(), 
					rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());
			
			if (sleeveAlreadyPresentInML && !validSleeveParentRelation) {
				populateSleeveTaggedToAnotherParentError(rfaBulkUploadRow);
			}
			
			if (!sleeveExistsInRFA && !sleeveAlreadyPresentInML){
				rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.SLEEVE_ADDITION);
			}
		} else if (CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveTrueLegalName())
				|| CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveClientIdentifier())) {

			String sleeveIdentifier = rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel()
					.equals(rfaBulkUploadRow.getUploadTemplateField(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD).getFieldLabel())
							? rfaBulkUploadRow.getSleeveClientIdentifier()
							: rfaBulkUploadRow.getSleeveTrueLegalName();

			// Checking if entity with same clientIdentifier/legalName exists in MCPM
			MCPMClientIdentifier mcpmEntity = checkEntityBySleeveIdentifierInMcpm(sleeveIdentifier,
					rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());

			if (CommonUtil.isNotNull(mcpmEntity)) {

				String existingFieldInMCPM = null;
				if (CommonUtil.isEqual(mcpmEntity.getLegalName(), sleeveIdentifier)) {
					existingFieldInMCPM = RFAConstants.ENTITY_TRUE_LEGAL_NAME;
				} else if (CommonUtil.isEqual(mcpmEntity.getMonikerName(), sleeveIdentifier)) {
					existingFieldInMCPM = RFAConstants.CLIENT_IDENTIFIER;
				}
				Map<String, String> placeHolderMap = new HashMap<String, String>();
				placeHolderMap.put("existingFieldInMCPM", existingFieldInMCPM);
				placeHolderMap.put("fieldLabel", rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
				rfaBulkUploadRow.addError(RFAConstants.ANOTHER_ENTITY_EXISTS, placeHolderMap);
				return;
			} else {
				rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.SLEEVE_ADDITION);
			}
		}

	}

	private boolean addingParentAsSleeve(PartyBEntity existingSleeve) {
		if (CommonUtil.isNotNull(existingSleeve) && CommonUtil.isNotNull(existingSleeve.getIsAdded())
				&& existingSleeve.getIsAdded() && existingSleeve.getEntity().getIsSleeve() == 0) {
			return true;
		}
		return false;
	}

	private MCPMClientIdentifier checkEntityBySleeveIdentifierInMcpm(String sleeveClientIdentifier, Long companyId) {
		MCPMClientIdentifier mcpmClientIdentifier = uploadTemplateDAO
				.getEntityBySleeveIdentifier(sleeveClientIdentifier, companyId);
		return mcpmClientIdentifier;
	}

	private void populateAlreadyInMasterlistError(RfaBulkUploadRow rfaBulkUploadRow) {
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
		placeHolderMap.put("requestType", "Addition");
		rfaBulkUploadRow.addError(RFAConstants.ALREADY_IN_MASTERLIST, placeHolderMap);
	}
	
	private void populateSleeveTaggedToAnotherParentError(RfaBulkUploadRow rfaBulkUploadRow) {
		Map<String, String> placeHolderMap = new HashMap<String, String>();
		placeHolderMap.put("sleeveIdentifier", rfaBulkUploadRow.getSleeveIdentifierField().getFieldLabel());
		placeHolderMap.put("partybIdentifier", rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());			
		rfaBulkUploadRow.addError(RFAConstants.SLEEVE_TAGGED_TO_ANOTHER_PARENT, placeHolderMap);
	}
	
}
