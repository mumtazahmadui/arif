package com.markit.ms.rfa.rfabulkupload.factory.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.rfabulkupload.chain.impl.AdditionChain;
import com.markit.ms.rfa.rfabulkupload.factory.FactoryActionChain;

@Service
public class AdditionActionChain implements FactoryActionChain {

	@Autowired
	AdditionChain additionChain;
	
	@Override
	public void setChainAndProcess(RfaBulkUploadRow rfaBulkUploadRow) {
		additionChain.process(rfaBulkUploadRow);
	}
	
}
