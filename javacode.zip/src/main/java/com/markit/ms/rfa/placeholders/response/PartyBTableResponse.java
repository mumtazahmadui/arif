package com.markit.ms.rfa.placeholders.response;

import java.util.List;
import java.util.Map;

public class PartyBTableResponse {
private List<Map<String, String>> columns;
private List<Map<String, String>> rows;
private List<Map<String, String>> lineBreaks;
private List<Map<String, String>> previousLineBreaks;
private String placeHolderType;
public List<Map<String, String>> getColumns() {
	return columns;
}
public void setColumns(List<Map<String, String>> list) {
	this.columns = list;
}
public List<Map<String, String>> getRows() {
	return rows;
}
public void setRows(List<Map<String, String>> rows) {
	this.rows = rows;
}
public List<Map<String, String>> getLineBreaks() {
	return lineBreaks;
}
public void setLineBreaks(List<Map<String, String>> lineBreaks) {
	this.lineBreaks = lineBreaks;
}
public List<Map<String, String>> getPreviousLineBreaks() {
	return previousLineBreaks;
}
public void setPreviousLineBreaks(List<Map<String, String>> previousLineBreaks) {
	this.previousLineBreaks = previousLineBreaks;
}
public String getPlaceHolderType() {
	return placeHolderType;
}
public void setPlaceHolderType(String placeHolderType) {
	this.placeHolderType = placeHolderType;
}

}
