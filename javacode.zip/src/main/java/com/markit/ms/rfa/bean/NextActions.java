package com.markit.ms.rfa.bean;

public class NextActions {
	
	private Boolean viewHistory;
	private Boolean eSign;
	private Boolean editAmendment;
	private Boolean recallAmendment;
	private Boolean withdrawPartyB;
	private Boolean editLinkedExhibit;
	private Boolean linkExhibit;
	private Boolean responsePending;
	private Boolean editLinkedExhibitAction;
	private Boolean rejectRFA;
	private Boolean editRFA;
	private Boolean sendRFA;
	private Boolean responsePendingActions;
	
	private EsignHover esignHover;
	
	private Boolean documentLink;
	
	public NextActions(){
		viewHistory = false;
		eSign = false;
		editAmendment = false;
		recallAmendment = false;
		withdrawPartyB = false;
		editLinkedExhibit = false;
		linkExhibit = false;
		editLinkedExhibitAction = false;
		responsePending = false;
		rejectRFA = false;
		editRFA = false;
		sendRFA = false;
		responsePendingActions = false;
		documentLink=false;
	}
	
	public Boolean getDocumentLink() {
		return documentLink;
	}

	public void setDocumentLink(Boolean documentLink) {
		this.documentLink = documentLink;
	}

	public Boolean getViewHistory() {
		return viewHistory;
	}
	public void setViewHistory(Boolean viewHistory) {
		this.viewHistory = viewHistory;
	}
	public Boolean geteSign() {
		return eSign;
	}
	public void seteSign(Boolean eSign) {
		this.eSign = eSign;
	}
	public Boolean getEditAmendment() {
		return editAmendment;
	}
	public void setEditAmendment(Boolean editAmendment) {
		this.editAmendment = editAmendment;
	}
	public Boolean getRecallAmendment() {
		return recallAmendment;
	}
	public void setRecallAmendment(Boolean recallAmendment) {
		this.recallAmendment = recallAmendment;
	}
	public Boolean getWithdrawPartyB() {
		return withdrawPartyB;
	}
	public void setWithdrawPartyB(Boolean withdrawPartyB) {
		this.withdrawPartyB = withdrawPartyB;
	}
	public Boolean getEditLinkedExhibit() {
		return editLinkedExhibit;
	}
	public void setEditLinkedExhibit(Boolean editLinkedExhibit) {
		this.editLinkedExhibit = editLinkedExhibit;
	}
	public Boolean getLinkExhibit() {
		return linkExhibit;
	}
	public void setLinkExhibit(Boolean linkExhibit) {
		this.linkExhibit = linkExhibit;
	}

	public Boolean getResponsePending() {
		return responsePending;
	}

	public void setResponsePending(Boolean responsePending) {
		this.responsePending = responsePending;
	}

	public Boolean getEditLinkedExhibitAction() {
		return editLinkedExhibitAction;
	}

	public void setEditLinkedExhibitAction(Boolean editLinkedExhibitAction) {
		this.editLinkedExhibitAction = editLinkedExhibitAction;
	}

	public Boolean getRejectRFA() {
		return rejectRFA;
	}

	public void setRejectRFA(Boolean rejectRFA) {
		this.rejectRFA = rejectRFA;
	}

	public Boolean getEditRFA() {
		return editRFA;
	}

	public void setEditRFA(Boolean editRFA) {
		this.editRFA = editRFA;
	}

	public Boolean getSendRFA() {
		return sendRFA;
	}

	public void setSendRFA(Boolean sendRFA) {
		this.sendRFA = sendRFA;
	}

	public Boolean getResponsePendingActions() {
		return responsePendingActions;
	}

	public void setResponsePendingActions(Boolean responsePendingActions) {
		this.responsePendingActions = responsePendingActions;
	}
	
	public EsignHover getEsignHover() {
		return esignHover;
	}

	public void setEsignHover(EsignHover esignHover) {
		this.esignHover = esignHover;
	}
	
	public static class EsignHover
	{
		private Integer signedCount;
		
		private Integer totalCount;
		
		public Integer getSignedCount() {
			return signedCount;
		}

		public void setSignedCount(Integer signedCount) {
			this.signedCount = signedCount;
		}
		
		public Integer getTotalCount() {
			return totalCount;
		}

		public void setTotalCount(Integer totalCount) {
			this.totalCount = totalCount;
		}
	}
}
