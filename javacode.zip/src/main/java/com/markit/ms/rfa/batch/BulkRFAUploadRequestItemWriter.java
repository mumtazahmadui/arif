package com.markit.ms.rfa.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;

import com.markit.ms.rfa.bean.RFAUploadTemplateFile;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.rfabulkupload.template.RFABulkUploadProcessTemplate;
import com.markit.ms.rfa.rfabulkupload.util.RFABulkUploadFileUtil;
import com.markit.ms.rs.select.all.domain.SelectAllConfig;

public class BulkRFAUploadRequestItemWriter implements ItemWriter<RfaBulkUploadRow> {

	private static final Logger logger = LoggerFactory.getLogger(BulkRFAUploadRequestItemWriter.class);

	private Long batchId;

	@Value("#{jobParameters['userId']}")
	private String userId;

	@Value("#{jobParameters['companyId']}")
	private Long companyId;

	private SelectAllConfig selectAllConfig;

	private Long bulkRequestId;

	private String configBeanName;

	private Long templateId;

	private List<RfaBulkUploadRow> validatedRfaBulkUploadRowList = new ArrayList<RfaBulkUploadRow>();

	private List<RfaBulkUploadRow> rfaCreateList = new ArrayList<RfaBulkUploadRow>();

	@Resource
	ApplicationContext applicationContext;

	@Autowired
	RFABulkUploadFileUtil fileUtil;

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Autowired
	RFABulkUploadProcessTemplate rfaBulkUploadProcessTemplate;

	@PostConstruct
	public void postContructMethod() {

	}

	@Override
	public void write(List<? extends RfaBulkUploadRow> listLogEntries) throws Exception {
		for (RfaBulkUploadRow item : listLogEntries) {
			if (item.getErrors().isEmpty()) {
				rfaCreateList.add(item);
			}
			validatedRfaBulkUploadRowList.add(item);
		}
	}

	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	public void setConfigBeanName(String configBeanName) {
		this.configBeanName = configBeanName;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	@AfterStep
	public ExitStatus afterStep(StepExecution stepExecution) {
		rfaBulkUploadProcessTemplate
				.setEntityRequestedActionsPerAgreement(new HashMap<Long, HashMap<Long, Set<BulkUploadAction>>>());
		rfaBulkUploadProcessTemplate.setMonikarNameList(new ArrayList<String>());
		rfaBulkUploadProcessTemplate.setSleeveEntityIdList(new ArrayList<Long>());
		rfaBulkUploadProcessTemplate.setPartyBEntityIdList(new ArrayList<Long>());
		rfaBulkUploadProcessTemplate.setRfaBulkUploadRowSet(new HashSet<RfaBulkUploadRow>());
		List<String> mandatoryColumErrors = (List<String>) stepExecution.getJobExecution().getExecutionContext()
				.get("errorMessage");
		RFAUploadTemplateFile rfaUploadTemplateFile = uploadTemplateDAO.getUploadedFileId(bulkRequestId);

		try {

			if (mandatoryColumErrors != null && !mandatoryColumErrors.isEmpty()) {
				fileUtil.writeMandatoryFieldMissingErrorFile(rfaUploadTemplateFile.getFileId(), mandatoryColumErrors,
						companyId, bulkRequestId, Long.parseLong(userId));
			}
			if (errorsPresent(validatedRfaBulkUploadRowList)) {
				fileUtil.writeErrorFile(rfaUploadTemplateFile.getFileId(), validatedRfaBulkUploadRowList, companyId,
						bulkRequestId, Long.parseLong(userId));
			} else if (null != validatedRfaBulkUploadRowList)
				stepExecution.getJobExecution().getExecutionContext().put("rfaCreateList", rfaCreateList);

		} catch (RFAUIException e) {

			e.printStackTrace();
		}
		return null;
	}

	private boolean errorsPresent(List<RfaBulkUploadRow> rfaRows) {
		for (RfaBulkUploadRow row : rfaRows) {
			if (row.getErrors().size() > 0)
				return true;
		}
		return false;
	}
}