package com.markit.ms.rfa.bean;

/**
 * @author sucheta.krishali
 *
 */
public class RFAUploadTemplateField {
	
	private Long id;
	private String fieldIdentifier;
	private String fieldLabel;
	private String rule;
	private String aliasLabel;
	private Integer entityIdentifier;	
	private Long uploadTemplateId;
	private Integer isRequired;
	
	public RFAUploadTemplateField() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFieldIdentifier() {
		return fieldIdentifier;
	}

	public void setFieldIdentifier(String fieldIdentifier) {
		this.fieldIdentifier = fieldIdentifier;
	}

	public String getFieldLabel() {
		return fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}

	public String getRule() {
		return rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}

	public String getAliasLabel() {
		return aliasLabel;
	}

	public void setAliasLabel(String aliasLabel) {
		this.aliasLabel = aliasLabel;
	}

	public Integer getEntityIdentifier() {
		return entityIdentifier;
	}

	public void setEntityIdentifier(Integer entityIdentifier) {
		this.entityIdentifier = entityIdentifier;
	}

	public Long getUploadTemplateId() {
		return uploadTemplateId;
	}

	public void setUploadTemplateId(Long uploadTemplateId) {
		this.uploadTemplateId = uploadTemplateId;
	}

	public Integer getIsRequired() {
		return isRequired;
	}

	public void setIsRequired(Integer isRequired) {
		this.isRequired = isRequired;
	}

	
	
	
	
	
}
