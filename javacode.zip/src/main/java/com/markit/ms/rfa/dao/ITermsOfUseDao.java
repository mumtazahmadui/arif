package com.markit.ms.rfa.dao;

public interface ITermsOfUseDao {

	void updateTermsOfUse(Long fileId, String version, Long userId);
}
