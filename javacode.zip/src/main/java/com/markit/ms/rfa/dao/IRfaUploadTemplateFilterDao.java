package com.markit.ms.rfa.dao;

import java.util.List;
import java.util.Map;

import com.markit.ms.common.bean.Lookup;

public interface IRfaUploadTemplateFilterDao {
	List<Lookup> getUploadTemplateLookup(Long companyId,String filterString);

	public Map<String,List<String>>  getFilterValues() ;
	public Map<String,String>  getDefaultValue() ;

}
