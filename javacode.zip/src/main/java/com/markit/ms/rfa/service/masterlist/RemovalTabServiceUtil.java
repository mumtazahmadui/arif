package com.markit.ms.rfa.service.masterlist;

import java.util.List;
import java.util.Map;

import com.markit.ms.rfa.util.RFAConstants;

public class RemovalTabServiceUtil {

	/**
	 * 
	 * @param entityIdMap
	 * @param parentEntityIds
	 * @param currentParentIndex
	 * @return
	 */
	public static Boolean isParentEntityRemoved(Map<Long, Map<String, String>> entityIdMap, 
			List<Long> parentEntityIds, int currentParentIndex) {
		return entityIdMap.containsKey(parentEntityIds.get(currentParentIndex)) 
				&& entityIdMap.get(parentEntityIds.get(currentParentIndex)).containsKey(RFAConstants.RFA_ID_FIELD);
	}
	
}
