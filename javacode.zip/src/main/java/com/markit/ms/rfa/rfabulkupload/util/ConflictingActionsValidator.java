package com.markit.ms.rfa.rfabulkupload.util;

import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class ConflictingActionsValidator {

	@Autowired
	CommonValidator commonValidator;

	private Boolean hasConflictingActions;

	public Boolean hasConflictingActions(RfaBulkUploadRow rfaBulkUploadRow,
			Map<Long, Set<BulkUploadAction>> processedEntityActionsMap) {

		hasConflictingActions = false;

		checkRemovalConflictInPrecedingRow(rfaBulkUploadRow, processedEntityActionsMap);

		checkRemovalConflictInCurrentRow(rfaBulkUploadRow, processedEntityActionsMap);

		return hasConflictingActions;
	}

	private void checkRemovalConflictInPrecedingRow(RfaBulkUploadRow rfaBulkUploadRow,
			Map<Long, Set<BulkUploadAction>> processedEntityActionsMap) {
		Long partyBEntityId = rfaBulkUploadRow.getPartyBEntityId();
		if (isPartybOrParentRemovedInPreviousRow(partyBEntityId, processedEntityActionsMap)
				&& rfaBulkUploadRow.getRequestIdentified().size() > 0
				&& (rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.SLEEVE_ADDITION)
						|| rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.FNC)
						|| rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.EVC))
				&& !rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.REMOVAL)) {
			commonValidator.populateConflictActionErrors(rfaBulkUploadRow, RFAConstants.RFA_UPLOAD_CONFLICTING_ACTION);
			hasConflictingActions = true;
		}
	}

	private Boolean isPartybOrParentRemovedInPreviousRow(Long partyBEntityId,
			Map<Long, Set<BulkUploadAction>> processedEntityActionsMap) {

		if (processedEntityActionsMap.containsKey(partyBEntityId)) {
			Set<BulkUploadAction> actions = processedEntityActionsMap.get(partyBEntityId);
			for (BulkUploadAction action : actions) {
				if (CommonUtil.isNotNull(action) && action.equals(BulkUploadAction.REMOVAL)) {
					return true;
				}
			}
		}

		return false;
	}

	private void checkRemovalConflictInCurrentRow(RfaBulkUploadRow rfaBulkUploadRow,
			Map<Long, Set<BulkUploadAction>> processedEntityActionsMap) {
		if (processedEntityActionsMap.containsKey(rfaBulkUploadRow.getPartyBEntityId())
				&& rfaBulkUploadRow.getRequestIdentified().contains(BulkUploadAction.REMOVAL)) {
			Set<BulkUploadAction> actions = processedEntityActionsMap.get(rfaBulkUploadRow.getPartyBEntityId());
			if (!actions.isEmpty() && (actions.contains(BulkUploadAction.SLEEVE_ADDITION)
					|| actions.contains(BulkUploadAction.FNC) || actions.contains(BulkUploadAction.EVC))
					&& !actions.contains(BulkUploadAction.REMOVAL)) {
				commonValidator.populateConflictActionErrors(rfaBulkUploadRow,
						RFAConstants.RFA_UPLOAD_CONFLICTING_ACTION);
				hasConflictingActions = true;
			}
		}
	}

}
