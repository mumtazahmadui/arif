package com.markit.ms.rfa.service.impl;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.dao.SignatureServiceDao;
import com.markit.ms.common.service.IHTMLParser;
import com.markit.ms.rfa.service.ISignaturePlaceholderService;

@Service
public class SignaturePlaceholderServiceImpl implements ISignaturePlaceholderService
{

	@Autowired
    IHTMLParser htmParser;
	
	@Autowired
	private SignatureServiceDao signatureServiceDao;
	
	public static final String AMENDMENT_PLACEHOLDER_ID_BS_SIGNATURE = "bs_signature";
	public static final String AMENDMENT_PLACEHOLDER_ID_SS_SIGNATURE = "ss_signature";
	
	@Override
	public Integer getBsSignaturePlaceholderCount(Long amenmentId) {
		Integer bsSignaturePlaceholderCount = null;
		try {
			bsSignaturePlaceholderCount= htmParser.getSignaturePlaceholderCount(amenmentId, AMENDMENT_PLACEHOLDER_ID_BS_SIGNATURE);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bsSignaturePlaceholderCount;
	}

	@Override
	public Integer getSsSignaturePlaceholderCount(Long amenmentId) {
		Integer ssSignaturePlaceholderCount = null;
		try {
			ssSignaturePlaceholderCount = htmParser.getSignaturePlaceholderCount(amenmentId, AMENDMENT_PLACEHOLDER_ID_SS_SIGNATURE);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ssSignaturePlaceholderCount;
	}

	@Override
	public Integer getBsSignatureCount(Long amenmentId) {
		Integer bsSignCount = signatureServiceDao.getSignatureCount(amenmentId,1);
		return bsSignCount;
	}

	@Override
	public Integer getSsSignatureCount(Long amenmentId)
	{
		Integer ssSignCount = signatureServiceDao.getSignatureCount(amenmentId,0);
		return ssSignCount;
	}

}
