package com.markit.ms.rfa.exception;

public class RFAUIException extends Exception{
private static final long serialVersionUID = 1L;
	
	private String errorCode;
	public RFAUIException() {
		super();
	}

	public RFAUIException(String message, Throwable cause) {
		super(message + 
		        (cause == null?"":(" : " +cause.getMessage())), 
		            cause);
	}

	public RFAUIException(String message) {
		super(message);
	}
	
	public RFAUIException(String message , String errorCode) {
		super(message + "");
		this.errorCode = errorCode;
	}


	public RFAUIException(Throwable cause) {
		super(cause);
	}

	public String getErrorCode() {
		return errorCode;
	}
}
