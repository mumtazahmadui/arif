package com.markit.ms.rfa.service;

import java.util.List;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.markit.ms.rfa.bean.MasterlistTemplate;
import com.markit.ms.rfa.dto.MasterlistTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAUIException;

/**
 * @author prashant.aggarwal
 *
 */
public interface IMasterlistTemplateService {

	MasterlistTemplate saveMasterlistTemplate(MasterlistTemplate masterlistTemplate) throws RFAUIException;
	
	MasterlistTemplate getMasterlistTemplate(Long id);
	
	void deleteMasterListTemplateById(Long id) throws RFAException;
	
	public List<MasterlistTemplate> getMasterlistTemplateGrid(Long companyId, MasterlistTemplateSearchRequest templateSearchRequest);

	SXSSFWorkbook downloadMasterlistTemplate(Long mlTemplateId) throws Exception;
	
}
