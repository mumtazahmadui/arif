package com.markit.ms.rfa.controller;



import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.validation.ValidationErrorDTO;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAGenericException;
import com.markit.ms.rfa.exception.RFAUIException;

@ControllerAdvice(annotations = RestController.class)
public class ValidationAdvice {
	
	private static final Logger logger = LoggerFactory.getLogger(ValidationAdvice.class);

    @ExceptionHandler(Exception.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<CommonBaseResponse<String>> handleException(Exception exp) throws Exception {
    	throw exp;
    }
    
    
    @ExceptionHandler(RFAUIException.class)
    @ResponseBody
    @ResponseStatus(value = HttpStatus.OK)
    public ResponseEntity<CommonBaseResponse<RFAUIException>> processRFAUIException(Exception exp) throws Exception {
    	CommonBaseResponse<RFAUIException> commonBaseResponse = new CommonBaseResponse<RFAUIException>();
    	commonBaseResponse.setData((RFAUIException)exp);
    	return new ResponseEntity<CommonBaseResponse<RFAUIException>>(commonBaseResponse, HttpStatus.OK);
    }
    
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<CommonBaseResponse<ValidationErrorDTO>> processValidationError(MethodArgumentNotValidException ex) throws MethodArgumentNotValidException {
    	throw ex;
    }

    @ExceptionHandler(RFAException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    @ResponseBody
    public ResponseEntity<CommonBaseResponse<String>> processRFASystemException(RFAException ex, HttpServletResponse response) throws RFAException {
        throw ex;
    }
    
    @ExceptionHandler(RFAGenericException.class)
    public ResponseEntity<String> handleRFAGenericException(RFAGenericException ex){
    	logger.error(ex.getErrorMessage());
        return new ResponseEntity<String>(ex.getErrorMessage(), ex.getHttpStatusCode());
    }
    
    
}
