package com.markit.ms.rfa.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.common.constants.PermissionConstants;
@Controller
@RolesAllowed({PermissionConstants.BS_RFA, PermissionConstants.BS_RFA_SIGNATORY, PermissionConstants.SS_RFA, PermissionConstants.SS_RFA_SIGNATORY, PermissionConstants.SS_RFA_READ})
public class McsRedirectionController {
	
	@Resource private QueryService<Grid> getAmendmentDetails;
	
	@RequestMapping(value="/", method = RequestMethod.GET)
	public String index() {
		
		return "index";
	}
	
	@RequestMapping(value="/", method = RequestMethod.GET, params={"action", "amendment_id"})
	public String redirect(@RequestParam(value="action") String action,
			@RequestParam(value="amendment_id") String amendment_id,
			@RequestParam(value="exhibit_id", required=false) String exhibit_id,
			@RequestParam(value="file_id", required=false) String file_id,
			HttpServletRequest request) {
	
		Long sessionCompanyId = CommonUtil.getCompanyIdFromSession(request);
		
		Grid amendmentDetails = getAmendmentDetails.executeQuery("amendmentId", amendment_id);
		
		Map<String,String> row = amendmentDetails.getRows().get(0);
		
		String partyACompanyId = row.get("PARTYA_COMPANY_ID");
		String amendmentStatus = row.get("AMENDMENT_STATUS");
		String imCompanyId = row.get("IM_COMPANY_ID");
		
		boolean accessAllowedForSS = checkAccessAllowed(amendmentStatus, partyACompanyId, sessionCompanyId);
		boolean accessAllowedForBSRFAID = imCompanyId.equalsIgnoreCase(""+sessionCompanyId) ? true : false;
		boolean accessAllowedForSSRFAID = partyACompanyId.equalsIgnoreCase(""+sessionCompanyId) ? true : false;
		
		if ((action.equalsIgnoreCase("sellsideRejectsRfa") || action.equalsIgnoreCase("sellsideSendsRfa")
				|| action.equalsIgnoreCase("buysideRecallsRfa") || action.equalsIgnoreCase("buysideWithdrawsPartyb"))
				&& (accessAllowedForBSRFAID || accessAllowedForSSRFAID)) {
			return "redirect:/v1/amendmentLetters/" + amendment_id + "/actions/rfaid_pdf";
		} else if (action.equalsIgnoreCase("buysideSendsRfa") 
				&& accessAllowedForSS) {	// TODO: NEED help from Luxoft for integration on RFAReviewEditorController
			return "redirect://#/rfa/company/amendmentReview/" + amendment_id + "/" + exhibit_id;
		} else if (action.equalsIgnoreCase("sellsideSignatoryEsign") 
				&& accessAllowedForSS) {
			return "redirect://#/rfa/company/esign-ss/" + amendment_id + "/0";
		} 
		else if(action.equalsIgnoreCase("loginBulkFileUpload"))
			return "redirect://#/rfa/company/bulk-upload/files";
		else {
			return "index";
		}
	}
	
	
	@RequestMapping(value="/", method = RequestMethod.GET, params={"action"})
	public String redirect(@RequestParam(value="action") String action,
			HttpServletRequest request) {
			
		if(action.equalsIgnoreCase("loginBulkFileUpload"))
			return "redirect://#/rfa/company/bulk-upload/files";
		
		else {
			return "index";
		}
	}
	
	
	

	private boolean checkAccessAllowed(String amendmentStatus, String amendmentCompanyId,Long sessionCompanyId) {
		
		if(amendmentCompanyId.equalsIgnoreCase(""+sessionCompanyId) && 
				!amendmentStatus.equalsIgnoreCase(AmendmentStatus.RECALLED.getTrueName()) &&
				!amendmentStatus.equalsIgnoreCase(AmendmentStatus.REJECTED.getTrueName()) &&
				!amendmentStatus.equalsIgnoreCase(AmendmentStatus.COMPLETED.getTrueName())
				) {
			return true;
		}
		return false;
	}
	
}
