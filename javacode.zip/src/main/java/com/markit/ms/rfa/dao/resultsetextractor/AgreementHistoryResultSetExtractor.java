package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.MasterAgreementHistory;

public class AgreementHistoryResultSetExtractor implements
		ResultSetExtractor<MasterAgreementHistory> {

	@Override
	public MasterAgreementHistory extractData(ResultSet rs)
			throws SQLException, DataAccessException {
		Map<Long, AmendmentLetter> amendmentMap = new HashMap<Long, AmendmentLetter>();
		MasterAgreementHistory history = new MasterAgreementHistory();
		while (rs.next()){
			AmendmentLetter letter = amendmentMap.get(rs.getLong("id"));
			if (letter == null){
				letter = new AmendmentLetter();
				letter.setId(rs.getLong("id"));
				history.setMasterAgreementId(rs.getLong("master_agreement_id"));
/*				MasterAgreement masterAgreement = new MasterAgreement();
				masterAgreement.setId(rs.getLong("master_agreement_id"));
				letter.setMasterAgreement(masterAgreement);*/
				letter.setName(rs.getString("name"));
				letter.setDateSigned(rs.getDate("date_signed"));
				amendmentMap.put(rs.getLong("id"), letter);
			}
		}
		history.setAmendmentLetters(new ArrayList<AmendmentLetter>(amendmentMap.values()));
		return history;
	}
	
}
