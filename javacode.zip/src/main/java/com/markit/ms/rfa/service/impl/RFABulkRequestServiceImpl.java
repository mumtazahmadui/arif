package com.markit.ms.rfa.service.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.markit.ms.rfa.service.RFABulkRequestService;
import com.markit.ms.rs.select.all.domain.BulkRequest;
import com.markit.ms.rs.select.all.domain.BulkRequestStateEnum;
import com.markit.ms.rs.select.all.domain.SelectAllConfig;
import com.markit.ms.rs.select.all.repository.BulkRequestObjectParamRepository;
import com.markit.ms.rs.select.all.repository.BulkRequestObjectRepository;
import com.markit.ms.rs.select.all.repository.BulkRequestParamRepository;
import com.markit.ms.rs.select.all.repository.BulkRequestRepository;

@Service
public class RFABulkRequestServiceImpl implements RFABulkRequestService, ApplicationContextAware {

	private static final Logger logger = LoggerFactory.getLogger(RFABulkRequestServiceImpl.class);

	private static final String[] BATCH_CONTEXT_FILES = { "classpath*:/batch/bulk-RFA-create-job.xml" };
	private static final String SELECT_RFA_BULK_UPLOAD_BATCH = "selectRFABulkUploadProcessing";

	private ApplicationContext applicationContext;

	@Resource
	private BulkRequestRepository bulkRequestRepository;

	@Resource
	private BulkRequestObjectRepository bulkRequestObjectRepository;

	@Resource
	private BulkRequestParamRepository bulkRequestParamRepository;

	@Resource
	private BulkRequestObjectParamRepository bulkRequestObjectParamRepository;

	@Value("${mcpm.createSleeve.Url}")
	String mcpmCreateSleeveEntityUrl;

	@Override
	@Transactional(propagation = Propagation.NEVER)
	public void doProcess(final Long savedBulkRequestId, final Long userId, Long companyId, final String configBeanName,
			Long templateId, String ipAddress) {
		ApplicationContext batchContext = null;
		Job job = null;
		try {
			batchContext = new ClassPathXmlApplicationContext(BATCH_CONTEXT_FILES, applicationContext);

			job = (Job) batchContext.getBean(SELECT_RFA_BULK_UPLOAD_BATCH);
			JobLauncher jobLauncher = (JobLauncher) batchContext.getBean("jobLauncher");
			Map<String, JobParameter> map = new HashMap<String, JobParameter>();
			map.put("bulkRequestId", new JobParameter(savedBulkRequestId));
			map.put("startDateTime", new JobParameter(new Date()));
			map.put("userId", new JobParameter(new Long(userId)));
			map.put("companyId", new JobParameter(new Long(companyId)));
			map.put("configBeanName", new JobParameter(configBeanName));
			map.put("templateId", new JobParameter(templateId));
			map.put("mcpmCreateSleeveEntityUrl", new JobParameter(mcpmCreateSleeveEntityUrl));
			map.put("ipAddress", new JobParameter(ipAddress));
			JobParameters jobParameters = new JobParameters(map);
			logger.info("batch job {} started for the request/user {}/{}", SELECT_RFA_BULK_UPLOAD_BATCH,
					savedBulkRequestId, userId);
			JobExecution jobExecution = jobLauncher.run(job, jobParameters);

			logger.info("batch job {} completed with execution id {} for user {}/{}", SELECT_RFA_BULK_UPLOAD_BATCH,
					jobExecution.getId(), userId);
		} catch (Exception ex) {
			logger.error("Not able to execute Relationship batch: " + ex, ex);
		} finally {
			if (batchContext != null) {
				((ConfigurableApplicationContext) batchContext).close();
			}
		}
	}

	private String getServerName() throws UnknownHostException {
		String fullHostName = InetAddress.getLocalHost().getHostName();
		String array[] = new String[4];
		if (fullHostName != null) {
			array = fullHostName.split("\\.");
		}
		fullHostName = array[0];
		return fullHostName != null ? fullHostName.substring(fullHostName.length() - 3, fullHostName.length()) : null;
	}

	public Long saveBulkUploadRFARequest(SelectAllConfig config, Long userId, Long companyId, Long fileId)
			throws UnknownHostException {
		BulkRequest bulkRequest = new BulkRequest();
		bulkRequest.setBulkAction(config.getActionName());
		bulkRequest.setCreatedDate(new Date());
		bulkRequest.setCreatedBy(userId);
		bulkRequest.setCompanyId(companyId);
		bulkRequest.setState(BulkRequestStateEnum.SCHEDULED.getState());
		bulkRequest.setSendEmail(config.isSendEmailNotification() ? 1 : 0);
		bulkRequest.setConfigBeanName(config.getConfigBeanName());
		final String hostName = getServerName();
		bulkRequest.setHostName(hostName);
		bulkRequest.setFileId(fileId);
		bulkRequestRepository.create(bulkRequest);
		return bulkRequest.getRequestId();
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}
}