package com.markit.ms.rfa.command.validator;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.NotImplementedException;
import org.springframework.stereotype.Component;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.CommonFileResponse;
import com.markit.ms.rfa.bean.BulkValidationBean;
import com.markit.ms.rfa.bean.NewExhibitRequest;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;

@Component
public abstract class BulkActionValidator {

	@Resource
	protected Map<String, QueryService<Grid>> bulkValidationQueries;
	
	public Grid validate(List<Long> rfaIds, Long companyId, String companyType){
		throw new NotImplementedException();
	}
	
	public Grid validate(BulkValidationBean validationBean){
		throw new NotImplementedException();
	}
	
	public CommonBaseResponse<CommonFileResponse> validate(List<Long> rfaIds, BulkActionValidationType type, Long companyId, Long userId) throws Exception{
		throw new NotImplementedException();
	}
	
	public Map<Long, List<String>> validate(Map<Long, NewExhibitRequest> rfaMap){
		throw new NotImplementedException();
	}
	
	public List<Signature> validate(List<Signature> signatureList, String companyType, Long companyId){
		throw new NotImplementedException();
	}
}
