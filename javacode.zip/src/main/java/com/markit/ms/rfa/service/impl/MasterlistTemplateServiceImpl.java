package com.markit.ms.rfa.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.DownloadSheetData;
import com.markit.ms.common.service.impl.DownloadServiceImpl;
import com.markit.ms.rfa.bean.MasterlistTemplate;
import com.markit.ms.rfa.bean.MasterlistTemplateDownload;
import com.markit.ms.rfa.dao.IMasterlistTemplateDAO;
import com.markit.ms.rfa.dto.MasterlistTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAGenericException;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.IMasterlistTemplateService;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author prashant.aggarwal
 *
 */
@Service
public class MasterlistTemplateServiceImpl implements IMasterlistTemplateService {

	@Autowired
	IMasterlistTemplateDAO masterlistTemplateDAO;

	@Override
	public MasterlistTemplate saveMasterlistTemplate(MasterlistTemplate masterlistTemplate) throws RFAUIException {
		if (masterlistTemplate != null) {
			Long id = masterlistTemplateDAO.getCountMasterlistTemplateByName(masterlistTemplate.getTemplateName(),masterlistTemplate.getCompanyId());
			if (id > 0)
				throw new RFAUIException(RFAConstants.MASTERLIST_TEMPLATE_ALREADY_EXIST, HttpStatus.OK.toString());

			masterlistTemplate = masterlistTemplateDAO.saveMasterlistTemplate(masterlistTemplate);
		}
		return masterlistTemplate;
	}

	@Override
	public MasterlistTemplate getMasterlistTemplate(Long id) {
		MasterlistTemplate masterlistTemplate = masterlistTemplateDAO.getMasterlistTemplateById(id);
		return masterlistTemplate;
	}

	@Override
	public void deleteMasterListTemplateById(Long id) throws RFAException {
		Integer count = masterlistTemplateDAO.deleteMasterListTemplateById(id);
		if(count<=0)
			throw new RFAGenericException(RFAConstants.MASTERLIST_TEMPLATE_DOESNT_EXIST, HttpStatus.NOT_FOUND);		
	}

	@Override
	public List<MasterlistTemplate> getMasterlistTemplateGrid(Long companyId,
			MasterlistTemplateSearchRequest templateSearchRequest) {
		List<MasterlistTemplate> masterlistTemplates = masterlistTemplateDAO.getMasterlistTemplateGrid(companyId, templateSearchRequest);
		return masterlistTemplates;
	}

	@Override
	public SXSSFWorkbook downloadMasterlistTemplate(Long mlTemplateId) throws Exception {
		List<MasterlistTemplateDownload> mlTemplateFields = new ArrayList<MasterlistTemplateDownload>();
		mlTemplateFields = masterlistTemplateDAO.getMasterlistTemplateColumns(mlTemplateId);
		
		List<String> headerList = new ArrayList<String>();
		
		for(int i=0; i<mlTemplateFields.size(); i++){
			if(null != mlTemplateFields.get(i).getFieldLabel() && "" != mlTemplateFields.get(i).getFieldLabel()){
				headerList.add(mlTemplateFields.get(i).getFieldLabel());
			} else {
				headerList.add(mlTemplateFields.get(i).getFieldIdentifier());
			}
		}
		
		headerList.add(RFAConstants.IS_SLEEVE);
		
		List<DownloadSheetData> dataList = new ArrayList<DownloadSheetData>();
		dataList.add(new DownloadSheetData(0, null, null, 0));
		DownloadServiceImpl downloadService = new DownloadServiceImpl();
		InputStream inputStream = this.getClass().getResourceAsStream("/Masterlist_Template_Download.xlsx");
		SXSSFWorkbook workbook = downloadService.getSXSSWorkbook(inputStream, headerList);
		
		return workbook;
	}

}
