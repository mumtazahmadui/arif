package com.markit.ms.rfa.service;

import java.sql.Date;
import java.util.List;

import com.markit.ms.common.model.MasterAgreementSearchRequest;
import com.markit.ms.rfa.bean.AmendmentStatusObject;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.MasterAgreementHistory;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;

public interface IMasterAgreementService {
	public List<MasterAgreement> getMasterAgreements(Long companyId, MasterAgreementSearchRequest searchRequest);
	public MasterAgreementHistory getAmendmentmentLetterHistory(Long companyId, Long agreementId);
	public List<PartyBEntity> getExistingPartyB(Long masterAgreementId, List<Long> partyBEntityIds, Long amendmentId);
	public Date getMasterAgreementDateById(Long masterAgreementId);
	public List<AmendmentStatusObject> getAmendmentStatusOfModifiedEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId);
	public String getAmendmentStatusOfFNCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId);
	public String getAmendmentStatusOfEVCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId);
	public String getMasterlistTrueLegalName(Long entityId, Long masterAgreementId);
	public String getRequestTypeForValidation(Long partybId);
	public String getMasterlistMlTemplateName(Long masterAgreementId);
	public String getMlTemplateWithSleeve(Long masterAgreementId);
	public String getMlTemplateWithSleeveNameByAmendment(Long amendmentId);
	public void updateMasterAgreement(Long amendmentId);
	RfaBulkUploadRow determineMLExhibitLinkage(RfaBulkUploadRow rfaBulkUploadRow);
	public void getMasterAgreement(RfaBulkUploadRow rfaBulkUploadRow);
	public List<PartyBEntity> getExistingPartyB(Long masterAgreementId, List<Long> sleeveEntityIds, Long amendmentId,
			String callingSource);

}
