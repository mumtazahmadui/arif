package com.markit.ms.rfa.security;

import java.util.Collection;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.security.core.GrantedAuthority;

import com.markit.kyc.security.UserUtils;
import com.markit.kyc.security.UserxsUser;
import com.markit.kyc.security.UserxsUserDetails;
import com.markit.ms.rfa.security.domain.McpmUser;

public class McpmUserxsDetails implements UserxsUserDetails {

	private McpmUser effectiveUser;

	private UserxsUser userXS;
	private long loggedInTime;
	
	public McpmUserxsDetails(McpmUser mcpmUser, UserxsUser userXS, long loggedInTime) {
		this.effectiveUser = mcpmUser;
		this.userXS = userXS;
		this.loggedInTime = loggedInTime;
	}
	

	@Override
	public String getPassword() {
		
		return null;
	}

	@Override
	public String getUsername() {
		
		return null;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	@Override
	public UserxsUser getUserxUser() {
		return userXS;
	}


	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return UserUtils.getAuthorities(this.effectiveUser.getPermissions());
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
	
	public McpmUser getEffectiveUser() {
		return effectiveUser;
	}


	public long getLoggedInTime() {
		return loggedInTime;
	}


	public void setLoggedInTime(long loggedInTime) {
		this.loggedInTime = loggedInTime;
	}

}
