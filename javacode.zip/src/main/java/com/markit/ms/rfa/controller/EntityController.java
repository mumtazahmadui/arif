package com.markit.ms.rfa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.CommonBaseSearchRequest;
import com.markit.ms.rfa.service.IEntityService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

import javax.servlet.http.HttpServletRequest;
@RestController
@RequestMapping(value = "/v1/company")
@Api(value = "entity" , description = "Entity APIs")
public class EntityController {

	@Autowired
    private IEntityService entityService;

    @RequestMapping(value="{id}/entity",method = RequestMethod.POST)
    @ApiOperation(value = "Get all PartyB accounts")
    public CommonBaseResponse<List<Entity>> getAllEntities(@PathVariable Long id
    		, @RequestParam(required=false) String filterString, @RequestBody CommonBaseSearchRequest commonBaseSearchRequest,HttpServletRequest request){
		 if(null == filterString) {
			 filterString = "";
		 }
		 Long companyId = CommonUtil.getCompanyIdFromSession(request);
    	 CommonBaseResponse<List<Entity>> commonBaseResponse = new  CommonBaseResponse<List<Entity>>();
    	 List<Entity> entityList = entityService.getAllEntities(companyId, filterString, commonBaseSearchRequest);
    	 commonBaseResponse.setData(entityList);
    	 return commonBaseResponse;
    }
    
    @RequestMapping(value="{id}/entity",method = RequestMethod.GET)
    @ApiOperation(value = "Get all PartyB sleeve accounts")
    public CommonBaseResponse<List<Entity>> getAllSleeveEntities(@PathVariable Long id, @RequestParam(required=false) String type
    		, @RequestParam(required=false) String filterString, @RequestParam(required=false) List<Long> masterlistIds
    		, @RequestParam(required=false) List<Long> entityIds, @RequestParam(required=false) Long offSet
    		, @RequestParam(required=false) Long pageSize, HttpServletRequest request){
    	if(null == filterString) {
    		filterString = "";
    	}
    	Long companyId = CommonUtil.getCompanyIdFromSession(request);
    	CommonBaseResponse<List<Entity>> commonBaseResponse = new  CommonBaseResponse<List<Entity>>();
    	List<Entity> entityList = null;
    	if(!masterlistIds.isEmpty() && !entityIds.isEmpty()) {
    		entityList = entityService.getSleeveAccountsForParentEntities(companyId, masterlistIds, entityIds);
    	} else {
    		entityList = entityService.getAllSleeveEntities(companyId, filterString, offSet, pageSize);
    	}
    	commonBaseResponse.setData(entityList);
    	return commonBaseResponse;
    }
}
