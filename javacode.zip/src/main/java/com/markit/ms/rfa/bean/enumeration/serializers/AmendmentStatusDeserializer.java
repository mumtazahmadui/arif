package com.markit.ms.rfa.bean.enumeration.serializers;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;

public class AmendmentStatusDeserializer extends JsonDeserializer<AmendmentStatus> {

	@Override
	public AmendmentStatus deserialize(JsonParser jp, DeserializationContext arg1) throws IOException, JsonProcessingException {


		String trueName = null;
		if(jp.getCurrentToken() == JsonToken.START_OBJECT){
			// display Name
			jp.nextToken();
			jp.nextToken();
			// true Name
			jp.nextToken();
			jp.nextToken();
			trueName = jp.getValueAsString();
			// END_OBJECT
			jp.nextToken();
			
		} 

		AmendmentStatus taskDefId = AmendmentStatus.fromString(trueName);
		if (taskDefId != null) {
			return taskDefId;
		}
		throw new JsonMappingException("Invalid type");
	}
}
