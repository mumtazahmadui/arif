package com.markit.ms.rfa.dto;

public class BulkProcessResponse<T> {

	private Long bulkRequestId;

	private Integer errorCount;

	private Long errorFileId;

	private T data;

	public Long getBulkRequestId() {
		return bulkRequestId;
	}

	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	public Integer getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(Integer errorCount) {
		this.errorCount = errorCount;
	}

	public Long getErrorFileId() {
		return errorFileId;
	}

	public void setErrorFileId(Long errorFileId) {
		this.errorFileId = errorFileId;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}
}