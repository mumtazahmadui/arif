package com.markit.ms.rfa.bean;

import java.math.BigDecimal;
import java.util.Date;

public class MasterlistDownload {
	
	private BigDecimal masterAgreementId;
	private String agreementDate;
	private String investmentManager;
	private String partyA;
	private String masterlistIdentifier;
	private String modificationType;
	private Long entityId;
	private Long partybId;
	private boolean isAdded;
	private String columnName;
	private String oldColumnValue;
	private String columnValue;
	private boolean isControlColumn;
	private Long columnIndex;
	private String oldLegalName;
	private String newLegalName;
	private String oldClientIdentifier;
	private String newClientIdentifier;
	private String oldLeiName;
	private String newLeiName;
	private Date addedDate;
	private Date modifiedDate;
	private String addedDateString;
	private String modifiedDateString;
	private BigDecimal rfaId;
	
	public BigDecimal getMasterAgreementId() {
		return masterAgreementId;
	}
	public void setMasterAgreementId(BigDecimal masterAgreementId) {
		this.masterAgreementId = masterAgreementId;
	}
	private String agreementType;
	private Long parentEntityId;
	
	public String getAgreementDate() {
		return agreementDate;
	}
	public void setAgreementDate(String agreementDate) {
		this.agreementDate = agreementDate;
	}
	public String getInvestmentManager() {
		return investmentManager;
	}
	public void setInvestmentManager(String investmentManager) {
		this.investmentManager = investmentManager;
	}
	public String getPartyA() {
		return partyA;
	}
	public void setPartyA(String partyA) {
		this.partyA = partyA;
	}
	public String getMasterlistIdentifier() {
		return masterlistIdentifier;
	}
	public void setMasterlistIdentifier(String masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}
	public String getModificationType() {
		return modificationType;
	}
	public void setModificationType(String modificationType) {
		this.modificationType = modificationType;
	}
	public Long getEntityId() {
		return entityId;
	}
	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}
	public Long getPartybId() {
		return partybId;
	}
	public void setPartybId(Long partybId) {
		this.partybId = partybId;
	}
	public boolean isAdded() {
		return isAdded;
	}
	public void setAdded(boolean isAdded) {
		this.isAdded = isAdded;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getOldColumnValue() {
		return oldColumnValue;
	}
	public void setOldColumnValue(String oldColumnValue) {
		this.oldColumnValue = oldColumnValue;
	}
	public String getColumnValue() {
		return columnValue;
	}
	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}
	public boolean isControlColumn() {
		return isControlColumn;
	}
	public void setControlColumn(boolean isControlColumn) {
		this.isControlColumn = isControlColumn;
	}
	public Long getColumnIndex() {
		return columnIndex;
	}
	public void setColumnIndex(Long columnIndex) {
		this.columnIndex = columnIndex;
	}
	public String getOldLegalName() {
		return oldLegalName;
	}
	public void setOldLegalName(String oldLegalName) {
		this.oldLegalName = oldLegalName;
	}
	public String getNewLegalName() {
		return newLegalName;
	}
	public void setNewLegalName(String newLegalName) {
		this.newLegalName = newLegalName;
	}
	public String getOldClientIdentifier() {
		return oldClientIdentifier;
	}
	public void setOldClientIdentifier(String oldClientIdentifier) {
		this.oldClientIdentifier = oldClientIdentifier;
	}
	public String getNewClientIdentifier() {
		return newClientIdentifier;
	}
	public void setNewClientIdentifier(String newClientIdentifier) {
		this.newClientIdentifier = newClientIdentifier;
	}
	public String getOldLeiName() {
		return oldLeiName;
	}
	public void setOldLeiName(String oldLeiName) {
		this.oldLeiName = oldLeiName;
	}
	public String getNewLeiName() {
		return newLeiName;
	}
	public void setNewLeiName(String newLeiName) {
		this.newLeiName = newLeiName;
	}
	public Date getAddedDate() {
		return addedDate;
	}
	public void setAddedDate(Date addedDate) {
		this.addedDate = addedDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public String getAddedDateString() {
		return addedDateString;
	}
	public void setAddedDateString(String addedDateString) {
		this.addedDateString = addedDateString;
	}
	public String getModifiedDateString() {
		return modifiedDateString;
	}
	public void setModifiedDateString(String modifiedDateString) {
		this.modifiedDateString = modifiedDateString;
	}
	public BigDecimal getRfaId() {
		return rfaId;
	}
	public void setRfaId(BigDecimal rfaId) {
		this.rfaId = rfaId;
	}
	public String getAgreementType() {
		return agreementType;
	}
	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}
	
	public void setParentEntityId(Long parentEntityId) {
		this.parentEntityId = parentEntityId;
	}
	
	public Long getParentEntityId() {
		return parentEntityId;
	}
}
