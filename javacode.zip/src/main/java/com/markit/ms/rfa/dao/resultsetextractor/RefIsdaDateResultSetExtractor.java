package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;

public class RefIsdaDateResultSetExtractor implements ResultSetExtractor<List<Date>>
{

	@Override
	public List<Date> extractData(ResultSet rs) throws SQLException, DataAccessException
	{
		List<Date> dates = new ArrayList<Date>();
		while(rs.next()){
			dates.add(rs.getDate("value"));
		}
		return dates;
	}
}
