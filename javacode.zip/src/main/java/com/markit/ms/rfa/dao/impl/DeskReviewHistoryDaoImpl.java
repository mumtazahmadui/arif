package com.markit.ms.rfa.dao.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.PartyBDeskReviewData;
import com.markit.ms.rfa.dao.DeskReviewHistoryDao;
import com.markit.ms.rfa.dao.rowmapper.DeskReviewHistoryAmendmentLevelRowMapper;
import com.markit.ms.rfa.dao.rowmapper.DeskReviewHistoryRowMapper;
import com.markit.ms.rfa.dto.PartyBDeskReviewDetails;

/**
 * This class provides dao operation implementation for Amendment Letter/
 * PartyB's desk statuses history details
 * 
 * @since RFA5.0
 *
 */
@Repository
public class DeskReviewHistoryDaoImpl extends BaseDAOImpl implements DeskReviewHistoryDao {
	private static final Logger LOGGER = LoggerFactory.getLogger(DeskReviewHistoryDaoImpl.class);

	@Value("${deskReviewHistory#create}")
	private String CREATE_REVIEW_HISTORY;
	
	@Value("${deskReviewHistory#createAtAmendment}")
	private String CREATE_REVIEW_HISTORY_AT_AMENDMENT;

	@Value("${deskReviewHistory#reviewHistoryDetails}")
	private String FETCH_REVIEW_HISTORY;

	@Value("${deskReviewHistory#amendmentReviewHistoryDetails}")
	private String FETCH_AMENDMENT_REVIEW_HISTORY;

	@Value("${deskReviewHistory#escalatedHistoryDetail}")
	private String FETCH_ESCALTED_HISTORY;

	@Value("${deskReviewHistory#escalatedToUsers}")
	private String ESCALTED_TO_USERS;

	@Value("${deskReviewHistory#insertEscalatedToUsers}")
	private String INSERT_ESCALTED_TO_USERS;

	@Override
	public Long create(PartyBDeskReviewData deskReviewData) {

		KeyHolder keyHolder = new GeneratedKeyHolder();

		SqlParameterSource params = new MapSqlParameterSource().addValue("deskCode", deskReviewData.getDeskCode())
				.addValue("partyBId", deskReviewData.getPartyBId()).addValue("createdBy", deskReviewData.getCreatedBy())
				.addValue("createdDate", deskReviewData.getCreatedDate())
				.addValue("isReviewed", deskReviewData.isReviewed())
				.addValue("isBulkAction", deskReviewData.isBulkAction());

		LOGGER.debug("create : CREATE_REVIEW_HISTORY : " + CREATE_REVIEW_HISTORY);

		namedParameterJdbcTemplate.update(CREATE_REVIEW_HISTORY, params, keyHolder);
		return keyHolder.getKey().longValue();
	}

	@Override
	public void createAtAmendment(PartyBDeskReviewData deskReviewData) {

		SqlParameterSource params = new MapSqlParameterSource().addValue("deskCode", deskReviewData.getDeskCode())
				.addValue("amendmentId", deskReviewData.getAmendmentId()).addValue("createdBy", deskReviewData.getCreatedBy())
				.addValue("createdDate", deskReviewData.getCreatedDate())
				.addValue("isReviewed", deskReviewData.isReviewed());

		LOGGER.debug("create : CREATE_REVIEW_HISTORY_AT_AMENDMENT : " + CREATE_REVIEW_HISTORY_AT_AMENDMENT);

		namedParameterJdbcTemplate.update(CREATE_REVIEW_HISTORY_AT_AMENDMENT, params);

	}
	
	@Override
	public List<PartyBDeskReviewDetails> fetchReviewHistoryDetails(PartyBDeskReviewData deskReviewData) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("deskCode", deskReviewData.getDeskCode())
				.addValue("partyBId", deskReviewData.getPartyBId()).addValue("pageSize", 5);

		LOGGER.debug("fetchReviewHistoryDetails : FETCH_REVIEW_HISTORY : "
				+ FETCH_REVIEW_HISTORY);

		return namedParameterJdbcTemplate.query(FETCH_REVIEW_HISTORY, params, new DeskReviewHistoryRowMapper());
	}

	@Override
	public List<PartyBDeskReviewDetails> fetchAmendmentReviewHistoryDetails(Long amendmentId, String deskCode) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("deskCode", deskCode)
				.addValue("amendmentId", amendmentId).addValue("pageSize", 5);

		LOGGER.debug("fetchAmendmentReviewHistoryDetails : FETCH_AMENDMENT_REVIEW_HISTORY : "
				+ FETCH_AMENDMENT_REVIEW_HISTORY);

		return namedParameterJdbcTemplate.query(FETCH_AMENDMENT_REVIEW_HISTORY, params,
				new DeskReviewHistoryAmendmentLevelRowMapper());
	}

	@Override
	public PartyBDeskReviewDetails fetchEscalatedHistoryDetails(PartyBDeskReviewData deskReviewData) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("deskCode", deskReviewData.getDeskCode())
				.addValue("partyBId", deskReviewData.getPartyBId());

		LOGGER.debug("fetchEscalatedHistoryDetails : FETCH_ESCALTED_HISTORY : "
				+ FETCH_ESCALTED_HISTORY);
		
		List<PartyBDeskReviewDetails> details = namedParameterJdbcTemplate.query(FETCH_ESCALTED_HISTORY, params,
				new DeskReviewHistoryRowMapper());

		if(CollectionUtils.isNotEmpty(details)) {
			return details.get(0);
		}else {
			return null;			
		}
	}

	@Override
	public List<String> getEscalatedToUsers(Long reviewHistoryId) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("historyId", reviewHistoryId);

		LOGGER.debug("getEscalatedToUsers : ESCALTED_TO_USERS : " + ESCALTED_TO_USERS);

		return namedParameterJdbcTemplate.queryForList(ESCALTED_TO_USERS, params, String.class);
	}

	@Override
	public void insertEscalatedUsers(Long deskReviewHistoryId, List<Long> userIds) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("deskReviewHistoryId", deskReviewHistoryId)
				.addValue("userIds", userIds);

		LOGGER.debug("insertEscalatedUsers : INSERT_ESCALTED_TO_USERS : "
				+ INSERT_ESCALTED_TO_USERS);

		namedParameterJdbcTemplate.update(INSERT_ESCALTED_TO_USERS, params);
	}

}
