package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.common.bean.Lookup;


public interface IExhibitTemplateFilterDAO
{
	public List<Lookup> nameLookup(Long id, String filterString);
	public List<Lookup> linkedByLookup(Long id, String filterString);
	public List<Lookup> createdByLookup(Long id, String filterString);
	
	public List<Lookup> partyALegalNameLookup(Long id, String filterString);
	
	public List<String> refIsdaDateLookup(Long id, String filterString);
	
	public List<Lookup> masterlistIdentifierLookup(Long id, String filterString);
}
