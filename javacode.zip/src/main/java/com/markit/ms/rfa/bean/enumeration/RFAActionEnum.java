package com.markit.ms.rfa.bean.enumeration;

public enum RFAActionEnum {

	BULK_CHASER("BULK_CHASER"),
	BULK_SEND("BULK_SEND"),
	BULK_SIGN("BULK_SIGN"),
	BULK_UPLOAD_EXHIBIT_TEMPLATE("BULK_UPLOAD_EXHIBIT_TEMPLATE"),
	BULK_SAVE_EXHIBIT_DATA("BULK_SAVE_EXHIBIT_DATA"),
	BULK_SIGNATORY_NOTIFICATION("BULK_SIGNATORY_NOTIFICATION");
	
	private String name;
	
	private RFAActionEnum(String name){
		this.name = name;
	}
	
	public String getName(){
        return this.name;
    }
	
	public static RFAActionEnum fromString(String str){
		if (null == str){
			return null;
		}
		for (RFAActionEnum action : RFAActionEnum.values()){
			if (action.name.equalsIgnoreCase(str)) return action;
		}
		return null;
	}
}
