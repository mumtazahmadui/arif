package com.markit.ms.rfa.batch.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.batch.service.BulkActionService;
import com.markit.ms.rfa.bean.BulkActionBean;
import com.markit.ms.rfa.bean.BulkExhibitBean;
import com.markit.ms.rfa.bean.NewExhibitRequest;
import com.markit.ms.rfa.bean.enumeration.RFAActionEnum;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.service.INewExhibitService;

@Service("bulkExhibitService")
public class BulkExhibitServiceImpl extends BulkActionService {

	private static Logger LOGGER = LoggerFactory.getLogger(BulkExhibitServiceImpl.class);

	@Autowired
	INewExhibitService newExhibitService;

	@Autowired
	IAmendmentLetterService amendmentLetterService;

	/*
	 * @Autowired IFileService fileService;
	 */

	/*
	 * @Autowired IRfaFileService rfaFileService;
	 */

	public void processBulkAction(BulkActionBean bulkActionBean) {
		try {
			BulkExhibitBean bulkExhibitBean = (BulkExhibitBean) bulkActionBean;
			byte[] file = bulkExhibitBean.getFile();
			Map<Long, NewExhibitRequest> exhibitRequestMap = newExhibitService.getExhibitRequestMap(file,
					bulkExhibitBean.getFileName(), bulkExhibitBean.getRfaIdList());
			Map<Long, NewExhibitRequest> validExhibitRequestMap = newExhibitService
					.validateExhibitData(exhibitRequestMap);
			this.saveExhibitData(validExhibitRequestMap, bulkActionBean);
		} catch (Exception e) {
			LOGGER.error("Invalid file content uploaded by user:\n" + e);
			throw new IllegalArgumentException(e);
		}
	}

	private void saveExhibitData(Map<Long, NewExhibitRequest> exhibitRequestMap, BulkActionBean bulkActionBean) {
		try {
			Collection<Future<Long>> futures = new ArrayList<Future<Long>>();
			Set<Long> keySet = exhibitRequestMap.keySet();
			for (Long rfaId : keySet) {
				NewExhibitRequest newExhibitRequest = exhibitRequestMap.get(rfaId);
				futures.add(this.updateExhibit(rfaId, bulkActionBean.getUserId(), null, newExhibitRequest, true));
			}
			for (Future<Long> future : futures) {
				future.get();
			}
		} catch (Exception e) {
			LOGGER.error("Error while updating exhibit values:\n" + e);
			throw new IllegalArgumentException(e);
		}
	}

	private Future<Long> updateExhibit(Long rfaId, Long userId, Long exhibitId, NewExhibitRequest newExhibitRequest,
			boolean isBulkUpdate) {
		try {
			return newExhibitService.updateExhibit(rfaId, userId, null, newExhibitRequest, true);
		} catch (Exception e) {
			LOGGER.error("Error while updating exhibit values for RFA Id:" + rfaId + " - Underlying Exception - " + e);
			amendmentLetterService.saveErrorMessage(RFAActionEnum.BULK_SAVE_EXHIBIT_DATA.getName(), rfaId,
					"Error while updating exhibit values for RFA Id:" + rfaId + " - Underlying Exception - " + e,
					userId);
		}
		return new AsyncResult<Long>(rfaId);
	}
}
