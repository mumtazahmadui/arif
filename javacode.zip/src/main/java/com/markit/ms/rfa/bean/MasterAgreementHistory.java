package com.markit.ms.rfa.bean;

import java.util.List;


public class MasterAgreementHistory {
	private Long masterAgreementId;
	private List<AmendmentLetter> amendmentLetters;
	public Long getMasterAgreementId() {
		return masterAgreementId;
	}
	public void setMasterAgreementId(Long masterAgreementId) {
		this.masterAgreementId = masterAgreementId;
	}
	public List<AmendmentLetter> getAmendmentLetters() {
		return amendmentLetters;
	}
	public void setAmendmentLetters(List<AmendmentLetter> amendmentLetters) {
		this.amendmentLetters = amendmentLetters;
	}
}
