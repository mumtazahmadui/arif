package com.markit.ms.rfa.batch;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.AfterStep;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import com.google.common.collect.Maps;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.kyc.security.service.userxs.ServiceUserSessionManager;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.SleeveEntityRequest;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

public class BulkRFAUploadRequestProcessedItemReader implements ItemReader<Map<Long, List<RfaBulkUploadRow>>> {

	@Value("#{jobParameters['userId']}")
	private String userId;

	private Long bulkRequestId;

	private int index = 0;

	List<RfaBulkUploadRow> errorRowList = new ArrayList<RfaBulkUploadRow>();

	private List<Long> listOfKeys = new ArrayList<Long>();
	private static final Logger logger = LoggerFactory.getLogger(BulkRFAUploadRequestProcessedItemReader.class);

	private Map<Long, Map<Long, List<RfaBulkUploadRow>>> rfaCreateMap = new HashMap<Long, Map<Long, List<RfaBulkUploadRow>>>();

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Value("#{jobParameters['mcpmCreateSleeveEntityUrl']}")
	private String mcpmCreateSleeveEntityUrl;

	@Resource(name = "rsServiceUserSessionManager")
	private ServiceUserSessionManager serviceUserSessionManager;

	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	@Override
	public Map<Long, List<RfaBulkUploadRow>> read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		if (index == rfaCreateMap.size()) {
			return null;
		}
		return rfaCreateMap.get(listOfKeys.get(index++));
	}

	@BeforeStep
	public void initializeValues(StepExecution stepExecution) {

		List<RfaBulkUploadRow> rfaBulkUploadRows = (List<RfaBulkUploadRow>) stepExecution.getJobExecution()
				.getExecutionContext().get("rfaCreateList");

		if (rfaBulkUploadRows != null && !rfaBulkUploadRows.isEmpty()) {
			try {
				createSleeveEntity(rfaBulkUploadRows);
				convertRowListMap(rfaBulkUploadRows);
				for (Long key : rfaCreateMap.keySet()) {
					listOfKeys.add(key);
				}
			} catch (Exception e) {
				listOfKeys = null;
				logger.error(e.getMessage());
				stepExecution.getJobExecution().getExecutionContext().put("errorRowList", errorRowList);
			}
		}
	}

	private void convertRowListMap(List<RfaBulkUploadRow> rfaBulkUploadRows) throws Exception {

		List<RfaBulkUploadRow> rfaBulkUploadRowsMAId;
		List<RfaBulkUploadRow> rfaBulkUploadRowsLTId;
		RfaBulkUploadRow placeHolderRow = null;
		try {
			Map<Long, List<RfaBulkUploadRow>> mlIdentifierMap = new HashMap<Long, List<RfaBulkUploadRow>>();

			for (RfaBulkUploadRow bulkUploadRow : rfaBulkUploadRows) {
				placeHolderRow = bulkUploadRow;
				if (mlIdentifierMap.get(bulkUploadRow.getMasterAgreementId()) == null) {
					rfaBulkUploadRowsMAId = new ArrayList<RfaBulkUploadRow>();
					rfaBulkUploadRowsMAId.add(bulkUploadRow);
					mlIdentifierMap.put(bulkUploadRow.getMasterAgreementId(), rfaBulkUploadRowsMAId);
				} else {
					removeDuplicateRow(mlIdentifierMap, bulkUploadRow);
					removeDuplicateActionRow(mlIdentifierMap, bulkUploadRow);
					if (mlIdentifierMap.get(bulkUploadRow.getMasterAgreementId()) == null) {
						rfaBulkUploadRowsMAId = new ArrayList<RfaBulkUploadRow>();
						rfaBulkUploadRowsMAId.add(bulkUploadRow);
						mlIdentifierMap.put(bulkUploadRow.getMasterAgreementId(), rfaBulkUploadRowsMAId);
					} else {
						mlIdentifierMap.get(bulkUploadRow.getMasterAgreementId()).add(bulkUploadRow);
					}
				}

			}

			for (Long key : mlIdentifierMap.keySet()) {
				Map<Long, List<RfaBulkUploadRow>> LTIdentifierMap = new HashMap<Long, List<RfaBulkUploadRow>>();

				for (RfaBulkUploadRow bulkUploadRow : mlIdentifierMap.get(key)) {
					placeHolderRow = bulkUploadRow;
					for (BulkUploadAction action : bulkUploadRow.getRequestIdentified()) {
						if ((LTIdentifierMap.isEmpty()) || (CommonUtil.isNotNull(bulkUploadRow.getLetterTemplate())
								&& CommonUtil.isNotNull(bulkUploadRow.getLetterTemplate().get(action))
								&& CommonUtil.isNull(
										LTIdentifierMap.get(bulkUploadRow.getLetterTemplate().get(action).getId())))) {
							rfaBulkUploadRowsLTId = new ArrayList<RfaBulkUploadRow>();
							rfaBulkUploadRowsLTId.add(bulkUploadRow);
							LTIdentifierMap.put(bulkUploadRow.getLetterTemplate().get(action).getId(),
									rfaBulkUploadRowsLTId);
						} else if (!rowStoredAlready(bulkUploadRow, LTIdentifierMap,
								bulkUploadRow.getLetterTemplate().get(action).getId())) {
							LTIdentifierMap.get(bulkUploadRow.getLetterTemplate().get(action).getId())
									.add(bulkUploadRow);
						}
					}
				}
				rfaCreateMap.put(key, LTIdentifierMap);
			}
		} catch (Exception e) {
			errorRowList.add(placeHolderRow);
			e.printStackTrace();
			throw new Exception("Exception occurred in convertRowListMap method");
		}
	}

	// to restrict from again inserting the same row in map in case of multiple
	// requests are there in row
	private boolean rowStoredAlready(RfaBulkUploadRow bulkUploadRow, Map<Long, List<RfaBulkUploadRow>> LTIdentifierMap,
			Long key) {
		for (RfaBulkUploadRow previousRow : LTIdentifierMap.get(key)) {
			if (CommonUtil.isNotNull(previousRow) && previousRow.equals(bulkUploadRow)) {
				return true;
			}
		}
		return false;
	}

	private void createSleeveEntity(List<RfaBulkUploadRow> rfaBulkUploadRows) throws Exception {

		for (RfaBulkUploadRow rfaRow : rfaBulkUploadRows) {
			Long companyId = rfaRow.getRfaUploadTemplate().getCompanyId();
			if (CommonUtil.isNotNull(rfaRow.getSleeveClientIdentifier())
					&& (CommonUtil.isNull(rfaRow.getSleeveEntityId()))) {
				SleeveEntityRequest sleeveEntity = new SleeveEntityRequest();
				sleeveEntity = uploadTemplateDAO.getParentEntityRecord(rfaRow.getPartyBEntityId(), companyId);
				String legalName = sleeveEntity.getLegalName() + " - " + rfaRow.getSleeveClientIdentifier();
				sleeveEntity.setCompanyId(companyId);
				sleeveEntity.setUserId(Long.parseLong(userId));
				sleeveEntity.setName(legalName);
				sleeveEntity.setLegalName(legalName);
				sleeveEntity.setParentEntityId(rfaRow.getPartyBEntityId());
				sleeveEntity.setMonikerName(rfaRow.getSleeveClientIdentifier());
				sleeveEntity.setNameToUse(RFAConstants.NAME_TO_USE);
				Long sleeveEntityId = uploadTemplateDAO.getSleeveEntity(legalName, companyId);
				if (CommonUtil.isNull(sleeveEntityId)) {
					logger.info("Creating " + legalName + " entity in MCPM");
					createSleeveEntity(rfaRow, companyId, sleeveEntity);
					sleeveEntityId = uploadTemplateDAO.getSleeveEntity(legalName, companyId);
					logger.info(legalName + " created in MCPM");
				}
				rfaRow.setSleeveEntityId(sleeveEntityId);

			}

		}
	}

	private void createSleeveEntity(RfaBulkUploadRow rfaBulkUploadRow, Long companyId, SleeveEntityRequest entity)
			throws Exception {
		Map<String, Object> uriParams = Maps.newHashMap();
		uriParams.put("company", companyId);

		HttpStatus httpStatus = null;
		try {
			String auth = serviceUserSessionManager.validateSession().getOwnerName() + ":"
					+ serviceUserSessionManager.validateSession().getTicketId().getBytes();
			byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
			String authHeader = "Basic " + new String(encodedAuth);

			RequestEntity<SleeveEntityRequest> requestEntity = RequestEntity
					.post(new UriTemplate(mcpmCreateSleeveEntityUrl).expand(uriParams))
					.header(HttpHeaders.AUTHORIZATION,
							WebUtils.createBasicAuthHeaderValue(
									serviceUserSessionManager.validateSession().getOwnerName(),
									serviceUserSessionManager.validateSession().getTicketId().getBytes()))
					.contentType(org.springframework.http.MediaType.APPLICATION_JSON).body(entity);

			RestTemplate restTemplate = new RestTemplate();
			httpStatus = restTemplate.exchange(requestEntity, String.class).getStatusCode();

			logger.error(httpStatus.toString());
		} catch (Exception e) {
			errorRowList.add(rfaBulkUploadRow);
			logger.error("Updating entity " + entity.getLegalName() + " failed.");
			logger.error(e.getMessage());
			throw new Exception("Exception in creating/updating sleeve entity");
		}
	}

	private void removeDuplicateRow(Map<Long, List<RfaBulkUploadRow>> mlIdentifierMap, RfaBulkUploadRow bulkUploadRow) {
		List<RfaBulkUploadRow> listOfRows = mlIdentifierMap.get(bulkUploadRow.getMasterAgreementId());
		for (RfaBulkUploadRow row : listOfRows) {
			if (row.equals(bulkUploadRow)) {
				mlIdentifierMap.get(bulkUploadRow.getMasterAgreementId()).remove(row);
				break;
			}
		}

	}

	private void removeDuplicateActionRow(Map<Long, List<RfaBulkUploadRow>> mlIdentifierMap,
			RfaBulkUploadRow currentRow) {
		List<RfaBulkUploadRow> listOfRows = new ArrayList<RfaBulkUploadRow>(
				mlIdentifierMap.get(currentRow.getMasterAgreementId()));
		for (RfaBulkUploadRow previousRow : listOfRows) {
			if (!currentRow.getMasterAgreementId().equals(previousRow.getMasterAgreementId())) {
				break;
			}
			if (CommonUtil.isNotNull(previousRow.getPartyBEntityId())
					&& !currentRow.getPartyBEntityId().equals(previousRow.getPartyBEntityId())) {
				continue;
			} else if (CommonUtil.isNull(previousRow.getPartyBEntityId())) {
				handleNewPartyBAddition(mlIdentifierMap, previousRow, currentRow);
			}

			Iterator<BulkUploadAction> itr = previousRow.getRequestIdentified().iterator();
			while (itr.hasNext()) {
				BulkUploadAction action = (BulkUploadAction) itr.next();
				if (currentRow.getRequestIdentified().contains(action)) {
					if ((action == BulkUploadAction.SLEEVE_ADDITION || action == BulkUploadAction.SLEEVE_REMOVAL)
							&& previousRow.getSleeveEntityId().equals(currentRow.getSleeveEntityId())) {
						itr.remove();
					} else if (action != BulkUploadAction.SLEEVE_ADDITION
							&& action != BulkUploadAction.SLEEVE_REMOVAL) {
						itr.remove();
					}
				}

				// To handle the case where sleeve removal and partyB removal are in same file
				// in different row
				if (currentRow.getRequestIdentified().contains(BulkUploadAction.REMOVAL)
						&& previousRow.getRequestIdentified().contains(BulkUploadAction.SLEEVE_REMOVAL)) {
					previousRow.getRequestIdentified().remove(BulkUploadAction.SLEEVE_REMOVAL);
				} else if (currentRow.getRequestIdentified().contains(BulkUploadAction.SLEEVE_REMOVAL)
						&& previousRow.getRequestIdentified().contains(BulkUploadAction.REMOVAL)) {
					currentRow.getRequestIdentified().remove(BulkUploadAction.SLEEVE_REMOVAL);
				}
			}
		}
	}

	private void handleNewPartyBAddition(Map<Long, List<RfaBulkUploadRow>> mlIdentifierMap,
			RfaBulkUploadRow previousRow, RfaBulkUploadRow currentRow) {
		if (CommonUtil.isNotEqual(previousRow.getPartyBTrueLegalName(), currentRow.getPartyBTrueLegalName())) {
			return;
		}
		for (BulkUploadAction action : currentRow.getRequestIdentified()) {
			if (previousRow.getRequestIdentified().contains(action)) {
				previousRow.getRequestIdentified().remove(action);
			}
		}
	}

}
