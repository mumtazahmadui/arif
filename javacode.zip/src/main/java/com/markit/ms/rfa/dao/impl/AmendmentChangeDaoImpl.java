package com.markit.ms.rfa.dao.impl;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.AmendmentChangeAudit;
import com.markit.ms.rfa.bean.AmendmentCommentAudit;
import com.markit.ms.rfa.bean.CommentAudit;
import com.markit.ms.rfa.dao.IAmendmentChangeDAO;

@Repository
public class AmendmentChangeDaoImpl extends BaseDAOImpl implements IAmendmentChangeDAO {

	private final byte[] nullByte = "".getBytes();

	@Override
	public void saveRfaCommentAudit(List<AmendmentCommentAudit> commentAuditList, Long rfaid, String source,
			String partyType, String query) {
		if (commentAuditList == null) {
			return;
		}
		Timestamp date = new Timestamp(System.currentTimeMillis());
		commentAuditList.sort((AmendmentCommentAudit a1 ,AmendmentCommentAudit a2)->a1.getSequence().compareTo(a2.getSequence()));
		for (AmendmentCommentAudit amendmentCommentAudit : commentAuditList) {
			for (CommentAudit commentAudit : amendmentCommentAudit.getComments()) {
				MapSqlParameterSource params = new MapSqlParameterSource()
						.addValue("rfaid", rfaid)
						.addValue("pinid", amendmentCommentAudit.getId())
						.addValue("location", amendmentCommentAudit.getSequence())
						.addValue("action", amendmentCommentAudit.getAction())
						.addValue("attribute", amendmentCommentAudit.getAttributes())
						.addValue("commentid", commentAudit.getId())
						.addValue("userid", commentAudit.getUserId())
						.addValue("username", commentAudit.getUserName())
						.addValue("previous", nullByte)
						.addValue("comment",commentAudit.getText() )
						.addValue("value",nullByte)
						.addValue("metadata", "COMMENT")
						.addValue("source", source)
						.addValue("actiondate", new Timestamp(commentAudit.getTime()))
						.addValue("modifieddate", date)
						.addValue("partytype", partyType);
				namedParameterJdbcTemplate.update(query, params);
			}
		}

	}

	@Override
	public void saveRfaChangeLogAudit(List<AmendmentChangeAudit> changeAuditList, Long rfaid, String source,
			String partyType, String query) {
		if (changeAuditList == null) {
			return;
		}
		Timestamp date = new Timestamp(System.currentTimeMillis());
		for (AmendmentChangeAudit amendmentChangeAudit : changeAuditList) {
			MapSqlParameterSource params = new MapSqlParameterSource().addValue("rfaid", rfaid).addValue("pinid", "")
					.addValue("location", amendmentChangeAudit.getLocation())
					.addValue("action", amendmentChangeAudit.getAction()).addValue("attribute", null)
					.addValue("commentid", null).addValue("userid", 0)
					.addValue("username", amendmentChangeAudit.getEmail())
					.addValue("previous", amendmentChangeAudit.getPrevious()==null?nullByte:amendmentChangeAudit.getPrevious().getBytes())
					.addValue("value", amendmentChangeAudit.getCurrent().getBytes())
					.addValue("comment",amendmentChangeAudit.getComment())
					.addValue("metadata", "CHANGE LOG")
					.addValue("source", source).addValue("actiondate", amendmentChangeAudit.getActiondate())
					.addValue("modifieddate", date).addValue("partytype", partyType);
			namedParameterJdbcTemplate.update(query, params);
		}

	}
}
