package com.markit.ms.rfa.service.impl;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.MasterAgreementLookup;
import com.markit.ms.common.dao.IRfaLookupDao;
import com.markit.ms.common.model.MasterAgreementSearchRequest;
import com.markit.ms.common.service.IMasterAgreementLookupService;
import com.markit.ms.rfa.bean.AmendmentStatusObject;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.MasterAgreementHistory;
import com.markit.ms.rfa.bean.MasterlistValidatorBean;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.dao.IMasterAgreementDao;
import com.markit.ms.rfa.service.IMasterAgreementService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class MasterAgreementServiceImpl implements IMasterAgreementService {

	@Autowired
	private IMasterAgreementDao masterAgreementDao;
	
	@Autowired
	private IMasterAgreementLookupService masterAgreementLookupService;
	
	@Autowired
	private IRfaLookupDao rfaLookupDao;
	
	@Override
	public List<MasterAgreement> getMasterAgreements(Long companyId, MasterAgreementSearchRequest searchRequest) {
		List<MasterAgreement> masterAgreements = masterAgreementDao.getMasterAgreements(companyId, searchRequest);
		return masterAgreements;
	}

	@Override
	public MasterAgreementHistory getAmendmentmentLetterHistory(Long companyId, Long agreementId) {
		return masterAgreementDao.getMasterAgreementHistory(companyId, agreementId);
	}

	@Override
	public List<PartyBEntity> getExistingPartyB(Long masterAgreementId, List<Long> partyBEntityIds, Long amendmentId) {
		return masterAgreementDao.getExistingPartyBListForValidation(masterAgreementId, partyBEntityIds, amendmentId);
	}
	
	@Override
	public Date getMasterAgreementDateById(Long masterAgreementId) {
		return masterAgreementDao.getMasterAgreementDateById(masterAgreementId);
	}

	@Override
	public List<AmendmentStatusObject> getAmendmentStatusOfModifiedEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId) {
		return masterAgreementDao.getAmendmentStatusOfModifiedEntityNotYetResponded(masterAgreementId, amendmentId, entityId);
	}
	
	@Override
	public String getAmendmentStatusOfFNCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId) {
		return masterAgreementDao.getAmendmentStatusOfFNCEntityNotYetResponded(masterAgreementId, amendmentId, entityId);
	}
	
	@Override
	public String getAmendmentStatusOfEVCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId) {
		return masterAgreementDao.getAmendmentStatusOfEVCEntityNotYetResponded(masterAgreementId, amendmentId, entityId);
	}

	@Override
	public String getMasterlistTrueLegalName(Long entityId, Long masterAgreementId) {
		return masterAgreementDao.getMasterlistTrueLegalName(entityId, masterAgreementId);
	}
	
	@Override
	public String getRequestTypeForValidation(Long partybId) {
		return masterAgreementDao.getRequestTypeForValidation(partybId);
	}

	@Override
	public String getMasterlistMlTemplateName(Long masterAgreementId) {
		return masterAgreementDao.getMasterlistMlTemplateName(masterAgreementId);
	}

	@Override
	public String getMlTemplateWithSleeve(Long masterAgreementId) {
		return masterAgreementDao.getMlTemplateWithSleeve(masterAgreementId);
	}

	@Override
	public String getMlTemplateWithSleeveNameByAmendment(Long amendmentId) {
		return masterAgreementDao.getMlTemplateWithSleeveByAmednment(amendmentId);
	}

	@Override
	public void updateMasterAgreement(Long amendmentId) {
		masterAgreementDao.updateMasterAgreement(amendmentId);
		
	}

	@Override
	public RfaBulkUploadRow determineMLExhibitLinkage(RfaBulkUploadRow rfaBulkUploadRow) {
		RfaBulkUploadRow rf=masterAgreementDao.checkMasterListExhibitLinkage(rfaBulkUploadRow);
		return rf;
	}

	@Override
	public void getMasterAgreement(RfaBulkUploadRow rfaBulkUploadRow) {

		if (CommonUtil.isEqual(RFAConstants.REF_TABLE,
				rfaBulkUploadRow.getRfaUploadTemplate().getRule(RFAConstants.MASTERLIST_IDENTIFIER))) {

			MasterAgreementLookup lookup = masterAgreementLookupService.getMasterAgreementLookup(
					rfaBulkUploadRow.getPartyATrueLegalName(), rfaBulkUploadRow.getAgreementType(),
					rfaBulkUploadRow.getAgreementDateFormatted(), rfaBulkUploadRow.getMlIdentifier(),
					rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());
			if (CommonUtil.isNull(lookup)) {
				rfaBulkUploadRow.addError(RFAConstants.MASTER_AGREEMENT_NOT_FOUND);
				return;
			} else {
				rfaBulkUploadRow.setMasterAgreementId(lookup.getMasterAgreementId());
				if(CommonUtil.isNull(rfaBulkUploadRow.getMasterAgreementId()) || rfaBulkUploadRow.getMasterAgreementId() == 0) {
					rfaBulkUploadRow.addError(RFAConstants.MASTER_AGREEMENT_NOT_FOUND);
					return;
				}
			}
		} else {
			getMasterAgreementByDetails(rfaBulkUploadRow);
		}

		if (CommonUtil.isNotNull(rfaBulkUploadRow.getMasterAgreementId())) {
			MasterAgreement masterAgreement = masterAgreementDao
					.getMasterAgreementById(rfaBulkUploadRow.getMasterAgreementId());
			rfaBulkUploadRow.setMasterAgreement(masterAgreement);
			rfaBulkUploadRow.setMlIdentifier(masterAgreement.getMasterlistIdentifier());
		}

	}

	private void getMasterAgreementByDetails(RfaBulkUploadRow rfaBulkUploadRow) {

		MasterlistValidatorBean masterAgreement = rfaLookupDao.getMasterAgreementByDetails(
				rfaBulkUploadRow.getPartyATrueLegalName(), rfaBulkUploadRow.getAgreementType(),
				rfaBulkUploadRow.getAgreementDateFormatted(), rfaBulkUploadRow.getInvestmentManager(),
				rfaBulkUploadRow.getMlIdentifier(), rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId());

		if (CommonUtil.isNotNull(masterAgreement)) {
			rfaBulkUploadRow.setMasterAgreementId(masterAgreement.getId());
		} else {
			rfaBulkUploadRow.addError(RFAConstants.MASTER_AGREEMENT_NOT_FOUND);
		}
	}
	
	@Override
	public List<PartyBEntity> getExistingPartyB(Long masterAgreementId, List<Long> partyBEntityIds, Long amendmentId, String callingSource) {
		return masterAgreementDao.getExistingPartyBListForValidation(masterAgreementId, partyBEntityIds, amendmentId, callingSource);
	}
}
