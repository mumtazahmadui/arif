package com.markit.ms.rfa.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.repository.core.StJdbcTemplate;
import com.markit.ms.common.constants.PartyBPlaceholderConstants;
import com.markit.ms.common.dao.IPartyBPlaceholderDao;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.dao.resultsetextractor.LineBreakResultSetExtractor;
import com.markit.ms.rfa.placeholders.request.BSPartyBTableRequest;
import com.markit.ms.rfa.placeholders.request.LineBreak;
import com.markit.ms.rfa.placeholders.request.SSPartyBTableRequest;
import com.markit.ms.rfa.placeholders.request.SSResponse;
import com.markit.ms.rfa.util.RFAConstants;
@Repository
public class PartyBPlaceholderDaoImpl extends BaseDAOImpl implements IPartyBPlaceholderDao {
	
	@Value("${UPDATE_AMENDMENT_SS_NEXT_STEP_TASK_PROC}")
    private String UPDATE_AMENDMENT_SS_NEXT_STEP_TASK_PROC;
	
	@Value("${UPDATE_REJECTED_PARTYB_FOR_AMENDMENT_TO_REJECTED_SENT}")
    private String UPDATE_REJECTED_PARTYB_FOR_AMENDMENT_TO_REJECTED_SENT;
	
	@Value("${PLACE_HOLDER_PARTYB_INSERT_LINE_BREAKS}")
    private String PLACE_HOLDER_PARTYB_INSERT_LINE_BREAKS;
	
	@Value("${PLACE_HOLDER_PARTYB_DELETE_OLD_LINE_BREAKS}")
    private String PLACE_HOLDER_PARTYB_DELETE_OLD_LINE_BREAKS;

	@Value("${SS_PARTYB_RESPONSE_EXHIBIT_VALUE_CHANGE}")
    private String SS_PARTYB_RESPONSE_EXHIBIT_VALUE_CHANGE;
	
	@Value("${SS_PARTYB_RESPONSE_FUND_NAME_CHANGE}")
    private String SS_PARTYB_RESPONSE_FUND_NAME_CHANGE;
	
	@Value("${SS_PARTYB_RESPONSE_ADDITION_REMOVAL}")
    private String SS_PARTYB_RESPONSE_ADDITION_REMOVAL;
	
	@Value("${PARTYB_TABLE_GET_LINE_BREAKS}")
    private String PARTYB_TABLE_GET_LINE_BREAKS;
	
	@Value("${PARTYB_TABLE_GET_PREVIOUS_LINE_BREAKS}")
    private String PARTYB_TABLE_GET_PREVIOUS_LINE_BREAKS;

	@Value("${GET_ALL_PARTYB_STATUS}")
	private String GET_ALL_PARTYB_STATUS;
	
	@Value("${UPDATE_STATE_TRANSITION_FOR_BOTH_BS_AND_SS}")
    private String UPDATE_STATE_TRANSITION_FOR_BOTH_BS_AND_SS;
	
	@Value("${UPDATE_AMENDMENT_LETTER}")
	private String UPDATE_AMENDMENT_LETTER;
	
	@Resource protected StJdbcTemplate  jdbcTemplate;
	
	@Override
	public List<Map<String,String>> getLineBreaks(final Long amendmentId,
			final String placeholderType) {
		SqlParameterSource params = new MapSqlParameterSource()
		.addValue(PartyBPlaceholderConstants.AMENDMENT_ID, amendmentId)
		.addValue(PartyBPlaceholderConstants.PARTYB_PLACEHOLDER_TYPE, placeholderType);
		List<Map<String,String>> rows = namedParameterJdbcTemplate.query(PARTYB_TABLE_GET_LINE_BREAKS, params, new LineBreakResultSetExtractor());
		return rows;
	}
	
	
	@Override
	public void updateBSLineBreaks(final Long amendmentId,
			final Long userId,
			final String placeholderType,
			final BSPartyBTableRequest bsPartyBTableRequest) {
		// 1. Remove old line breaks.
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue(PartyBPlaceholderConstants.PLACEHOLDER_TYPE, placeholderType)
		.addValue(PartyBPlaceholderConstants.AMENDMENT_ID, amendmentId)
		.addValue(PartyBPlaceholderConstants.USER_ID, userId);
		namedParameterJdbcTemplate.update(PLACE_HOLDER_PARTYB_DELETE_OLD_LINE_BREAKS, paramSource);
		
		// 2. Batch update New line breaks.
		final List<LineBreak> lineBreaks = bsPartyBTableRequest.getLineBreaks();
		Map<String, Object>[] paramList = new Map[lineBreaks.size()];
		for(int index=0; index < paramList.length ; index++) {
			LineBreak lineBreak = lineBreaks.get(index);
			paramList[index] = Maps.newHashMap();
			paramList[index].put(PartyBPlaceholderConstants.AMENDMENT_ID, amendmentId);
			paramList[index].put(PartyBPlaceholderConstants.LINE_BREAK_INDEX, lineBreak.getLineBreakIndex());
			paramList[index].put(PartyBPlaceholderConstants.LINE_BREAK_TEXT, lineBreak.getLineBreakText()!=null? lineBreak.getLineBreakText().getBytes() : null);
			paramList[index].put(PartyBPlaceholderConstants.SHOW_HEADER_TEXT, lineBreak.getShowHeaderText().getBytes());
			paramList[index].put(PartyBPlaceholderConstants.PLACEHOLDER_TYPE, placeholderType);
			paramList[index].put(PartyBPlaceholderConstants.EXHIBIT_CONTROL_COLUMN_ID, lineBreak.getExhibitControlColumnId());
			paramList[index].put(PartyBPlaceholderConstants.USER_ID, userId);
		}
		
		jdbcTemplate.batchUpdate(PLACE_HOLDER_PARTYB_INSERT_LINE_BREAKS, paramList);
	}

	@Override
	public void updateSSResponse(Long amendmentId, Long userId,
			SSPartyBTableRequest ssPartyBTableRequest) {
	
		// 2. Batch update New line breaks.
		final List<SSResponse> ssResponses = ssPartyBTableRequest.getSsResponses();
		Map<String, Object>[] paramList = new Map[ssResponses.size()];
		for(int index=0; index < paramList.length ; index++) {
			SSResponse ssResponse = ssResponses.get(index);
			paramList[index] = Maps.newHashMap();
			paramList[index].put(PartyBPlaceholderConstants.PARTYB_ID, ssResponse.getPartyBId());
			paramList[index].put(PartyBPlaceholderConstants.SS_RESPONSE_COMMENTS, ssResponse.getResponseComments());
			paramList[index].put(PartyBPlaceholderConstants.SS_RESPONSE_STATUS, ssResponse.getResponseStatus());
			paramList[index].put(PartyBPlaceholderConstants.USER_ID, userId);
			if(PartyBPlaceholderConstants.PARTYB_FUND_NAME_CHANGE_PLACEHOLDER.equals(ssPartyBTableRequest.getPlaceHolderType())) {
				paramList[index].put(PartyBPlaceholderConstants.FUND_NAME_CHANGE_ID, ssResponse.getPartyBFundNameChangeId());
			}
			if(PartyBPlaceholderConstants.PARTYB_EXHIBIT_VALUE_CHANGE_PLACEHOLDER.equals(ssPartyBTableRequest.getPlaceHolderType())) {
				paramList[index].put(PartyBPlaceholderConstants.EXHIBIT_VALUE_CHANGE_ID, ssResponse.getPartyBExhibitValueChangeId());
			}
		}
		if(PartyBPlaceholderConstants.PARTYB_FUND_NAME_CHANGE_PLACEHOLDER.equals(ssPartyBTableRequest.getPlaceHolderType())) {
			jdbcTemplate.batchUpdate(SS_PARTYB_RESPONSE_FUND_NAME_CHANGE, paramList);
		} else if(PartyBPlaceholderConstants.PARTYB_EXHIBIT_VALUE_CHANGE_PLACEHOLDER.equals(ssPartyBTableRequest.getPlaceHolderType())) {
			jdbcTemplate.batchUpdate(SS_PARTYB_RESPONSE_EXHIBIT_VALUE_CHANGE, paramList);
		} else {
			jdbcTemplate.batchUpdate(SS_PARTYB_RESPONSE_ADDITION_REMOVAL, paramList);
		}
		        
	}
	
	@Override
	public void updateAmendmentBySsResponse(Long amendmentId, Long userId){
		SqlParameterSource paramSource = new MapSqlParameterSource()
        .addValue("amendmentId", amendmentId);
		List<String> allPartyBStatus = jdbcTemplate.query(GET_ALL_PARTYB_STATUS, paramSource, new RowMapper<String>() {
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getString("PARTYB_ACK_STATUS");
			}
		});
		
		Boolean allPartyBRejected = true;
		if(allPartyBStatus.size() > 0){
			for(String partyBStatus : allPartyBStatus){
				if(!(partyBStatus != null && ((partyBStatus.equalsIgnoreCase("Rejected")) ||
						partyBStatus.equalsIgnoreCase("Rejected Sent") || partyBStatus.equalsIgnoreCase("Accepted Sent") ||
						partyBStatus.equalsIgnoreCase("Withdrawn"))))
				{
					allPartyBRejected = false;
				}
			}
		}
		
		if(allPartyBRejected){
			MapSqlParameterSource params = new MapSqlParameterSource()
			.addValue("amendment_id", amendmentId)
			.addValue("amendmentStatus", AmendmentStatus.COMPLETED.getDisplayName())
			.addValue("created_by", userId);
			namedParameterJdbcTemplate.update(UPDATE_STATE_TRANSITION_FOR_BOTH_BS_AND_SS, params);
			namedParameterJdbcTemplate.update(UPDATE_REJECTED_PARTYB_FOR_AMENDMENT_TO_REJECTED_SENT, params);
		}
	}


	public void updateAmendmentStatusAndNextStep(Long amendmentId){
		//1. Update Sell side next steps
		 SqlParameterSource params = new MapSqlParameterSource()
	        .addValue("amendmentId",amendmentId)
	        .addValue("action", RFAConstants.ACTION_SS_UPDATE);
	    	namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_SS_NEXT_STEP_TASK_PROC, params);
	}
	@Override
	public List<Map<String, String>> getPreviousLineBreaks(Long amendmentId,
			String placeholderType) {
		SqlParameterSource params = new MapSqlParameterSource()
		.addValue(PartyBPlaceholderConstants.AMENDMENT_ID, amendmentId)
		.addValue(PartyBPlaceholderConstants.PARTYB_PLACEHOLDER_TYPE, placeholderType);
		List<Map<String,String>> rows = namedParameterJdbcTemplate.query(PARTYB_TABLE_GET_PREVIOUS_LINE_BREAKS, params, new LineBreakResultSetExtractor());
		return rows;
	}

	@Override
	public void updateAmendment(Long amendmentId, Long userId){
		SqlParameterSource params = new MapSqlParameterSource()
		.addValue("id", amendmentId)
		.addValue("modified_by", userId);
		namedParameterJdbcTemplate.update(UPDATE_AMENDMENT_LETTER, params);
	}
}
