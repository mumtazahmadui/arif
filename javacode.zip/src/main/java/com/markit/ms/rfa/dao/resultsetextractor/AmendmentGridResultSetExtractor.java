package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.PartyBDeskReviewStatus;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;
import com.markit.ms.rfa.bean.enumeration.RFADealerAction;
import com.markit.ms.rfa.bean.enumeration.RFARequestType;
import com.markit.ms.rfa.util.PartyBDeskConstants;

public class AmendmentGridResultSetExtractor implements ResultSetExtractor<List<AmendmentLetter>> {
	private static final Logger LOGGER = LoggerFactory.getLogger(AmendmentGridResultSetExtractor.class.getName());

	private boolean buySideGrid = false;
	public AmendmentGridResultSetExtractor(boolean buySideGrid) {
		this.buySideGrid = buySideGrid;
	}

	public List<AmendmentLetter> extractData(ResultSet rs) throws SQLException {
		Map<Long,AmendmentLetter > amendmentLetterMap = new LinkedHashMap<Long ,AmendmentLetter>();
		while (rs.next()) {
			AmendmentLetter letter = amendmentLetterMap.get(rs.getLong("amendmentId"));
			if(letter == null){
				letter = new AmendmentLetter();
				letter.setId(rs.getLong("amendmentId"));
				letter.setwSignStatus(rs.getString("wSignStatus"));
				letter.setName(rs.getString("amendmentName"));
			//	letter.setContent(CommonUtil.getValueFromBase64(rs.getBytes("content")));
				letter.setAmendmentStatus(AmendmentStatus.fromString(rs.getString("amendmentStatus")));
                letter.setExhibitValued(rs.getInt("exhibitValued") == 1);
                letter.setExhibitTemplateId(rs.getLong("exhibitTemplateId")==0?null:rs.getLong("exhibitTemplateId"));
                letter.setTotalCount(rs.getLong("totalCount"));
                Exhibit exhibit = new Exhibit();
                exhibit.setId(rs.getLong("exhibitId"));
                letter.setExhibit(exhibit);
                letter.setFileId(rs.getLong("file_id"));
                MasterAgreement masterAgreement = new MasterAgreement();
                masterAgreement.setId(rs.getLong("masterAgreementId"));
                masterAgreement.setName(rs.getString("masterAgreementName"));
                masterAgreement.setMasterlistIdentifier(rs.getString("masterlistIdentifier"));
                masterAgreement.setMasterlistIdentifier(rs.getString("masterlistIdentifier"));
                masterAgreement.setAgreementDate(rs.getDate("masterAgreementDate"));
                masterAgreement.setMasterlistIdentifierAgreementType(rs.getString("masterlistIdentifierAgreementType"));
                masterAgreement.setAgreementType(rs.getString("agreementType"));
                Entity investmentManager = new Entity();
                investmentManager.setId(rs.getLong("investmentManagerId"));
                investmentManager.setName(rs.getString("investmentManagerName"));
                masterAgreement.setInvestmentManager(investmentManager);
                Entity partyACompany = new Entity();
                partyACompany.setName(rs.getString("partyAName"));
                partyACompany.setId(rs.getLong("partyACompId"));
                masterAgreement.setPartyA(partyACompany);
                letter.setMasterAgreement(masterAgreement);
                amendmentLetterMap.put(rs.getLong("amendmentId"), letter);
                letter.setPartyBEntities(new ArrayList<PartyBEntity>());
                letter.setSubmitedDate(rs.getDate("submit_date"));
                letter.setBsNextStep(rs.getString("bs_next_step"));
                letter.setSsNextStep(rs.getString("ss_next_step"));
                letter.setHistory(rs.getInt("history_exists")==1?true:false);
                
            	letter.setSignedCount((rs.getInt("bsSignCount")));
            	letter.setBsSignPlaceholderCount(rs.getInt("bsSignPlaceholderCount"));
                
            	letter.setIgnoreExhibit(rs.getInt("ignoreExhibit"));
            	
            	letter.setSignDisabled(rs.getBoolean("signDisabled"));
            	
            	if(buySideGrid) {
	            	/**
	            	 * set desk status as checked for 1st time
	            	 * update amendment letter status later based on partyB desk status
	            	 */
	            	letter.setAmendmentDeskOneStatus(PartyBDeskConstants.CHECKED);
	            	letter.setAmendmentDeskTwoStatus(PartyBDeskConstants.CHECKED);
            	}
            	
                if(!buySideGrid) {
                	letter.setSignedCount((rs.getInt("ssSignCount")));
                	letter.setSsSignPlaceholderCount(rs.getInt("ssSignPlaceholderCount"));
                	letter.setAmendmentStatus(AmendmentStatus.fromString(rs.getString("amendmentStatus_SS")));
	                
                }
			}
			PartyBEntity partyBEntity = new PartyBEntity();
			partyBEntity.setId(rs.getLong("partybId"));
			partyBEntity.setIsAdded(rs.getLong("isAdded") == 1 ? true : false);
			Integer is_modified = rs.getInt("is_modified");
			partyBEntity.setIsModified((is_modified == null || is_modified == 0)? false : true);
			partyBEntity.setReason(rs.getString("partyBAckReason"));
			Entity entity = new Entity();
			entity.setLei(rs.getString("lei_name"));
			entity.setClientIdentifier(rs.getString("moniker_name"));
			entity.setTrueLegalName(rs.getString("partyBName"));
			entity.setName(rs.getString("partyBName"));
			partyBEntity.setEntity(entity);
			partyBEntity.setAcknowledgementStatus(PartyBAckStatus.fromString(rs.getString("partyBAckStatus")));
			
			RFADealerAction dealerAction=RFADealerAction.NOT_ACTIONED;

			if(partyBEntity.getAcknowledgementStatus() != null) {

				if (partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.WITHDRAWN){
					letter.getPartyBWithdrawn().add(partyBEntity);
					dealerAction = RFADealerAction.WITHDRAWN;
				}else if (partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.PENDING
						&& partyBEntity.getIsAdded()){
					letter.getPartyBPending().add(partyBEntity);
					dealerAction = RFADealerAction.PENDING;
				}else if (partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.REJECTED ||
						partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.REJECTED_SENT){
					letter.getPartyBRejected().add(partyBEntity);
					dealerAction = RFADealerAction.REJECTED;
				}else if (partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.ACCEPTED_SENT){
					letter.getPartyBAccepted().add(partyBEntity);
					dealerAction = RFADealerAction.EXECUTED;
					
				}else if (partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.ACCEPTED ||
						partyBEntity.getAcknowledgementStatus() == PartyBAckStatus.ACCEPTED_SIGNED){
					if(!buySideGrid) {
						letter.getPartyBAccepted().add(partyBEntity);
					}
					dealerAction = RFADealerAction.PENDING_EXECUTION;
				}
				
				
			}
			
			partyBEntity.setDealerAction(dealerAction.getName());

			
			RFARequestType requestType=null;
			if (partyBEntity.getIsAdded() && !partyBEntity.getIsModified()){
				letter.getPartyBAdded().add(partyBEntity);
				requestType = RFARequestType.ADDITION;
			} else if(partyBEntity.getIsModified()) {
				letter.getPartyBModification().add(partyBEntity);
				
				if(StringUtils.isNoneEmpty(rs.getString("fund_name_change_Id"))) {
					requestType = RFARequestType.MODIFICATION_FNC;
				}else if(StringUtils.isNoneEmpty(rs.getString("exhibit_value_change_id"))) {
					requestType = RFARequestType.MODIFICATION_EVC;
				}
			}
			else if(!partyBEntity.getIsAdded()){
				letter.getPartyBRemoved().add(partyBEntity);
				requestType = RFARequestType.REMOVAL;
			}
			
			partyBEntity.setRequestType(requestType!=null?requestType.getName():null);
			
			if(!buySideGrid) {
				setPartyBDeskStatus(rs, partyBEntity);				
			}else {
				setBuysideDeskStatus(rs, partyBEntity,letter);				
			}
						
			try {
				String showFilterFlag = String.valueOf(1);
				if (!(rs.getString("myStatusFlag").equals(showFilterFlag)
						&& rs.getString("entityIdFlag").equals(showFilterFlag)
						&& rs.getString("monikerNameFlag").equals(showFilterFlag)
						&& rs.getString("leiFlag").equals(showFilterFlag))) {
					partyBEntity.setPartyBHidden(true);
				}
				LOGGER.debug("extractData : partyb hidden : " + partyBEntity.getId() + " : "
						+ partyBEntity.isPartyBHidden());
			}catch (SQLException e) {
				LOGGER.error("extractData : column doesn't exists");
			}
			
			letter.getPartyBEntities().add(partyBEntity);
			
		}
		List<AmendmentLetter> amendmentList = new ArrayList<AmendmentLetter>(amendmentLetterMap.values());
		return amendmentList;
	}
	
	private void setBuysideDeskStatus(ResultSet rs, PartyBEntity partyBEntity, AmendmentLetter letter ) throws SQLException {
		PartyBDeskReviewStatus deskStatus = new PartyBDeskReviewStatus();
		deskStatus.setDeskOneStatus(rs.getInt("PARTYB_DESK_ONE_STATUS"));
		deskStatus.setDeskTwoStatus(rs.getInt("PARTYB_DESK_TWO_STATUS"));
		
		/**
		 * update amendment letter desk status based on partyB
		 * if all partyB's are checked then amendment letter status to be checked
		 * else unchecked
		 */
		letter.setAmendmentDeskOneStatus(letter.getAmendmentDeskOneStatus() & deskStatus.getDeskOneStatus());
		letter.setAmendmentDeskTwoStatus(letter.getAmendmentDeskTwoStatus() & deskStatus.getDeskTwoStatus());
		
		String cpdeskStatus = rs.getString("CP_DESK_STATUS");
		
		if(cpdeskStatus!=null) {
			String[] cpDeskArr = cpdeskStatus.split(",");
			
			Map<String,String> cpDeskStatusMap = new HashMap<>();
			for(int i=0;i<cpDeskArr.length;i++) {
				String[] cpDeskStatusArr = cpDeskArr[i].split("::");
				cpDeskStatusMap.put(cpDeskStatusArr[0],cpDeskStatusArr[1]);
			}
			
			deskStatus.setBsCPDeskStatus(cpDeskStatusMap);			
		}
		partyBEntity.setDeskStatus(deskStatus);
	}
	
	private void setPartyBDeskStatus(ResultSet rs,PartyBEntity partyBEntity) throws SQLException {
		PartyBDeskReviewStatus deskStatus = new PartyBDeskReviewStatus();
		deskStatus.setOnboardingEscalation(rs.getInt("ONBOARDING_ESCALATED"));
		deskStatus.setOnboardingNotified(rs.getInt("ONBOARDING_NOTIFIED"));
		deskStatus.setOnboardingInProgress(rs.getInt("ONBOARDING_IN_PROGRESS"));
		deskStatus.setOnboardingCompleted(rs.getInt("ONBOARDING_COMPLETED"));
		deskStatus.setKycEscalation(rs.getInt("KYC_ESCALATED"));
		deskStatus.setKycNotified(rs.getInt("KYC_NOTIFIED"));
		deskStatus.setKycInProgress(rs.getInt("KYC_IN_PROGRESS"));
		deskStatus.setKycCompleted(rs.getInt("KYC_COMPLETED"));
		deskStatus.setTaxEscalation(rs.getInt("TAX_ESCALATED"));
		deskStatus.setTaxNotified(rs.getInt("TAX_NOTIFIED"));
		deskStatus.setTaxInProgress(rs.getInt("TAX_IN_PROGRESS"));
		deskStatus.setTaxCompleted(rs.getInt("TAX_COMPLETED"));
		deskStatus.setCreditEscalation(rs.getInt("CREDIT_ESCALATED"));
		deskStatus.setCreditNotified(rs.getInt("CREDIT_NOTIFIED"));
		deskStatus.setCreditInProgress(rs.getInt("CREDIT_IN_PROGRESS"));
		deskStatus.setCreditCompleted(rs.getInt("CREDIT_COMPLETED"));
		deskStatus.setLegalEscalation(rs.getInt("LEGAL_ESCALATED"));
		deskStatus.setLegalNotified(rs.getInt("LEGAL_NOTIFIED"));
		deskStatus.setLegalInProgress(rs.getInt("LEGAL_IN_PROGRESS"));
		deskStatus.setLegalCompleted(rs.getInt("LEGAL_COMPLETED"));
		deskStatus.setOperationsEscalation(rs.getInt("OPERATIONS_ESCALATED"));
		deskStatus.setOperationsNotified(rs.getInt("OPERATIONS_NOTIFIED"));
		deskStatus.setOperationsInProgress(rs.getInt("OPERATIONS_IN_PROGRESS"));
		deskStatus.setOperationsCompleted(rs.getInt("OPERATIONS_COMPLETED"));
		deskStatus.setManagerEscalation(rs.getInt("MANAGER_ESCALATED"));
		deskStatus.setManagerNotified(rs.getInt("MANAGER_NOTIFIED"));
		deskStatus.setManagerInProgress(rs.getInt("MANAGER_IN_PROGRESS"));
		deskStatus.setManagerCompleted(rs.getInt("MANAGER_COMPLETED"));
		partyBEntity.setDeskStatus(deskStatus);
		
	}
}
