package com.markit.ms.rfa.service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.markit.ms.rfa.bean.NewExhibitRequest;

public interface INewExhibitService {

	Future<Long> updateExhibit(Long amendmentId, Long userId, Long exhibitId, NewExhibitRequest newExhibitRequest, boolean isBulkUpdate);

	Long getExhibitColId(Long amendmentId, String columnName);

	Map<Long, NewExhibitRequest> getExhibitRequestMap(byte[] file, String fileName, List<Long> rfaIds) throws Exception;

	Map<Long, NewExhibitRequest> validateExhibitData(Map<Long, NewExhibitRequest> exhibitRequestMap);

	void updateExhibit(Long amendmentId, NewExhibitRequest newExhibitRequest, Long userId);

	Long bulkUpdateExhibitData(Long fileId, String fileName, Long userId, Long companyId) throws Exception;
	
	Future<Long> updateExhibitSS(Long amendmentId, Long userId, Long exhibitId, NewExhibitRequest newExhibitRequest);
}
