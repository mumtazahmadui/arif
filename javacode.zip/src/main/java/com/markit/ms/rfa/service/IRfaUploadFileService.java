package com.markit.ms.rfa.service;

import java.util.List;

import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.bean.RFATemplateNames;
import com.markit.ms.rfa.bean.RFAUploadFile;
import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.dto.RfaUploadFileSearchRequest;
import com.markit.ms.rfa.dto.RfaUploadTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAUIException;

/**
 * @author sucheta.krishali
 *
 */
public interface IRfaUploadFileService {

	
	public List<RFAUploadFile> getUploadFileGrid(Long companyId, RfaUploadFileSearchRequest uploadFileSearchRequest);
	List<Lookup> getFilterUploadedBy(Long companyId, String filterString);
	List<Lookup> getFilterProcessingStatus(Long companyId, String filterString);
	List<Lookup> getTemplateNamesByCompany(Long companyId);

}
