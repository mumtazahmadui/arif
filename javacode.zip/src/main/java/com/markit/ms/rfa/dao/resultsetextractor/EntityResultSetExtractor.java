package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;

public class EntityResultSetExtractor implements ResultSetExtractor<List<Entity>> {

	@Override
	public List<Entity> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Map<Long, Entity> entityMap = new LinkedHashMap<Long, Entity>();
		
		while (rs.next()){
			Entity entity = entityMap.get(rs.getLong("entityid"));
			if (entity == null){
				entity = new Entity();
				entity.setId(rs.getLong("entityid"));
				entity.setName(rs.getString("legal_name"));
				entity.setClientIdentifier(rs.getString("moniker_name"));
				entity.setTrueLegalName(rs.getString("legal_name"));
				entity.setLei(rs.getString("lei_name"));
				entity.setValue(rs.getString("legal_name"));
				entity.setIsSleeve(null == rs.getString("is_sleeve") ? 0 : rs.getLong("is_sleeve"));
				entityMap.put(rs.getLong("entityid"), entity);
			}
		}
		List<Entity> list = new ArrayList<Entity>(entityMap.values());
		return list;
	}
	
}
