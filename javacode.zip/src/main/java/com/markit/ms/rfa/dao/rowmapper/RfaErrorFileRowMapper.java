package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.RfaErrorFile;

public class RfaErrorFileRowMapper implements RowMapper<RfaErrorFile> {

	public RfaErrorFile mapRow(ResultSet rs, int rowNum) throws SQLException {
		RfaErrorFile rfaErrorFile = new RfaErrorFile();
		rfaErrorFile.setId(rs.getLong("id"));
		rfaErrorFile.setFileName(rs.getString("fileName"));
		rfaErrorFile.setContentType(rs.getString("contentType"));
		rfaErrorFile.setBytes(rs.getBytes("bytes"));
		rfaErrorFile.setCreatedBy(rs.getLong("createdBy"));
		rfaErrorFile.setCompanyId(rs.getLong("companyId"));
		rfaErrorFile.setCreatedDate(rs.getDate("createdDate"));
		return rfaErrorFile;
	}
}
