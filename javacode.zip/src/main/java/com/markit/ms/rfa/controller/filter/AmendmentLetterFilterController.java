package com.markit.ms.rfa.controller.filter;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.exception.RFAGenericException;
import com.markit.ms.rfa.service.IAmendmentFilterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;

@RestController
@RequestMapping(value = "v1/company")
@Api(value="AmendmentLetterFilter", description= "AmendmentLetterFilter API")
public class AmendmentLetterFilterController {

	@Autowired
	private IAmendmentFilterService filterService;
	
	@RequestMapping(value = "{id}/amendment_letter_filter/review_status", method = RequestMethod.GET)
	public CommonBaseResponse<List<Lookup>> getReviewStatus(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = filterService.getReviewStatus(filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/amendment_letter_filter/agreement_date", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterAgreementDate(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getAgreementDate(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/amendment_letter_filter/investment_manager", method = RequestMethod.GET)
	public CommonBaseResponse<List<Lookup>> filterInvestmentManager(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<Lookup>> commonBaseResponse = null;
		commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = filterService.getInvestmentManager(companyIdFromSession, filterString, companyType);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/amendment_letter_filter/masterlist_identifier", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterMasterlistIdentifier(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<String>> commonBaseResponse = null;
		commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getMasterlistIdentifier(companyIdFromSession, filterString, companyType);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}

	@RequestMapping(value = "{id}/amendment_letter_filter/party_a", method = RequestMethod.GET)
	public CommonBaseResponse<List<Lookup>> filterPartyA(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = filterService.getPartyA(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}

	@RequestMapping(value = "{id}/amendment_letter_filter/party_b", method = RequestMethod.GET)
	public CommonBaseResponse<List<Lookup>> filterPartyB(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = filterService.getPartyB(companyIdFromSession, filterString, companyTypeFromSession);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}	
	
	@RequestMapping(value = "{id}/amendment_letter_filter/addition_action", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterAdditionAction(@PathVariable long id, @RequestParam(required=false) String filterString){
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getAdditionAction(filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}	
	
	@RequestMapping(value = "{id}/amendment_letter_filter/request_status", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterRequestStatus(@PathVariable long id,
			@RequestParam(required = false) String filterString, HttpServletRequest request) {
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list =null;
		if(CompanyType.isBSCompany(companyType)) {
			list = filterService.getRequestStatus(filterString);			
		}else {
			list = filterService.getSellsideRequestStatus(filterString);
		}
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}	
	
	@RequestMapping(value = "{id}/amendment_letter_filter/sellside_request_status", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterSellsideRequestStatus(@PathVariable long id, @RequestParam(required=false) String filterString){
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getSellsideRequestStatus(filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	
	@RequestMapping(value = "{id}/amendment_letter_filter/party_b_client_identifier", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterPartyBClientIdentifier(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getPartyBClientIdentifier(companyIdFromSession, filterString, companyTypeFromSession);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/amendment_letter_filter/party_b_lei", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterPartyBLei(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getPartyBLei(companyIdFromSession, filterString, companyTypeFromSession);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}	
	
	@RequestMapping(value = "{id}/amendment_letter_filter/submit_date", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterSubmitDate(@PathVariable long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		//String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = filterService.getSubmitdate(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/amendment_letter_filter/rfa_id", method = RequestMethod.GET)
	public CommonBaseResponse<List<Long>> filterRfaId(@PathVariable long id, @RequestParam(required=false) String filterString, 
			@RequestParam(required=false) String amendmentStatus, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<Long>> commonBaseResponse = new CommonBaseResponse<>();
		List<Long> list = filterService.getRfaId(companyIdFromSession, filterString, companyTypeFromSession, amendmentStatus);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}	
	
	@RequestMapping(value = "{id}/amendment_letter_filter/agreement_type", method = RequestMethod.GET)
	public CommonBaseResponse<List<String>> filterAgreementType(@PathVariable long id, @RequestParam(required=false) String filterString, 
			@RequestParam(required=false) String amendmentStatus, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<>();
		List<String> list = filterService.getAgreementType(companyIdFromSession, filterString, companyTypeFromSession);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/amendment_letter_filter/my_status", method = RequestMethod.GET)
	public CommonBaseResponse<List<Lookup>> getMyStatus(@PathVariable long id, @RequestParam(required=false) String filterString, 
			@RequestParam(required=false) String amendmentStatus, HttpServletRequest request){
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<>();
		if (!CompanyType.isSSCompany(companyTypeFromSession)) {
			throw new RFAGenericException("This user is unauthorized for the specified resource.", HttpStatus.UNAUTHORIZED);
		}
		List<Lookup> list = filterService.getMyStatus(filterString, companyTypeFromSession);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
}
