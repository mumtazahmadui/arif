package com.markit.ms.rfa.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.security.RolesAllowed;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.markit.fileutil.common.domain.MCFile;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.kyc.security.UserUtils;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.constants.PermissionConstants;
import com.markit.ms.common.model.CommonBaseRequest;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.rfa.bean.BulkNotificationBean;
import com.markit.ms.rfa.bean.BulkSignatoryNotificationBean;
import com.markit.ms.rfa.bean.BulkValidationBean;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.notifier.BulkActionEmailNotificationInvoker;
import com.markit.ms.rfa.command.validator.BulkActionValidationInvoker;
import com.markit.ms.rfa.command.validator.impl.NextStepPdfGenerator;
import com.markit.ms.rfa.dto.BulkProcessResponse;
import com.markit.ms.rfa.dto.RfaEmailNotification;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.security.McpmUserxsDetails;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.service.INewExhibitService;
import com.markit.ms.rfa.service.IRfaErrorFileService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.markit.ms.rfa.bean.enumeration.RFAStatusEnum;

@RestController
@RequestMapping(value = "/v1/amendmentLetters")
@Api(value = "amendment_letter_bulk_actions", description = "Amendment Letter Bulk Actions APIs")
public class AmendmentLetterBulkActionController {

	private static Logger LOGGER = LoggerFactory.getLogger(AmendmentLetterBulkActionController.class);

	private static final String BULK_ACTION_ERROR_PDF = "Bulk Action_RFAs not actioned.pdf";
	
	private static final String EXCEL_FILE = "xlsx";


	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	@Autowired
	private INewExhibitService newExhibitService;

	@Autowired
	private BulkActionValidationInvoker bulkActionValidationInvoker;

	@Autowired
	private BulkActionEmailNotificationInvoker bulkEmailNotificationInvoker;

	@Autowired
	private NextStepPdfGenerator nextStepPdfGenerator;
	
	@Autowired
	private IRfaErrorFileService rfaErrorFileService;
	
	@Autowired
	private IFileService fileService;
	
	@RequestMapping(method = RequestMethod.POST, params = "validate")
	@ApiOperation(value = "filter out valid RFAs")
	public @ResponseBody BulkProcessResponse<Grid> validRfaIds(HttpServletRequest request, HttpServletResponse response,
			@RequestParam(value = "action") String action, @RequestBody List<Long> rfaIds) throws Exception {
		validateNotEmpty(rfaIds, action);
		
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		Long userId = CommonUtil.getUserIdFromSession(request);
		BulkValidationBean validationBean = new BulkValidationBean();
		validationBean.setCompanyId(companyId);
		validationBean.setCompanyType(CommonUtil.getCompanyTypeFromSession(request));
		validationBean.setRfaIdList(rfaIds);
		BulkActionValidationType validationEnum = BulkActionValidationType.fromType(action);
		validationBean.setValidationType(validationEnum);

		BulkProcessResponse<Grid> bulkProcessResponse = new BulkProcessResponse<Grid>();
		Grid grid = bulkActionValidationInvoker.invoke(validationBean);		
		List<Long> validRfaIdList = bulkActionValidationInvoker.convertValidRfaIdsToList(grid);
		
		@SuppressWarnings("unchecked")
		List<Long> erroneousIdList = Lists.newArrayList(CollectionUtils.subtract(rfaIds, validRfaIdList));
		if (!erroneousIdList.isEmpty()) {
			bulkProcessResponse.setErrorCount(erroneousIdList.size());
			byte[] errorPdfContent = nextStepPdfGenerator.generatePdf(erroneousIdList, validationEnum, companyId, userId);
			Long errorFileId = rfaErrorFileService.create(BULK_ACTION_ERROR_PDF, errorPdfContent, "application/pdf", companyId, userId);
			bulkProcessResponse.setErrorFileId(errorFileId);
			response.addHeader("Error-Location", "/v1/company/" + companyId + "/rfaErrorFile/" + errorFileId);
		}
		
		bulkProcessResponse.setData(grid);
		return bulkProcessResponse;
	}
	
	@RequestMapping(value = "actions/bulk-sign", method = RequestMethod.POST)
	@ApiOperation(value = "Bulk Sign Amendmentment Letter")
	@ResponseStatus(value = HttpStatus.CREATED)
	public void bulkSignAmendmentmentLetter(@RequestBody List<Signature> signatureList, HttpServletRequest request) throws Exception {

		Long userId = CommonUtil.getUserIdFromSession(request);
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		String ipAddress = CommonUtil.obtainIpAddress(request);
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();

		for (Signature signature : signatureList) {
			signature.setCompanyType(companyType);
			signature.setIpAddress(ipAddress);
		}

		List<Signature> validSignatures = bulkActionValidationInvoker.invoke(signatureList, companyId, companyType);
		if (validSignatures.isEmpty()) {
			throw new IllegalArgumentException("No valid Signatures provided.");
		}

		amendmentLetterService.bulkSignRFA(validSignatures, companyId, userId, mcpmUserxsDetails.getUserxUser().getLoginName(),
				mcpmUserxsDetails.getLoggedInTime());
	}

	@RequestMapping(value = "actions/bulk-send-rfa", method = RequestMethod.PUT)
	@ApiOperation(value = "Bulk Send RFA")
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody Map<String, Long> bulkSendRFA(@RequestBody List<Long> rfaIds, HttpServletRequest request) throws Exception {
		validateNotEmpty(rfaIds, BulkActionValidationType.SEND.getType());

		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		String companyTypeFromSession = CommonUtil.getCompanyTypeFromSession(request);

		BulkValidationBean validationBean = new BulkValidationBean();
		validationBean.setCompanyId(companyIdFromSession);
		validationBean.setCompanyType(companyTypeFromSession);
		validationBean.setRfaIdList(rfaIds);
		validationBean.setValidationType(BulkActionValidationType.SEND);
		Grid grid = bulkActionValidationInvoker.invoke(validationBean);
		List<Long> validRfaIdList = bulkActionValidationInvoker.convertValidRfaIdsToList(grid);
		if (validRfaIdList.isEmpty()) {
			throw new IllegalArgumentException("No valid RFA IDs for Send action");
		}
		Long bulkRequestId = amendmentLetterService.bulkSendRFA(validRfaIdList, userIdFromSession, companyTypeFromSession, companyIdFromSession);
		return ImmutableMap.of("bulkRequestId", bulkRequestId);
	}

	@RequestMapping(value = "exhibits", method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public @ResponseBody Map<String, Long> updateExhibitData(@RequestParam Long fileId, @RequestParam String fileName, HttpServletResponse response,
			HttpServletRequest request) throws Exception {
		Long userId = CommonUtil.getUserIdFromSession(request);
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		Long bulkRequestId = newExhibitService.bulkUpdateExhibitData(fileId, fileName, userId, companyId);
		return ImmutableMap.of("bulkRequestId", bulkRequestId);
	}

	@RequestMapping(value = "actions/signatory-notification", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void sendSignatoryNotifications(HttpServletRequest request, @RequestBody CommonBaseRequest<RfaEmailNotification> bulkActionPostRequest)
			throws Exception {
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();

		BulkValidationBean validationBean = new BulkValidationBean();
		validationBean.setCompanyId(mcpmUserxsDetails.getEffectiveUser().getCompanyId());
		validationBean.setCompanyType(mcpmUserxsDetails.getEffectiveUser().getCompanyType());
		validationBean.setRfaIdList(bulkActionPostRequest.getData().getRfaIds());
		validationBean.setValidationType(BulkActionValidationType.SIGNATORY_NOTIFICATION);
		Grid grid = bulkActionValidationInvoker.invoke(validationBean);
		List<Long> validRfaIdList = bulkActionValidationInvoker.convertValidRfaIdsToList(grid);
		if (validRfaIdList.isEmpty()) {
			throw new IllegalArgumentException("No valid RFA IDs were provided for Signatory Notification Email.");
		}
		
		

		BulkSignatoryNotificationBean bulkSignatoryNotificationBean = new BulkSignatoryNotificationBean();
		bulkSignatoryNotificationBean.setCompanyId(mcpmUserxsDetails.getEffectiveUser().getCompanyId());
		bulkSignatoryNotificationBean.setCompanyType(mcpmUserxsDetails.getEffectiveUser().getCompanyType());
		bulkSignatoryNotificationBean.setUserId(mcpmUserxsDetails.getEffectiveUser().getId());
		bulkSignatoryNotificationBean.setBulkActionValidationType(BulkActionValidationType.SIGNATORY_NOTIFICATION);
		bulkSignatoryNotificationBean.setRfaIdList(validRfaIdList);
		bulkSignatoryNotificationBean.setEmailRecipients(bulkActionPostRequest.getData().getEmailRecipients());
		bulkSignatoryNotificationBean.setESign(bulkActionPostRequest.getData().getIsESign());
		bulkSignatoryNotificationBean.setNotifiedBy(mcpmUserxsDetails.getEffectiveUser().getEmail());
		bulkSignatoryNotificationBean.setSenderName(mcpmUserxsDetails.getEffectiveUser().getFirstName() +" "+mcpmUserxsDetails.getEffectiveUser().getLastName());
		bulkSignatoryNotificationBean.setWSign(bulkActionPostRequest.getData().getIsWSign());
		bulkSignatoryNotificationBean.setCustomNotificationMessage(bulkActionPostRequest.getData().getCustomNotificationMessage());
		bulkEmailNotificationInvoker.invoke(bulkSignatoryNotificationBean);
		
		amendmentLetterService.updatNotifiedByfor(validRfaIdList, mcpmUserxsDetails.getEffectiveUser().getId());
		if (bulkActionPostRequest.getData().getIsWSign()) {
			for (Long id : validRfaIdList) {
				amendmentLetterService.updateStatus(RFAStatusEnum.NOTIFIED.getName(), id,
						mcpmUserxsDetails.getEffectiveUser().getCompanyType());
			}
		}
	}

	@RequestMapping(value = "chaser", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	@ApiOperation(value = "Create chaser email notification")
	@RolesAllowed({ PermissionConstants.BS_RFA, PermissionConstants.BS_RFA_SIGNATORY })
	public @ResponseBody void createChaser(@RequestBody List<Long> ids, HttpServletRequest request) {
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();

		BulkValidationBean validationBean = new BulkValidationBean();
		validationBean.setCompanyId(mcpmUserxsDetails.getEffectiveUser().getCompanyId());
		validationBean.setCompanyType(mcpmUserxsDetails.getEffectiveUser().getCompanyType());
		validationBean.setRfaIdList(ids);
		validationBean.setValidationType(BulkActionValidationType.CHASER);
		Grid grid = bulkActionValidationInvoker.invoke(validationBean);
		List<Long> validRfaIdList = bulkActionValidationInvoker.convertValidRfaIdsToList(grid);
		if (validRfaIdList.isEmpty()) {
			throw new IllegalArgumentException("No valid RFA IDs were provided for Signatory Notification Email.");
		}

		BulkNotificationBean bulkNotificationBean = new BulkNotificationBean();
		bulkNotificationBean.setCompanyId(mcpmUserxsDetails.getEffectiveUser().getCompanyId());
		bulkNotificationBean.setCompanyType(mcpmUserxsDetails.getEffectiveUser().getCompanyType());
		bulkNotificationBean.setUserId(mcpmUserxsDetails.getEffectiveUser().getId());
		bulkNotificationBean.setRfaIdList(validRfaIdList);
		amendmentLetterService.saveChasers(bulkNotificationBean);
	}

	@RequestMapping(value = "actions/bulk-send-chaser", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void sendChasers(HttpServletRequest request) throws Exception {
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		BulkNotificationBean bulkNotificationBean = new BulkNotificationBean();		
		bulkNotificationBean.setUserId(mcpmUserxsDetails.getEffectiveUser().getId());
		bulkNotificationBean.setBulkActionValidationType(BulkActionValidationType.CHASER);
		bulkEmailNotificationInvoker.invoke(bulkNotificationBean);
	}
	
	@RequestMapping(value = "actions/uploadbulkRFAFile", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	@ApiOperation(value = "Upload Bulk RFA File")
	public @ResponseBody Map<String, Long> uploadBulkRFAFile(@RequestParam Long templateId, @RequestParam String fileName,
			@RequestParam final MultipartFile file, HttpServletResponse response, HttpServletRequest request)
			throws Exception {

		LOGGER.info("Entering uploadBulkRFAFile method");
		Long userId = CommonUtil.getUserIdFromSession(request);
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		String companyType = CommonUtil.getCompanyTypeFromSession(request);
		String ipAddress = CommonUtil.obtainIpAddress(request);
		Long fileId = null;
		Long bulkRequestId = null;
		Long bulkRFAUploadId = null;
		if (!FilenameUtils.isExtension(fileName, EXCEL_FILE)) {
			throw new RFAUIException(RFAConstants.INCORRECT_FILE_EXTENSION, HttpStatus.OK.toString());
		}
		MCFile mcFile = fileService.saveFile(fileName, file.getBytes(), companyId, userId);
		if (null != mcFile) {
			fileId = mcFile.getFileId();
			bulkRequestId = amendmentLetterService.bulkUploadRFA(userId, companyType, companyId, fileId, templateId, ipAddress);
			if (null != bulkRequestId)
				amendmentLetterService.saveBulkUploadFileTemplate(templateId, userId, companyId, bulkRequestId);
			bulkRFAUploadId = amendmentLetterService.getBulkRFAUploadId(bulkRequestId);
		}

		LOGGER.info("Exiting uploadBulkRFAFile method");
		return ImmutableMap.of("bulkRFAUploadId", bulkRFAUploadId);

	}

	private void validateNotEmpty(List<Long> rfaIds, String action) {
		if (CollectionUtils.isEmpty(rfaIds)) {
			throw new IllegalArgumentException("No RFA Ids provided for validation of bulk " + action + " action.");
		}
	}
}