package com.markit.ms.rfa.placeholders.request;

import java.util.List;

public class BSPartyBTableRequest {
	private List<LineBreak> lineBreaks;

	public List<LineBreak> getLineBreaks() {
		return lineBreaks;
	}

	public void setLineBreaks(List<LineBreak> lineBreaks) {
		this.lineBreaks = lineBreaks;
	}
}
