package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.util.CommonUtil;

public class LineBreakResultSetExtractor implements
ResultSetExtractor<List<Map<String, String>>> {

	public List<Map<String, String>> extractData(ResultSet rs) throws SQLException,
	DataAccessException {
		List<Map<String, String>> rows = new ArrayList<Map<String, String>>();
		while(rs.next()) {
			Long lineBreakId = rs.getLong("LINE_BREAK_ID");
			Integer lineBreakIndex = rs.getInt("LINE_BREAK_INDEX");
			String lineBreakText = CommonUtil.getValueFromBase64(rs.getBytes("LINE_BREAK_TEXT"));
			String showHeaderText = CommonUtil.getValueFromBase64(rs.getBytes("SHOW_HEADER_TEXT"));
			Long exhibitControlColumnId = rs.getLong("EXHIBIT_CONTROL_COLUMN_ID");
			Map<String,String> row = new HashMap<String,String>();
			row.put("LINE_BREAK_ID", lineBreakId+"");
			row.put("LINE_BREAK_INDEX", lineBreakIndex+"");
			row.put("LINE_BREAK_TEXT", lineBreakText);
			row.put("SHOW_HEADER_TEXT", showHeaderText+"");
			row.put("EXHIBIT_CONTROL_COLUMN_ID", exhibitControlColumnId+"");
			rows.add(row);
		}
		return rows;
	}

}
