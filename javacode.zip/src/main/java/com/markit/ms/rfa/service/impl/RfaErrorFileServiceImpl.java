package com.markit.ms.rfa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.RfaErrorFile;
import com.markit.ms.rfa.dao.IRfaErrorFileDao;
import com.markit.ms.rfa.service.IRfaErrorFileService;

@Service
public class RfaErrorFileServiceImpl implements IRfaErrorFileService {

	@Autowired
	private IRfaErrorFileDao rfaErrorFileDao;

	@Override
	public Long create(String fileName, byte[] bytes, String contentType, long companyId, long userId) {
		RfaErrorFile rfaErrorFile = new RfaErrorFile();
		rfaErrorFile.setFileName(fileName);
		rfaErrorFile.setCreatedBy(userId);
		rfaErrorFile.setCompanyId(companyId);
		rfaErrorFile.setContentType(contentType);
		rfaErrorFile.setBytes(bytes);
		rfaErrorFileDao.create(rfaErrorFile);
		return rfaErrorFile.getId();
	}

	@Override
	public RfaErrorFile retreive(long fileId) {
		return rfaErrorFileDao.read(fileId);
	}

	@Override
	public int deleteFile(long fileId,long companyId) {

		return rfaErrorFileDao.deleteFile(fileId,companyId);
	}
}