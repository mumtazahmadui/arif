package com.markit.ms.rfa.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.i18n.LocaleContextHolder;

import com.google.common.base.Function;
import com.marketxs.util.HttpUtil.Base64Encoder;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.domain.Grid.Row;
import com.markit.kyc.security.UserUtils;
import com.markit.ms.common.util.Base64Decoder;
import com.markit.ms.rfa.bean.AmendmentCommentAudit;
import com.markit.ms.rfa.security.McpmUserxsDetails;
import com.markit.ms.rfa.security.domain.McpmUser;

public class CommonUtil {
    
    private static final String COMMENT_HTML_TEMPLATE_NAME = "report/template/commentHtmlTemplate.vm";
    
    public static Locale getCurrentLocale() {
        return LocaleContextHolder.getLocale();
    }
	public static String convertToUTF8(byte[] input)
			throws UnsupportedEncodingException {
		if(input == null) {
			return "";
		}
		byte[] decodedReportInfo = Base64Decoder.getDecodedString(input);
        
        String htmlStr = new String(decodedReportInfo, "UTF-8");
        htmlStr = java.net.URLDecoder.decode(htmlStr, "UTF-8");
		return htmlStr;
	}
	public static String encodeString(String input)
			throws UnsupportedEncodingException {
		if(input == null) {
			return "";
		}
		
		String urlEncoded = java.net.URLEncoder.encode(input, "UTF-8");
		String base64Encoded= Base64Encoder.toBase64(urlEncoded);
        
		return base64Encoded;
	}
	public static String updateAmpersandAndBRTag(String input) {
		input = UnicodeEnum.replaceUnicodeCharInString(input);
		return input;
	}
	public static String getDateForFormat(Date agreementDate, String format) {
		if(null == agreementDate) {
			return null;
		}
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		return simpleDateFormat.format(agreementDate);
	}
	public static String replaceNullWithSpaceInPDF(String value) {
		 return value != null? value : "";
	}
	
	public static String getValueFromBase64(byte[] byteValue) {
		return byteValue != null ? new String(byteValue) : null;
	}
	
	public static String signDate(Date today) {
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy h:mm:ss a");       
		String reportDate = df.format(today);
		return reportDate;
	}
	public static Long getUserIdFromSession(HttpServletRequest request) {
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		McpmUser mcpmUser = mcpmUserxsDetails.getEffectiveUser();
		return mcpmUser.getId();
	}
	
	public static Long convertZeroToNull(Long number) {
		if(number==0) {
			return null;
		}
		return number;
	}
	
	public static String getUISignFormat(Timestamp timestamp) {
		if(timestamp != null) {
			String date = new SimpleDateFormat("dd-MMM-yyyy h:mm:ss a").format(timestamp);
			return date;
		} else {
			return "";
		}
	}
	
	public static String changeDateFormat(String date, String sourceFormat
			, String destinationFormat) throws ParseException {
		SimpleDateFormat sdfSource = new SimpleDateFormat(sourceFormat);
		Date dateObj = sdfSource.parse(date);
		SimpleDateFormat sdfDestination = new SimpleDateFormat(destinationFormat);
		return sdfDestination.format(dateObj);
	}
	
	public static Long getCompanyIdFromSession(HttpServletRequest request){
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		McpmUser mcpmUser = mcpmUserxsDetails.getEffectiveUser();
		return mcpmUser.getCompanyId();
	}
	
	public static String getCompanyTypeFromSession(HttpServletRequest request){
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		McpmUser mcpmUser = mcpmUserxsDetails.getEffectiveUser();
		return mcpmUser.getCompanyType();
	}
	
	public static String obtainIpAddress(HttpServletRequest request) {
		String ipAddress = null;
		if (request.getHeader("X-Forwarded-For") != null) {
			String[] headerArr = request.getHeader("X-Forwarded-For").split(",");
			ipAddress = headerArr[0];
		}
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}
		return ipAddress;
	}
	
	public static Grid decodeGridRows(Grid grid, List<String> columnNames) {
		if (grid.isEmpty() || !CollectionUtils.containsAny(grid.getRows().get(0).keySet(), columnNames)) {
			return grid;
		}
		return grid.mapRows(new Function<Row, Row>() {
			@Override
			public Row apply(Row input) {
				Map<String, String> nmap = new LinkedHashMap<String, String>();
				input.getData().forEach((k, v) -> {
					String value = v;
					if (value != null && columnNames.contains(k)) {
						try {
							value = URLDecoder.decode(value, "UTF-8");
						} catch (UnsupportedEncodingException e) {
						}
					}
					nmap.put(k, value);
				});
				return new Row(nmap);
			}
		});
	}
	
//	public static void main(String args[]) throws IOException {
//		String encodedString = "JTNDcCUzRSUzQ3AlM0UlM0NpbnB1dCUyMGlkJTNEJTIyZGF0ZV9waW5uZWQlMjIlMjBjbGFzcyUzRCUyMnBsYWNlLWhvbGRlciUyMGRpc2FibGVkJTIwZGlzcGxheS1ub25lJTIyJTIwcmVhZG9ubHklM0QlMjIlMjIlM0UlRUYlQkIlQkYlM0NiciUyRiUzRSUyMCUzQ2lucHV0JTIwaWQlM0QlMjJwYXJ0eUFSZWxhdGlvbnMlMjIlMjByZWFkb25seSUzRCUyMiUyMiUyMGNsYXNzJTNEJTIycGxhY2UtaG9sZGVyJTIwZGlzYWJsZWQlMjIlMjB2YWx1ZSUzRCUyMlBhcnR5JTIwQSUyMFJlbGF0aW9uJTIyJTNFJTIwJTNDYnIlMkYlM0VlcndxcmVxd2Vyd2VyJTNDJTJGcCUzRSUzQ3AlM0UlRUYlQkIlQkZ3ZXJ3ZXJ3ZXIlM0NiciUyRiUzRSUzQyUyRnAlM0UlM0NwJTNFJUVGJUJCJUJGd2Vyd2Vyd2Vyd2VyZXclM0NiciUyRiUzRSUzQyUyRnAlM0UlM0NwJTNFJUVGJUJCJUJGd2VyZXdyd2Vyd2VyJTNDYnIlMkYlM0UlM0MlMkZwJTNFJTNDcCUzRSVFRiVCQiVCRndlcndlcndlcndlciUzQ2JyJTJGJTNFJTNDJTJGcCUzRSUzQ3AlM0UlRUYlQkIlQkYlM0NiciUyRiUzRSUzQ2lucHV0JTIwaWQlM0QlMjJwYXJ0eUJBZGRpdGlvbiUyMiUyMHJlYWRvbmx5JTNEJTIyJTIyJTIwY2xhc3MlM0QlMjJwbGFjZS1ob2xkZXIlMjBkaXNhYmxlZCUyMiUyMHZhbHVlJTNEJTIyUGFydHklMjBCJTIwQWRkaXRpb24lMjIlM0UlM0NiciUyRiUzRXdlcndlcndlcnJlJTNDYnIlMkYlM0UlM0NiciUyRiUzRSUzQ2JyJTJGJTNFJTNDYnIlMkYlM0UlM0NpbnB1dCUyMGlkJTNEJTIycGFydHlCUmVtb3ZhbCUyMiUyMGNsYXNzJTNEJTIycGxhY2UtaG9sZGVyJTIwdW5zZWxlY3RhYmxlJTIwZGlzYWJsZWQlMjIlMjByZWFkb25seSUzRCUyMiUyMiUyMHZhbHVlJTNEJTIyUGFydHklMjBCJTIwUmVtb3ZhbCUyMiUyMHVuc2VsZWN0YWJsZSUzRCUyMm9uJTIyJTNFJTNDYnIlMkYlM0UlM0NpbnB1dCUyMGlkJTNEJTIyYnNfc2lnbmF0dXJlJTVCMSU1RCUyMiUyMHJlYWRvbmx5JTNEJTIyJTIyJTIwY2xhc3MlM0QlMjJwbGFjZS1ob2xkZXIlMjBkaXNhYmxlZCUyMiUyMHZhbHVlJTNEJTIyQnV5c2lkZSUyMFNpZ25hdHVyZSU1QjElNUQlMjIlMjBpbmRleCUzRCUyMjElMjIlM0UlM0NiciUyRiUzRSUzQ2lucHV0JTIwaWQlM0QlMjJzc19zaWduYXR1cmUlNUIxJTVEJTIyJTIwcmVhZG9ubHklM0QlMjIlMjIlMjBjbGFzcyUzRCUyMnBsYWNlLWhvbGRlciUyMGRpc2FibGVkJTIyJTIwdmFsdWUlM0QlMjJTZWxsc2lkZSUyMFNpZ25hdHVyZSU1QjElNUQlMjIlMjBpbmRleCUzRCUyMjElMjIlM0UlM0NiciUyRiUzRSUzQ2JyJTJGJTNFJTNDJTJGcCUzRSUzQ2JyJTJGJTNFJTNDJTJGcCUzRQ==";
////		System.out.println(encodedString);
//		System.out.println(CommonUtil.convertToUTF8(encodedString.getBytes()));
//		encodeTest();
//	}
	private static void encodeTest() throws IOException  {
		File file = new File("C:\\Users\\abhishek.tiwari\\Desktop\\6.1\\Prod_ML_New\\Prod_Exhibit_Issue_Fix.HTML");
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			String line = null;
			StringBuilder build = new StringBuilder();
			while ((line = br.readLine()) != null) {
				//System.out.println(line);
				build.append(line);
			}
			String encoded = encodeString(build.toString());
			System.out.println("EncodedString::" + encoded);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		} finally {
			br.close();
			fr.close();
		}
		
	}
	
	public static Boolean isNull(Object obj)
	{
		if (null == obj)
			return true;
		else
			return false;
	}
	
	public static Boolean isNotNull(Object obj)
	{
		if (null != obj)
			return true;
		else
			return false;
	}
	
	public static Boolean isNotNull(String value)
    {
        if (value != null && value != "" && value.trim().length() > 0)
            return true;
        else
            return false;
    }
	
	public static Boolean isNull(String value)
    {
        if (value == null || value == "" || value.equals(""))
            return true;
        else
            return false;
    }
	
	public static Boolean isEqual(String value1, String value2)	{
		if (isNotNull(value1) && isNotNull(value2) && value1.equalsIgnoreCase(value2))
			return true;
		else
			return false;
	}

	public static boolean isNotEqual(String value1, String value2) {
		if (isNotNull(value1) && isNotNull(value2) && !value1.equalsIgnoreCase(value2))
			return true;
		else
			return false;
	}
	
	public static String addLocationTagPdf(String contentHtml) {
		Document doc = Jsoup.parse(contentHtml);
		Elements link = doc.select("annotation");
		for (Element paragraph : link) {
			String linkHref = paragraph.attr("data-annotation-seq");
			paragraph.prepend("<span style=\"font-size: 65%;font-weight: bolder;vertical-align:super;\">["+linkHref+"]</span>");
		}
		return doc.html();
	}

 	
	public static byte[] generateCommentHtml(List<AmendmentCommentAudit> amendmentContent,VelocityEngine velocityEngine,String source) {
		if(amendmentContent==null||amendmentContent.isEmpty()) {
			return "".getBytes();
		}
		amendmentContent.sort((AmendmentCommentAudit a1 ,AmendmentCommentAudit a2)->a1.getSequence().compareTo(a2.getSequence()));
		VelocityContext context = new VelocityContext();
		Properties p = new Properties();
		p.setProperty("resource.loader", "class");
		p.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
		p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");     
		context.put("appendix",amendmentContent);
		context.put("source",source);
		velocityEngine.init(p);
		Template template = velocityEngine.getTemplate(COMMENT_HTML_TEMPLATE_NAME);
		StringWriter writer = new StringWriter();
		template.merge(context, writer);
		String encodeCommentHtml;
		try {
			encodeCommentHtml = CommonUtil.encodeString(writer.toString());
			return encodeCommentHtml.getBytes();
		} catch (UnsupportedEncodingException e) {
			return "".getBytes();
		}

	}
}
