package com.markit.ms.rfa.bean;

import java.util.Date;

import com.markit.ms.common.bean.Entity;

public class MasterAgreement {

	private Long id;
	private String name;
	private Date agreementDate;
	private Entity investmentManager;
	private Entity partyA;
	private String masterlistIdentifier;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Long deleted;
	private String partyARelation;
	private String agreementType;
	private String masterlistIdentifierAgreementType;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getAgreementDate() {
		return agreementDate;
	}
	public void setAgreementDate(Date agreementDate) {
		this.agreementDate = agreementDate;
	}
	public Entity getInvestmentManager() {
		return investmentManager;
	}
	public void setInvestmentManager(Entity investmentManager) {
		this.investmentManager = investmentManager;
	}
	public Entity getPartyA() {
		return partyA;
	}
	public void setPartyA(Entity partyA) {
		this.partyA = partyA;
	}
	public String getMasterlistIdentifier() {
		return masterlistIdentifier;
	}
	public void setMasterlistIdentifier(String masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Long getDeleted() {
		return deleted;
	}
	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}
	public String getPartyARelation() {
		return partyARelation;
	}
	public void setPartyARelation(String partyARelation) {
		this.partyARelation = partyARelation;
	}
	public String getAgreementType() {
		return agreementType;
	}
	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}
	public String getMasterlistIdentifierAgreementType() {
		return masterlistIdentifierAgreementType;
	}
	public void setMasterlistIdentifierAgreementType(String masterlistIdentifierAgreementType) {
		this.masterlistIdentifierAgreementType = masterlistIdentifierAgreementType;
	}
	
}
