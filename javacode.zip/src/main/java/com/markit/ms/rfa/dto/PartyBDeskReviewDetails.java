package com.markit.ms.rfa.dto;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

/***
 * Holds the reviewed details for each desk of amendment letter partyB
 * 
 * @since RFA5.0
 */
public class PartyBDeskReviewDetails{
	
	@JsonIgnore
	private Long id;
	private int deskStatus;
	private String actionDate;
	private String actionedBy;
	private List<String> escalatedTo;
	@JsonIgnore
	private int totalAuditCount;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getDeskStatus() {
		return deskStatus;
	}
	public void setDeskStatus(int deskStatus) {
		this.deskStatus = deskStatus;
	}
	public String getActionDate() {
		return actionDate;
	}
	public void setActionDate(String actionDate) {
		this.actionDate = actionDate;
	}
	public String getActionedBy() {
		return actionedBy;
	}
	public void setActionedBy(String actionedBy) {
		this.actionedBy = actionedBy;
	}
	public List<String> getEscalatedTo() {
		return escalatedTo;
	}
	public void setEscalatedTo(List<String> escalatedTo) {
		this.escalatedTo = escalatedTo;
	}
	public int getTotalAuditCount() {
		return totalAuditCount;
	}
	public void setTotalAuditCount(int totalAuditCount) {
		this.totalAuditCount = totalAuditCount;
	}

	
	
}
