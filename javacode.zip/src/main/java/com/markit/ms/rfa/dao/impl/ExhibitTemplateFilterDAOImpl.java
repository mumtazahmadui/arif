package com.markit.ms.rfa.dao.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.common.dao.rowmapper.LookupRowMapper;
import com.markit.ms.rfa.dao.IExhibitTemplateFilterDAO;
import com.markit.ms.rfa.dao.resultsetextractor.AgreementDateResultSetExtractor;

@Repository
public class ExhibitTemplateFilterDAOImpl extends BaseDAOImpl implements IExhibitTemplateFilterDAO
{
	
	@Value("${GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_NAME}")
    private String GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_NAME;
	
	@Value("${GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_LINKED_BY}")
	private String GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_LINKED_BY;
	
	@Value("${GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_CREATED_BY}")
	private String GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_CREATED_BY;
	
	@Value("${GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_PARTYA_LEGAL_NAME}")
	private String GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_PARTYA_LEGAL_NAME;
	
	@Value("${GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_REF_ISDA_DATE}")
	private String GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_REF_ISDA_DATE;
	
	@Value("${GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_MASTERLIST_IDENTIFIER}")
	private String GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_MASTERLIST_IDENTIFIER;
	
	@Override
	public List<Lookup> nameLookup(Long id, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_NAME, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<Lookup> linkedByLookup(Long id, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_LINKED_BY, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<Lookup> createdByLookup(Long id, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_CREATED_BY, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<Lookup> partyALegalNameLookup(Long id, String filterString)
	{
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_PARTYA_LEGAL_NAME, paramSource, new LookupRowMapper());
    	return lookupList;
	}

	@Override
	public List<String> refIsdaDateLookup(Long id, String filterString)
	{
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", id)
			.addValue("filterString", "%" + filterString.replace("-", " ") + "%");
		DateFormat formatter  = new SimpleDateFormat("dd-MMM-yyyy");
		List<Date> dates = namedParameterJdbcTemplate.query(GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_REF_ISDA_DATE, paramSource, new AgreementDateResultSetExtractor());		
		List<String> filteredDates = new ArrayList<String>();
		String currentDate;
		for (Date date : dates){
			currentDate = formatter.format(date);
			filteredDates.add(currentDate);
		}
		return filteredDates;
	}

	@Override
	public List<Lookup> masterlistIdentifierLookup(Long id, String filterString)
	{
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", id).addValue("filterString", "%"+filterString+"%");
		List<Lookup> lookupList = namedParameterJdbcTemplate.query(GET_RFA_EXHIBIT_TEMPLATE_LOOKUP_BY_MASTERLIST_IDENTIFIER, paramSource, new LookupRowMapper());
    	return lookupList;
	}
}
