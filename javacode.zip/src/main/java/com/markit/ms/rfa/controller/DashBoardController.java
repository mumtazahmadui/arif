package com.markit.ms.rfa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.bean.CompanyAmendmentStats;
import com.markit.ms.rfa.bean.MyStatusLegend;
import com.markit.ms.rfa.dao.IDashboardDao;
import com.markit.ms.rfa.service.IDashboardService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;

@RestController
@RequestMapping(value = "/v1/dashboard")
@Api(value = "Dashboard" , description = "DashBoard API")
public class DashBoardController {
	
	@Autowired
    private IDashboardService dashboardService;
	
	@Autowired
	private IDashboardDao dashboardDao;
	
    @RequestMapping(value = "company/{id}/amendment_stats",method = RequestMethod.GET)
    public  CommonBaseResponse<CompanyAmendmentStats> getAmendmentStatus(@PathVariable Long id,HttpServletRequest request){
    	 long companyId = CommonUtil.getCompanyIdFromSession(request);
    	 CommonBaseResponse<CompanyAmendmentStats> response = new  CommonBaseResponse<CompanyAmendmentStats>();
    	 CompanyAmendmentStats companyAmendmentStats = dashboardService.getCompanyAmendmentStats(companyId);
    	 response.setData(companyAmendmentStats);
    	 return response;        
    }
    
    @RequestMapping(value = "myStatusLegend", method = RequestMethod.GET)
    public @ResponseBody List<MyStatusLegend> getMyStatusLegend(HttpServletRequest request) {
    	Long companyId = CommonUtil.getCompanyIdFromSession(request);
    	Long userId = CommonUtil.getUserIdFromSession(request);
    	
    	return dashboardDao.getMyStatusLegend(companyId, userId);
    }
    
}
