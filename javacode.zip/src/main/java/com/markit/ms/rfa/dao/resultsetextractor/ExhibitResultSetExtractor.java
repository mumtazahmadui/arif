package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.bean.ExhibitCell;
import com.markit.ms.rfa.bean.ExhibitColumn;
import com.markit.ms.rfa.util.CommonUtil;

public class ExhibitResultSetExtractor implements ResultSetExtractor<Exhibit> {
	
	public Exhibit extractData(ResultSet rs) throws SQLException {
		Exhibit exhibit = null;
		//TODO-Sajil user ExhibitColumn.id as key
		Map<ExhibitColumn,List<ExhibitCell>> exhibitColsMap = new HashMap<ExhibitColumn,List<ExhibitCell>>();
		while (rs.next()) {
			if(exhibit == null){
				exhibit = new Exhibit();
				exhibit.setAmendmentId(rs.getLong("amendment_id"));
				exhibit.setTextContent(CommonUtil.getValueFromBase64(rs.getBytes("text_content")));
				exhibit.setHtmlContent(CommonUtil.getValueFromBase64(rs.getBytes("html_content")));
			}
			ExhibitColumn exhibtCol = new ExhibitColumn();
			exhibtCol.setId(rs.getLong("column_id")); 
			exhibtCol.setColumnIndex(rs.getLong("column_index"));
			exhibtCol.setColumnStyle(rs.getString("column_style"));
			exhibtCol.setColumnName(rs.getString("column_name"));
			List<ExhibitCell> exhibitCells = exhibitColsMap.get(exhibtCol);
			if(exhibitCells == null){
				exhibitCells = new ArrayList<ExhibitCell>();
				exhibitColsMap.put(exhibtCol, exhibitCells);
				exhibtCol.setCells(exhibitCells);
			}
			ExhibitCell cell = new ExhibitCell();
			cell.setId(rs.getLong("cell_id"));  
			cell.setValue(rs.getString("value"));
			exhibitCells.add(cell);
		}
		List<ExhibitColumn> columns = new ArrayList<ExhibitColumn>(exhibitColsMap.keySet());
		exhibit.setColumns(columns);
		return exhibit;
	}
	
}
