package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.bean.RFATemplateNames;
import com.markit.ms.rfa.bean.RFAUploadFile;
import com.markit.ms.rfa.dto.RfaUploadFileSearchRequest;

/**
 * @author sucheta.krishali
 *
 */
public interface IRfaUploadFileDAO
{
	List<RFAUploadFile> getUploadFileGrid(Long companyId, RfaUploadFileSearchRequest templateSearchRequest);
	public List<Lookup> getFilterUploadedBy(Long companyId, String filterString) ;

	public List<Lookup> getFilterProcessingStatus(Long companyId, String filterString) ;
	
	public List<Lookup> getTemplateNamesByCompany(Long companyId);

}
