package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.common.bean.Lookup;


/**
 * @author prashant.aggarwal
 *
 */
public interface IMasterlistTemplateFilterDAO
{
	List<Lookup> mlTemplateLookUp(Long companyId, String filterString);	
}
