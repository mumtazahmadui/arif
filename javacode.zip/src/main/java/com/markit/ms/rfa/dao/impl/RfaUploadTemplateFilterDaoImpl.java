package com.markit.ms.rfa.dao.impl;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.RfaFieldNameValue;
import com.markit.ms.rfa.bean.enumeration.RfaUploadTemplateRulesEnum;
import com.markit.ms.rfa.dao.IRfaUploadTemplateFilterDao;

@Repository
public class RfaUploadTemplateFilterDaoImpl extends BaseDAOImpl implements IRfaUploadTemplateFilterDao {

    @Value("${GET_FILTER_VALUES}")
    private String GET_FILTER_VALUES;
    
    @Value("${GET_DEFAULT_VALUE}")
    private String GET_DEFAULT_VALUE;
    
    
    @Value("${GET_UPLOAD_TEMPLATE_NAMES_BY_COMPANYID}")
    private String GET_UPLOAD_TEMPLATE_NAMES_BY_COMPANYID;
    
/*    
	@Override
	public List<String> getFilterValues(String filterString) {
		MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("filterString", filterString);
		
		try {
			List<String> lookupList = namedParameterJdbcTemplate.queryForList(GET_FILTER_VALUES, paramSource,
					String.class);
			return lookupList;

		} catch (EmptyResultDataAccessException e) {
			return null;
		}
		
		
	}*/

	@Override
	public Map<String,List<String>>   getFilterValues() {
		
		  List<String> filterList = new ArrayList<String>();
		for (RfaUploadTemplateRulesEnum rule : RfaUploadTemplateRulesEnum.values()) {
			filterList.add(rule.getName());
		}

		MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("filterString", filterList);
			
		/*Map<String,List<String>> lookup = new HashMap<String,List<String>>();
		List<Map<String, Object>> rows = namedParameterJdbcTemplate.queryForList(GET_FILTER_VALUES, paramSource);
		for (Map<String, Object> row : rows) {
			
			if(lookup.containsKey(row.get("FIELD_IDENTIFIER")))				
			{
				lookup.get(row.get("FIELD_IDENTIFIER")).add((String)row.get("FIELD_VALUE"));
			}
			else
			{
				List<String> list=new ArrayList<String>();
				lookup.put((String)(row.get("FIELD_IDENTIFIER")),list);
				list.add((String)row.get("FIELD_VALUE"));
			}
		}*/
		
		try{
			
			Map<String,List<String>> lookup = new HashMap<String,List<String>>();
		List<RfaFieldNameValue> rows=namedParameterJdbcTemplate.query(GET_FILTER_VALUES, paramSource,new RowMapper<RfaFieldNameValue>() {

				@Override
				public RfaFieldNameValue mapRow(ResultSet rs, int rowNum)
						throws SQLException {

					RfaFieldNameValue esce = new RfaFieldNameValue();

					esce.setName(rs.getString("name"));
					esce.setFieldValue(rs.getString("fieldValue"));
					return esce;
				}});
		
			for (RfaFieldNameValue  row : rows) {
			
			if(lookup.containsKey(row.getName())	)			
			{
				lookup.get(row.getName()).add((String)row.getFieldValue());
			}
			else
			{
				List<String> list=new ArrayList<String>();
				lookup.put((String)(row.getName()),list);
				list.add((String)row.getFieldValue());
			}
		}
		return lookup;
	 }
	    catch (EmptyResultDataAccessException e) {
	    	return null;
	    }
	}

	
	@Override
	public Map<String, String> getDefaultValue() {

		List<String> filterList = new ArrayList<String>();
		for (RfaUploadTemplateRulesEnum rule : RfaUploadTemplateRulesEnum.values()) {
			filterList.add(rule.getName());
		}

		MapSqlParameterSource paramSource = new MapSqlParameterSource().addValue("filterString", filterList);

		try {

			Map<String, String> lookup = new HashMap<String, String>();
			List<RfaFieldNameValue> rows = namedParameterJdbcTemplate.query(GET_DEFAULT_VALUE, paramSource,
					new RowMapper<RfaFieldNameValue>() {

						@Override
						public RfaFieldNameValue mapRow(ResultSet rs, int rowNum) throws SQLException {

							RfaFieldNameValue esce = new RfaFieldNameValue();

							esce.setName(rs.getString("name"));
							esce.setDefaultValue(rs.getString("defaultValue"));
							return esce;
						}
					});

			for (RfaFieldNameValue row : rows) {
				if (!lookup.containsKey(row.getName())) {
					lookup.put((String) (row.getName()), (String) row.getDefaultValue());
				}
			}
			return lookup;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	@Override
	public List<Lookup> getUploadTemplateLookup(Long companyId,String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId)
				.addValue("filterString", "%"+filterString+"%");
		List<Map<String, Object>> uploadTemplates  = namedParameterJdbcTemplate.queryForList(GET_UPLOAD_TEMPLATE_NAMES_BY_COMPANYID, paramSource);

		List<Lookup> lookupList = new ArrayList<Lookup>();
		for(Map<String, Object> uploadTemplate : uploadTemplates){
			Lookup lookup = new Lookup();
			lookup.setId(new Long(((BigDecimal)uploadTemplate.get("id")).longValue()));
			lookup.setValue((String)uploadTemplate.get("template_name"));			
			lookupList.add(lookup);
		}

		return lookupList;
	}

	




}
