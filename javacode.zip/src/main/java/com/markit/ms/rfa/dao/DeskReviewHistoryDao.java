package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.rfa.bean.PartyBDeskReviewData;
import com.markit.ms.rfa.dto.PartyBDeskReviewDetails;

/**
 * This class provides dao operation implementation for Amendment Letter
 * PartyB's desk statuses history details
 * 
 * @since RFA5.0
 *
 */
public interface DeskReviewHistoryDao {

	/**
	 * inserts <code>PartyBDeskReviewData</code> in database
	 * 
	 * @param deskReviewData
	 * @return unique id of desk review history data
	 */
	Long create(PartyBDeskReviewData deskReviewData);
	
	/**
	 * inserts deskReviewData at amendment level in database
	 * 
	 * @param deskReviewData
	 */	
	void createAtAmendment(PartyBDeskReviewData deskReviewData);


	/**
	 * gets latest reviewed history details for desk code of partyB
	 * 
	 * @param deskReviewData
	 * @return list of reviewed history
	 */
	List<PartyBDeskReviewDetails> fetchReviewHistoryDetails(PartyBDeskReviewData deskReviewData);

	/**
	 * gets latest reviewed history details for desk where action taken was at
	 * amendment letter level
	 * 
	 * @param amendmentId
	 * @param deskCode
	 * @return list of reviewed history at amendment letter level
	 */
	List<PartyBDeskReviewDetails> fetchAmendmentReviewHistoryDetails(Long amendmentId, String deskCode);

	/**
	 * gets last escalated details for desk code of partyB
	 *
	 * @param deskReviewData
	 * @return details of last escalated action
	 */
	PartyBDeskReviewDetails fetchEscalatedHistoryDetails(PartyBDeskReviewData deskReviewData);

	/**
	 * gets list of users who were notified for escalation
	 * 
	 * @param reviewHistoryId
	 * @return list of users email id
	 */
	List<String> getEscalatedToUsers(Long reviewHistoryId);

	/**
	 * inserts list of users who are notified of escalation in database
	 * 
	 * @param deskReviewHistoryId
	 * @param userIds
	 */
	void insertEscalatedUsers(Long deskReviewHistoryId, List<Long> userIds);

}
