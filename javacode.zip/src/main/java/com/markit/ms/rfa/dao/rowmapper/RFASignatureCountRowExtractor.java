package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.bean.AmendmentSignData;

public class RFASignatureCountRowExtractor implements ResultSetExtractor<Map<Long, AmendmentSignData>> {
	
	@Override
	public Map<Long, AmendmentSignData> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Map<Long, AmendmentSignData> signatureCountsForRFAIds = new HashMap<Long, AmendmentSignData>();
		AmendmentSignData amendmentSignData;
		while(rs.next()){
			
			if(signatureCountsForRFAIds.containsKey(rs.getLong("amendment_id"))) {
				amendmentSignData = signatureCountsForRFAIds.get(rs.getLong("amendment_id"));
				populateSignCount(rs, amendmentSignData);
			} else {
				amendmentSignData = new AmendmentSignData();
				populateSignCount(rs, amendmentSignData);
			}
			
			signatureCountsForRFAIds.put(rs.getLong("amendment_id"), amendmentSignData);
		}
		return signatureCountsForRFAIds;
	}

	private void populateSignCount(ResultSet rs, AmendmentSignData amendmentSignData) throws SQLException {
		if(rs.getString("mysigntype").equals("E_SIGN")) {
			amendmentSignData.seteSignCount(rs.getInt("total"));
		} else {
			amendmentSignData.setwSignCount(rs.getInt("total"));
		}
	}
}
