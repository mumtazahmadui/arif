package com.markit.ms.rfa.service;

import java.io.UnsupportedEncodingException;

import com.markit.ms.rfa.bean.PartyAPlaceHolder;

public interface IPartyAPlaceholderService {

	PartyAPlaceHolder getPartyAPlaceholder(Long amendmentId) throws UnsupportedEncodingException;

	void updatePartyAPlaceholder(PartyAPlaceHolder partyAPlaceholder,
			Long amendmentId, Long userId) throws UnsupportedEncodingException;
}
