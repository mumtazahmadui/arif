package com.markit.ms.rfa.bean;

public class RejectionReason {
private String reason;

public String getReason() {
	return reason;
}

public void setReason(String reason) {
	this.reason = reason;
}
}
