package com.markit.ms.rfa.command.validator.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.domain.Grid.Row;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.rfa.bean.BulkValidationBean;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.validator.BulkActionValidator;

public class SignatureValidator extends BulkActionValidator {

	@Override
	public Grid validate(BulkValidationBean validationBean) {
		QueryService<Grid> queryService = bulkValidationQueries.get(BulkActionValidationType.E_SIGN.toString());
		Map<String, Object> params = Maps.newHashMap();
		params.put("rfaIds", validationBean.getRfaIdList());
		params.put("companyId", validationBean.getCompanyId());
		params.put("buysideCompanyType", validationBean.getCompanyType().equalsIgnoreCase("BS") ? true : false);
		return queryService.executeQuery(params);
	}

	public List<Signature> validate(List<Signature> signatureList, String companyType, Long companyId) {
		List<Long> rfaIds = new ArrayList<Long>();
		for (Signature signature : signatureList) {
			rfaIds.add(signature.getAmendmentId());
		}

		QueryService<Grid> queryService = bulkValidationQueries.get(BulkActionValidationType.E_SIGN.toString());
		Map<String, Object> params = Maps.newHashMap();
		params.put("rfaIds", rfaIds);
		params.put("companyId", companyId);
		params.put("buysideCompanyType", companyType.equalsIgnoreCase("BS") ? true : false);

		Grid grid = queryService.executeQuery(params);
		List<Long> validRfaIds = new ArrayList<Long>();
		for (Row row : grid.getRowList()) {
			Long rfaId = new Long(row.get("validRfaId"));
			validRfaIds.add(rfaId);
		}

		List<Signature> validSignatures = new ArrayList<Signature>();
		for (Signature signature : signatureList) {
			if (validRfaIds.contains(signature.getAmendmentId())) {
				validSignatures.add(signature);
			}
		}
		return validSignatures;
	}
}