package com.markit.ms.rfa.bean;

public class RequestStatus {
private Long draft;
private Long submitted;
private Long received;
private Long completed;
private Long partiallyCompleted;
private Long recalled;
private Long rejected;
private Long deleted;

public RequestStatus(){
	draft = 0L;
	submitted = 0L;
	completed = 0L;
	partiallyCompleted = 0L;
	recalled = 0L;
	received = 0L;
	rejected = 0L;
	deleted = 0L;
}

public Long getDraft() {
	return draft;
}
public void setDraft(Long draft) {
	this.draft = draft;
}
public Long getSubmitted() {
	return submitted;
}
public void setSubmitted(Long submitted) {
	this.submitted = submitted;
}
public Long getCompleted() {
	return completed;
}
public void setCompleted(Long completed) {
	this.completed = completed;
}
public Long getPartiallyCompleted() {
	return partiallyCompleted;
}
public void setPartiallyCompleted(Long partiallyCompleted) {
	this.partiallyCompleted = partiallyCompleted;
}
public Long getRecalled() {
	return recalled;
}
public void setRecalled(Long recalled) {
	this.recalled = recalled;
}

public Long getReceived() {
	return received;
}

public void setReceived(Long recieved) {
	this.received = recieved;
}

public Long getRejected() {
	return rejected;
}

public void setRejected(Long rejected) {
	this.rejected = rejected;
}

public Long getDeleted() {
	return deleted;
}

public void setDeleted(Long deleted) {
	this.deleted = deleted;
}

}
