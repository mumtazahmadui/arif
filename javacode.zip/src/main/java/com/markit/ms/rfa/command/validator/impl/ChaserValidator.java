package com.markit.ms.rfa.command.validator.impl;

import java.util.Map;

import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.bean.BulkValidationBean;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.validator.BulkActionValidator;

public class ChaserValidator extends BulkActionValidator {

	@Override
	public Grid validate(BulkValidationBean validationBean) {
		QueryService<Grid> queryService = bulkValidationQueries.get(BulkActionValidationType.CHASER.toString());

		Map<String, Object> params = Maps.newHashMap();
		params.put("rfaIds", validationBean.getRfaIdList());
		params.put("companyId", validationBean.getCompanyId());

		return queryService.executeQuery(params);
	}
}
