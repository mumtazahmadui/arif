package com.markit.ms.rfa.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.dao.IFileServiceValidatorDAO;
@Repository
public class FileServiceValidatorDAOImpl extends BaseDAOImpl implements IFileServiceValidatorDAO {

	@Value("${CHECK_FILE_ACCESS}")
    private String CHECK_FILE_ACCESS;
	
	@Override
	public boolean validateFileAccess(Long fileId, Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().
				addValue("companyId", companyId).
				addValue("fileId", fileId);
		Integer count = namedParameterJdbcTemplate.queryForObject(CHECK_FILE_ACCESS, paramSource, new RowMapper<Integer>() {
			@Override
			public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
				return rs.getInt("count");
			}
		});
    	return (count != null && count > 0) ? true : false;
	}

}
