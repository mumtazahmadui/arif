package com.markit.ms.rfa.batch.service;

import java.util.concurrent.ExecutionException;

public interface BulkUploadService {

	void validateThrottlingForAction(String bulkAction, int throttlingLevel, Long companyId)
			throws IllegalAccessException;

	// Long processRequest(SelectAllConfig config, List<BulkRequestParam>
	// requestParamList, Map<Long, List<BulkRequestParam>> requestObjectParamMap,
	// Long userId, Long companyId) throws Exception;
	//
	void process(Long savedBulkRequestId, Long userId, Long companyId, String configBeanName, Long templateId,
			String ipAddress) throws InterruptedException, ExecutionException;

	// public Long processBulkUploadRFARequest(SelectAllConfig config,
	// List<BulkRequestParam> requestParamList,
	// Long userId, Long companyId,Long fileId) throws Exception;
	void processSynchronous(Long savedBulkRequestId, Long userId, Long companyId, String configBeanName,
			Long templateId, String ipAddress);
}
