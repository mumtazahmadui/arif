package com.markit.ms.rfa.rfabulkupload.chain.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.markit.ms.common.constants.SpringConstants;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.impl.RemovalCompositeCommand;

@Service
@Scope(SpringConstants.SPRING_SCOPE_PROTOTYPE)
public class RemovalChain implements ActionChain {

	private ActionChain chain;

	@Autowired
	RemovalCompositeCommand removalCommand;

	@Override
	public void setNextChain(ActionChain actionChain) {
		this.chain = actionChain;
	}

	@Override
	public void process(RfaBulkUploadRow rfaBulkUploadRow) {

		removalCommand.execute(rfaBulkUploadRow, chain);

	}

}
