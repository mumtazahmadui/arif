package com.markit.ms.rfa.dao;

import java.util.Date;
import java.util.List;

import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.bean.MasterlistDownload;
import com.markit.ms.rfa.bean.MasterlistValidatorBean;
import com.markit.ms.rfa.bean.McpmMasterlistLegalNameMapper;
import com.markit.ms.rfa.dto.MasterlistSearchRequest;

public interface IMasterlistDao {
	public List<Masterlist> getMasterlistGrid(Long companyId, MasterlistSearchRequest masterlistSearchRequest);
	public Long getMasterlistGridTotalCount(Long companyId, MasterlistSearchRequest masterlistSearchRequest);
	public List<MasterlistDownload> getMasterlistActiveRemoveTabs(Long masterAgreementId);
	public List<MasterlistDownload> getMasterlistModifiedTab(Long masterAgreementId);
	public String getMasterlistControlColumn(Long masterAgreementId);
	public Date getMasterlistUpdateDate(Long masterAgreementId);
	public List<McpmMasterlistLegalNameMapper> getMcpmMasterlistLegalNameMapping(Long masterAgreementId);
	public List<Masterlist> getMasterlistWithoutRfa(Long companyId, Long masterlistId);
	public void deleteMasterlist(Long masterAgreementId);
	public void updateAgreementType(Long masterAgreementId, Long agreementTypeId);
	public List<MasterlistValidatorBean> getUniqueMasterAgreement(MasterlistValidatorBean masterlist);
	public MasterlistValidatorBean getMasterAgreementById(Long masterAgreementId);
}
