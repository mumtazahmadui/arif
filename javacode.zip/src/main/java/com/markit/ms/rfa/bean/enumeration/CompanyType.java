package com.markit.ms.rfa.bean.enumeration;


public enum CompanyType {

	BS("BS","Buy side"), SS("SS","Sell Side");
	
	private String name;
	private String description;
	
	private CompanyType(String name, String description){
		this.name = name;
		this.description = description;
	}
	
	
	public String getName()
    {
        return this.name;
    }
	
	public static CompanyType fromString(String str){
		if (str == null){
			return null;
		}
		for (CompanyType type : CompanyType.values()){
			if (type.name.equalsIgnoreCase(str)) 
				return type;
		}
		return null;
	}
	
	public static Boolean isBSCompany(String companyType){
		if (CompanyType.fromString(companyType).equals(CompanyType.BS)) 
			return true;
		else 
			return false;
	}
	
	public static Boolean isSSCompany(String companyType){
		if (CompanyType.fromString(companyType).equals(CompanyType.SS))
			return true;
		else
			return false;
	}
}
