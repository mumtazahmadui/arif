package com.markit.ms.rfa.rfabulkupload.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.markit.fileutil.common.domain.MCFile;
import com.markit.ms.common.bean.McFile;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.RfaNotificationBean;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.notifier.BulkActionEmailNotificationInvoker;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFABulkUploadUtil;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author prashant.aggarwal
 *
 */
@Service
public class RFABulkUploadFileUtil {

	@Autowired
	private IFileService fileService;

	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	@Autowired
	private BulkActionEmailNotificationInvoker bulkEmailNotificationInvoker;

	public List<RfaBulkUploadRow> readBulkUploadFile() {
		return null;

	}

	/**
	 * Method to write error file when all row objects are validated.
	 * 
	 * @param fileId
	 * @param rfaBulkUploadRows
	 * @throws RFAUIException
	 */
	public void writeErrorFile(Long fileId, List<RfaBulkUploadRow> rfaBulkUploadRows, Long companyId,
			Long bulkRequestId, Long userId) throws RFAUIException {

		McFile mcFile = fileService.getMcFile(fileId, companyId);
		String fileName = mcFile.getFileName();
		String mimeType = mcFile.getMimeType();
		byte[] fileBytes = fileService.getFile(fileId, companyId);
		InputStream inputStream = new ByteArrayInputStream(fileBytes);
		String errorfileName = "ErrorFile.xlsx";

		try {
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheetAt(workbook.getActiveSheetIndex());
			int rowStart = sheet.getFirstRowNum();
			int rowEnd = RFABulkUploadUtil.getLastRowNum(sheet);

			// checks if list of obkects= no of rows in original excel file
			if (rfaBulkUploadRows == null || rfaBulkUploadRows.isEmpty() || rowEnd != rfaBulkUploadRows.size()) {
				throw new RFAUIException(RFAConstants.INCORRECT_ERROR_LIST, HttpStatus.OK.toString());
			}

			// checks if there isno error in list
			int countErrors = 0;
			for (RfaBulkUploadRow rfaBulkUploadRow : rfaBulkUploadRows) {
				if (rfaBulkUploadRow.getErrors() != null && !rfaBulkUploadRows.isEmpty())
					countErrors++;
			}
			if (countErrors == 0)
				return;

			XSSFRow rHeader = sheet.getRow(0);
			int lastColumnHeader = rHeader.getLastCellNum();
			XSSFCell cellHeader = rHeader.createCell(lastColumnHeader);
			cellHeader.setCellValue((String) "Errors(s)");

			XSSFCellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setWrapText(true);

			for (int rowNum = rowStart + 1; rowNum <= rowEnd; rowNum++) {
				XSSFRow r = sheet.getRow(rowNum);
				int lastColumn = lastColumnHeader;
				if (CommonUtil.isNull(r))
					r = sheet.createRow(rowNum);
				XSSFCell cell = r.createCell(lastColumn);

				RfaBulkUploadRow rfaBulkUploadRow = rfaBulkUploadRows.get(rowNum - 1);
				int errorNum = 1;
				StringBuffer buffer = new StringBuffer("");
				if (rfaBulkUploadRow.getErrors() != null && !rfaBulkUploadRows.isEmpty()) {

					for (String str : rfaBulkUploadRow.getErrors()) {
						buffer.append(("<Error " + errorNum + ">:" + str));
						buffer.append("\n");
						errorNum++;
					}
				}
				cell.setCellValue((String) buffer.toString());
				cell.setCellStyle(cellStyle);

			}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			workbook.write(baos);
			byte[] xls = baos.toByteArray();
			MCFile mcFileError = fileService.saveFile(errorfileName, xls, companyId, userId);
			System.out.println(mcFileError.getFileId());

			amendmentLetterService.updateBulkUploadFileTemplate(mcFileError.getFileId(), bulkRequestId,
					RFAConstants.BULK_UPLOAD_STATUS_ERROR);

			RfaNotificationBean bulkNotificationBean = new RfaNotificationBean();
			bulkNotificationBean.setUserId(userId);
			bulkNotificationBean.setUploadId(amendmentLetterService.getBulkRFAUploadId(bulkRequestId));
			bulkNotificationBean.setBulkActionValidationType(BulkActionValidationType.ERROR_NOTIFICATION);
			bulkEmailNotificationInvoker.invoke(bulkNotificationBean);

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method to write error file error is encountered before validating rows in
	 * upload file.
	 * 
	 * @param fileId
	 * @param errorString
	 */
	public void writeMandatoryFieldMissingErrorFile(Long fileId, List<String> errorList, Long companyId,
			Long bulkRequestId, Long userId) {
		McFile mcFile = fileService.getMcFile(fileId, companyId);
		String fileName = mcFile.getFileName();
		String mimeType = mcFile.getMimeType();
		byte[] fileBytes = fileService.getFile(fileId, companyId);
		InputStream inputStream = new ByteArrayInputStream(fileBytes);
		String errorfileName = "ErrorFile.xlsx";
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheetAt(workbook.getActiveSheetIndex());
			int rowStart = sheet.getFirstRowNum();
			int rowEnd = RFABulkUploadUtil.getLastRowNum(sheet);

			if (errorList == null || errorList.isEmpty()) {
				throw new RFAUIException(RFAConstants.INCORRECT_ERROR_LIST, HttpStatus.OK.toString());
			}

			// craete error string
			StringBuffer errorString = new StringBuffer();
			for (String str : errorList)
				errorString.append(str + "\n");

			XSSFRow rHeader = sheet.getRow(0);
			int lastColumnHeader = rHeader.getLastCellNum();
			XSSFCell cellHeader = rHeader.createCell(lastColumnHeader);
			cellHeader.setCellValue((String) "Errors(s)");

			XSSFCellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setWrapText(true);

			for (int rowNum = rowStart + 1; rowNum <= rowEnd; rowNum++) {
				XSSFRow r = sheet.getRow(rowNum);
				int lastColumn = lastColumnHeader;
				XSSFCell cell = r.createCell(lastColumn);

				cell.setCellValue((String) errorString.toString());
				cell.setCellStyle(cellStyle);

			}
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			workbook.write(baos);
			byte[] xls = baos.toByteArray();
			MCFile mcFileError = fileService.saveFile(errorfileName, xls, companyId, userId);
			System.out.println(mcFileError.getFileId());

			amendmentLetterService.updateBulkUploadFileTemplate(mcFileError.getFileId(), bulkRequestId,
					RFAConstants.BULK_UPLOAD_STATUS_ERROR);

			RfaNotificationBean bulkNotificationBean = new RfaNotificationBean();
			bulkNotificationBean.setUserId(userId);
			bulkNotificationBean.setUploadId(amendmentLetterService.getBulkRFAUploadId(bulkRequestId));
			bulkNotificationBean.setBulkActionValidationType(BulkActionValidationType.ERROR_NOTIFICATION);
			bulkEmailNotificationInvoker.invoke(bulkNotificationBean);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// return null;
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void writeErrorFileByFindingRow(Long fileId, List<RfaBulkUploadRow> errorRowList, Long companyId,
			Long bulkRequestId, long userId) {
		McFile mcFile = fileService.getMcFile(fileId, companyId);
		String fileName = mcFile.getFileName();
		String mimeType = mcFile.getMimeType();
		byte[] fileBytes = fileService.getFile(fileId, companyId);
		InputStream inputStream = new ByteArrayInputStream(fileBytes);
		String errorfileName = "ErrorFile.xlsx";

		XSSFWorkbook workbook;
		try {
			workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheetAt(workbook.getActiveSheetIndex());

			int rowStart = sheet.getFirstRowNum();
			int rowEnd = RFABulkUploadUtil.getLastRowNum(sheet);

			XSSFRow rHeader = sheet.getRow(0);
			int lastColumnHeader = rHeader.getLastCellNum();
			XSSFCell cellHeader = rHeader.createCell(lastColumnHeader);
			cellHeader.setCellValue((String) "Errors(s)");
			XSSFCellStyle cellStyle = workbook.createCellStyle();
			cellStyle.setWrapText(true);

			for (RfaBulkUploadRow rfaRow : errorRowList) {
				for (int rowNum = rowStart + 1; rowNum <= rowEnd; rowNum++) {
					XSSFRow r = sheet.getRow(rowNum);
					int lastColumn = lastColumnHeader;
					if (rfaRow.getRowNum() == r.getRowNum()+1) {
						XSSFCell cell = r.createCell(lastColumn);
						cell.setCellValue(RFAConstants.EXCEPTION_CASE);
						cell.setCellStyle(cellStyle);
					}
				}
			}

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			workbook.write(baos);
			byte[] xls = baos.toByteArray();
			MCFile mcFileError = fileService.saveFile(errorfileName, xls, companyId, userId);

			amendmentLetterService.updateBulkUploadFileTemplate(mcFileError.getFileId(), bulkRequestId,
					RFAConstants.BULK_UPLOAD_STATUS_ERROR);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
