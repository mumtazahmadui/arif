package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.MasterlistDownload;
import com.markit.ms.rfa.util.CommonUtil;

public class MasterlistActiveRemoveTabRowMapper implements RowMapper<MasterlistDownload> {
	
	public MasterlistDownload mapRow(ResultSet rs, int rowNum) throws SQLException {
		MasterlistDownload masterlistDownload = new MasterlistDownload();
		masterlistDownload.setModifiedDate(rs.getTimestamp("modified_date"));
		masterlistDownload.setAgreementDate(CommonUtil.getDateForFormat(rs.getDate("agreement_date"), "dd-MMM-yyyy"));
		masterlistDownload.setInvestmentManager(rs.getString("investment_manager"));
		masterlistDownload.setPartyA(rs.getString("partyA"));
		masterlistDownload.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
		masterlistDownload.setAdded(rs.getLong("is_added") == 1 ? true : false);
		masterlistDownload.setEntityId(rs.getLong("entity_id"));
		masterlistDownload.setColumnName(rs.getString("column_name"));
		masterlistDownload.setColumnValue(rs.getString("column_value"));
		masterlistDownload.setControlColumn(rs.getLong("is_control_column") == 1 ? true : false);
		masterlistDownload.setColumnIndex(rs.getLong("column_index"));
		masterlistDownload.setAgreementType(rs.getString("agreement_type"));
		masterlistDownload.setParentEntityId(rs.getLong("parent_entity_id"));
		return masterlistDownload;
	}
}
