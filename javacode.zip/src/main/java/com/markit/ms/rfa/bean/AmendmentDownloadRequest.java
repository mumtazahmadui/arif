package com.markit.ms.rfa.bean;

public class AmendmentDownloadRequest {

	private Long[] amendmentIds;
	
	private boolean isDownloadable;
	public Long[] getAmendmentIds() {
		return amendmentIds;
	}
	public void setAmendmentIds(Long[] amendmentIds) {
		this.amendmentIds = amendmentIds;
	}
	public boolean isDownloadable() {
		return isDownloadable;
	}
	public void setIsDownloadable(boolean isDownloadable) {
		this.isDownloadable = isDownloadable;
	}
	
	
}
