package com.markit.ms.rfa.service.impl;

import java.io.UnsupportedEncodingException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.springframework.stereotype.Service;

import com.google.common.net.UrlEscapers;
import com.marketxs.util.HttpUtil.Base64Encoder;
import com.markit.ms.common.service.impl.HTMLParserImpl;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.service.IAmendmentContentModifier;
import com.markit.ms.rfa.util.CommonUtil;

@Service
public class AmendmentContentModifierImpl implements IAmendmentContentModifier {

	private static final String sleeveAdditionPlaceholder = "<p>﻿</p><input id=\"sleeveAddition\" readonly=\"\" class=\"place-holder disabled\" value=\"< Sleeve Addition >\">";
	private static final String sleeveRemovalPlaceholder = "<p>﻿</p><input id=\"sleeveRemoval\" readonly=\"\" class=\"place-holder disabled\" value=\"< Sleeve Removal >\">";
	private static final String datePinnedPlaceholder = "<input type=\"text\" id=\"date_pinned\" class=\"place-holder disabled display-none\">";
	
	
	@Override
	public String insertSleevePlaceholder(AmendmentLetter amendmentLetter) {
		
		Document doc;
		String base64EncodedContent = "";
		try {
			String content = CommonUtil.convertToUTF8(amendmentLetter.getContent().getBytes());
			
			doc = Jsoup.parse(content);
			
			if (HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter)) {
				Element elementPartyBAddition = doc.getElementById(HTMLParserImpl.AMENDMENT_PLACEHOLDER_ID_PARTYB_ADDED);
				elementPartyBAddition.after(sleeveAdditionPlaceholder);
			}
			if (HTMLParserImpl.hasPartyBRemovalPlaceholder(amendmentLetter)){
				Element elementPartyBRemoval = doc.getElementById(HTMLParserImpl.AMENDMENT_PLACEHOLDER_ID_PARTYB_REMOVED);			
				elementPartyBRemoval.after(sleeveRemovalPlaceholder);
			}
						
			String finalContent = doc.getElementsByTag("body").get(0).html();
			
			String urlEncoded = java.net.URLEncoder.encode(finalContent, "UTF-8").replace("+", "%20");
			base64EncodedContent= Base64Encoder.toBase64(urlEncoded);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return base64EncodedContent;
	}

	@Override
	public String insertDatePinnedPlaceholder(AmendmentLetter amendmentLetter) {
		Document doc;
		String base64EncodedContent = "";
		try {
			String content = CommonUtil.convertToUTF8(amendmentLetter.getContent().getBytes());
			
			doc = Jsoup.parse(content);
			doc.getElementsByTag("body").get(0).child(0).before(datePinnedPlaceholder);
						
			String finalContent = doc.getElementsByTag("body").get(0).html();
			
			String urlEncoded = java.net.URLEncoder.encode(finalContent, "UTF-8").replace("+", "%20");
			base64EncodedContent= Base64Encoder.toBase64(urlEncoded);

		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return "";
		}
		return base64EncodedContent;
	}

	
}
