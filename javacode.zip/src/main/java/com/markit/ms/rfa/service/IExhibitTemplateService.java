package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.dto.TemplateSearchRequest;

public interface IExhibitTemplateService {

	ExhibitTemplate saveExhibitTemplate(ExhibitTemplate exhibitTemplate);
	
	ExhibitTemplate updateExhibitTemplate(ExhibitTemplate exhibitTemplate);
	
	ExhibitTemplate deleteExhibitTemplate(Long id, Long companyId);
	
	List<ExhibitTemplate> getAllExhibitTemplatesByCompanyId(Long companyId);

	List<ExhibitTemplate> getExhibitTemplateGrid(Long companyId, TemplateSearchRequest exhibitTemplateSearchRequest);

	Long getExhibitTemplateGridTotalCount(Long companyId, TemplateSearchRequest exhibitTemplateSearchRequest);

	ExhibitTemplate getExhibitTemplateById(Long exhibitTemplateId, Long companyId);

	void linkMasterlistToExhibitTemplate(Long exhibitTemplateId, Long masterAgreementId, Long companyId, Long userId);

	Integer validateExhibitTemplateColumns(ExhibitTemplate requestTemplate, Boolean forExhibitTemplateCreation, long userId);

	ExhibitTemplate getExhibitTemplateByMasterAgreementId(Long masterAgreementId, Long companyId);
	
}
