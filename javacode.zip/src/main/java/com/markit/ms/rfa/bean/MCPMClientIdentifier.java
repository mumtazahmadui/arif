package com.markit.ms.rfa.bean;

public class MCPMClientIdentifier {
	private String monikerName;
	private String legalName;

	public String getMonikerName() {
		return monikerName;
	}

	public void setMonikerName(String monikerName) {
		this.monikerName = monikerName;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

}
