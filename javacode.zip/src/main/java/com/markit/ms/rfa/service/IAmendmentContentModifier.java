package com.markit.ms.rfa.service;

import com.markit.ms.rfa.bean.AmendmentLetter;

public interface IAmendmentContentModifier {

	/**
	 * @author joseph.howe
	 * 
	 * @param amendmentContent 
	 * 	an encoded String of HTML amendment content  
	 * @return the updated String
	 */
	public String insertSleevePlaceholder(AmendmentLetter amendmentContent);
	
	/**
	 * 
	 * @param amendmentContent
	 * 	an encoded String of HTML amendment content
	 * @return the updated String
	 */	
	public String insertDatePinnedPlaceholder(AmendmentLetter amendmentContent);
}
