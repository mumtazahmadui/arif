package com.markit.ms.rfa.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.dao.IPartyBDao;
import com.markit.ms.rfa.dao.resultsetextractor.SleevePartyBResultSetExtractor;
import com.markit.ms.rfa.dao.rowmapper.PartyBEntityRowMapper;
import com.markit.ms.rfa.util.RFAConstants;

@Repository
public class PartyBDaoImpl extends BaseDAOImpl implements IPartyBDao {

	@Value("${WITHDRAW_PARTYB}")
	private String WITHDRAW_PARTYB;

	@Value("${GET_PARTYB_ENTITY_BY_ID}")
	private String GET_PARTYB_ENTITY_BY_ID;

	@Value("${COPY_PARTYB_TO_SNAP}")
	private String COPY_PARTYB_TO_SNAP;

	@Value("${GET_PARTYB_ID_BY_LEGAL_NAME}")
	private String GET_PARTYB_ID_BY_LEGAL_NAME;

	@Value("${GET_SLEEVES_IN_PROGRESS}")
	private String GET_SLEEVES_IN_PROGRESS;

	@Value("${GET_PARTYB_ENTITY_FROM_MCPM_BY_CI}")
	private String GET_PARTYB_ENTITY_FROM_MCPM_BY_CI;

	@Value("${GET_PARTYB_ENTITY_FROM_MCPM_BY_TLN}")
	private String GET_PARTYB_ENTITY_FROM_MCPM_BY_TLN;

	@Value("${GET_PARTYB_ID_FROM_AMENDMENT}")
	private String GET_PARTYB_ID_FROM_AMENDMENT;

	@Value("${GET_PARTYB_DETAILS_FOR_DESK_NOTIFIC_BS}")
	private String GET_PARTYB_DETAILS_FOR_DESK_NOTIFIC_BS;

	@Value("${GET_PARTYB_DETAILS_FOR_DESK_NOTIFIC_SS}")
	private String GET_PARTYB_DETAILS_FOR_DESK_NOTIFIC_SS;

	@Value("${GET_AMENDMENT_DETAILS_FOR_DESK_NOTIFIC}")
	private String GET_AMENDMENT_DETAILS_FOR_DESK_NOTIFIC;
	
	@Value("${GET_PARTYB_AMENDMENT_STATUS}")
	private String GET_PARTYB_AMENDMENT_STATUS;

	private static final Logger logger = LoggerFactory.getLogger(PartyBDaoImpl.class);

	@Override
	public PartyBEntity withdrawPartyB(Long userId, PartyBEntity partyBEntity) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("id", partyBEntity.getId())
				.addValue("modified_by", userId);
		namedParameterJdbcTemplate.update(WITHDRAW_PARTYB, params);

		partyBEntity = getPartyBEntityById(partyBEntity.getId());
		return partyBEntity;
	}

	@Override
	public PartyBEntity getPartyBEntityById(Long id) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);
		PartyBEntity partyBEntity = namedParameterJdbcTemplate.queryForObject(GET_PARTYB_ENTITY_BY_ID, paramSource,
				new PartyBEntityRowMapper());
		return partyBEntity;
	}

	@Override
	public void copyPartyBEntitiesToSnap(Long amendmentId, Long userId) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("amendmentId", amendmentId);
		namedParameterJdbcTemplate.update(COPY_PARTYB_TO_SNAP, params);
	}

	@Override
	public Long getPartyBIdByLegalName(String legalName, Long amendmentId) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("rfaId", amendmentId).addValue("legalName",
				legalName);
		return namedParameterJdbcTemplate.queryForObject(GET_PARTYB_ID_BY_LEGAL_NAME, params, Long.class);
	}

	@Override
	public Long getPartyBIdByLegalNameAndClientId(String legalName, String clientId, Long amendmentId) {
		StringBuilder whereCondition = new StringBuilder();
		if (legalName != null && StringUtils.isNotBlank(legalName)) {
			whereCondition.append(" and p_details.true_legal_name = :legalName");
		}
		if (clientId != null && StringUtils.isNotBlank(clientId)) {
			whereCondition.append(" and p_details.client_identifier = :clientId");
		}
		String query = GET_PARTYB_ID_BY_LEGAL_NAME.replaceAll("whereCondition", whereCondition.toString());
		SqlParameterSource params = new MapSqlParameterSource().addValue("rfaId", amendmentId)
				.addValue("legalName", legalName).addValue("clientId", clientId);
		return namedParameterJdbcTemplate.queryForObject(query, params, Long.class);
	}

	@Override
	public List<PartyBEntity> getSleevesInProgress(Long parentEntityId, Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("parentEntityId", parentEntityId)
				.addValue("masterAgreementId", masterAgreementId);
		List<PartyBEntity> entities = namedParameterJdbcTemplate.query(GET_SLEEVES_IN_PROGRESS, paramSource,
				new SleevePartyBResultSetExtractor());
		return entities;
	}

	@Override
	public Long getPartyBIdFromMCPM(String fieldName, String fieldValue, Long companyId) {

		SqlParameterSource paramSource;
		Long entityId = null;

		try {
			if (fieldName.equalsIgnoreCase(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD)
					|| fieldName.equalsIgnoreCase(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD)) {
				paramSource = new MapSqlParameterSource().addValue("fieldValue", fieldValue).addValue("companyId",
						companyId);
				entityId = namedParameterJdbcTemplate.queryForObject(GET_PARTYB_ENTITY_FROM_MCPM_BY_TLN, paramSource,
						Long.class);
			} else if (fieldName.equalsIgnoreCase(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD)
					|| fieldName.equalsIgnoreCase(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD)) {
				paramSource = new MapSqlParameterSource().addValue("fieldValue", fieldValue).addValue("companyId",
						companyId);
				entityId = namedParameterJdbcTemplate.queryForObject(GET_PARTYB_ENTITY_FROM_MCPM_BY_CI, paramSource,
						Long.class);
			}
		} catch (Exception e) {
			logger.error("Error finding entity " + fieldValue);
		}

		return entityId;
	}

	@Override
	public List<Long> getPartyBFromAmendmentId(Long amendmentId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentId", amendmentId);

		logger.debug("getPartyBFromAmendmentId : GET_PARTYB_ID_FROM_AMENDMENT : " + GET_PARTYB_ID_FROM_AMENDMENT);

		List<Long> partyBs = namedParameterJdbcTemplate.queryForList(GET_PARTYB_ID_FROM_AMENDMENT, paramSource,
				Long.class);
		return partyBs;
	}

	@Override
	public List<Map<String, Object>> getPartyBDetailsForDeskNotification(List<Long> partyBIds,String companyType) {

		String sql = CompanyType.isSSCompany(companyType) ? GET_PARTYB_DETAILS_FOR_DESK_NOTIFIC_SS
				: GET_PARTYB_DETAILS_FOR_DESK_NOTIFIC_BS;

		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("partyBs", partyBIds);

		logger.debug("getPartyBDetailsForDeskNotification : GET_PARTYB_DETAILS_FOR_DESK_NOTIFIC sql : " + sql);

		return namedParameterJdbcTemplate.queryForList(sql, paramSource);

	}

	@Override
	public List<Map<String, Object>> getAmendmentDetailsForDeskNotification(List<Long> amendmentIds) {

		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentIds",
				CollectionUtils.isNotEmpty(amendmentIds) ? amendmentIds : null);

		logger.debug("getAmendmentDetailsForDeskNotification : " + GET_AMENDMENT_DETAILS_FOR_DESK_NOTIFIC);

		return namedParameterJdbcTemplate.queryForList(GET_AMENDMENT_DETAILS_FOR_DESK_NOTIFIC, paramSource);
	}
	
	@Override
	public List<String> getPartyBAmendmentStatus(List<Long> partyBIds,String companyType) {

		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("partyBs", partyBIds)
				.addValue("isBsCompany", CompanyType.isBSCompany(companyType)?Integer.valueOf(1):Integer.valueOf(0) );

		logger.debug("getPartyBDetailsStatus : GET_PARTYB_AMENDMENT_STATUS sql : " + GET_PARTYB_AMENDMENT_STATUS);

		return namedParameterJdbcTemplate.queryForList(GET_PARTYB_AMENDMENT_STATUS, paramSource,String.class);

	}
}
