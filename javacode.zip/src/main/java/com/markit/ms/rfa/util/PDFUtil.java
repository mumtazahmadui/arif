package com.markit.ms.rfa.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.util.PDFMergerUtility;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;

public class PDFUtil {
	public static final int PIXEL_TO_INCHES_FACTOR = 100;
	public static final int TEXT_WIDTH = 1233;
	public static final int COLUMN_WIDTH = 250;
	 public static String stripNonValidXMLCharacters(String in) {

	        StringBuilder out = new StringBuilder(); 
	        char current;

	        if (in == null || ("".equals(in))) return "";
	            for (int i = 0; i < in.length(); i++) {
	                current = in.charAt(i);
	                if ((current == 0x9) ||
	                    (current == 0xA) ||
	                    (current == 0xD) ||
	                    ((current >= 0x20) && (current <= 0xD7FF)) ||
	                    ((current >= 0xE000) && (current <= 0xFFFD)) ||
	                    ((current >= 0x10000) && (current <= 0x10FFFF)))
	                    out.append(current);
	                }
	    
	        return out.toString();
	    }
	 
		static public boolean checkPartyBAdded(List<PartyBEntity> partyBEntities) {
			for (PartyBEntity partyBEntity : partyBEntities) {
				if(partyBEntity.getIsAdded() 
						&& (partyBEntity.getDeleted() ==null || partyBEntity.getDeleted() == 0) 
						&& partyBEntity.getAcknowledgementStatus() != PartyBAckStatus.WITHDRAWN) {
					return true;
				}
			}
			return false;
		}
		static public int calculateWidth(Integer columns) {
			int width = TEXT_WIDTH;
			if(columns != null) {
				int columnPixel = COLUMN_WIDTH;
				width = (columns +1) * columnPixel;
				width = width > TEXT_WIDTH ? width : TEXT_WIDTH;
			}   
	       //Convert to inches
	        int widthInches = (int)(width/PIXEL_TO_INCHES_FACTOR);
			return widthInches;
		}
		 public static byte[] merge(byte[]... pdfContent) {

			    if (pdfContent == null || pdfContent.length == 0) {
			      throw new IllegalArgumentException("No Pdf content supplied for merging");
			    }

			    ByteArrayOutputStream bos = new ByteArrayOutputStream();

			    try {

			      PDFMergerUtility pdfMergerUtility = new PDFMergerUtility();
			      for (byte[] byteArray : pdfContent) {
			        pdfMergerUtility.addSource(new ByteArrayInputStream(byteArray));
			      }

			      pdfMergerUtility.setDestinationStream(bos);
			      pdfMergerUtility.mergeDocuments();

			    }

			    catch (Exception ex) {
			      throw new RuntimeException(ex.getMessage());
			    }
			    return bos.toByteArray();
			  }
		 
		 public static byte[] convertImageToPDF(byte[] bytes) throws IOException, DocumentException {
				ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();
				Document document = null;
				try {
					Image image = Image.getInstance(bytes);
					image.setAbsolutePosition(0, 0);
					image.setBorderWidth(0);
					document = new Document(new Rectangle(image.getPlainWidth(), image.getPlainHeight()));
					PdfWriter writer = PdfWriter.getInstance(document, arrayOutputStream);
					writer.open();
					document.open();
					document.add(image);
					document.close();
					writer.close();
				} finally {
					arrayOutputStream.close();
				}
				return arrayOutputStream.toByteArray();
			}
}
