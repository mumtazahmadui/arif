package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.MasterAgreement;

public class MasterAgreementListResultSetExtractor implements
		ResultSetExtractor<List<MasterAgreement>> {

	@Override
	public List<MasterAgreement> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Map<Long, MasterAgreement> agreementMap = new LinkedHashMap<Long, MasterAgreement>();
		
		while (rs.next()){
			MasterAgreement agreement = agreementMap.get(rs.getLong("id"));
			if (agreement == null){
				agreement = new MasterAgreement();
				agreement.setId(rs.getLong("id"));
				agreement.setAgreementDate(rs.getDate("agreement_date"));
				agreement.setAgreementType(rs.getString("agreementType"));
				agreement.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
				
				Entity partyA = new Entity();
				partyA.setId(rs.getLong("partyAEntityId"));
				partyA.setName(rs.getString("partyAName"));
				partyA.setTrueLegalName(rs.getString("partyALegalName"));
				partyA.setClientIdentifier(rs.getString("partyAClientIdentifier"));
				partyA.setLei(rs.getString("partyALeiName"));
				agreement.setPartyA(partyA);
				
				Entity investmentManager = new Entity();
				investmentManager.setId(rs.getLong("IMEntityId"));
				investmentManager.setName(rs.getString("IMName"));
				investmentManager.setTrueLegalName(rs.getString("IMLegalName"));
				investmentManager.setClientIdentifier(rs.getString("IMClientIdentifier"));
				investmentManager.setLei(rs.getString("IMLeiName"));
				agreement.setInvestmentManager(investmentManager);
				
				agreementMap.put(agreement.getId(), agreement);
			}
		}
		List<MasterAgreement> list = new ArrayList<MasterAgreement>(agreementMap.values());
		return list;
	}

}
