package com.markit.ms.rfa.bean;

import java.util.List;

public class RfaFilterResponse {
private String fieldIdentifier;
private String defaultValue;
private List<String> values;
public String getDefaultValue() {
	return defaultValue;
}
public void setDefaultValue(String defaultValue) {
	this.defaultValue = defaultValue;
}
public List<String> getValues() {
	return values;
}
public void setValues(List<String> values) {
	this.values = values;
}
public String getFieldIdentifier() {
	return fieldIdentifier;
}
public void setFieldIdentifier(String fieldIdentifier) {
	this.fieldIdentifier = fieldIdentifier;
}




}
