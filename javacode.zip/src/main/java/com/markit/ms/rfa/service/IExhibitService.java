package com.markit.ms.rfa.service;

import com.markit.ms.rfa.bean.Exhibit;

public interface IExhibitService {
	public Exhibit getExhibitByAmendmentId(Long amendmentId);
	public Exhibit createExhibit(Exhibit exhibit);
	public Exhibit updateExhibit(Long companyId, String companyType, Long userId, Exhibit exhibit) throws Exception;
}
