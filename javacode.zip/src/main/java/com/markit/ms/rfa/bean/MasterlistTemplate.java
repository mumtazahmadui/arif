package com.markit.ms.rfa.bean;

import java.util.Date;
import java.util.List;


public class MasterlistTemplate {
	
	private Long id;
	private String templateName;
	private Long companyId;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Integer deleted;
	List<MasterAgreementBasic> masterListLinked = null;
	
	//Added extra field to store count of total rows returned for MLTemplate Grid Search
	private Integer totalRowCount;
	
	List<TemplateField> templateFields = null;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}	

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public List<TemplateField> getTemplateFields() {
		return templateFields;
	}

	public void setTemplateFields(List<TemplateField> templateFields) {
		this.templateFields = templateFields;
	}

	public Integer getDeleted() {
		return deleted;
	}

	public void setDeleted(Integer deleted) {
		this.deleted = deleted;
	}

	public Integer getTotalRowCount() {
		return totalRowCount;
	}

	public void setTotalRowCount(Integer totalRowCount) {
		this.totalRowCount = totalRowCount;
	}

	public List<MasterAgreementBasic> getMasterListLinked() {
		return masterListLinked;
	}

	public void setMasterListLinked(List<MasterAgreementBasic> masterListLinked) {
		this.masterListLinked = masterListLinked;
	}
	
	
			
}
