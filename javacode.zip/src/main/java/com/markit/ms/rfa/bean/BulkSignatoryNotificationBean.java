package com.markit.ms.rfa.bean;

public class BulkSignatoryNotificationBean extends BulkNotificationBean {

	private boolean isESign;
	private boolean isWSign;
	private String customNotificationMessage;
	private String notifiedBy;
	private String senderName;
	
	
	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getNotifiedBy() {
		return notifiedBy;
	}

	public void setNotifiedBy(String notifiedBy) {
		this.notifiedBy = notifiedBy;
	}

	public boolean isESign() {
		return isESign;
	}

	public void setESign(boolean isESign) {
		this.isESign = isESign;
	}

	public boolean isWSign() {
		return isWSign;
	}

	public void setWSign(boolean isWSign) {
		this.isWSign = isWSign;
	}

	public String getCustomNotificationMessage() {
		return customNotificationMessage;
	}

	public void setCustomNotificationMessage(String customNotificationMessage) {
		this.customNotificationMessage = customNotificationMessage;
	}

}