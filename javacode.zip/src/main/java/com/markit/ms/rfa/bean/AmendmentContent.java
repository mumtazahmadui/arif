package com.markit.ms.rfa.bean;

import java.util.List;

public class AmendmentContent {
	private String content;
	private String comment;
	private List<AmendmentCommentAudit> commentlog;
	private List<AmendmentChangeAudit> changelog;
	private Long rfaid;
	private ActionCount changeLogCount;
	private ActionCount commentCount;
	private String partyType;
	private Integer agreed;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public List<AmendmentCommentAudit> getCommentlog() {
		return commentlog;
	}

	public void setCommentlog(List<AmendmentCommentAudit> commentlog) {
		this.commentlog = commentlog;
	}

	public List<AmendmentChangeAudit> getChangelog() {
		return changelog;
	}

	public void setChangelog(List<AmendmentChangeAudit> changelog) {
		this.changelog = changelog;
	}

	public Long getRfaid() {
		return rfaid;
	}

	public void setRfaid(Long rfaid) {
		this.rfaid = rfaid;
	}

	public ActionCount getChangeLogCount() {
		return changeLogCount;
	}

	public void setChangeLogCount(ActionCount changeLogCount) {
		this.changeLogCount = changeLogCount;
	}

	public ActionCount getCommentCount() {
		return commentCount;
	}

	public void setCommentCount(ActionCount commentCount) {
		this.commentCount = commentCount;
	}

	public String getPartyType() {
		return partyType;
	}

	public void setPartyType(String partyType) {
		this.partyType = partyType;
	}

	public Integer getAgreed() {
		return agreed;
	}

	public void setAgreed(Integer agreed) {
		this.agreed = agreed;
	}

}
