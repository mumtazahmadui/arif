package com.markit.ms.rfa.controller;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.markit.fileutil.common.domain.FileDetails;
import com.markit.fileutil.file.service.IFileUtilService;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.rfa.service.ITermsOfUseService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;

@RestController
@RequestMapping(value = "/v1/termsOfUse")
@Api(value = "terms of use" , description = "Terms of use API")
public class TermsOfUseController {
	  @Resource IFileService fileService;
	  @Resource ITermsOfUseService termsOfUseService;
	  @Resource QueryService<Long> selectTermsOfUseFile;
	  @Resource IFileUtilService fileUtil;
	  @RequestMapping(method = RequestMethod.POST)
	  @ResponseStatus(value = HttpStatus.CREATED)
	  public @ResponseBody void createTermsOfUse(
			  @RequestParam String version, 
			  @RequestParam MultipartFile file, 
			  HttpServletRequest request)
	      throws Exception {
		  Long userId = CommonUtil.getUserIdFromSession(request);
		  Long companyId = CommonUtil.getUserIdFromSession(request);
		  termsOfUseService.saveTermsOfUse(file.getBytes(), version, companyId, userId);
	  }
	  
	  @RequestMapping(method = RequestMethod.GET)
	  @ResponseStatus(value = HttpStatus.CREATED)
	  public @ResponseBody void createTermsOfUse(@RequestParam String version,
			  HttpServletResponse response)
	      throws Exception {
		  Long fileId = selectTermsOfUseFile.executeQuery("version" , version);
		  byte[] fileContent = null;
		  if(fileId != null) {
			  fileContent = fileService.getFile(fileId,1L);
		  }
		  WebUtils.write2Response(response, fileContent, "application/pdf");
	  }
}
