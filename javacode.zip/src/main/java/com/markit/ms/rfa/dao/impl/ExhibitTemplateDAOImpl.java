package com.markit.ms.rfa.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.bean.ExhibitTemplateColumn;
import com.markit.ms.rfa.dao.IExhibitTemplateDAO;
import com.markit.ms.rfa.dao.resultsetextractor.ExhibitTemplateResultSetExtractor;
import com.markit.ms.rfa.dto.TemplateSearchRequest;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Repository
public class ExhibitTemplateDAOImpl extends BaseDAOImpl implements IExhibitTemplateDAO
{
	@Value("${REINITIALIZE_EXISTING_COLUMN}")
    private String REINITIALIZE_EXISTING_COLUMN;

	@Value("${SAVE_RFA_EXHIBIT_TEMPLATE}")
    private String SAVE_RFA_EXHIBIT_TEMPLATE;
    
    @Value("${SAVE_RFA_EXHIBIT_TEMPLATE_COL}")
    private String SAVE_RFA_EXHIBIT_TEMPLATE_COL;
    
    @Value("${UPDATE_RFA_EXHIBIT_TEMPLATE}")
    private String UPDATE_RFA_EXHIBIT_TEMPLATE;
    
    @Value("${UPDATE_RFA_EXHIBIT_TEMPLATE_COL}")
    private String UPDATE_RFA_EXHIBIT_TEMPLATE_COL;
    
    @Value("${DELETE_RFA_EXHIBIT_TEMPLATE}")
    private String DELETE_RFA_EXHIBIT_TEMPLATE;
    
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_BY_ID}")
    private String GET_RFA_EXHIBIT_TEMPLATE_BY_ID;
    
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID}")
    private String GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID;    
    
    @Value("${GET_ALL_RFA_EXHIBIT_TEMPLATES_BY_COMPANY_ID}")
    private String GET_ALL_RFA_EXHIBIT_TEMPLATES_BY_COMPANY_ID;
    
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_GRID}")
    private String GET_RFA_EXHIBIT_TEMPLATE_GRID;
    
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_GRID_TOTAL_COUNT}")
    private String GET_RFA_EXHIBIT_TEMPLATE_GRID_TOTAL_COUNT;
    
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_BY_NAME}")
    private String GET_RFA_EXHIBIT_TEMPLATE_BY_NAME;
    
    @Value("${LINK_MASTERLIST_TO_EXHIBIT_TEMPLATE}")
    private String LINK_MASTERLIST_TO_EXHIBIT_TEMPLATE;
    
    @Value("${GET_RFA_EXHIBIT_TEMPLATE_BY_ID_WITH_DELETED_COLUMNS}")
    private String GET_RFA_EXHIBIT_TEMPLATE_BY_ID_WITH_DELETED_COLUMNS;

    @Value("${GET_ALL_UNSIGNED_AMENDMENT_RELATED_TO_EXHIBIT_TEMPLATE}")
    private String GET_ALL_UNSIGNED_AMENDMENT_RELATED_TO_EXHIBIT_TEMPLATE;
    
    @Value("${IS_COLUMN_NAME_CHANGED}")
    private String IS_COLUMN_NAME_CHANGED;
    
    @Autowired
    AmendmentLetterDaoImpl amendmentLetterDao;
    
    @Override
    public ExhibitTemplate saveExhibitTemplate(ExhibitTemplate exhibitTemplate)
    {        
        SqlParameterSource paramSource = new MapSqlParameterSource()
        	.addValue("name", exhibitTemplate.getName())
            .addValue("companyid", exhibitTemplate.getCompanyId())
            .addValue("text_content", exhibitTemplate.getTextContent().getBytes())
            .addValue("html_content", exhibitTemplate.getHtmlContent().getBytes())
            .addValue("created_by", exhibitTemplate.getCreatedBy())
            .addValue("modified_by", exhibitTemplate.getModifiedBy());
        KeyHolder keyHolder = new GeneratedKeyHolder();
        namedParameterJdbcTemplate.update(SAVE_RFA_EXHIBIT_TEMPLATE, paramSource, keyHolder);
        exhibitTemplate.setId(keyHolder.getKey().longValue());
        
        if(null != exhibitTemplate.getColumns()) {
        	List<ExhibitTemplateColumn> exhibitTemplateColumnList = exhibitTemplate.getColumns();
        	for (ExhibitTemplateColumn exhibitTemplateColumn : exhibitTemplateColumnList) {
        		if(exhibitTemplateColumn.getDeleted() != null && exhibitTemplateColumn.getDeleted() == 1) {
                    continue;
        		} else {
                     paramSource = new MapSqlParameterSource()
                      .addValue("rfa_exhibit_template_id", exhibitTemplate.getId())
                      .addValue("column_name", exhibitTemplateColumn.getColumnName())
                      .addValue("column_index", exhibitTemplateColumn.getColumnIndex())
                      .addValue("column_style", exhibitTemplateColumn.getColumnStyle())
                      .addValue("created_by", exhibitTemplateColumn.getCreatedBy())
                      .addValue("modified_by", exhibitTemplateColumn.getModifiedBy())
                      .addValue("is_control_column", exhibitTemplateColumn.isControlColumn()? 1 :0)
                      .addValue("REINITIALIZED", exhibitTemplateColumn.isReinitialized()? 1 : 0);
                namedParameterJdbcTemplate.update(SAVE_RFA_EXHIBIT_TEMPLATE_COL, paramSource);
                //exhibitTemplateColumn.setId(keyHolder.getKey().longValue());
              }
			}
        }
        return getExhibitTemplateById(exhibitTemplate.getId(), 0L,exhibitTemplate.getCompanyId());
    }
    
    @Override
    public ExhibitTemplate updateExhibitTemplate(ExhibitTemplate exhibitTemplate)
    {
    	MapSqlParameterSource paramSource = new MapSqlParameterSource()
    		.addValue("id", exhibitTemplate.getId())
			.addValue("name", exhibitTemplate.getName())
			.addValue("companyid", exhibitTemplate.getCompanyId())
			.addValue("text_content", exhibitTemplate.getTextContent().getBytes())
			.addValue("html_content", exhibitTemplate.getHtmlContent().getBytes())
			.addValue("modified_by", exhibitTemplate.getModifiedBy());
    	namedParameterJdbcTemplate.update(UPDATE_RFA_EXHIBIT_TEMPLATE, paramSource);
    	
    	Boolean newColAdded = false;
    	
    	if(null != exhibitTemplate.getColumns()) {
    		List<ExhibitTemplateColumn> exhibitTemplateColumnList = exhibitTemplate.getColumns();
        	for (ExhibitTemplateColumn exhibitTemplateColumn : exhibitTemplateColumnList) {
        		paramSource = new MapSqlParameterSource()
	        		.addValue("rfa_exhibit_template_id", exhibitTemplate.getId())
	    			.addValue("column_name", exhibitTemplateColumn.getColumnName())
	    			.addValue("column_index", exhibitTemplateColumn.getColumnIndex())
	    			.addValue("column_style", exhibitTemplateColumn.getColumnStyle())
	    			.addValue("modified_by", exhibitTemplateColumn.getModifiedBy())
	        		.addValue("deleted", exhibitTemplateColumn.getDeleted())
	        		.addValue("is_control_column", exhibitTemplateColumn.isControlColumn()? 1 :0);
        		if(null != exhibitTemplateColumn.getId() && exhibitTemplateColumn.getId() > 0) {
        			paramSource.addValue("id", exhibitTemplateColumn.getId());
        			Integer columnNameChanged = isColumnNameChanged(paramSource);
        			paramSource.addValue("column_name_changed", columnNameChanged);
        			namedParameterJdbcTemplate.update(UPDATE_RFA_EXHIBIT_TEMPLATE_COL, paramSource);
        			if(columnNameChanged == 1) {
        				exhibitTemplateColumn.setReinitialized(true);
        				createNewOrReinitializeExistingColumn(paramSource,
							exhibitTemplateColumn);
        			}
        		} else {
        			createNewOrReinitializeExistingColumn(paramSource,
							exhibitTemplateColumn);
        			//newColAdded = true;
        			//exhibitTemplateColumn.setId(keyHolder.getKey().longValue());
        		}
        	}
       // 	if(newColAdded){
        		List<Long> amendmentLetterIdList = namedParameterJdbcTemplate.query(
            			GET_ALL_UNSIGNED_AMENDMENT_RELATED_TO_EXHIBIT_TEMPLATE, paramSource, new RowMapper<Long>() {
            				public Long mapRow(ResultSet rs, int rowNum)throws SQLException {
				               	return rs.getLong(1);
        					}
						});
        		if(amendmentLetterIdList.size() > 0){
	        		
	        		for(Long amendmentLetterId : amendmentLetterIdList){
	        			amendmentLetterDao.updateBSTaskAndNextSteps(amendmentLetterId, RFAConstants.ACTION_EXHIBIT_TEMPLAT_UPDATE);
	        		}
        		}
    //    	}
    	}
    	return getExhibitTemplateById(exhibitTemplate.getId(), 0L,exhibitTemplate.getCompanyId());
    }

	private Integer isColumnNameChanged(MapSqlParameterSource paramSource) {
 
		List<Integer> columnChanged = namedParameterJdbcTemplate.query(
    			IS_COLUMN_NAME_CHANGED, paramSource, new RowMapper<Integer>() {

					@Override
					public Integer mapRow(ResultSet rs, int rowNum)
							throws SQLException {
							Integer columnChanged =  rs.getInt("COLUMN_CHANGED");
							return columnChanged;
					}
    			});
		return columnChanged.get(0)!= null? columnChanged.get(0): 0;
	}

	

	private void createNewOrReinitializeExistingColumn(
			MapSqlParameterSource paramSource,
			ExhibitTemplateColumn exhibitTemplateColumn) {
		paramSource.addValue("created_by", exhibitTemplateColumn.getCreatedBy());
		paramSource.addValue("REINITIALIZED", exhibitTemplateColumn.isReinitialized()? 1 : 0);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		namedParameterJdbcTemplate.update(SAVE_RFA_EXHIBIT_TEMPLATE_COL, paramSource, keyHolder);
	}
    
    @Override
    public ExhibitTemplate deleteExhibitTemplate(Long id,Long companyid)
    {        
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id).addValue("companyid", companyid);
    	namedParameterJdbcTemplate.update(DELETE_RFA_EXHIBIT_TEMPLATE, paramSource);
    	return getExhibitTemplateById(id, 1L,companyid);
    }
    
    @Override
	public List<ExhibitTemplate> getAllExhibitTemplatesByCompanyId(Long companyId) {
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", companyId);
    	List<ExhibitTemplate> exhibitTemplateList = namedParameterJdbcTemplate.query(
    			GET_ALL_RFA_EXHIBIT_TEMPLATES_BY_COMPANY_ID, paramSource, new ExhibitTemplateResultSetExtractor(true));
    	return exhibitTemplateList;
	}
    
	@Override
	public List<ExhibitTemplate> getExhibitTemplateGrid(Long companyId, TemplateSearchRequest exhibitTemplateSearchRequest) {
		List<Lookup> templateNameList = exhibitTemplateSearchRequest.getTemplateName();
    	List<Lookup> createdByList = exhibitTemplateSearchRequest.getCreatedBy();
    	List<Lookup> linkedByList = exhibitTemplateSearchRequest.getLinkedBy();
    	List<Lookup> partyAList = exhibitTemplateSearchRequest.getPartyALegalName();
    	List<String> refIsdaDateList = exhibitTemplateSearchRequest.getRefIsdaDate();
    	List<Lookup> masterlistIdentifierList = exhibitTemplateSearchRequest.getMasterlistIdentifier();
    	
    	StringBuilder whereCondition = new StringBuilder();
    	
    	MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("offset", exhibitTemplateSearchRequest.getOffSet())
			.addValue("page_size", exhibitTemplateSearchRequest.getPageSize());
    	
    	if(null != templateNameList && templateNameList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : templateNameList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and ret.id in (:name)");
    		paramSource.addValue("name", filteredIdList);
    	}
    	if(null != createdByList && createdByList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : createdByList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and ret.created_by in (:created_by)");
			paramSource.addValue("created_by", filteredIdList);
    	}
    	if(null != linkedByList && linkedByList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : linkedByList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and ret.linked_by in (:linked_by)");
			paramSource.addValue("linked_by", filteredIdList);
    	}
    	if(null != partyAList && partyAList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : partyAList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and e.entityid in (:partyA)");
			paramSource.addValue("partyA", filteredIdList);
    	}
    	if(null != refIsdaDateList && refIsdaDateList.size() > 0) {
    		whereCondition.append(" and rma.AGREEMENT_DATE in (:agreementDate) ");
        	paramSource.addValue("agreementDate", refIsdaDateList);
    	}
    	if(null != masterlistIdentifierList && masterlistIdentifierList.size() > 0) {
    		List<String> filteredIdList = new ArrayList<String>();
    		for (Lookup lookup : masterlistIdentifierList) {
    			filteredIdList.add(lookup.getValue());
			}
    		whereCondition.append(" and rma.MASTERLIST_IDENTIFIER in (:masterlist_identifier) ");
			paramSource.addValue("masterlist_identifier", filteredIdList);
    	}
    	
    	String gridQuery = GET_RFA_EXHIBIT_TEMPLATE_GRID.replaceAll("whereCondition", whereCondition.toString());
    	
    	List<ExhibitTemplate> exhibitTemplateList = namedParameterJdbcTemplate.query(
    			gridQuery, paramSource, new ExhibitTemplateResultSetExtractor(false));
    	return exhibitTemplateList;
	}

	@Override
	public Long getExhibitTemplateGridTotalCount(Long companyId,
			TemplateSearchRequest exhibitTemplateSearchRequest) {
		List<Lookup> templateNameList = exhibitTemplateSearchRequest.getTemplateName();
    	List<Lookup> createdByList = exhibitTemplateSearchRequest.getCreatedBy();
    	List<Lookup> partyAList = exhibitTemplateSearchRequest.getPartyALegalName();
    	List<String> refIsdaDate = exhibitTemplateSearchRequest.getRefIsdaDate();
    	List<Lookup> masterlistIdentifers = exhibitTemplateSearchRequest.getMasterlistIdentifier();
    	List<Lookup> linkedBy = exhibitTemplateSearchRequest.getLinkedBy();
    	StringBuilder whereCondition = new StringBuilder();
    	
    	MapSqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId);
    	
    	if(null != templateNameList && templateNameList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : templateNameList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and ret.id in (:name)");
    		paramSource.addValue("name", filteredIdList);
    	}
    	if(null != createdByList && createdByList.size() > 0) {
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : createdByList) {
    			filteredIdList.add(lookup.getId());
			}
    		whereCondition.append(" and ret.created_by in (:created_by)");
			paramSource.addValue("created_by", filteredIdList);
    	}
    	if (null != partyAList && partyAList.size() > 0){
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : partyAList){
    			filteredIdList.add(lookup.getId());
    		}
    		whereCondition.append("and rma.partya_companyid in (:partyA_companyId)");
			paramSource.addValue("partyA_companyId", filteredIdList);
    	}
    	if (null != masterlistIdentifers && masterlistIdentifers.size() > 0){
    		List<String> filteredValueList = new ArrayList<String>();
    		for (Lookup lookup : masterlistIdentifers){
    			filteredValueList.add(lookup.getValue());
    		}
    		whereCondition.append("and rma.masterlist_identifier in (:masterlist_identifier)");
			paramSource.addValue("masterlist_identifier", filteredValueList);
    	}
    	if (null != linkedBy && linkedBy.size() > 0){
    		List<Long> filteredIdList = new ArrayList<Long>();
    		for (Lookup lookup : linkedBy){
    			filteredIdList.add(lookup.getId());
    		}
    		whereCondition.append("and ret.linked_by in (:linked_by)");
			paramSource.addValue("linked_by", filteredIdList);
    	}
		if(refIsdaDate != null && refIsdaDate.size() > 0) {
			whereCondition.append(" and rma.agreement_date in (:refIsdaDate) ");
			paramSource.addValue("refIsdaDate", refIsdaDate);
    	}
    	String countQuery = GET_RFA_EXHIBIT_TEMPLATE_GRID_TOTAL_COUNT.replaceAll("whereCondition", whereCondition.toString());
    	
    	Long totalCount = namedParameterJdbcTemplate.queryForObject(countQuery, paramSource, Long.class);
    	return totalCount;
	}
	
	@Override
	public ExhibitTemplate getExhibitTemplateById(Long id, Long deleted, Long companyid)
    {        
    	ExhibitTemplate exhibitTemplate = new ExhibitTemplate();
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id).addValue("deleted", deleted).addValue("companyid", companyid);
    	List<ExhibitTemplate> exhibitTemplateList = namedParameterJdbcTemplate.query(
    			GET_RFA_EXHIBIT_TEMPLATE_BY_ID, paramSource, new ExhibitTemplateResultSetExtractor(true));
    	if(null != exhibitTemplateList && exhibitTemplateList.size()>0) {
    		exhibitTemplate = exhibitTemplateList.get(0);
    	}
    	return exhibitTemplate;
    }
	
	@Override
	public ExhibitTemplate getExhibitTemplateByMasterAgreementId(Long id, Long deleted, Long companyid)
    {        
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id).addValue("deleted", deleted).addValue("companyid", companyid);
    	List<ExhibitTemplate> exhibitTemplateList = namedParameterJdbcTemplate.query(
    			GET_RFA_EXHIBIT_TEMPLATE_BY_MASTER_AGREEMENT_ID, paramSource, new ExhibitTemplateResultSetExtractor(true));
    	if(null != exhibitTemplateList && exhibitTemplateList.size()>0) {
        	ExhibitTemplate exhibitTemplate = new ExhibitTemplate();
    		exhibitTemplate = exhibitTemplateList.get(0);
        	return exhibitTemplate;
    	}
    	else
    		return null;
    }	
	
	@Override
	public Long getExhibitTemplateByName(Long companyId, String name) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyid", companyId).addValue("name",
				name);
		try {
			// Have called queryForList instead of queryForObject because old
			// data has multiple exhibit template with same name. After this
			// change
			// there can not be 2 exhibit template with same name.
			List<Long> id = namedParameterJdbcTemplate.queryForList(GET_RFA_EXHIBIT_TEMPLATE_BY_NAME, paramSource,
					Long.class);
			if (CommonUtil.isNotNull(id) && !id.isEmpty())
				return id.get(0);
			else
				return null;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	@Override
	public void linkMasterlistToExhibitTemplate(Long exhibitTemplateId, Long masterAgreementId, Long companyId, Long userId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("exhibitTemplateId", exhibitTemplateId)
				.addValue("masterAgreementId", masterAgreementId)
				.addValue("companyId", companyId)
				.addValue("userId", userId);
		namedParameterJdbcTemplate.update(LINK_MASTERLIST_TO_EXHIBIT_TEMPLATE, paramSource);
	}

	@Override
	public Integer validateExhibitTemplateColumns(ExhibitTemplate exhibitTemplateRequest, Long userID)
	{
		List<ExhibitTemplateColumn> exhibitTempColForDeletion = new ArrayList<ExhibitTemplateColumn>();
		List<ExhibitTemplateColumn> mergeColumns = new ArrayList<ExhibitTemplateColumn>();
		ExhibitTemplate exhibitTemplate = getExhibitTemplateByIdWithDeletedColumns(exhibitTemplateRequest.getId(), exhibitTemplateRequest.getCompanyId());
		if(null != exhibitTemplateRequest.getColumns() && null != exhibitTemplate.getColumns()) {
    		List<ExhibitTemplateColumn> exhibitTemplateReqColumnList = exhibitTemplateRequest.getColumns();
        	for (ExhibitTemplateColumn exhibitTemplateReqColumn : exhibitTemplateReqColumnList) {
        		if(exhibitTemplateReqColumn.getId() == null || exhibitTemplateReqColumn.getDeleted().longValue() != 1L){
        			for(ExhibitTemplateColumn exhibitTemplateColumn : exhibitTemplate.getColumns()){
        				String reqColumnName = exhibitTemplateReqColumn.getColumnName().replaceAll("[^a-zA-Z0-9 ]", "").trim();
        				String dbColumnName = exhibitTemplateColumn.getColumnName().replaceAll("[^a-zA-Z0-9 ]", "").trim();
        				if((reqColumnName.length() == 0 && exhibitTemplateReqColumn.getColumnName().length() > 0)){
        					return 2;
        				}
        				if(isDBColumnIDNotEqualToRequestColumnID(exhibitTemplateReqColumn,
								exhibitTemplateColumn, reqColumnName,
								dbColumnName) ||
        						(exhibitTemplateReqColumn.getId() == null && 
        								reqColumnName.equalsIgnoreCase(dbColumnName))){
			        					if(exhibitTemplateColumn.getDeleted() != 1L) {
			        						return 3;
			        					}
			        					if(isDBColumnIDNotEqualToRequestColumnID(exhibitTemplateReqColumn,
			    								exhibitTemplateColumn, reqColumnName,
			    								dbColumnName)) {
			        						
			        						ExhibitTemplateColumn exhibitTemplateColumnForDeletion = new ExhibitTemplateColumn();
			        						exhibitTemplateColumnForDeletion.setId(exhibitTemplateReqColumn.getId());
			        						exhibitTemplateColumnForDeletion.setColumnName(exhibitTemplateColumn.getColumnName());
			        						exhibitTemplateColumnForDeletion.setColumnIndex(exhibitTemplateColumn.getColumnIndex());
			        						exhibitTemplateColumnForDeletion.setColumnStyle(exhibitTemplateColumn.getColumnStyle());
			        		    			exhibitTemplateColumnForDeletion.setModifiedBy(exhibitTemplateColumn.getModifiedBy());
			        		    			exhibitTemplateColumnForDeletion.setControlColumn(true);
			        		        		exhibitTemplateColumnForDeletion.setDeleted(1L);
			        		        		exhibitTempColForDeletion.add(exhibitTemplateColumnForDeletion);
			        					}
			        					mergeColumns.add(exhibitTemplateReqColumn);
			        					
        				}
        			}
        		}
        	}
    	}
		exhibitTemplateRequest.getColumns().addAll(exhibitTempColForDeletion);
		for(ExhibitTemplateColumn mergeColumn : mergeColumns) {
			this.mergeExistingColumn(
					mergeColumn.getColumnName()
					, mergeColumn.getColumnIndex().intValue()
					, exhibitTemplate.getId()
					, userID);
			mergeColumn.setReinitialized(true);
			mergeColumn.setId(null);
		}
		return 1;
	}


	private boolean isDBColumnIDNotEqualToRequestColumnID(
			ExhibitTemplateColumn exhibitTemplateReqColumn,
			ExhibitTemplateColumn exhibitTemplateColumn, String reqColumnName,
			String dbColumnName) {
		return exhibitTemplateReqColumn.getId() != null && 
				exhibitTemplateReqColumn.getId().longValue() != exhibitTemplateColumn.getId().longValue() &&
						reqColumnName.equalsIgnoreCase(dbColumnName);
	}
	
	private ExhibitTemplate getExhibitTemplateByIdWithDeletedColumns(Long id, Long companyid)
    {        
    	ExhibitTemplate exhibitTemplate = new ExhibitTemplate();
    	SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id).addValue("companyid", companyid);
    	List<ExhibitTemplate> exhibitTemplateList = namedParameterJdbcTemplate.query(
    			GET_RFA_EXHIBIT_TEMPLATE_BY_ID_WITH_DELETED_COLUMNS, paramSource, new ExhibitTemplateResultSetExtractor(true));
    	if(null != exhibitTemplateList && exhibitTemplateList.size()>0) {
    		exhibitTemplate = exhibitTemplateList.get(0);
    	}
    	return exhibitTemplate;
    }

	@Override
	public Integer mergeExistingColumn(String columnName, int columnIndex, Long exhibitTemplateId, Long userID) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("exhibitTemplateId", exhibitTemplateId)
		.addValue("columnName", columnName)
		.addValue("columnIndex", columnIndex)
		.addValue("userID", userID);
		namedParameterJdbcTemplate.update(REINITIALIZE_EXISTING_COLUMN, paramSource);
		return null;
	}
}
