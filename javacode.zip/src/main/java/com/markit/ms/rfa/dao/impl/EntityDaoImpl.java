package com.markit.ms.rfa.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.common.model.CommonBaseSearchRequest;
import com.markit.ms.rfa.dao.IEntityDao;
import com.markit.ms.rfa.dao.resultsetextractor.EntityResultSetExtractor;
import com.markit.ms.rfa.dao.resultsetextractor.SleeveEntityResultSetExtractor;
import com.markit.ms.rfa.dao.rowmapper.EntityRowMapper;
import com.markit.ms.rfa.util.CommonUtil;


@Repository
public class EntityDaoImpl extends BaseDAOImpl implements IEntityDao {
	
	@Value("${GET_COMPANY_ENTITIES}")
	private String GET_COMPANY_ENTITIES;
	
	@Value("${GET_SLEEVE_ENTITIES}")
	private String GET_SLEEVE_ENTITIES;
	
	@Value("${GET_SLEEVE_ACCOUNTS_FOR_PARENT_ENTITIES}")
	private String GET_SLEEVE_ACCOUNTS_FOR_PARENT_ENTITIES;

	@Value("${GET_CHILD_ENTITIES}")
	private String GET_CHILD_ENTITIES;
	
	@Value("${GET_PARENT_ENTITIY}")
	private String GET_PARENT_ENTITIY;
	
	@Value("${GET_ENTITIY}")
	private String GET_ENTITIY;
	
	@Value("${GET_PARTYA_ENTITY}")
	private String GET_PARTYA_ENTITY;
	
	@Override
	public List<Entity> getEntities(long companyId, String filterString, CommonBaseSearchRequest searchRequest) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyId)
		.addValue("filterString", "%"+filterString+"%")
		.addValue("offset", searchRequest.getOffSet())
		.addValue("page_size", searchRequest.getPageSize());
		
		List<Entity> entities = namedParameterJdbcTemplate.query(GET_COMPANY_ENTITIES, paramSource, new EntityResultSetExtractor());		
		return entities;
	}
	
	@Override
	public List<Entity> getAllSleeveEntities(Long companyId, String filterString, Long offSet, Long pageSize) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("filterString", "%"+filterString+"%")
			.addValue("offset", offSet)
			.addValue("page_size", pageSize);
	
		List<Entity> entities = namedParameterJdbcTemplate.query(GET_SLEEVE_ENTITIES, paramSource, new SleeveEntityResultSetExtractor());		
		return entities;
	}
	
	@Override
	public List<Entity> getSleeveAccountsForParentEntities(Long companyId, List<Long> masterlistIds, List<Long> parentEntityIds) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("parentEntityIds", parentEntityIds)
			.addValue("masterlistIds", masterlistIds);
		List<Entity> sleeveEntities = namedParameterJdbcTemplate.query(GET_SLEEVE_ACCOUNTS_FOR_PARENT_ENTITIES, paramSource, new EntityResultSetExtractor());	
		return sleeveEntities;
	}

	@Override
	public List<Entity> getMcpmChildEntities(Long companyId, Long parentEntityId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyid", companyId)
				.addValue("parentEntityId", parentEntityId);
			List<Entity> childEntities = namedParameterJdbcTemplate.query(GET_CHILD_ENTITIES, paramSource, new EntityResultSetExtractor());	
			return childEntities;
	}	
	
	@Override
	public Entity getParentEntity(Long entityId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("entityId", entityId);
		Entity entity = namedParameterJdbcTemplate.queryForObject(GET_PARENT_ENTITIY, paramSource, new EntityRowMapper());	
		return entity;
	}
	
	@Override
	public Entity getEntity(Long entityId, Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("entityId", entityId)
				.addValue("masterAgreementId", masterAgreementId);
		Entity entity = namedParameterJdbcTemplate.queryForObject(GET_ENTITIY, paramSource, new EntityRowMapper());	
		return entity;
	}

	@Override
	public Entity getPartyAEntity(String legalName) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("legalName", legalName);
		List<Entity> entity = namedParameterJdbcTemplate.query(GET_PARTYA_ENTITY, paramSource, new EntityRowMapper());
		if (entity.size() > 0) {
			for (Entity e : entity) {
				if (CommonUtil.isNotNull(e.getTrueLegalName())) {
					return e;
				}
			}
			return entity.get(0);
		} else
			return null;
	}
	
}
