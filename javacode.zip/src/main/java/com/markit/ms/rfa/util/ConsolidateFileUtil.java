package com.markit.ms.rfa.util;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.fileutil.common.domain.MCFile;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;

@Component
public class ConsolidateFileUtil {

	@Autowired
	private IAmendmentLetterDao amendmentLetterDao;

	@Autowired
	private IFileService fileService;

	@Resource
	private IReportGenerator reportGenerator;

	@Resource
	QueryService<String> selectNextStepForAmendment;

	private static final String CONSOLIDATED_WET_SIGNS = "ConsolidatedWSigns.pdf";
	private static final String CONSOLIDATED_SIGNS = "ConsolidatedSigns.pdf";
	private static final String ORG_RFA_PDF = "OrginalRFA.pdf";

	private static final Logger logger = LoggerFactory.getLogger(ConsolidateFileUtil.class.getName());

	/**
	 * This method consolidate the all The wet signs in chronological order.
	 * 
	 * @param amendmentId
	 * @param companyId
	 * @param userId
	 * @param companyType
	 * @return
	 * @throws Exception
	 */
	public byte[] consolidateWetSignsByRFAId(Long amendmentId, Long companyId, Long userId) {
		logger.info("In consolidateWetSignsByRFAId with  amendmentId" + amendmentId);
		List<Long> listOFWetSignData = amendmentLetterDao.getWetSignData(amendmentId);
		if (null != listOFWetSignData && listOFWetSignData.size() > 0) {
			byte[][] fileBytes = new byte[listOFWetSignData.size()][];

			for (int size = 0; size < listOFWetSignData.size(); size++) {
				byte[] fileByte = fileService.getFile(listOFWetSignData.get(size), companyId);
				fileBytes[size] = fileByte;
			}
			logger.info("Exiting consolidateWetSignsByRFAId with  amendmentId" + amendmentId);
			return PDFUtil.merge(fileBytes);
		} else
			return null;

	}

	/**
	 * This method append consolidated wet signs with latest E-signs
	 * 
	 * @param amendmentId
	 * @param companyId
	 * @param userId
	 * @param companyType
	 * @return
	 * @throws Exception
	 */
	public Long consolidateAllSigns(Long amendmentId, Long companyId, Long userId, String companyType)
			throws Exception {
		byte[] eSignByte = null;
		byte[] fullPDF = null;
		byte[] wSignByte = null;
		byte[] dynamicPdf = null;
		MCFile mcFile = null;
		Long latestESignFileId = null;
		logger.info("In ConsolidateAllSigns with  amendmentId" + amendmentId);
		latestESignFileId = amendmentLetterDao.getLatestESignData(amendmentId);
		if (CommonUtil.isNotNull(latestESignFileId))
			eSignByte = fileService.getFile(latestESignFileId, companyId);
		else {
			if (companyType.equals(RFAConstants.COMPANY_TYPE_SS)) {
				String ssNextStep = selectNextStepForAmendment.executeQuery("amendmentId", amendmentId);
				PDFContext pdfContext = PDFContextGenerator.getSellSideRFAIDContext();
				if ("SS_SEND_RFA".equalsIgnoreCase(ssNextStep)) {
					pdfContext = PDFContextGenerator.getSellSideRFAIDSignedContext();
				}

				dynamicPdf = reportGenerator.getPDFContent(amendmentId, pdfContext);
			} else {
				PDFContext pdfContext = PDFContextGenerator.getBuySideRFAIDContext();
				dynamicPdf = reportGenerator.getPDFContent(amendmentId, pdfContext);
			}
			eSignByte = dynamicPdf;
			mcFile = fileService.saveFile(ORG_RFA_PDF, eSignByte, companyId, userId);
			latestESignFileId = mcFile.getFileId();

		}

		wSignByte = consolidateWetSignsByRFAId(amendmentId, companyId, userId);

		if (CommonUtil.isNull(latestESignFileId) && CommonUtil.isNotNull(wSignByte)) {
			mcFile = fileService.saveFile(CONSOLIDATED_WET_SIGNS, wSignByte, companyId, userId);
			return mcFile.getFileId();
		} else if (CommonUtil.isNull(wSignByte) && CommonUtil.isNotNull(latestESignFileId))
			return latestESignFileId;
		else {
			fullPDF = PDFUtil.merge(eSignByte, wSignByte);
			mcFile = fileService.saveFile(CONSOLIDATED_SIGNS, fullPDF, companyId, userId);
			logger.info("Exiting ConsolidateAllSigns with  fileId" + mcFile.getFileId());
			return mcFile.getFileId();
		}
	}

}
