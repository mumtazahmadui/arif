package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.common.util.TemplateTypeEnum;
import com.markit.ms.rfa.bean.PartyBDeskReviewData;
import com.markit.ms.rfa.dto.PartyBDeskReviewDetails;

/**
 * This class provides method for amendment letter partyB's due diligence desk
 * actions
 * 
 * @since RFA5.0
 *
 */
public interface IDeskReviewService {

	/**
	 * gets latest reviewed history details specifying event type, date timestamp,
	 * actioned by for specific partyB
	 * 
	 * @return list of reviewed history details
	 */
	List<PartyBDeskReviewDetails> getReviewHistoryDetails(PartyBDeskReviewData deskReviewData);

	/**
	 * gets latest reviewed history details specifying event type, date timestamp,
	 * actioned by for specific amendment id
	 * 
	 * @return list of reviewed history details
	 */
	List<PartyBDeskReviewDetails> getAmendmentReviewHistoryDetails(Long amendmentId, String deskCode);

	/**
	 * gets last escalated action details specifying date timestamp, actioned by and
	 * users notified of esclataion for specific partyB
	 * 
	 * @return review details
	 */
	PartyBDeskReviewDetails getEscalatedDetail(PartyBDeskReviewData deskReviewData);

	/**
	 * inserts or updates reviewed action details of all partyB's for specific desk
	 * code <br>
	 * for each action reviewed history details are also saved
	 * 
	 */
	void updateDeskStatus(PartyBDeskReviewData deskReviewData);

	/**
	 * when any amendment letter is send to sell side by buy side, by default for
	 * all partyB's of that specific amendment letter, <i>Onboarding Notified</i>
	 * status is checked
	 * 
	 */
	void updateNotifiedStatusOnSendRFA(Long amendmentId, Long userId);

	/**
	 * html view of email that will be send to users for specified action
	 * 
	 * @return html view contents
	 */
	String getMailPreview(String deskName, PartyBDeskReviewData deskReviewData);

	/**
	 * sends notification mail containing details of all amendment's and partyB's
	 * selected, to all the provided users
	 * 
	 */
	void notifyUsers(String deskName, PartyBDeskReviewData deskReviewData);

	/**
	 * inserts or updates escalate action details of partyB for specific desk <br>
	 * reviewed history details are saved and for each history user details are
	 * saved who are notified of escalate actions
	 * 
	 */
	void escalateDeskStatus(PartyBDeskReviewData deskReviewData);

	/**
	 * sends escalation mail containing details of all amendment's and partyB's
	 * selected, to all the provided users
	 * 
	 */
	void escalteToUsers(String deskName, PartyBDeskReviewData deskReviewData);
	
	/**
	 * This method generate the grid search url with filter criteria
	 * 
	 * @param filterJson filter json
	 * @param loggedInUserId logged in user id
	 * @param templateType email template being used 
	 * @return generate URL
	 */
	String generateUrl(String filterJson, Long loggedInUserId, TemplateTypeEnum templateType);


}
