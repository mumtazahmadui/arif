package com.markit.ms.rfa.batch;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.RFAUploadTemplateFile;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.RfaNotificationBean;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.notifier.BulkActionEmailNotificationInvoker;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.rfabulkupload.util.RFABulkUploadFileUtil;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

public class BulkRFAUploadRequestProcessedItemWriter
		implements ItemWriter<Map<Long, List<AmendmentLetter>>>, StepExecutionListener {

	private Long bulkRequestId;

	@Value("#{jobParameters['userId']}")
	private String userId;

	private Long companyId;

	@Value("#{jobParameters['ipAddress']}")
	private String ipAddress;

	@Autowired
	private BulkActionEmailNotificationInvoker bulkEmailNotificationInvoker;

	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	@Autowired
	RFABulkUploadFileUtil fileUtil;

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	Boolean rfaCreatedSuccessfully = false;

	@Value("#{jobExecutionContext['errorRowList']}")
	List<RfaBulkUploadRow> errorRowList;

	private static final Logger logger = LoggerFactory.getLogger(BulkRFAUploadRequestProcessedItemWriter.class);

	@SuppressWarnings("unchecked")
	@BeforeStep
	public void initializeValues(StepExecution stepExecution) {
		errorRowList = (List<RfaBulkUploadRow>) stepExecution.getJobExecution().getExecutionContext()
				.get("errorRowList");
		if (CommonUtil.isNull(errorRowList)) {
			errorRowList = new ArrayList<RfaBulkUploadRow>();
			stepExecution.getJobExecution().getExecutionContext().put("errorRowList", errorRowList);
		}
	}

	@Override
	public void write(List<? extends Map<Long, List<AmendmentLetter>>> items) throws Exception {
		if (CommonUtil.isNull(errorRowList) || errorRowList.size() == 0) {
			for (Map<Long, List<AmendmentLetter>> item : items) {
				for (Long masterAgreementId : item.keySet()) {
					try {
						if (CommonUtil.isNull(errorRowList) || errorRowList.size() == 0) {
							amendmentLetterService.saveAmendmentLetters(companyId, RFAConstants.COMPANY_TYPE_BS,
									Long.parseLong(userId), item.get(masterAgreementId), ipAddress);
							rfaCreatedSuccessfully = true;
						}
					} catch (Exception e) {
						rfaCreatedSuccessfully = false;
						errorRowList.add(item.get(masterAgreementId).get(0).getRfaBulkUploadRows().get(
								item.get(masterAgreementId).get(0).getPartyBEntities().get(0).getEntity().getId()));
						throw e;
					}
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		errorRowList = (List<RfaBulkUploadRow>) stepExecution.getJobExecution().getExecutionContext()
				.get("errorRowList");
		try {
			if (CommonUtil.isNotNull(errorRowList) && errorRowList.size() > 0) {
				RFAUploadTemplateFile rfaUploadTemplateFile = uploadTemplateDAO.getUploadedFileId(bulkRequestId);
				fileUtil.writeErrorFileByFindingRow(rfaUploadTemplateFile.getFileId(), errorRowList, companyId,
						bulkRequestId, Long.parseLong(userId));

			} else if (rfaCreatedSuccessfully) {
				// update tables with status
				amendmentLetterService.updateBulkUploadFileTemplate(null, bulkRequestId,
						RFAConstants.BULK_UPLOAD_STATUS_COMPLETE);

				// send success mail

				RfaNotificationBean bulkNotificationBean = new RfaNotificationBean();
				bulkNotificationBean.setUserId(Long.parseLong(userId));
				bulkNotificationBean.setUploadId(amendmentLetterService.getBulkRFAUploadId(bulkRequestId));
				bulkNotificationBean.setBulkActionValidationType(BulkActionValidationType.SUCCESS_NOTIFICATION);
				bulkEmailNotificationInvoker.invoke(bulkNotificationBean);

			}
		} catch (Exception e) {
			logger.error("Error in BulkRFAUploadRequestProcessedItemWriter afterStep() " + e.getMessage());
			e.printStackTrace();
		}
		amendmentLetterService.updateBulkRequest(bulkRequestId, RFAConstants.BULK_UPLOAD_STATUS_COMPLETE);
		rfaCreatedSuccessfully = false;
		return null;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub

	}

	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

}
