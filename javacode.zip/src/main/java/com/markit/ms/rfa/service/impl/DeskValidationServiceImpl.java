package com.markit.ms.rfa.service.impl;

import static com.markit.ms.rfa.util.PartyBDeskConstants.BS_DESK_CODES;
import static com.markit.ms.rfa.util.PartyBDeskConstants.ESCALATED_DESK_CODES;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
import com.markit.ms.rfa.dao.DeskReviewStatusDao;
import com.markit.ms.rfa.dao.IPartyBDao;
import com.markit.ms.rfa.service.DeskValidationService;
import com.markit.ms.rfa.util.PartyBDeskConstants.DESKTYPES;
/**
 * This class provides method implementation of validation on desk actions
 * 
 * @since RFA5.0
 *
 */
@Service
public class DeskValidationServiceImpl implements DeskValidationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DeskValidationServiceImpl.class);
	private static final List<String> SS_AMENDMENT_STATUS_RESTRICT = Arrays.asList(
			AmendmentStatus.COMPLETED.getTrueName(), AmendmentStatus.RECALLED.getTrueName(),
			AmendmentStatus.REJECTED.getTrueName());
	private static final List<String> BS_AMENDMENT_STATUS_VALID = Arrays.asList(AmendmentStatus.DRAFT.getTrueName());
	private static final List<String> SS_ALLOWED_DESK_TYPES = Arrays.asList(DESKTYPES.OPERATIONS.name(),
			DESKTYPES.MANAGER.name(), DESKTYPES.TAX.name());

	@Autowired
	private DeskReviewStatusDao deskReviewStatusDao;

	@Resource
	private QueryService<String> getBSRfaStatus;

	@Resource
	private QueryService<String> getSSRfaStatus;

	@Autowired
	private IPartyBDao partyBDao;

	@Override
	public boolean validateBSReviewAction(Long amendmentId, String deskCode, Long userId) {
		boolean validRequest = false;
		if (BS_DESK_CODES.contains(deskCode)) {

			/**
			 * get desk type of specified desk code if user provided has respective desk
			 * role
			 */
			String deskType = deskReviewStatusDao.getDeskType(deskCode, userId);
			LOGGER.debug("validateBSReviewAction : deskType : " + deskType);

			if (StringUtils.isNotEmpty(deskType)) {
				/**
				 * gets amendment letter status status should not be empty for SS
				 */
				String bsRfaStatus = getBSRfaStatus.executeQuery("amendment_id", amendmentId);

				LOGGER.debug("validateBSReviewAction : bsRfaStatus : " + bsRfaStatus);

				if (AmendmentStatus.DRAFT.getTrueName()
						.equals((getBSRfaStatus.executeQuery("amendment_id", amendmentId)))) {
					validRequest = true;
				}
			}
		}
		LOGGER.debug("validateBSReviewAction : validRequest : " + validRequest);
		return validRequest;
	}

	@Override
	public boolean validateSSReviewAction(Long amendmentId, String deskCode, Long userId) {
		boolean validRequest = false;
		if (!ESCALATED_DESK_CODES.contains(deskCode)) {

			/**
			 * get desk type of specified desk code if user provided has respective desk
			 * role
			 */
			String deskType = deskReviewStatusDao.getDeskType(deskCode, userId);
			LOGGER.debug("validateSSReviewAction : deskType : " + deskType);

			if (StringUtils.isNotEmpty(deskType)) {
				validRequest = validateSSRFAStatusAction(amendmentId, deskType);
			}
		}
		LOGGER.debug("validateSSReviewAction : validRequest : " + validRequest);
		return validRequest;
	}

	@Override
	public boolean validateEscalateAction(Long amendmentId, String deskType, String deskCode) {
		boolean validRequest = false;
		if (ESCALATED_DESK_CODES.contains(deskCode)) {
			validRequest = validateSSRFAStatusAction(amendmentId, deskType.toUpperCase());
		}
		LOGGER.debug("validateEscalateAction : validRequest : " + validRequest);
		return validRequest;
	}

	/**
	 * validates SS desk action
	 * 
	 * @return
	 */
	private boolean validateSSRFAStatusAction(Long amendmentId, String deskType) {
		boolean validRequest = false;

		boolean deskTypeAllowed = false;
		/**
		 * action for Operations, Manager and Tax desks to be allowed even after rfa
		 * completion
		 */
		if (SS_ALLOWED_DESK_TYPES.contains(deskType)) {
			deskTypeAllowed = true;
		}

		/**
		 * gets amendment letter status status should not be empty for SS
		 */
		String ssRfaStatus = getSSRfaStatus.executeQuery("amendment_id", amendmentId);

		LOGGER.debug("validateSSRFAAction : ssRfaStatus : " + ssRfaStatus);

		if (StringUtils.isNotEmpty(ssRfaStatus) && (deskTypeAllowed || !SS_AMENDMENT_STATUS_RESTRICT
				.contains(getSSRfaStatus.executeQuery("amendment_id", amendmentId)))) {
			validRequest = true;
		}
		return validRequest;
	}

	@Override
	public boolean validateNotifyAction(List<Long> partyBIds, String deskType, String companyType) {
		boolean validRequest = false;

		List<String> statusList = partyBDao.getPartyBAmendmentStatus(partyBIds, companyType);

		if (CompanyType.isBSCompany(companyType) && BS_AMENDMENT_STATUS_VALID.containsAll(statusList)) {
			validRequest = true;
		} else if (CompanyType.isSSCompany(companyType)) {
			validRequest = true;

			/**
			 * action for Operations, Manager and Tax desks to be allowed even after rfa
			 * completion
			 */
			if (SS_ALLOWED_DESK_TYPES.contains(deskType.toUpperCase())) {
				validRequest = true;
			} else {
				for (String status : statusList) {
					if (SS_AMENDMENT_STATUS_RESTRICT.contains(status)) {
						validRequest = false;
						break;
					} else {
						validRequest = true;
					}
				}
			}

		}
		LOGGER.debug("validateNotifyAction : validRequest : " + validRequest);
		return validRequest;
	}
}
