package com.markit.ms.rfa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.AmendmentChangeAudit;
import com.markit.ms.rfa.bean.AmendmentCommentAudit;
import com.markit.ms.rfa.dao.IAmendmentChangeDAO;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;
import com.markit.ms.rfa.service.IAmendmentChangeService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class AmendmentChangeServiceImpl implements IAmendmentChangeService {

	@Autowired
	private IAmendmentChangeDAO amendmentChangeDao;

	@Autowired
	private IAmendmentLetterDao amendmentLetterDao;

	@Override
	public void saveRfaCommentAudit(List<AmendmentCommentAudit> commentAuditList, Long amendmentId, String source,
			String partyType, String query) {
		int commentsCount = commentAuditList.size(), resolvedCommentsCount = 0;

		for(AmendmentCommentAudit commentAudit : commentAuditList) {
			if(CommonUtil.isNotNull(commentAudit.getResolved()) && commentAudit.getResolved()) {
				resolvedCommentsCount++;
			}
		}
		
		if (commentsCount > 0) {
			amendmentLetterDao.updateCommentsCount(commentAuditList.size(), amendmentId, source, partyType);
		}
		if (resolvedCommentsCount > 0) {
			amendmentLetterDao.updateResolvedCommentsCount(resolvedCommentsCount, amendmentId);
		}
		amendmentChangeDao.saveRfaCommentAudit(commentAuditList, amendmentId, source, partyType, query);

	}

	@Override
	public void saveRfaChangeLogAudit(List<AmendmentChangeAudit> changeAuditList, Long amendmentId, String source,
			String partyType, String query) {
		int changeCount = 0, respondedCount = 0;
		for (AmendmentChangeAudit change : changeAuditList) {
			if (CommonUtil.isEqual(change.getAction(), RFAConstants.ACCEPTED)
					|| CommonUtil.isEqual(change.getAction(), RFAConstants.REJECTED)) {
				respondedCount++;
			} else {
				changeCount++;
			}
		}

		if (changeCount > 0) {
			amendmentLetterDao.updateChangesCount(amendmentId, changeCount, source);
		}
		if (respondedCount > 0) {
			amendmentLetterDao.updateChangesRespondedCount(amendmentId, respondedCount);
		}
		amendmentChangeDao.saveRfaChangeLogAudit(changeAuditList, amendmentId, source, partyType, query);

	}

}
