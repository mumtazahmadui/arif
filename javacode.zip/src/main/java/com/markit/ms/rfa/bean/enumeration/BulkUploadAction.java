package com.markit.ms.rfa.bean.enumeration;

import java.io.UnsupportedEncodingException;

import com.markit.ms.common.service.impl.HTMLParserImpl;
import com.markit.ms.rfa.bean.AmendmentLetter;

public enum BulkUploadAction {

	BLANK("Blank", "Blank") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) throws IllegalArgumentException {
			throw new IllegalArgumentException("Checking placeholders for type BLANK (this should never happen).");
		}
	},

	SLEEVE_ADDITION("Sleeve Addition", "Addition") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},
	SLEEVE_REMOVAL("Sleeve Removal", "Removal") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBRemovalPlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	ADDITION("Addition", "Addition") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	BLANK_ADD("Add", "Addition") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	MODIFICATION("Modifications", "Modifications") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBFundNameChangePlaceholder(amendmentLetter);
				hasPlaceholder = HTMLParserImpl.hasPartyBExhibitValueChangePlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	REMOVAL("Removal", "Removal") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBRemovalPlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	BLANK_REMOVE("Remove", "Removal") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBRemovalPlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	FNC("FNC", "FNC") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBFundNameChangePlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	EVC("EVC", "EVC") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				hasPlaceholder = HTMLParserImpl.hasPartyBFundNameChangePlaceholder(amendmentLetter);
				hasPlaceholder = HTMLParserImpl.hasPartyBExhibitValueChangePlaceholder(amendmentLetter);
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	APPLICATION_DETERMINES("Application Determines", "Application Determines") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder = false;
			boolean partyBAdditionPlaceholder;
			boolean fncPlaceholder;
			boolean evcPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				partyBAdditionPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
				fncPlaceholder = HTMLParserImpl.hasPartyBFundNameChangePlaceholder(amendmentLetter);
				evcPlaceholder = HTMLParserImpl.hasPartyBExhibitValueChangePlaceholder(amendmentLetter);
				if (partyBAdditionPlaceholder && fncPlaceholder && evcPlaceholder) {
					hasPlaceholder = true;
				}
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	ALL_ACTIONS("All actions", "All actions") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder = false;
			boolean partyBAdditionPlaceholder;
			boolean partyBRemovalPlaceholder;
			boolean fncPlaceholder;
			boolean evcPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				partyBAdditionPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
				partyBRemovalPlaceholder = HTMLParserImpl.hasPartyBRemovalPlaceholder(amendmentLetter);
				fncPlaceholder = HTMLParserImpl.hasPartyBFundNameChangePlaceholder(amendmentLetter);
				evcPlaceholder = HTMLParserImpl.hasPartyBExhibitValueChangePlaceholder(amendmentLetter);
				if (partyBAdditionPlaceholder && partyBRemovalPlaceholder && fncPlaceholder && evcPlaceholder) {
					hasPlaceholder = true;
				}
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	ADDITION_AND_REMOVAL("Addition and Removal", "Addition and Removal") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder = false;
			boolean partyBAdditionPlaceholder;
			boolean partyBRemovalPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				partyBAdditionPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
				partyBRemovalPlaceholder = HTMLParserImpl.hasPartyBRemovalPlaceholder(amendmentLetter);
				if (partyBAdditionPlaceholder && partyBRemovalPlaceholder) {
					hasPlaceholder = true;
				}
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	},

	ADDITION_AND_MODIFICATIONS("Addition and Modifications", "Addition and Modifications") {
		@Override
		public boolean checkPlaceholders(AmendmentLetter amendmentLetter) {
			boolean hasPlaceholder = false;
			boolean partyBAdditionPlaceholder;
			boolean fncPlaceholder;
			boolean evcPlaceholder;
			if (amendmentLetter.getContent() == null)
				return false;
			try {
				partyBAdditionPlaceholder = HTMLParserImpl.hasPartyBAdditionPlaceholder(amendmentLetter);
				fncPlaceholder = HTMLParserImpl.hasPartyBFundNameChangePlaceholder(amendmentLetter);
				evcPlaceholder = HTMLParserImpl.hasPartyBExhibitValueChangePlaceholder(amendmentLetter);
				if (partyBAdditionPlaceholder && (fncPlaceholder || evcPlaceholder)) {
					hasPlaceholder = true;
				}
			} catch (UnsupportedEncodingException e) {
				hasPlaceholder = false;
				e.printStackTrace();
			}
			return hasPlaceholder;
		}
	};

	private String type;

	private String name;

	private BulkUploadAction(String type, String name) {
		this.type = type;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public static BulkUploadAction fromType(String type) {
		for (BulkUploadAction anEnum : BulkUploadAction.values()) {
			if (anEnum.type.equalsIgnoreCase(type))
				return anEnum;
		}
		return null;
	}

	public abstract boolean checkPlaceholders(AmendmentLetter letterTemplate);

}
