package com.markit.ms.rfa.dto;

import java.util.List;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseSearchRequest;
public class TemplateSearchRequest extends CommonBaseSearchRequest{
	
	private List<Lookup> templateName;
	private List<Lookup> modifiedBy;
	private List<Lookup> createdBy;

	private List<Lookup> linkedBy;
	
	private List<Lookup> partyALegalName;
	
	private List<Lookup> masterlistIdentifier;
	
	private List<String> refIsdaDate;
	
	public List<Lookup> getTemplateName() {
		return templateName;
	}
	public void setTemplateName(List<Lookup> templateName) {
		this.templateName = templateName;
	}
	public List<Lookup> getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(List<Lookup> modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public List<Lookup> getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(List<Lookup> createdBy) {
		this.createdBy = createdBy;
	}
	public List<Lookup> getLinkedBy() {
		return linkedBy;
	}
	public void setLinkedBy(List<Lookup> linkedBy) {
		this.linkedBy = linkedBy;
	}
	public List<Lookup> getPartyALegalName() {
		return partyALegalName;
	}
	public void setPartyALegalName(List<Lookup> partyALegalName) {
		this.partyALegalName = partyALegalName;
	}
	public List<Lookup> getMasterlistIdentifier() {
		return masterlistIdentifier;
	}
	public void setMasterlistIdentifier(List<Lookup> masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}
	public List<String> getRefIsdaDate() {
		return refIsdaDate;
	}
	public void setRefIsdaDate(List<String> refIsdaDate) {
		this.refIsdaDate = refIsdaDate;
	}
}
