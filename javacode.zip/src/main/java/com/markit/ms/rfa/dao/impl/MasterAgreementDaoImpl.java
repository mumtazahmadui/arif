package com.markit.ms.rfa.dao.impl;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Maps;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.common.model.MasterAgreementSearchRequest;
import com.markit.ms.rfa.bean.AmendmentStatusObject;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.MasterAgreementHistory;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.dao.IMasterAgreementDao;
import com.markit.ms.rfa.dao.resultsetextractor.AgreementHistoryResultSetExtractor;
import com.markit.ms.rfa.dao.resultsetextractor.MasterAgreementListResultSetExtractor;
import com.markit.ms.rfa.dao.resultsetextractor.MasterAgreementResultSetExtractor;
import com.markit.ms.rfa.dao.rowmapper.PartyBEntityRowMapper;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Repository
public class MasterAgreementDaoImpl extends BaseDAOImpl implements IMasterAgreementDao {

	@Value("${GET_ALL_MASTER_AGREEMENTS_WITH_EXHIBIT_LINKAGE}")
	private String GET_ALL_MASTER_AGREEMENTS_WITH_EXHIBIT_LINKAGE;
	
	@Value("${GET_ALL_MASTER_AGREEMENTS_WITHOUT_EXHIBIT_LINKAGE}")
	private String GET_ALL_MASTER_AGREEMENTS_WITHOUT_EXHIBIT_LINKAGE;
	
	@Value("${GET_EXISTING_PARTYB_LIST_FOR_VALIDATION}")
	private String GET_EXISTING_PARTYB_LIST_FOR_VALIDATION;
	
	@Value("${GET_MASTER_AGREEMENT_HISTORY}")
	private String GET_MASTER_AGREEMENT_HISTORY;
	
    @Value("${GET_MASTER_AGREEMENT_DATE_BY_ID}")
    private String GET_MASTER_AGREEMENT_DATE_BY_ID;
    
    @Value("${GET_MASTERLIST_TRUE_LEGAL_NAME}")
    private String GET_MASTERLIST_TRUE_LEGAL_NAME;
    
    @Value("${GET_REQUEST_TYPE_FOR_VALIDATION}")
    private String GET_REQUEST_TYPE_FOR_VALIDATION;
    
    @Value("${GET_MASTER_AGREEMENT_ML_TEMPLATE}")
    private String GET_MASTER_AGREEMENT_ML_TEMPLATE;
    
    @Value("${GET_ML_TEMPLATE_WITH_SLEEVE}")
    private String GET_ML_TEMPLATE_WITH_SLEEVE;
    
    @Value("${GET_ML_TEMPLATE_BY_AMENDMENT}")
    private String GET_ML_TEMPLATE_BY_AMENDMENT;
    
    @Value("${UPDATE_MASTER_AGREEMENT_FROM_AMENDMENT}")
    private String UPDATE_MASTER_AGREEMENT_FROM_AMENDMENT;
    
    @Value("${GET_MASTER_AGREEMENT_BY_ID}")
    private String GET_MASTER_AGREEMENT_BY_ID;
    
    
    @Value("${CHECK_MASTERLIST_LINKAGE_BY_AGREEMENT_ID}")
    private String CHECK_MASTERLIST_LINKAGE_BY_AGREEMENT_ID;
    
    @Resource
    QueryService<List<AmendmentStatusObject>> getAmendmentStatusOfModifiedEntitiesNotYetResponded;        
    
    @Resource
    QueryService<String> getAmendmentStatusOfFncEntitiesNotYetResponded;
    
    @Resource
    QueryService<String> getAmendmentStatusOfEvcEntitiesNotYetResponded;    

    @Resource
    QueryService<List<PartyBEntity>> getExistingPartyBListForValidation;
    
	@Override
	public List<MasterAgreement> getMasterAgreements(long companyId, MasterAgreementSearchRequest searchRequest) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyId)
		.addValue("offset", searchRequest.getOffSet())
		.addValue("page_size", searchRequest.getPageSize());
		String query = GET_ALL_MASTER_AGREEMENTS_WITHOUT_EXHIBIT_LINKAGE;
		if(null != searchRequest.getMasterListLinked() && searchRequest.getMasterListLinked()) {
			query = GET_ALL_MASTER_AGREEMENTS_WITH_EXHIBIT_LINKAGE;
		}
		List<MasterAgreement> masterAgreements = namedParameterJdbcTemplate.query(query
				, paramSource, new MasterAgreementListResultSetExtractor());
		return masterAgreements;
	}
	
	@Override
	public List<PartyBEntity> getExistingPartyBListForValidation(Long masterAgreementId, List<Long> partyBEntityIds, Long amendmentId) {

		Map<String, Object> params = Maps.newHashMap();
		params.put("masterAgreementId", masterAgreementId);
		params.put("partyBEntityIds", partyBEntityIds);
		
		List<PartyBEntity> existingPartyB = getExistingPartyBListForValidation.executeQuery(params);
		
		return existingPartyB;
	}

	@Override
	public MasterAgreementHistory getMasterAgreementHistory(Long companyId,
			Long agreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyId", companyId)
		.addValue("agreementId", agreementId);
		
		MasterAgreementHistory agreementHistory = namedParameterJdbcTemplate.query(GET_MASTER_AGREEMENT_HISTORY, paramSource, new AgreementHistoryResultSetExtractor());
		
		return agreementHistory;
	}

	@Override
	public Date getMasterAgreementDateById(Long masterAgreementId) {
		Date agreementDate = null;
    	MapSqlParameterSource params = null;
    	if(null != masterAgreementId) {
    		params = new MapSqlParameterSource().addValue("id", masterAgreementId);
    		agreementDate = namedParameterJdbcTemplate.queryForObject(GET_MASTER_AGREEMENT_DATE_BY_ID, params, Date.class);
    	}
    	return agreementDate;
	}

	@Override
	public List<AmendmentStatusObject> getAmendmentStatusOfModifiedEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId) {
		List<AmendmentStatusObject> amendmentStatusObjectList = null;

    	if(null != masterAgreementId) {
    		
    		Map<String, Object> params = Maps.newHashMap();
    		params.put("masterAgreementId", masterAgreementId);
    		params.put("entityId", entityId);
    		params.put("amendmentId", amendmentId);
    		try {
    			amendmentStatusObjectList = getAmendmentStatusOfModifiedEntitiesNotYetResponded.executeQuery(params);
    			
    			if(null == amendmentStatusObjectList || amendmentStatusObjectList.size() < 1) {
    				amendmentStatusObjectList = new ArrayList<>();
    				AmendmentStatusObject amendmentStatusObject = new AmendmentStatusObject();
        			amendmentStatusObject.setAmendmentStatus(RFAConstants.NOT_YET_RESPONDED_STATUS);
    				amendmentStatusObjectList.add(amendmentStatusObject);
    			}
    			if(amendmentStatusObjectList.size() > 0 && null == amendmentStatusObjectList.get(0).getRequestType()) {
    				amendmentStatusObjectList.get(0).setAmendmentStatus(RFAConstants.NOT_YET_RESPONDED_STATUS);
    			}
    			if(amendmentStatusObjectList.size() > 1 && null == amendmentStatusObjectList.get(1).getRequestType()) {
    				amendmentStatusObjectList.get(1).setAmendmentStatus(RFAConstants.NOT_YET_RESPONDED_STATUS);
    			}
    		} catch(IncorrectResultSizeDataAccessException error){
    			AmendmentStatusObject amendmentStatusObject = new AmendmentStatusObject();
    			amendmentStatusObject.setAmendmentStatus(RFAConstants.NOT_YET_RESPONDED_STATUS);
    			amendmentStatusObjectList = new ArrayList<>();
    			amendmentStatusObjectList.add(amendmentStatusObject);
    		}
    	}
    	return amendmentStatusObjectList;
	}
	
	@Override
	public String getAmendmentStatusOfFNCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId) {
		String amendmentStatusOfFNCEntityNotYetResponded = null;
		
		if(null != masterAgreementId) {
    		Map<String, Object> params = Maps.newHashMap();
    		params.put("masterAgreementId", masterAgreementId);
    		params.put("entityId", entityId);
    		params.put("amendmentId", amendmentId);			
			try {
				amendmentStatusOfFNCEntityNotYetResponded = getAmendmentStatusOfFncEntitiesNotYetResponded.executeQuery(params);
				if (amendmentStatusOfFNCEntityNotYetResponded == null) return RFAConstants.NOT_YET_RESPONDED_STATUS;
    		} catch(IncorrectResultSizeDataAccessException error){
    			amendmentStatusOfFNCEntityNotYetResponded = RFAConstants.NOT_YET_RESPONDED_STATUS;
    		}
		}
		return amendmentStatusOfFNCEntityNotYetResponded;
	}
	
	@Override
	public String getAmendmentStatusOfEVCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId) {
		String amendmentStatusOfEVCEntityNotYetResponded = null;

		if(null != masterAgreementId) {
    		Map<String, Object> params = Maps.newHashMap();
    		params.put("masterAgreementId", masterAgreementId);
    		params.put("entityId", entityId);
    		params.put("amendmentId", amendmentId);			
			try {
				amendmentStatusOfEVCEntityNotYetResponded = getAmendmentStatusOfEvcEntitiesNotYetResponded.executeQuery(params);
				if (amendmentStatusOfEVCEntityNotYetResponded == null) return RFAConstants.NOT_YET_RESPONDED_STATUS;
    		} catch(IncorrectResultSizeDataAccessException error){
    			amendmentStatusOfEVCEntityNotYetResponded = RFAConstants.NOT_YET_RESPONDED_STATUS;
    		}
		}
		return amendmentStatusOfEVCEntityNotYetResponded;
	}

	@Override
	public String getMasterlistTrueLegalName(Long entityId, Long masterAgreementId) {
		String masterlistTrueLegalName = null;
    	MapSqlParameterSource params = null;
    	if(null != masterAgreementId) {
    		params = new MapSqlParameterSource().addValue("id", masterAgreementId).addValue("entityId", entityId);
    		try {
    			masterlistTrueLegalName = namedParameterJdbcTemplate.queryForObject(GET_MASTERLIST_TRUE_LEGAL_NAME, params, String.class);
    		} catch(IncorrectResultSizeDataAccessException error){
    			masterlistTrueLegalName = "";
    		}
    	}
    	return masterlistTrueLegalName;
	}
	@Override
	public String getRequestTypeForValidation(Long partybId) {
		String requestType = null;
		SqlParameterSource params = null;
		if(null != partybId) {
			params = new MapSqlParameterSource().addValue("partyb_id", partybId);
			try {
				requestType = namedParameterJdbcTemplate.queryForObject(GET_REQUEST_TYPE_FOR_VALIDATION, params, String.class);
			} catch(IncorrectResultSizeDataAccessException error){
				requestType = "";
			}
		}
		return requestType;
	}

	@Override
	public String getMasterlistMlTemplateName(Long masterAgreementId)
	{
		String mlTemplateName = null;
    	MapSqlParameterSource params = null;
    	if(null != masterAgreementId) {
    		params = new MapSqlParameterSource().addValue("masterAgreementId", masterAgreementId);
    		mlTemplateName = namedParameterJdbcTemplate.queryForObject(GET_MASTER_AGREEMENT_ML_TEMPLATE, params, String.class);
    	}
    	return mlTemplateName;
	}

	@Override
	public String getMlTemplateWithSleeve(Long masterAgreementId)
	{
		String mlTemplateWithSleeve = null;
    	MapSqlParameterSource params = null;
    	if(null != masterAgreementId) {
    		params = new MapSqlParameterSource().addValue("masterAgreementId", masterAgreementId);
    		try{
    			mlTemplateWithSleeve = namedParameterJdbcTemplate.queryForObject(GET_ML_TEMPLATE_WITH_SLEEVE, params, String.class);
    		}
    		catch(EmptyResultDataAccessException e){
    			return null;
    		}
    	}
    	return mlTemplateWithSleeve;
	}

	@Override
	public String getMlTemplateWithSleeveByAmednment(Long amendmentId)
	{
		String mlTemplateWithSleeve = null;
    	MapSqlParameterSource params = null;
    	if(null != amendmentId) {
    		params = new MapSqlParameterSource().addValue("amendmentId", amendmentId);
    		try{
    			mlTemplateWithSleeve = namedParameterJdbcTemplate.queryForObject(GET_ML_TEMPLATE_BY_AMENDMENT, params, String.class);
    		}
    		catch(EmptyResultDataAccessException e){
    			return null;
    		}
    	}
    	return mlTemplateWithSleeve;
	}

	@Override
	public void updateMasterAgreement(Long amendmentId)
	{
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("amendmentId", amendmentId);
		try{
			namedParameterJdbcTemplate.update(UPDATE_MASTER_AGREEMENT_FROM_AMENDMENT, paramSource);
		} catch(Exception error){
			error.printStackTrace();
		}
	}
	
	public MasterAgreement getMasterAgreementById(Long masterAgreementId){
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("masterAgreementId", masterAgreementId);
		MasterAgreement agreement = namedParameterJdbcTemplate.query(GET_MASTER_AGREEMENT_BY_ID, paramSource, new MasterAgreementResultSetExtractor());
		return agreement;
	}
		
	
	@Override
	public RfaBulkUploadRow checkMasterListExhibitLinkage(RfaBulkUploadRow rfaBulkUploadRow) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyId",
				rfaBulkUploadRow.getRfaUploadTemplate().getCompanyId())
				.addValue("masterAgreementId", rfaBulkUploadRow.getMasterAgreementId());
		
		
		List<RfaBulkUploadRow> rf = namedParameterJdbcTemplate.query(CHECK_MASTERLIST_LINKAGE_BY_AGREEMENT_ID, paramSource,
				new BeanPropertyRowMapper<RfaBulkUploadRow>(RfaBulkUploadRow.class));

		if (rf.isEmpty()) {
			rfaBulkUploadRow.addError(RFAConstants.RFA_EXHIBIT_LINKAGE_DOESNT_EXIST);
		} 
		
		return rfaBulkUploadRow;
	}
	
	@Override
	public List<PartyBEntity> getExistingPartyBListForValidation(Long masterAgreementId, List<Long> partyBEntityIds,
			Long amendmentId, String callingSource) {
		
		Map<String, Object> params = Maps.newHashMap();
		params.put("masterAgreementId", masterAgreementId);
		params.put("partyBEntityIds", partyBEntityIds);
		params.put("amendmentId", amendmentId);
		
		if (CommonUtil.isNotNull(callingSource) && callingSource.equalsIgnoreCase(RFAConstants.FNC)) {
			params.put("fncCallingSource", Boolean.valueOf(true));
		} else if (CommonUtil.isNotNull(callingSource) && callingSource.equalsIgnoreCase(RFAConstants.EVC)) {
			params.put("evcCallingSource", Boolean.valueOf(true));
		}

		
		List<PartyBEntity> existingPartyB = getExistingPartyBListForValidation.executeQuery(params);
		
		return existingPartyB;
	}
}
