package com.markit.ms.rfa.service;

import java.util.List;
import java.util.Map;

import com.markit.ms.rfa.placeholders.request.BSPartyBTableRequest;
import com.markit.ms.rfa.placeholders.request.SSPartyBTableRequest;

public interface IPartyBPlaceholderService {

	void updateSSResponse(Long amendmentId, Long userId, SSPartyBTableRequest ssPartyBTableRequest);

	void updateBSLineBreaks(Long amendmentId, Long userId,
			String placeholderType, BSPartyBTableRequest bsPartyBTableRequest);
	
	public List<Map<String,String>> getLineBreaks(final Long amendmentId,
			final String placeholderType);

	List<Map<String, String>> getPreviousLineBreaks(Long amendmentId,
			String partybAdditionPlaceholder);
	
	public void updateAmendmentStatusAndNextStep(Long amendmentId);

	void updateAmendmentBySsResponse(Long amendmentId, Long userId);
	
	public void updateAmendment(Long amendmentId, Long userId);
}
