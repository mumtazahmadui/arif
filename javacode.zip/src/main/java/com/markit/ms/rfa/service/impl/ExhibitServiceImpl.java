package com.markit.ms.rfa.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;
import com.markit.ms.rfa.dao.IExhibitDao;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.service.IAmendmentLettterPDFService;
import com.markit.ms.rfa.service.IExhibitService;

@Service
@Deprecated
public class ExhibitServiceImpl implements IExhibitService {
	
	@Autowired
	private IAmendmentLetterService amendmentLetterService;
	
	@Autowired
	private IAmendmentLettterPDFService amendmentLettterPDFService;
	
	@Autowired
	private IExhibitDao exhibitDao;

	@Autowired
	private IAmendmentLetterDao amendmentLetterDao;
	
	@Override
	@Transactional
	public Exhibit createExhibit(Exhibit exhibit) {
		return exhibitDao.createExhibit(exhibit);
	}

	@Override
	@Transactional
	public Exhibit updateExhibit(Long companyId, String companyType, Long userId, Exhibit exhibit) throws Exception {
		AmendmentLetter amendmentLetter = amendmentLetterService.getAmendmentLetterById(exhibit.getAmendmentId());
		amendmentLetter.setExhibit(exhibit);
		List<AmendmentLetter> amendmentLetterList = new ArrayList<AmendmentLetter>();
		amendmentLetterList.add(amendmentLetter);
		amendmentLetterList = amendmentLetterService.bulkUpdateAmendmentLetter(companyId, companyType, userId, amendmentLetterList);
		return amendmentLetterList.get(0).getExhibit();
	}
	
	@Override
	public Exhibit getExhibitByAmendmentId(Long amendmentId) {
		AmendmentLetter amendmentLetter = amendmentLetterDao.getAmendmentLetterById(amendmentId,null);
		Exhibit exhibit = amendmentLetter.getExhibit();
		exhibit.setPartyBEntities(amendmentLetter.getPartyBEntities());
		return exhibit;
	}
}
