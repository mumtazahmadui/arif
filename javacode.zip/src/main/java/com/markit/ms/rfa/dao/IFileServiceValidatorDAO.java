package com.markit.ms.rfa.dao;

public interface IFileServiceValidatorDAO {
	public boolean validateFileAccess(Long fileId, Long companyId);
}
