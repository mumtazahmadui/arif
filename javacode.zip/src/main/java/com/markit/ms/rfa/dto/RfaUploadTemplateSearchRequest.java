package com.markit.ms.rfa.dto;

import java.util.List;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseSearchRequest;
/**
 * @author sucheta.krishali
 *
 */
public class RfaUploadTemplateSearchRequest extends CommonBaseSearchRequest{

	private List<Lookup> uploadTemplateName;

	public List<Lookup> getUploadTemplateName() {
		return uploadTemplateName;
	}

	public void setUploadTemplateName(List<Lookup> uploadTemplateName) {
		this.uploadTemplateName = uploadTemplateName;
	}




}
