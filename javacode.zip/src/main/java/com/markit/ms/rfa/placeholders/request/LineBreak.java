package com.markit.ms.rfa.placeholders.request;

public class LineBreak {
	private int lineBreakIndex;
	private String lineBreakText;
	private String showHeaderText;
	private long exhibitControlColumnId;

	public LineBreak() {
	}

	public int getLineBreakIndex() {
		return lineBreakIndex;
	}

	public void setLineBreakIndex(int lineBreakIndex) {
		this.lineBreakIndex = lineBreakIndex;
	}

	public String getLineBreakText() {
		return lineBreakText;
	}

	public void setLineBreakText(String lineBreakText) {
		this.lineBreakText = lineBreakText;
	}

	public String getShowHeaderText() {
		return showHeaderText;
	}

	public void setShowHeaderText(String showHeaderText) {
		this.showHeaderText = showHeaderText;
	}

	public long getExhibitControlColumnId() {
		return exhibitControlColumnId;
	}

	public void setExhibitControlColumnId(long exhibitControlColumnId) {
		this.exhibitControlColumnId = exhibitControlColumnId;
	}
}