package com.markit.ms.rfa.bean;

public class PendingTasks {
	private Long pendingExhibitComplete;
	private Long pendingResponse;
	private Long pendingEsign;
	private Long sendRFA;
	public PendingTasks(){
		pendingExhibitComplete = 0L;
		pendingEsign = 0L;
		pendingResponse = 0L;
	}
	
	public Long getPendingExhibitComplete() {
		return pendingExhibitComplete;
	}
	public void setPendingExhibitComplete(Long pendingExhibitComplete) {
		this.pendingExhibitComplete = pendingExhibitComplete;
	}
	public Long getPendingEsign() {
		return pendingEsign;
	}
	public void setPendingEsign(Long pendingEsign) {
		this.pendingEsign = pendingEsign;
	}
	public Long getPendingResponse() {
		return pendingResponse;
	}
	public void setPendingResponse(Long pendingResponse) {
		this.pendingResponse = pendingResponse;
	}

	public Long getSendRFA() {
		return sendRFA;
	}

	public void setSendRFA(Long sendRFA) {
		this.sendRFA = sendRFA;
	}
	
}
