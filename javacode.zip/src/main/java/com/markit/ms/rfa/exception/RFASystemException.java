package com.markit.ms.rfa.exception;


public class RFASystemException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public RFASystemException() {
		super();
	}

	public RFASystemException(String message, Throwable cause) {
		super(message + 
		        (cause == null?"":(" : " +cause.getMessage())), 
		            cause);
	}

	public RFASystemException(String message) {
		super(message);
	}

	public RFASystemException(Throwable cause) {
		super(cause);
	}

}
