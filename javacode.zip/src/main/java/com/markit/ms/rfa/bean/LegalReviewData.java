package com.markit.ms.rfa.bean;

public class LegalReviewData {
	private long legal_review_id;
	private long review_id;
    private String updateBy;
    private boolean editable;
	public long getLegal_review_id() {
		return legal_review_id;
	}
	public void setLegal_review_id(long legal_review_id) {
		this.legal_review_id = legal_review_id;
	}
	public long getReview_id() {
		return review_id;
	}
	public void setReview_id(long review_id) {
		this.review_id = review_id;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public boolean getEditable() {
		return editable;
	}
	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}
