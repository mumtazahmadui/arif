package com.markit.ms.rfa.service.impl;

import static com.markit.ms.rfa.util.PartyBDeskConstants.BS_DESK_CODES;
import static com.markit.ms.rfa.util.PartyBDeskConstants.ESCALATED_DESK_CODES;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.markit.ms.common.bean.Email;
import com.markit.ms.common.bean.User;
import com.markit.ms.common.service.EmailFilterMetadataService;
import com.markit.ms.common.service.EmailService;
import com.markit.ms.common.service.IUserService;
import com.markit.ms.common.util.TemplateTypeEnum;
import com.markit.ms.rfa.bean.PartyBDeskReviewData;
import com.markit.ms.rfa.dao.DeskReviewHistoryDao;
import com.markit.ms.rfa.dao.DeskReviewStatusDao;
import com.markit.ms.rfa.dao.IPartyBDao;
import com.markit.ms.rfa.dto.PartyBDeskReviewDetails;
import com.markit.ms.rfa.service.IDeskReviewService;
import com.markit.ms.rfa.service.IMcsRedirectUrlGenerator;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PartyBDeskConstants.NOTIFICATION_ACTION;
import com.markit.ms.rfa.util.PartyBDeskConstants.ONBOARDING;
import com.markit.ms.rfa.util.RFAConstants;;

/**
 * This class provides method implementation for amendment letter partyB's due
 * diligence desk actions
 * 
 * @since RFA5.0
 *
 */
@Service
public class DeskReviewServiceImpl implements IDeskReviewService {

	private static final Logger LOGGER = LoggerFactory.getLogger(DeskReviewServiceImpl.class);
	private static final String PARTYB_LIST_KEY = "partyBList";

	@Autowired
	private DeskReviewStatusDao deskReviewStatusDao;

	@Autowired
	private DeskReviewHistoryDao deskReviewHistoryDao;

	@Autowired
	private IPartyBDao partyBDao;

	@Autowired
	private IUserService userService;

	@Autowired
	private EmailService mailService;

	@Autowired
	private EmailFilterMetadataService emailFilterMetadataService;

	@Autowired
	IMcsRedirectUrlGenerator gridSearchUrlGenerator;
		
	@Autowired
	IMcsRedirectUrlGenerator viewRfaUrlGenerator;
	
	@Override
	public List<PartyBDeskReviewDetails> getReviewHistoryDetails(PartyBDeskReviewData deskReviewData) {
		return deskReviewHistoryDao.fetchReviewHistoryDetails(deskReviewData);
	}

	public List<PartyBDeskReviewDetails> getAmendmentReviewHistoryDetails(Long amendmentId, String deskCode) {
		return deskReviewHistoryDao.fetchAmendmentReviewHistoryDetails(amendmentId, deskCode);
	}

	@Override
	public PartyBDeskReviewDetails getEscalatedDetail(PartyBDeskReviewData deskReviewData) {
		PartyBDeskReviewDetails escalatedHistory = deskReviewHistoryDao.fetchEscalatedHistoryDetails(deskReviewData);

		/**
		 * get details of users who are notified of escalate action
		 */
		if (escalatedHistory != null && escalatedHistory.getId() != null) {
			escalatedHistory.setEscalatedTo(deskReviewHistoryDao.getEscalatedToUsers(escalatedHistory.getId()));
			return escalatedHistory;
		}

		return new PartyBDeskReviewDetails();
	}

	@Override
	@Transactional
	public void updateDeskStatus(PartyBDeskReviewData deskReviewData) {
		deskReviewData.setCreatedDate(new Date());
		if (CollectionUtils.isNotEmpty(deskReviewData.getPartyBIds())) {
			for (int i = 0; i < deskReviewData.getPartyBIds().size(); i++) {
				deskReviewData.setPartyBId(deskReviewData.getPartyBIds().get(i));

				deskReviewStatusDao.insertOrUpdate(deskReviewData);

				deskReviewHistoryDao.create(deskReviewData);
			}

			/**
			 * for bulk action at amendmentLevel save the action details
			 */
			if (BS_DESK_CODES.contains(deskReviewData.getDeskCode()) && deskReviewData.isBulkAction()) {
				deskReviewHistoryDao.createAtAmendment(deskReviewData);
			}
		}

	}

	@Override
	@Transactional
	public void escalateDeskStatus(PartyBDeskReviewData deskReviewData) {

		if (deskReviewData != null && deskReviewData.getPartyBId() != null) {

			deskReviewStatusDao.insertOrUpdate(deskReviewData);
			Long deskReviewHistoryId = deskReviewHistoryDao.create(deskReviewData);

			/**
			 * for desk review history details insert details of users who are being
			 * notified of escalation
			 */
			if (deskReviewHistoryId != null && CollectionUtils.isNotEmpty(deskReviewData.getUserIds())) {
				deskReviewHistoryDao.insertEscalatedUsers(deskReviewHistoryId, deskReviewData.getUserIds());
			}
		}
	}

	@Override
	@Transactional
	public void updateNotifiedStatusOnSendRFA(Long amendmentId, Long userId) {
		/**
		 * get all partyB's for amendment id
		 */
		List<Long> partyBIds = partyBDao.getPartyBFromAmendmentId(amendmentId);

		LOGGER.debug("updateNotifiedStatusOnSendRFA : PartyB ids" + partyBIds);

		if (CollectionUtils.isNotEmpty(partyBIds)) {
			PartyBDeskReviewData deskReviewData = new PartyBDeskReviewData();
			deskReviewData.setCreatedBy(userId);
			deskReviewData.setReviewed(Boolean.valueOf(true));
			deskReviewData.setDeskCode(ONBOARDING.NOTIFIED.code);
			deskReviewData.setPartyBIds(partyBIds);
			deskReviewData.setBulkAction(Boolean.valueOf(true));
			deskReviewData.setAmendmentId(amendmentId);

			updateDeskStatus(deskReviewData);
		}
	}

	@Override
	public String getMailPreview(String deskName, PartyBDeskReviewData deskReviewData) {

		User loggedInUser = userService.getUser(deskReviewData.getCreatedBy());

		TemplateTypeEnum templateType;
		if (CommonUtil.isEqual(deskName, RFAConstants.SIGNATORY)) {
			templateType = TemplateTypeEnum.RFA_SIGNATORY_NOTIFICATION;
		} else if (CommonUtil.isNotNull(deskName)) {
			templateType = TemplateTypeEnum.RFA_DUE_DILIGENCE_NOTIFICATION;
		} else {
			templateType = TemplateTypeEnum.RFA_CUSTOM_NOTIFICATION;
		}

		/**
		 * get all the parameters which are to be provide for Email Template
		 */
		Map<String, Object> emailTemplateParams = getParamsForEmailNotification(deskName, loggedInUser, deskReviewData);
		
		if(ESCALATED_DESK_CODES.contains(deskReviewData.getDeskCode())){
			emailTemplateParams.put("escalationFlag", true);
		}
		
		return mailService.getMailPreview(emailTemplateParams, templateType);

	}

	@Override
	@Transactional
	public void notifyUsers(String deskName, PartyBDeskReviewData deskReviewData) {

		User loggedInUser = userService.getUser(deskReviewData.getCreatedBy());

		NOTIFICATION_ACTION action;
		if (CommonUtil.isNull(deskName)) {
			action = NOTIFICATION_ACTION.CUSTOM;
		} else {
			action = NOTIFICATION_ACTION.BULK;
		}

		sendMail(loggedInUser, deskReviewData, deskName, action);

	}

	@Override
	@Transactional
	public void escalteToUsers(String deskName, PartyBDeskReviewData deskReviewData) {

		User loggedInUser = userService.getUser(deskReviewData.getCreatedBy());

		/**
		 * escalate action is taken for single partyB
		 */
		deskReviewData.setPartyBIds(Arrays.asList(deskReviewData.getPartyBId()));

		sendMail(loggedInUser, deskReviewData, deskName, NOTIFICATION_ACTION.ESCALATION);
	}

	/**
	 * creates <code>Email</code> object and send mail using
	 * <code>EmailService</code>
	 * 
	 */
	private void sendMail(User loggedInUser, PartyBDeskReviewData deskReviewData, String deskName,
			NOTIFICATION_ACTION action) {

		TemplateTypeEnum templateType = TemplateTypeEnum.RFA_DUE_DILIGENCE_NOTIFICATION;

		/**
		 * get all the parameters which are to be required for Email Template
		 */
		Map<String, Object> emailTemplateParams = getParamsForEmailNotification(deskName, loggedInUser, deskReviewData);

		Map<String, Object> subjectTemplateParams = new HashMap<>();

		switch (action) {
		case CUSTOM:
			templateType = TemplateTypeEnum.RFA_CUSTOM_NOTIFICATION;
			subjectTemplateParams.put("subjectData", deskReviewData.getSubject());
			break;
		case BULK:
			subjectTemplateParams.put("subjectData", deskName + " Review Requested");
			break;
		case ESCALATION:
			emailTemplateParams.put("escalationFlag", true);
			subjectTemplateParams.put("subjectData", deskName + " Escalation");
			break;
		}	
		
		setUrlParamsForEmailNotification(emailTemplateParams, loggedInUser.getUserId(),templateType);
		
		/**
		 * gets list of all users
		 */
		List<User> notificationUsers = null;
		if (deskReviewData.getUserIds() != null) {
			notificationUsers = userService.getUsersByIds(deskReviewData.getUserIds());
		} else if (deskReviewData.getEmailIds() != null) {
			notificationUsers = new ArrayList<>();
			User userTemp;
			for (int i = 0; i < deskReviewData.getEmailIds().size(); i++) {
				userTemp = new User();
				userTemp.setEmail(deskReviewData.getEmailIds().get(i));
				notificationUsers.add(userTemp);
			}
		}

		List<String> ccUsers = new ArrayList<>();
		ccUsers.add(loggedInUser.getEmail());

		/**
		 * add all required email parameters
		 */

		Email mail = new Email();
		mail.setTemplateArgsMap(emailTemplateParams);
		mail.setSubTemplateArgsMap(subjectTemplateParams);
		mail.setCcEmailId(ccUsers);

		LOGGER.debug("sendMail : saving mail for Template");

		if (notificationUsers != null) {
			mailService.saveMail(mail, notificationUsers, templateType);
		} else {
			LOGGER.error("sendMail : notification users list empty");
		}
	}

	/**
	 * get params required for RFA Dashboard notification Email Template
	 * 
	 * @return
	 */
	private Map<String, Object> getParamsForEmailNotification(String deskName, User loggedInUser,
			PartyBDeskReviewData deskReviewData) {

		List<Map<String, Object>> partyBDetails = null;
		/**
		 * get all partyB details for selected amendment's and partyB's
		 */
		if (CommonUtil.isEqual(deskName, RFAConstants.SIGNATORY)) {
			partyBDetails = partyBDao.getAmendmentDetailsForDeskNotification(deskReviewData.getAmendmentIds());
		} else {
			partyBDetails = partyBDao.getPartyBDetailsForDeskNotification(deskReviewData.getPartyBIds(),
					loggedInUser.getCompanyType());
		}

		LOGGER.debug("getParamsForEmailNotification : PartyB's selected : "
				+ (partyBDetails != null ? partyBDetails.size() : Integer.valueOf(0)));

		Map<String, Object> emailTemplateParams = new HashMap<String, Object>();
		emailTemplateParams.put("desk_name", deskName);
		emailTemplateParams.put(PARTYB_LIST_KEY, partyBDetails);
		emailTemplateParams.put("intiator_full_name", loggedInUser.getFullName());
		if (deskReviewData.getMessage() != null) {
			emailTemplateParams.put("custom_text_message", deskReviewData.getMessage().replace("\n", "<br/>"));
		}

		mailService.addContactParams(emailTemplateParams);

		return emailTemplateParams;
	}
	
	/**
	 * set link url's for email notifications
	 * @param emailTemplateParams
	 * @param userId
	 * @param templateType 
	 */
	private void setUrlParamsForEmailNotification(Map<String, Object> emailTemplateParams, Long userId,
			TemplateTypeEnum templateType) {
		
		/**
		 * create filter criteria for partyB details and generate url for the dashboard
		 * filters
		 */
		String filterJSON = getFilterCriteriaJson((List<Map<String, Object>>)emailTemplateParams.get(PARTYB_LIST_KEY));
		emailTemplateParams.put("login", generateUrl(filterJSON, userId,templateType));
		LOGGER.debug("setUrlParamsForEmailNotification : login url : " + emailTemplateParams.get("login"));
		
		
		try {
			Map<String, String> queryStringParams = new HashMap<>();
			queryStringParams.put("amendment_id", StringUtils.EMPTY);				
			emailTemplateParams.put("viewRfa", viewRfaUrlGenerator.generateUrl(queryStringParams));

		} catch (Exception e) {
			LOGGER.error("setUrlParamsForEmailNotification : Error generating view rfa url");
		}	
	}
	
	/**
	 * create json from data provided
	 */
	private String getFilterCriteriaJson(List<Map<String, Object>> dataList) {

		/**
		 * list of amendment ids for filter
		 */
		Set<Long> rfaId = new HashSet<>();
		/**
		 * list of partyBs for filter
		 */
		List<Map<String, Object>> partyBAccount = new ArrayList<>();

		if (dataList != null) {
			Map<String, Object> data;
			Map<String, Object> partyBAccountMap;
			for (int i = 0; i < dataList.size(); i++) {

				data = dataList.get(i);

				rfaId.add(((BigDecimal) data.get("amendmentId")).longValue());
				partyBAccountMap = new HashMap<>();
				partyBAccountMap.put("id", ((BigDecimal) data.get("partyBEntityId")).longValue());
				partyBAccountMap.put("value", data.get("partyBEntityLegalName"));
				partyBAccount.add(partyBAccountMap);

			}
		}

		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("rfaId", rfaId);
		resultMap.put("partyBAccount", partyBAccount);

		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.create();

		return gson.toJson(resultMap);

	}

	@Override
	public String generateUrl(String filterJson, Long loggedInUserId, TemplateTypeEnum templateType) {
		
		/**
		 * save filters in database and get unique id for each filter
		 */
		Long filterTokenId = emailFilterMetadataService.generateFilterToken(loggedInUserId, templateType.eventDesc,
				filterJson, templateType);

		Map<String, String> queryStringParams = new HashMap<>();
		queryStringParams.put("filterId", String.valueOf(filterTokenId));

		try {
			return gridSearchUrlGenerator.generateUrl(queryStringParams);

		} catch (Exception e) {
			LOGGER.error("generateUrl : Error generating filter url");
		}
		return null;

	}
}
