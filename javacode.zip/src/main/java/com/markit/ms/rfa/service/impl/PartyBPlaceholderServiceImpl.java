package com.markit.ms.rfa.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.markit.ms.common.dao.IPartyBPlaceholderDao;
import com.markit.ms.rfa.placeholders.request.BSPartyBTableRequest;
import com.markit.ms.rfa.placeholders.request.SSPartyBTableRequest;
import com.markit.ms.rfa.service.IPartyBPlaceholderService;
@Service
public class PartyBPlaceholderServiceImpl implements IPartyBPlaceholderService {
	@Resource IPartyBPlaceholderDao partyBPlaceholderDao;
	
	@Override
	public void updateBSLineBreaks(Long amendmentId, Long userId,String placeholderType, BSPartyBTableRequest bsPartyBTableRequest) {
		partyBPlaceholderDao.updateBSLineBreaks(amendmentId, userId, placeholderType, bsPartyBTableRequest);
	}
	@Override
	@Transactional
	public void updateSSResponse(Long amendmentId, Long userId,
			SSPartyBTableRequest ssPartyBTableRequest) {
		partyBPlaceholderDao.updateSSResponse(amendmentId, userId, ssPartyBTableRequest);
	}
	@Override
	public List<Map<String, String>> getLineBreaks(Long amendmentId,
			String placeholderType) {
		// TODO Auto-generated method stub
		return partyBPlaceholderDao.getLineBreaks(amendmentId, placeholderType);
	}
	@Override
	public List<Map<String, String>> getPreviousLineBreaks(Long amendmentId,
			String placeholderType) {
		return partyBPlaceholderDao.getPreviousLineBreaks(amendmentId,
				placeholderType);
	}
	@Override
	@Transactional
	public void updateAmendmentStatusAndNextStep(Long amendmentId) {
		partyBPlaceholderDao.updateAmendmentStatusAndNextStep(amendmentId);
	}
	
	@Override
	@Transactional
	public void updateAmendmentBySsResponse(Long amendmentId, Long userId) {
		partyBPlaceholderDao.updateAmendmentBySsResponse(amendmentId, userId);
	}
	
	@Override
	public void updateAmendment(Long amendmentId, Long userId){
		partyBPlaceholderDao.updateAmendment(amendmentId, userId);
	}
}
