package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.common.bean.Lookup;


public interface ILetterTemplateFilterDAO
{
	public List<Lookup> nameLookup(Long id, String filterString);
	public List<Lookup> lastEditedByLookup(Long id, String filterString);
	public List<Lookup> createdByLookup(Long id, String filterString);
}
