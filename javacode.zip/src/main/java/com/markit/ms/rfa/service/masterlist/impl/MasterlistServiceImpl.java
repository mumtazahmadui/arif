package com.markit.ms.rfa.service.masterlist.impl;


import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.activity.InvalidActivityException;
import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.bean.DownloadSheetData;
import com.markit.ms.common.service.impl.DownloadServiceImpl;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.bean.MasterlistDownload;
import com.markit.ms.rfa.bean.MasterlistTemplate;
import com.markit.ms.rfa.bean.MasterlistValidatorBean;
import com.markit.ms.rfa.bean.McpmMasterlistLegalNameMapper;
import com.markit.ms.rfa.bean.TemplateField;
import com.markit.ms.rfa.dao.IMasterAgreementDao;
import com.markit.ms.rfa.dao.IMasterlistDao;
import com.markit.ms.rfa.dao.IMasterlistTemplateDAO;
import com.markit.ms.rfa.dto.MasterlistSearchRequest;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.masterlist.IActiveTabService;
import com.markit.ms.rfa.service.masterlist.IMasterlistService;
import com.markit.ms.rfa.service.masterlist.IModifiedTabService;
import com.markit.ms.rfa.service.masterlist.IRemovalTabService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.MasterlistDownloadModifiedDateComparator;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class MasterlistServiceImpl implements IMasterlistService {
	
	@Autowired
	private IMasterlistDao masterlistDao;
	
	@Autowired
	private IMasterlistTemplateDAO masterlistTemplateDao;
	
	@Autowired
	private IMasterAgreementDao masterAgreementDao;
	
	@Autowired
	private IActiveTabService activeTabService;
	
	@Autowired
	private IRemovalTabService removalTabService;
	
	@Autowired
	private IModifiedTabService modifiedTabService;
	
	@Resource private QueryService<Grid> getActiveSleevesInMasterlist;
	
	@Override
	public List<Masterlist> getMasterlistGrid(Long companyId,
			MasterlistSearchRequest masterlistSearchRequest) {
		return masterlistDao.getMasterlistGrid(companyId, masterlistSearchRequest);
	}

	@Override
	public Long getMasterlistGridTotalCount(Long companyId,
			MasterlistSearchRequest masterlistSearchRequest) {
		return masterlistDao.getMasterlistGridTotalCount(companyId, masterlistSearchRequest);
	}

	@Override
	public SXSSFWorkbook downloadMasterlist(Long masterAgreementId) throws Exception {
		List<DownloadSheetData> dataList = new ArrayList<DownloadSheetData>();
		List<MasterlistDownload> activeRemoveTabsList = new ArrayList<MasterlistDownload>();
		List<MasterlistDownload> modifiedTabList = new ArrayList<MasterlistDownload>();
		List<MasterlistDownload> addedList = new ArrayList<MasterlistDownload>();
		List<MasterlistDownload> removedList = new ArrayList<MasterlistDownload>();
		List<MasterlistDownload> modifiedList = new ArrayList<MasterlistDownload>();
		//Legal Name, <Parent Entity Id, <Sleeve Entity Id ,<Column name, Column Value>
		Map<String, Map<Long,Map<Long ,Map<String, String>>>> activeTabMap = new LinkedHashMap<>();
		Map<String, Map<Long,Map<Long,Map<String, String>>>> removeTabMap = new LinkedHashMap<>();
		Map<Long, Map<String,String>> modifiedListOldColumnMap = new LinkedHashMap<Long, Map<String,String>>();
		Map<Long, Map<String,String>> modifiedListNewColumnMap = new LinkedHashMap<Long, Map<String,String>>();
		List<String> customHorizontalColumns = new ArrayList<String>();
		customHorizontalColumns.add(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD);
		customHorizontalColumns.add(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD);
		customHorizontalColumns.add(RFAConstants.PARTYB_LEI);
		customHorizontalColumns.add(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD);
		customHorizontalColumns.add(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD);
		
		Map<String, Map<String, String>> templateColumnsMap = new LinkedHashMap<>();
		
		String[] modifiedTabheaders = {"modificationType", "oldLegalName", "newLegalName", "oldClientIdentifier"
				, "newClientIdentifier", "oldLeiName", "newLeiName", "addedDateString", "modifiedDateString", "rfaId"};
		
		activeRemoveTabsList = masterlistDao.getMasterlistActiveRemoveTabs(masterAgreementId);
		modifiedTabList = masterlistDao.getMasterlistModifiedTab(masterAgreementId);
		Collections.sort(modifiedTabList, new MasterlistDownloadModifiedDateComparator());
		String controlColumn = masterlistDao.getMasterlistControlColumn(masterAgreementId);
		Date masterlistUpdateDate = masterlistDao.getMasterlistUpdateDate(masterAgreementId);
		String masterlistUpdateDateString = CommonUtil.getDateForFormat(masterlistUpdateDate, "dd-MMM-yyyy");
		
		MasterlistTemplate masterlistTemplate = null;
		Long templateId = masterlistTemplateDao.getMasterlistTemplateByMasterlist(masterAgreementId);
		if(null != templateId){
			masterlistTemplate = masterlistTemplateDao.getMasterlistTemplateById(templateId);
			getTemplateColumnsMap(templateColumnsMap, masterlistTemplate);
		}

		Map<Long, String> legalNameEntityMap = new LinkedHashMap<>();
		Map<Long, Map<Long, Map<String, String>>> activeTabParentEntityMap = null;
		Map<Long, Map<Long, Map<String, String>>> removeTabParentEntityMap = null;
		Map<Long, Map<String, String>> activeTabEntityMap = null;
		Map<Long, Map<String, String>> removeTabEntityMap = null;
		Map<String, String> activeTabColumnMap = null;
		Map<String, String> removeTabColumnMap = null;
		List<String> allColumnNames = new ArrayList<>();
		Map<Long,String> clientIdentifierMap = new HashMap<>();
		Map<Long,String> leiMap = new HashMap<>();
		// This information needs to be used when merging the information
		for(MasterlistDownload ml : activeRemoveTabsList) {
			String columnName = ml.getColumnName();
			String columnValue = ml.getColumnValue();
			if(null != columnName && RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(columnName)
					&& null!= columnValue && columnValue.length()!= 0 ) {
				clientIdentifierMap.put(ml.getParentEntityId(), columnValue);
			}
			if(null != columnName && RFAConstants.PARTYB_LEI.equalsIgnoreCase(columnName)
					&& null!= columnValue && columnValue.length()!= 0 ) {
				leiMap.put(ml.getParentEntityId(), columnValue);
			}
		}
		
		for(MasterlistDownload masterlistDownload : activeRemoveTabsList) {
			String legalName = null;
			String columnName = masterlistDownload.getColumnName();
			String columnValue = masterlistDownload.getColumnValue();
			if(!allColumnNames.contains(columnName)) {
				allColumnNames.add(columnName);
			}
			if(null != columnName && RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD.equalsIgnoreCase(columnName)) {
				legalName = columnValue;
				legalNameEntityMap.put(masterlistDownload.getParentEntityId(), legalName);
			}
			legalName = legalNameEntityMap.get(masterlistDownload.getParentEntityId());
			if(masterlistDownload.isAdded()) 
			{
				if(null == activeTabMap.get(legalName)) {
					activeTabParentEntityMap = new LinkedHashMap<>();
					if(null != masterlistDownload.getModifiedDate()) {
						if(masterlistDownload.isAdded()) {
							addedList.add(masterlistDownload);
						}
					}
				} else {
					activeTabParentEntityMap = activeTabMap.get(legalName);
					if(null != masterlistDownload.getModifiedDate()) {
						if(masterlistDownload.isAdded()) {
							addedList.add(masterlistDownload);
						}
					}
				}
				
				if(null == activeTabParentEntityMap.get(masterlistDownload.getParentEntityId())) {
					activeTabEntityMap = new LinkedHashMap<Long, Map<String, String>>();
				} else {
					activeTabEntityMap = activeTabParentEntityMap.get(masterlistDownload.getParentEntityId());
				}
				if(null == activeTabEntityMap.get(masterlistDownload.getEntityId())) {
					activeTabColumnMap = new LinkedHashMap<String, String>();
				} else {
					activeTabColumnMap = activeTabEntityMap.get(masterlistDownload.getEntityId());
				}
				
				if(null != columnName && RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(columnName)) {
					columnValue = clientIdentifierMap.get(masterlistDownload.getParentEntityId());
				}
				if(null != columnName && RFAConstants.PARTYB_LEI.equalsIgnoreCase(columnName)) {
					columnValue = leiMap.get(masterlistDownload.getParentEntityId());
				}
				activeTabColumnMap.put(columnName, columnValue);
				activeTabEntityMap.put(masterlistDownload.getEntityId(), activeTabColumnMap);
				activeTabParentEntityMap.put(masterlistDownload.getParentEntityId(), activeTabEntityMap);
				activeTabMap.put(legalName, activeTabParentEntityMap);
			}
			
			if(!masterlistDownload.isAdded()) 
			{
				if(null == removeTabMap.get(legalName)) 
				{
					removeTabParentEntityMap = new LinkedHashMap<>();
					if(null != masterlistDownload.getModifiedDate()) {
						if(masterlistDownload.isAdded()) {
							addedList.add(masterlistDownload);
						} else {
							removedList.add(masterlistDownload);
						}
					}
				}
				else 
				{
					removeTabParentEntityMap = removeTabMap.get(legalName);
					if(null != masterlistDownload.getModifiedDate()) {
						if(masterlistDownload.isAdded()) {
							addedList.add(masterlistDownload);
						} else {
							removedList.add(masterlistDownload);
						}
					}
				}
				
				if(null == removeTabParentEntityMap.get(masterlistDownload.getParentEntityId())) {
					removeTabEntityMap = new LinkedHashMap<Long, Map<String, String>>();
					
				} else {
					removeTabEntityMap = removeTabParentEntityMap.get(masterlistDownload.getParentEntityId());
					
				}
				
				if(null == removeTabEntityMap.get(masterlistDownload.getEntityId())) {
					removeTabColumnMap = new LinkedHashMap<String, String>();
				} else {
					removeTabColumnMap = removeTabEntityMap.get(masterlistDownload.getEntityId());
				}
				
				if(null != columnName && RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(columnName)) {
					columnValue = clientIdentifierMap.get(masterlistDownload.getParentEntityId());
				}
				if(null != columnName && RFAConstants.PARTYB_LEI.equalsIgnoreCase(columnName)) {
					columnValue = leiMap.get(masterlistDownload.getParentEntityId());
				}

				removeTabColumnMap.put(columnName, columnValue);
				removeTabEntityMap.put(masterlistDownload.getEntityId(), removeTabColumnMap);
				removeTabParentEntityMap.put(masterlistDownload.getParentEntityId(), removeTabEntityMap);
				removeTabMap.put(legalName, removeTabParentEntityMap);
			}
		}
		

		
		Collections.sort(addedList, new MasterlistDownloadModifiedDateComparator());
		Collections.sort(removedList, new MasterlistDownloadModifiedDateComparator());
		
		Set<String> addRemoveTabscolumnSet = new LinkedHashSet<String>();
		Set<String> modifiedTabColumnSet = new LinkedHashSet<String>();
		Set<String> nonCustomColumnsSet = new LinkedHashSet<String>();

		for (String columnKey : allColumnNames) {
			if(customHorizontalColumns.contains(columnKey)){
				addRemoveTabscolumnSet.add(columnKey);
			} else {
				nonCustomColumnsSet.add(columnKey);
			}
			if(!RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.PARTYB_LEI_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.PARTYB_ACCOUNT_TRUE_LEGAL_NAME_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.PARTYB_ACCOUNT_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.PARTYB_ACCOUNT_LEI_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.PARTYB_LEI.equalsIgnoreCase(columnKey)
					&& !RFAConstants.DATE_ADDED_FIELD.equalsIgnoreCase(columnKey)
					&& !RFAConstants.RFA_ID_FIELD.equalsIgnoreCase(columnKey)) {
				modifiedTabColumnSet.add(columnKey);
			}
		}

		for(String columnKey: nonCustomColumnsSet){
			addRemoveTabscolumnSet.add(columnKey);
		}
		
		setModifiedTabOldAndNewColumnMap(modifiedTabList, modifiedList, modifiedListOldColumnMap, modifiedListNewColumnMap);
		
		dataList.add(new DownloadSheetData(2, modifiedList, modifiedTabheaders, 9));
		DownloadServiceImpl downloadService = new DownloadServiceImpl();
		InputStream inputStream = this.getClass().getResourceAsStream("/Masterlist_Template.xlsx");
		SXSSFWorkbook workbook = downloadService.getSXSSWorkbookFromList(inputStream, dataList);
		
		Map<String, CellStyle> cellstyles = getWorkbookCellStyles(workbook);
		Map<String, String> verticalColumnsValueMap = getVerticalColumnValues(addedList, removedList, masterAgreementId);
		
		
		activeTabService.prepareActiveTab(workbook, cellstyles, addedList, removedList, masterlistUpdateDateString, addRemoveTabscolumnSet, controlColumn, legalNameEntityMap, activeTabMap, templateColumnsMap, verticalColumnsValueMap);
		removalTabService.prepareRemovedTab(workbook, cellstyles, addedList, removedList, masterlistUpdateDateString, addRemoveTabscolumnSet, controlColumn, legalNameEntityMap, removeTabMap, templateColumnsMap, verticalColumnsValueMap);
		modifiedTabService.prepareModifiedTab(workbook, cellstyles, addedList, removedList, masterlistUpdateDateString, modifiedTabColumnSet, controlColumn, modifiedList, modifiedListNewColumnMap, modifiedListOldColumnMap, templateColumnsMap, verticalColumnsValueMap);
		
        return workbook;
	}
	
	private Map<String, String> getVerticalColumnValues(List<MasterlistDownload> valuesList1, List<MasterlistDownload> valuesList2, Long masterAgreementId)
	{
		Map<String, String> verticalColumnValues = new LinkedHashMap<>();
		if(null != valuesList1 && !valuesList1.isEmpty()) {
			verticalColumnValues.put(RFAConstants.AGREEMENT_TYPE, valuesList1.get(0).getAgreementType());
			verticalColumnValues.put(RFAConstants.REF_MASTER_AGREEMENT_DATE, valuesList1.get(0).getAgreementDate());
			verticalColumnValues.put(RFAConstants.INVESTMENT_MANAGER, valuesList1.get(0).getInvestmentManager());
			verticalColumnValues.put(RFAConstants.PARTYA_TRUE_LEGAL_NAME_FIELD, valuesList1.get(0).getPartyA());
			verticalColumnValues.put(RFAConstants.MASTERLIST_IDENTIFIER, valuesList1.get(0).getMasterlistIdentifier());
		} else if(null != valuesList2 && !valuesList2.isEmpty()) {
			verticalColumnValues.put(RFAConstants.AGREEMENT_TYPE, valuesList2.get(0).getAgreementType());
			verticalColumnValues.put(RFAConstants.REF_MASTER_AGREEMENT_DATE, valuesList2.get(0).getAgreementDate());
			verticalColumnValues.put(RFAConstants.INVESTMENT_MANAGER, valuesList2.get(0).getInvestmentManager());
			verticalColumnValues.put(RFAConstants.PARTYA_TRUE_LEGAL_NAME_FIELD, valuesList2.get(0).getPartyA());
			verticalColumnValues.put(RFAConstants.MASTERLIST_IDENTIFIER, valuesList2.get(0).getMasterlistIdentifier());
		} else {
			// If there are no Party Bs for addition/removal then it's a Shell Masterlist...
			MasterAgreement masterAgreement = masterAgreementDao.getMasterAgreementById(masterAgreementId);
			DateFormat formatter  = new SimpleDateFormat("dd-MMM-yyyy");
			verticalColumnValues.put(RFAConstants.AGREEMENT_TYPE, masterAgreement.getAgreementType());
			verticalColumnValues.put(RFAConstants.REF_MASTER_AGREEMENT_DATE, formatter.format(masterAgreement.getAgreementDate()));
			verticalColumnValues.put(RFAConstants.INVESTMENT_MANAGER, masterAgreement.getInvestmentManager().getTrueLegalName());
			verticalColumnValues.put(RFAConstants.PARTYA_TRUE_LEGAL_NAME_FIELD, masterAgreement.getPartyA().getTrueLegalName());
			verticalColumnValues.put(RFAConstants.MASTERLIST_IDENTIFIER, masterAgreement.getMasterlistIdentifier());
		}
		return verticalColumnValues;
	}

	private void getTemplateColumnsMap(Map<String, Map<String, String>> templateColumnsMap,
			MasterlistTemplate masterlistTemplate)
	{
		Map<String, String> verticalColumns = new LinkedHashMap<>();
		Map<String, String> horizontalColumns = new LinkedHashMap<>();
		Map<String, String> modifiedSheetHorizontalColumns = new LinkedHashMap<>();
		List<TemplateField> templateFields = masterlistTemplate.getTemplateFields();
		int i = 0, modifiedSheetStart = 0;
		for(; i<templateFields.size(); i++){
			if(templateFields.get(i).getFieldVisibility() == 1 && !templateFields.get(i).getFieldIdentifier().equalsIgnoreCase(RFAConstants.COUNTERPATY_NAME)){
				verticalColumns.put(templateFields.get(i).getFieldIdentifier(), templateFields.get(i).getFieldLabel());
			}
			if(templateFields.get(i).getFieldIdentifier().equalsIgnoreCase(RFAConstants.PARTYA_TRUE_LEGAL_NAME_FIELD)){
				i++;
				break;
			}
		}
		
		modifiedSheetStart = i;
		
		for(; i<templateFields.size(); i++){
			if(templateFields.get(i).getFieldVisibility() == 1 && !templateFields.get(i).getFieldIdentifier().equals(RFAConstants.NEW_LEGAL_NAME)
					&& !templateFields.get(i).getFieldIdentifier().equals(RFAConstants.OLD_LEGAL_NAME) && !templateFields.get(i).getFieldIdentifier().equals("Party A Pre-LEI/LEI")
					&& !templateFields.get(i).getFieldIdentifier().equals(RFAConstants.NEW_CLIENT_IDENTIFIER) && !templateFields.get(i).getFieldIdentifier().equals(RFAConstants.OLD_CLIENT_IDENTIFIER)
					&& !templateFields.get(i).getFieldIdentifier().equals(RFAConstants.NEW_LEI) && !templateFields.get(i).getFieldIdentifier().equals(RFAConstants.OLD_LEI)){
				horizontalColumns.put(templateFields.get(i).getFieldIdentifier(), templateFields.get(i).getFieldLabel());
			}
		}
		
		modifiedSheetHorizontalColumns.put("modificationType", "Modification Type");
		for(; modifiedSheetStart<templateFields.size(); modifiedSheetStart++){
			
			if (templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD) && templateFields.get(modifiedSheetStart).getFieldVisibility() == 1 )
				modifiedSheetHorizontalColumns.put(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD, templateFields.get(modifiedSheetStart).getFieldLabel());
			if (templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD) && templateFields.get(modifiedSheetStart).getFieldVisibility() == 1 )
				modifiedSheetHorizontalColumns.put(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD, templateFields.get(modifiedSheetStart).getFieldLabel());
				
			
			if(templateFields.get(modifiedSheetStart).getFieldVisibility() == 1 && 
					(templateFields.get(modifiedSheetStart).getFieldIdentifier().contains("Old") || templateFields.get(modifiedSheetStart).getFieldIdentifier().contains("New"))){
				if(templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.OLD_LEGAL_NAME)){
					modifiedSheetHorizontalColumns.put("oldLegalName", templateFields.get(modifiedSheetStart).getFieldLabel());
				} else if(templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.NEW_LEGAL_NAME)){
					modifiedSheetHorizontalColumns.put("newLegalName", templateFields.get(modifiedSheetStart).getFieldLabel());
				} else if(templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.OLD_CLIENT_IDENTIFIER)){
					modifiedSheetHorizontalColumns.put("oldClientIdentifier", templateFields.get(modifiedSheetStart).getFieldLabel());
				} else if(templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.NEW_CLIENT_IDENTIFIER)){
					modifiedSheetHorizontalColumns.put("newClientIdentifier", templateFields.get(modifiedSheetStart).getFieldLabel());
				} else if(templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.OLD_LEI)){
					modifiedSheetHorizontalColumns.put("oldLeiName", templateFields.get(modifiedSheetStart).getFieldLabel());
				} else if(templateFields.get(modifiedSheetStart).getFieldIdentifier().equals(RFAConstants.NEW_LEI)){
					modifiedSheetHorizontalColumns.put("newLeiName", templateFields.get(modifiedSheetStart).getFieldLabel());	
				}
			}
		}
		modifiedSheetHorizontalColumns.put("addedDateString", "Date Added");
		modifiedSheetHorizontalColumns.put("modifiedDateString", "Date Modified");
		modifiedSheetHorizontalColumns.put("rfaId", "RFA ID");
		
		templateColumnsMap.put("verticalColumns", verticalColumns);
		templateColumnsMap.put("horizontalColumns", horizontalColumns);
		templateColumnsMap.put("modifiedSheetHorizontalColumns", modifiedSheetHorizontalColumns);
	}

	private Map<String, CellStyle> getWorkbookCellStyles(SXSSFWorkbook workbook) 
	{
		Map<String, CellStyle> cellStyles = new HashMap<String, CellStyle>(); 
		
		CellStyle columnNameStyle = workbook.createCellStyle();
		Font columnFont = workbook.createFont();
		columnFont.setFontHeightInPoints((short)9);
		columnFont.setFontName("Calibri");
		columnFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		columnNameStyle.setFont(columnFont);
		cellStyles.put("columnNameStyle", columnNameStyle);
		
		CellStyle headerStyle = workbook.createCellStyle();
		Font headerFont = workbook.createFont();
		headerFont.setFontHeightInPoints((short)9);
		headerFont.setFontName("Calibri");
		headerFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
		headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
		headerStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		headerStyle.setFont(headerFont);
		headerStyle.setBorderBottom(CellStyle.BORDER_THIN);
		headerStyle.setBorderTop(CellStyle.BORDER_THIN);
		headerStyle.setBorderRight(CellStyle.BORDER_THIN);
		headerStyle.setBorderLeft(CellStyle.BORDER_THIN);
		cellStyles.put("headerStyle", headerStyle);
		
		CellStyle columnValueStyle = workbook.createCellStyle();
		Font columnValueFont = workbook.createFont();
		columnValueFont.setFontHeightInPoints((short)9);
		columnValueFont.setFontName("Calibri");
		columnValueStyle.setFont(columnValueFont);
		columnValueStyle.setBorderBottom(CellStyle.BORDER_THIN);
		columnValueStyle.setBorderTop(CellStyle.BORDER_THIN);
		columnValueStyle.setBorderRight(CellStyle.BORDER_THIN);
		columnValueStyle.setBorderLeft(CellStyle.BORDER_THIN);
		columnValueStyle.setVerticalAlignment(CellStyle.VERTICAL_TOP);
		cellStyles.put("columnValueStyle", columnValueStyle);
		
		CellStyle mergedCellStyle = workbook.createCellStyle();
		Font mergeCellFont = workbook.createFont();
		mergeCellFont.setFontHeightInPoints((short)9);
		mergeCellFont.setFontName("Calibri");
		mergedCellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		mergedCellStyle.setFont(mergeCellFont);
		mergedCellStyle.setBorderBottom(CellStyle.BORDER_THIN);
		mergedCellStyle.setBorderTop(CellStyle.BORDER_THIN);
		mergedCellStyle.setBorderRight(CellStyle.BORDER_THIN);
		mergedCellStyle.setBorderLeft(CellStyle.BORDER_THIN);
		cellStyles.put("mergedCellStyle", mergedCellStyle);
		
		return cellStyles;
	}

	private void setModifiedTabOldAndNewColumnMap(List<MasterlistDownload> modifiedTabList,
			List<MasterlistDownload> modifiedList, Map<Long, Map<String, String>> modifiedListOldColumnMap,
			Map<Long, Map<String, String>> modifiedListNewColumnMap)
	{
		Map<String, String> oldColumnMap = null;
		Map<String, String> newColumnMap = null;
		for (MasterlistDownload masterlistDownload : modifiedTabList) {
			if(null == modifiedListOldColumnMap.get(masterlistDownload.getPartybId())) {
				oldColumnMap = new LinkedHashMap<String, String>();
				modifiedList.add(masterlistDownload);
			} else {
				oldColumnMap = modifiedListOldColumnMap.get(masterlistDownload.getPartybId());
			}
			if(null == modifiedListNewColumnMap.get(masterlistDownload.getPartybId())) {
				newColumnMap = new LinkedHashMap<String, String>();
			} else {
				newColumnMap = modifiedListNewColumnMap.get(masterlistDownload.getPartybId());
			}
			String columnName = masterlistDownload.getColumnName();
			if(!RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD.equalsIgnoreCase(columnName)
					&& !RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equalsIgnoreCase(columnName)
					&& !RFAConstants.PARTYB_LEI_FIELD.equalsIgnoreCase(columnName)) {
				String oldColumnValue = masterlistDownload.getOldColumnValue();
				String newColumnValue = masterlistDownload.getColumnValue();
				oldColumnMap.put(columnName, oldColumnValue);
				newColumnMap.put(columnName, newColumnValue);
			}
			modifiedListOldColumnMap.put(masterlistDownload.getPartybId(), oldColumnMap);
			modifiedListNewColumnMap.put(masterlistDownload.getPartybId(), newColumnMap);
		}
	}

	@Override
	public SXSSFWorkbook downloadMcpmPartybMappingFile(Long masterAgreementId) throws Exception {
		List<McpmMasterlistLegalNameMapper> masterlistMcpmMapperList = masterlistDao
				.getMcpmMasterlistLegalNameMapping(masterAgreementId);
		String[] headers = {"masterlistLegalName", "mcpmLegalName"};
		List<DownloadSheetData> dataList = new ArrayList<DownloadSheetData>();
		dataList.add(new DownloadSheetData(0, masterlistMcpmMapperList, headers, 2));
		DownloadServiceImpl downloadService = new DownloadServiceImpl();
		InputStream inputStream = this.getClass().getResourceAsStream("/MCPM_PartyB_Mapping_Template.xlsx");
		SXSSFWorkbook workbook = downloadService.getSXSSWorkbookFromList(inputStream, dataList);
		return workbook;
	}
	
	@Override
	public void deleteMasterlist(Long companyId, Long masterAgreementId) throws InvalidActivityException {
		List<Masterlist> masterlist = masterlistDao.getMasterlistWithoutRfa(companyId, masterAgreementId);
		if(masterlist.size() == 0){
			masterlistDao.deleteMasterlist(masterAgreementId);
		} else {
			throw new InvalidActivityException();
		}
	}
	
	@Override
	public void updateAgreementType(Long companyId, Long masterAgreementId, Masterlist masterlist) throws RFAUIException{
		MasterlistValidatorBean masterlistTobeUpdated = masterlistDao.getMasterAgreementById(masterAgreementId);
		
		masterlistTobeUpdated.setAgreementTypeId(masterlist.getAgreementTypeId());
		List<MasterlistValidatorBean> masterlists = masterlistDao.getUniqueMasterAgreement(masterlistTobeUpdated);
		
		if(masterlists.size() == 0){
			masterlistDao.updateAgreementType(masterAgreementId, masterlist.getAgreementTypeId());
		} else {
			throw new RFAUIException(RFAConstants.MASTERLIST_EXISTS_WITH_AGREEMENT_TYPE, HttpStatus.BAD_REQUEST.toString());
		}
		
	}
}
