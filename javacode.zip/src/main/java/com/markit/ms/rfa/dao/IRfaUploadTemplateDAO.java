package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.rfa.bean.MCPMClientIdentifier;
import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.bean.RFAUploadTemplateFile;
import com.markit.ms.rfa.bean.RfaUploadTemplateDownload;
import com.markit.ms.rfa.bean.SleeveEntityRequest;
import com.markit.ms.rfa.dto.RfaUploadTemplateSearchRequest;

/**
 * @author sucheta.krishali
 *
 */
public interface IRfaUploadTemplateDAO
{
	RFAUploadTemplate saveUploadTemplate(RFAUploadTemplate masterlistTemplate);
	
	RFAUploadTemplate getUploadTemplateById(Long id);  
	
	Long getCountUploadTemplateByName(String uploadTemplateName,Long companyId);
	
	List<RFAUploadTemplateField> getTemplateFieldsByUploadTemplateId(Long uploadTemplateId);  
	Integer deleteUploadTemplateById(Long id);

	RFAUploadTemplate editUploadTemplate(RFAUploadTemplate uploadTemplate) ;

	Long getCountUploadTemplateById(Long templateId,Long companyId) ;

	List<RFAUploadTemplate> getUploadTemplateGrid(Long companyId, RfaUploadTemplateSearchRequest templateSearchRequest);
	List<RfaUploadTemplateDownload> getUploadTemplateColumns(Long templateId);
	RFAUploadTemplateFile getUploadedFileId(Long bulkRequestId);
	Long getSleeveEntity(String Name,Long companyId);

	void linkSleeveAndParent(Long parentEntityId, Long sleeveEntityId, Long companyId);
	SleeveEntityRequest getParentEntityRecord(Long parentEntityId,Long companyId);
	MCPMClientIdentifier getEntityBySleeveIdentifier(String sleeveClientIdentifier,Long companyId) ;
	public Long getParentEntityId(Long entityId,Long companyId);
	public Long getSleeveParentEntityId(Long sleeveEntityId,Long companyId);

	public List<Long> getListSleeveEntities(Long entityId,Long companyId);


}
