package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.dto.TemplateSearchRequest;

public interface IExhibitTemplateDAO
{
	ExhibitTemplate saveExhibitTemplate(ExhibitTemplate exhibitTemplate);

	ExhibitTemplate updateExhibitTemplate(ExhibitTemplate exhibitTemplate);

	ExhibitTemplate deleteExhibitTemplate(Long id, Long companyid);

	List<ExhibitTemplate> getAllExhibitTemplatesByCompanyId(Long companyId);

	List<ExhibitTemplate> getExhibitTemplateGrid(Long companyId, TemplateSearchRequest exhibitTemplateSearchRequest);

	Long getExhibitTemplateGridTotalCount(Long companyId, TemplateSearchRequest exhibitTemplateSearchRequest);

	ExhibitTemplate getExhibitTemplateById(Long id, Long deleted, Long companyid);

	Long getExhibitTemplateByName(Long companyId, String name);
	
	void linkMasterlistToExhibitTemplate(Long exhibitTemplateId, Long masterAgreementId, Long companyId, Long userId);

	Integer validateExhibitTemplateColumns(ExhibitTemplate exhibitTemplate, Long userID);

	Integer mergeExistingColumn(String columnName, int columnIndex,	Long exhibitTemplateId, Long userId);

	ExhibitTemplate getExhibitTemplateByMasterAgreementId(Long id, Long deleted, Long companyid);
}
