package com.markit.ms.rfa.bean.enumeration;

@Deprecated
public enum MyStatusReviewDetail {

	DESK_ONE("BS - Desk1"),
	DESK_TWO("BS - Desk2");
	

	private String description;
	
	private MyStatusReviewDetail(String role) {
		this.description = role;
	}

	public String getDescription() {
		return description;
	}
	
}
