package com.markit.ms.rfa.controller.filter;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.dao.IMasterlistTemplateFilterDAO;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

/**
 * @author prashant.aggarwal
 *
 */
@RestController
@RequestMapping(value = "/v1/masterlist_template_filter")
@Api(value = "masterlist_template_filter" , description = "Masterlist Template Filter APIs")
public class MasterlistTemplateFilterController {

	@Autowired
	IMasterlistTemplateFilterDAO masterlistTemplateFilterDAO;

	@RequestMapping(value = "template_name", method = RequestMethod.GET)
	@ApiOperation(value = "Masterlist Template Name Filter")
	public CommonBaseResponse<List<Lookup>> mlTemplateLookUp(@RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = masterlistTemplateFilterDAO.mlTemplateLookUp(companyId, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}

}