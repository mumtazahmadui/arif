package com.markit.ms.rfa.dto;

import java.util.List;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseSearchRequest;
/**
 * @author sucheta.krishali
 *
 */
public class RfaUploadFileSearchRequest extends CommonBaseSearchRequest{

	private List<Lookup> uploadBy;
	private List<Lookup> processingStatus;
	
	
	public List<Lookup> getUploadBy() {
		return uploadBy;
	}
	public void setUploadBy(List<Lookup> uploadBy) {
		this.uploadBy = uploadBy;
	}
	public List<Lookup> getProcessingStatus() {
		return processingStatus;
	}
	public void setProcessingStatus(List<Lookup> processingStatus) {
		this.processingStatus = processingStatus;
	}


	




}
