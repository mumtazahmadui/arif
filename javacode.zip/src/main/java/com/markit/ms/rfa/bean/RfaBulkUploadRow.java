package com.markit.ms.rfa.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.marketxs.util.HashMap;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.rfabulkupload.util.ErrorGenerator;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

/**
 * @author prashant.aggarwal
 *
 */
public class RfaBulkUploadRow {

	private MasterAgreement masterAgreement;
	private Long masterAgreementId;
	private String mlIdentifier;
	private String investmentManager;
	private BulkUploadAction action;
	private Set<BulkUploadAction> requestIdentified;
	private String agreementType;
	private String agreementDate;
	private String partyATrueLegalName;
	private Long partyBEntityId;
	private String partyBClientIdentifier;
	private String partyBTrueLegalName;
	private String partyBLEI;
	private String sleeveClientIdentifier;
	private String sleeveTrueLegalName;
	private Long sleeveEntityId;
	private boolean isAgreementDateFormatted;
	private boolean hasFundNameChange;
	private RFAUploadTemplate rfaUploadTemplate;
	private ExhibitTemplate exhibitTemplate;
	private Map<String, String> exhibitData;
	private boolean isExhibitFullyValued;
	private Set<String> errors = new LinkedHashSet<String>();
	private Date agreementDateFormatted;
	private Long uploadTemplateId;
	private Map<BulkUploadAction, LetterTemplate> letterTemplate;
	private Boolean partyBExistsInAnotherRfa;
	private int rowNum;

	private static final Logger logger = LoggerFactory.getLogger(RfaBulkUploadRow.class.getName());

	public Boolean getPartyBExistsInAnotherRfa() {
		return partyBExistsInAnotherRfa;
	}

	public void setPartyBExistsInAnotherRfa(Boolean partyBExistsInAnotherRfa) {
		this.partyBExistsInAnotherRfa = partyBExistsInAnotherRfa;
	}

	public Map<BulkUploadAction, LetterTemplate> getLetterTemplate() {
		return letterTemplate;
	}

	public void setLetterTemplate(Map<BulkUploadAction, LetterTemplate> letterTemplate) {
		this.letterTemplate = letterTemplate;
	}

	public Long getUploadTemplateId() {
		return uploadTemplateId;
	}

	public void setUploadTemplateId(Long uploadTemplateId) {
		this.uploadTemplateId = uploadTemplateId;
	}

	public Long getMasterAgreementId() {
		return masterAgreementId;
	}

	public void setMasterAgreementId(Long masterAgreementId) {
		this.masterAgreementId = masterAgreementId;
	}

	public MasterAgreement getMasterAgreement() {
		return masterAgreement;
	}

	public void setMasterAgreement(MasterAgreement masterAgreement) {
		this.masterAgreement = masterAgreement;
	}

	public String getMlIdentifier() {
		return mlIdentifier;
	}

	public void setMlIdentifier(String mlIdentifier) {
		this.mlIdentifier = mlIdentifier;
	}

	public String getInvestmentManager() {
		return investmentManager;
	}

	public void setInvestmentManager(String investmentManager) {
		this.investmentManager = investmentManager;
	}

	public BulkUploadAction getAction() {
		return action;
	}

	public void setAction(BulkUploadAction action) {
		this.action = action;
	}

	public Set<BulkUploadAction> getRequestIdentified() {
		if (requestIdentified == null)
			requestIdentified = new HashSet<BulkUploadAction>();

		return requestIdentified;
	}

	public void setRequestIdentified(Set<BulkUploadAction> requestIdentifiedN) {
		this.requestIdentified = requestIdentifiedN;
	}

	public String getAgreementType() {
		return agreementType;
	}

	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}

	public String getAgreementDate() {
		return agreementDate;
	}

	public void setAgreementDate(String agreementDate) {
		this.agreementDate = agreementDate;
	}

	public String getPartyATrueLegalName() {
		return partyATrueLegalName;
	}

	public void setPartyATrueLegalName(String partyATrueLegalName) {
		this.partyATrueLegalName = partyATrueLegalName;
	}

	public String getPartyBClientIdentifier() {
		return partyBClientIdentifier;
	}

	public void setPartyBClientIdentifier(String partyBClientIdentifier) {
		this.partyBClientIdentifier = partyBClientIdentifier;
	}

	public String getPartyBTrueLegalName() {
		return partyBTrueLegalName;
	}

	public void setPartyBTrueLegalName(String partyBTrueLegalName) {
		this.partyBTrueLegalName = partyBTrueLegalName;
	}

	public Long getPartyBEntityId() {
		return partyBEntityId;
	}

	public void setPartyBEntityId(Long partyBEntityId) {
		this.partyBEntityId = partyBEntityId;
	}

	public String getPartyBLEI() {
		return partyBLEI;
	}

	public void setPartyBLEI(String partyBLEI) {
		this.partyBLEI = partyBLEI;
	}

	public String getSleeveClientIdentifier() {
		return sleeveClientIdentifier;
	}

	public void setSleeveClientIdentifier(String sleeveClientIdentifier) {
		this.sleeveClientIdentifier = sleeveClientIdentifier;
	}

	public String getSleeveTrueLegalName() {
		return sleeveTrueLegalName;
	}

	public void setSleeveTrueLegalName(String sleeveTrueLegalName) {
		this.sleeveTrueLegalName = sleeveTrueLegalName;
	}

	public Map<String, String> getExhibitData() {
		return exhibitData;
	}

	public void setExhibitData(Map<String, String> exhibitData) {
		this.exhibitData = exhibitData;
	}

	public Set<String> getErrors() {
		return errors;
	}

	public void setErrors(Set<String> errors) {
		this.errors = errors;
	}

	public Long getSleeveEntityId() {
		return sleeveEntityId;
	}

	public void setSleeveEntityId(Long sleeveEntityId) {
		this.sleeveEntityId = sleeveEntityId;
	}

	public RFAUploadTemplate getRfaUploadTemplate() {
		return rfaUploadTemplate;
	}

	public void setRfaUploadTemplate(RFAUploadTemplate rfaUploadTemplate) {
		this.rfaUploadTemplate = rfaUploadTemplate;
	}

	public Date getAgreementDateFormatted() {
		return agreementDateFormatted;
	}

	public void setAgreementDateFormatted(Date agreementDateFormatted) {
		this.agreementDateFormatted = agreementDateFormatted;
	}

	public boolean isExhibitFullyValued() {
		return isExhibitFullyValued;
	}

	public ExhibitTemplate getExhibitTemplate() {
		return exhibitTemplate;
	}

	public void setExhibitTemplate(ExhibitTemplate exhibitTemplate) {
		this.exhibitTemplate = exhibitTemplate;
	}

	public boolean isAgreementDateFormatted() {
		return isAgreementDateFormatted;
	}

	public void setAgreementDateFormatted(boolean isAgreementDateFormatted) {
		this.isAgreementDateFormatted = isAgreementDateFormatted;
	}

	public boolean hasFundNameChange() {
		return hasFundNameChange;
	}

	public void setHasFundNameChange(boolean hasFundNameChange) {
		this.hasFundNameChange = hasFundNameChange;
	}

	public void addError(String error, Map<String, String> placeHolderMap) {
		errors.add(ErrorGenerator.generate(error, placeHolderMap));
	}

	public void addError(String error) {
		errors.add(ErrorGenerator.generate(error, null));
	}

	/**
	 * 
	 * This method will validate that all mandatory fields are present and add
	 * errors to this object's internal error list based on which are not.
	 * 
	 * @return Returns a boolean. Return value will be true if all valid fields are
	 *         present a valued with something more than whitespace. Otherwise, this
	 *         method will return false.
	 * 
	 * @author joseph.howe
	 */
	public boolean validateMandatoryFields() {
		logger.info("Validating mandatory fields on RFA Upload Row...");

		boolean isValid = true;
		Map<String, String> rowData = createMapOfRowValues();

		for (RFAUploadTemplateField field : rfaUploadTemplate.getTemplateFields()) {

			String fieldValue = rowData.get(field.getFieldIdentifier());

			if (field.getEntityIdentifier() == 1
					&& field.getFieldIdentifier().equalsIgnoreCase(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD)
					&& (fieldValue == null || fieldValue.trim().equalsIgnoreCase(""))) {
				errors.add(RFAConstants.NO_INPUT_PROVIDED
						+ rfaUploadTemplate.getFieldLabel(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD));
				isValid = false;
			} else if (field.getEntityIdentifier() == 1
					&& field.getFieldIdentifier().equalsIgnoreCase(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD)
					&& (fieldValue == null || fieldValue.trim().equalsIgnoreCase(""))) {
				errors.add(RFAConstants.NO_INPUT_PROVIDED
						+ rfaUploadTemplate.getFieldLabel(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD));
				isValid = false;
			} else if (field.getEntityIdentifier() == 1
					&& field.getFieldIdentifier().equalsIgnoreCase(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD)
					&& (sleeveTrueLegalName == null
							|| (sleeveTrueLegalName != null && sleeveTrueLegalName.trim().equalsIgnoreCase("")))
					&& (sleeveClientIdentifier != null && !sleeveClientIdentifier.trim().equalsIgnoreCase(""))) {
				errors.add(RFAConstants.NO_INPUT_PROVIDED
						+ rfaUploadTemplate.getFieldLabel(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD));
				isValid = false;
			} else if (field.getEntityIdentifier() == 1
					&& field.getFieldIdentifier().equalsIgnoreCase(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD)
					&& (sleeveClientIdentifier == null
							|| (sleeveClientIdentifier != null && sleeveClientIdentifier.trim().equalsIgnoreCase("")))
					&& (sleeveTrueLegalName != null && !sleeveTrueLegalName.trim().equalsIgnoreCase(""))) {
				errors.add(RFAConstants.NO_INPUT_PROVIDED
						+ rfaUploadTemplate.getFieldLabel(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD));
				isValid = false;
			} else if (field.getEntityIdentifier() != 1 && field.getIsRequired() == 1
					&& !field.getRule().equalsIgnoreCase(RFAConstants.REF_TABLE)
					&& ((fieldValue != null && fieldValue.trim().equals("")) || fieldValue == null)) {
				errors.add(RFAConstants.NO_INPUT_PROVIDED + field.getFieldLabel());
				isValid = false;
			}

		}

		return isValid;
	}

	private Map<String, String> createMapOfRowValues() {
		Map<String, String> rowValueMap = new HashMap();
		rowValueMap.put(RFAConstants.REF_MASTER_AGREEMENT_DATE, agreementDate);
		rowValueMap.put(RFAConstants.AGREEMENT_TYPE, agreementType);
		rowValueMap.put(RFAConstants.PARTYA_TRUE_LEGAL_NAME_FIELD, partyATrueLegalName);
		rowValueMap.put(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD, partyBClientIdentifier);
		rowValueMap.put(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD, partyBTrueLegalName);
		rowValueMap.put(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD, sleeveTrueLegalName);
		rowValueMap.put(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD, sleeveClientIdentifier);
		rowValueMap.put(RFAConstants.INVESTMENT_MANAGER, investmentManager);
		rowValueMap.put(RFAConstants.MASTERLIST_IDENTIFIER, mlIdentifier);
		if (action != null)
			rowValueMap.put(RFAConstants.ACTION, action.getType());

		return rowValueMap;
	}

	/**
	 * 
	 * This method will validate the Reference Master Agreement Date provided for
	 * this row matches the date format specified in the RFA Bulk Upload Template.
	 * 
	 * @return Returns a boolean. Return value will be true if date can be parsed
	 *         successfully.
	 * 
	 * @author joseph.howe
	 */
	public boolean validateDateFormat() {
		logger.info("Validating date format on RFA Upload Row...");

		boolean isValid = true;
		SimpleDateFormat formatter;
		String formatRule = RFAConstants.RFA_BULK_UPLOAD_DEFAULT_DATE_FORMAT; // default formatting

		try {
			// If the excel column was already formatted as a date...
			if (isAgreementDateFormatted) {
				formatter = new SimpleDateFormat(formatRule);
				Date formattedDate = formatter.parse(agreementDate);
				if (formattedDate == null) {
					errors.add(RFAConstants.DATE_FORMATTING_ERROR + RFAConstants.RFA_BULK_UPLOAD_DEFAULT_DATE_FORMAT);
					isValid = false;
				} else {
					agreementDateFormatted = formattedDate;
				}
			} else {

				boolean isRegexPassed = false;
				String unsplitFormatRule = rfaUploadTemplate.getRule(RFAConstants.REF_MASTER_AGREEMENT_DATE);
				String[] splitRule = unsplitFormatRule.split("=");
				formatRule = splitRule[1].trim();

				if (formatRule.equals("MM/dd/yyyy") || formatRule.equals("dd/MM/yyyy"))
					isRegexPassed = checkRegexForDateDDMMYYYY(agreementDate);
				else if (formatRule.equals("MM/dd/yy") || formatRule.equals("dd/MM/yy"))
					isRegexPassed = checkRegexForDateDDMMYY(agreementDate);
				else if (formatRule.equals("dd-MMM-yyyy"))
					isRegexPassed = checkRegexForDateDDMMMYYYY(agreementDate);
				else if (formatRule.equals("MMM-dd-yyyy"))
					isRegexPassed = checkRegexForDateMMMDDYYYY(agreementDate);
				if (isRegexPassed) {
					formatter = new SimpleDateFormat(formatRule);
					formatter.setLenient(false);
					Date formattedDate = formatter.parse(agreementDate);
					if (formattedDate == null) {
						errors.add(RFAConstants.DATE_FORMATTING_ERROR + formatRule);
						isValid = false;
					} else {
						agreementDateFormatted = formattedDate;
					}
				} else {
					errors.add(RFAConstants.DATE_FORMATTING_ERROR + formatRule);
					isValid = false;
				}

			}
		} catch (ParseException e) {
			e.printStackTrace();
			errors.add(RFAConstants.DATE_FORMATTING_ERROR + formatRule);
			isValid = false;
		}

		return isValid;
	}

	boolean checkRegexForDateDDMMYYYY(String date) {
		String regex = "^\\d{2}/\\d{2}/\\d{4}$";
		Pattern p = Pattern.compile(regex);

		return p.matcher(date).matches();

	}

	boolean checkRegexForDateDDMMYY(String date) {
		String regex = "^\\d{2}/\\d{2}/\\d{2}$";
		Pattern p = Pattern.compile(regex);

		return p.matcher(date).matches();

	}

	boolean checkRegexForDateDDMMMYYYY(String date) {
		String regex = "^\\d{2}-\\D{3}-\\d{4}$";
		Pattern p = Pattern.compile(regex);

		return p.matcher(date).matches();

	}

	boolean checkRegexForDateMMMDDYYYY(String date) {
		String regex = "^\\D{3}-\\d{2}-\\d{4}$";
		Pattern p = Pattern.compile(regex);

		return p.matcher(date).matches();

	}

	/**
	 * 
	 * This method will validate the exhibit columns provided for this row match
	 * those in the Masterlist.
	 * 
	 * <p>
	 * This method also sets the property isExhibitFullyValued to verify if this row
	 * has been valued for every exhibit column present in the Masterlist or has
	 * exhibit values pending.
	 * 
	 * @return Returns a boolean. Return value will be true unless a value is
	 *         provided for a column which is not in this Masterlist.
	 * 
	 * @author joseph.howe
	 */
	public boolean validateExhibitColumns() {
		logger.info("Validating exhibit columns on RFA Upload Row...");

		boolean isValid = true;

		if (null != exhibitTemplate) {

			List<ExhibitTemplateColumn> exhibitTemplateCols = exhibitTemplate.getColumns();
			String columnValue = "";
			isExhibitFullyValued = true;

			if (CommonUtil.isNull(exhibitData)) {
				return true;
			}

			Map<String, String> exhibits = new HashMap();

			// validateTemplateHasColumn
			for (String columnName : exhibitData.keySet()) {
				columnValue = exhibitData.get(columnName);
				for (ExhibitTemplateColumn templateColumn : exhibitTemplateCols) {
					if (templateColumn.getColumnName().equalsIgnoreCase(columnName)
							|| templateColumn.getColumnName()
									.equalsIgnoreCase(getUploadTemplateField(columnName).getFieldLabel())
							|| templateColumn.getColumnName()
									.equalsIgnoreCase(getUploadTemplateField(columnName).getAliasLabel())) {
						exhibits.put(columnName, columnValue);
						break;
					}
				}
			}

			// to keep those columns which are present in exhibit template, if not then keep
			// alias column
			for (String columnName : exhibitData.keySet()) {
				for (ExhibitTemplateColumn templateColumn : exhibitTemplateCols) {
					if (templateColumn.getColumnName()
							.equalsIgnoreCase(getUploadTemplateField(columnName).getAliasLabel())) {
						if (CommonUtil.isNotNull(exhibits.get(getUploadTemplateField(columnName).getAliasLabel()))) {
							exhibits.remove(getUploadTemplateField(columnName).getFieldLabel());
						}
					} else if (templateColumn.getColumnName()
							.equalsIgnoreCase(getUploadTemplateField(columnName).getFieldLabel())) {
						if (CommonUtil.isNotNull(exhibits.get(getUploadTemplateField(columnName).getFieldLabel()))) {
							exhibits.remove(getUploadTemplateField(columnName).getAliasLabel());
						}
					}
				}
			}

			if (!(exhibitTemplateCols.size() - 3 == exhibits.size())) {
				isExhibitFullyValued = false;
			}

			// to match name of exhibits as per exhibit template cols
			String colValue = null;
			for (ExhibitTemplateColumn templateColumn : exhibitTemplateCols) {
				if (CommonUtil.isNotNull(exhibits.get(templateColumn.getColumnName()))) {
					continue;
				} else {
					if (CommonUtil.isNotNull(getUploadTemplateField(templateColumn.getColumnName()))
							&& CommonUtil.isNotNull(exhibits
									.get(getUploadTemplateField(templateColumn.getColumnName()).getAliasLabel()))) {
						colValue = exhibits.get(getUploadTemplateField(templateColumn.getColumnName()).getAliasLabel());
						exhibits.remove(getUploadTemplateField(templateColumn.getColumnName()).getAliasLabel());
						exhibits.put(templateColumn.getColumnName(), colValue);
					} else if (CommonUtil.isNotNull(getUploadTemplateField(templateColumn.getColumnName()))
							&& CommonUtil.isNotNull(exhibits
									.get(getUploadTemplateField(templateColumn.getColumnName()).getFieldLabel()))) {
						colValue = exhibits.get(getUploadTemplateField(templateColumn.getColumnName()).getFieldLabel());
						exhibits.remove(getUploadTemplateField(templateColumn.getColumnName()).getFieldLabel());
						exhibits.put(templateColumn.getColumnName(), colValue);
					}
				}
			}

			this.exhibitData = exhibits;
		}
		return isValid;

	}

	public boolean checkPlaceholder(BulkUploadAction requestIdentified, LetterTemplate letterTemplate,
			String errorMessage) {
		logger.info("Checking placeholder is present for identified request on RFA Upload Row...");
		AmendmentLetter amendmentLetter = new AmendmentLetter();

		if (CommonUtil.isNull(letterTemplate)) {
			return false;
		}

		if (letterTemplate.getContent() != null) {
			amendmentLetter.setContent(letterTemplate.getContent());
		} else
			errors.add(RFAConstants.NO_CONTENT_IN_LETTER_TEMPLATE);

		boolean hasPlaceholder = requestIdentified.checkPlaceholders(amendmentLetter);

		if (!hasPlaceholder) {
			errors.add(errorMessage);
		}

		return hasPlaceholder;
	}

	public void validateAgreementType() {
		if (null != agreementType) {
			if (agreementType.equals(RFAConstants.CAA) || agreementType.equals(RFAConstants.ACA)) {
				errors.add(RFAConstants.AGRREEMENT_TYPE_ERROR);
			}

		}
	}

	public RFAUploadTemplateField getPartyBIdentifierField() {
		if (isEntityIdentifier(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD)) {
			return getUploadTemplateField(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD);
		} else if (isEntityIdentifier(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD)) {
			return getUploadTemplateField(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD);
		}
		return null;
	}

	public RFAUploadTemplateField getSleeveIdentifierField() {
		if (isEntityIdentifier(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD)) {
			return getUploadTemplateField(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD);
		} else if (isEntityIdentifier(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD)) {
			return getUploadTemplateField(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD);
		}
		return null;
	}

	public boolean isEntityIdentifier(String fieldName) {

		if (CommonUtil.isNotNull(this.getUploadTemplateField(fieldName))
				&& this.getUploadTemplateField(fieldName).getEntityIdentifier() == 1) {
			return true;
		}

		return false;
	}

	public RFAUploadTemplateField getUploadTemplateField(String field) {
		for (RFAUploadTemplateField currentField : rfaUploadTemplate.getTemplateFields()) {
			if (currentField.getFieldIdentifier().equalsIgnoreCase(field)
					|| currentField.getFieldLabel().equalsIgnoreCase(field)
					|| (CommonUtil.isNotNull(currentField.getAliasLabel())
							&& currentField.getAliasLabel().equalsIgnoreCase(field)))
				return currentField;
		}
		return null;
	}

	public int getRowNum() {
		return rowNum;
	}

	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}

	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		RfaBulkUploadRow other = (RfaBulkUploadRow) obj;
		if (CommonUtil.isNotNull(this.masterAgreementId) && this.masterAgreementId.equals(other.masterAgreementId)
				&& CommonUtil.isNotNull(this.mlIdentifier) && this.mlIdentifier.equals(other.mlIdentifier)
				&& CommonUtil.isNotNull(this.agreementType) && this.agreementType.equals(other.agreementType)
				&& CommonUtil.isNotNull(this.agreementDate) && this.agreementDate.equals(other.agreementDate)
				&& CommonUtil.isNotNull(this.partyATrueLegalName)
				&& this.partyATrueLegalName.equals(other.partyATrueLegalName)
				&& this.requestIdentified.equals(other.requestIdentified) && CommonUtil.isNotNull(this.partyBEntityId)
				&& this.partyBEntityId.equals(other.partyBEntityId)
				&& ((CommonUtil.isNull(this.sleeveEntityId) && (CommonUtil.isNull(other.sleeveEntityId)))
						|| (CommonUtil.isNotNull(this.sleeveEntityId) && CommonUtil.isNotNull(other.sleeveEntityId)
								&& this.sleeveEntityId.equals(other.sleeveEntityId)))
				&& ((CommonUtil.isNull(this.sleeveClientIdentifier)
						&& (CommonUtil.isNull(other.sleeveClientIdentifier)))
						|| (CommonUtil.isNotNull(this.sleeveClientIdentifier)
								&& CommonUtil.isNotNull(other.sleeveClientIdentifier)
								&& this.sleeveClientIdentifier.equals(other.sleeveClientIdentifier)))
				&& ((CommonUtil.isNull(this.sleeveTrueLegalName) && (CommonUtil.isNull(other.sleeveTrueLegalName)))
						|| (CommonUtil.isNotNull(this.sleeveTrueLegalName)
								&& CommonUtil.isNotNull(other.sleeveTrueLegalName)
								&& this.sleeveTrueLegalName.equals(other.sleeveTrueLegalName)))) {
			return true;
		}

		return false;
	}
}
