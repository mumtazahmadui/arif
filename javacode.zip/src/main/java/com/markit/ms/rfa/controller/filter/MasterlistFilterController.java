package com.markit.ms.rfa.controller.filter;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.service.IMasterlistFilterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "v1/company")
@Api(value="MasterlistFilter", description= "Masterlist Filter APIs")
public class MasterlistFilterController {
	 //TODO-Sajil The null check for filterString should be moved to an intercepter 
	@Autowired
	private IMasterlistFilterService masterlistFilterService;
	
	@RequestMapping(value = "{id}/master_list_filter/agreement_date", method = RequestMethod.GET)
	@ApiOperation(value = "Masterlist Agreement Date Filter")
	public CommonBaseResponse<List<String>> agreementDateLookup(@PathVariable Long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = masterlistFilterService.agreementDateLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/master_list_filter/investment_manager", method = RequestMethod.GET)
	@ApiOperation(value = "Masterlist Investment Manager Filter")
	public CommonBaseResponse<List<Lookup>> investmentManagerLookup(@PathVariable Long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = masterlistFilterService.investmentManagerLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/master_list_filter/party_a", method = RequestMethod.GET)
	@ApiOperation(value = "Masterlist PartyA Filter")
	public CommonBaseResponse<List<Lookup>> partyALookup(@PathVariable Long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = masterlistFilterService.partyALookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/master_list_filter/masterlist_identifier", method = RequestMethod.GET)
	@ApiOperation(value = "Masterlist Identifier Filter")
	public CommonBaseResponse<List<String>> masterlistIdentifierLookup(@PathVariable Long id, @RequestParam(required=false) String filterString, HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = masterlistFilterService.masterlistIdentifierLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/master_list_filter/agreement_types", method = RequestMethod.GET)
	@ApiOperation(value = "Masterlist Agreement Type Filter")
	public CommonBaseResponse<List<Lookup>>  agreementTypeLookUp(@PathVariable Long id, @RequestParam(required=false) String filterString){

		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = masterlistFilterService.agreementTypeLookup(filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;	
	}
}
