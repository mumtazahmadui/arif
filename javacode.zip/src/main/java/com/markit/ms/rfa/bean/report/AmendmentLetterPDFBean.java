package com.markit.ms.rfa.bean.report;

public class AmendmentLetterPDFBean {
private byte[] amendmentLetterContent;
private byte[] exhibitTextContent;
private byte[] exhibitHTMLContent;
private int noOfColumns;
private Long imSignatureID;
public byte[] getAmendmentLetterContent() {
	return amendmentLetterContent;
}
public void setAmendmentLetterContent(byte[] amendmentLetterContent) {
	this.amendmentLetterContent = amendmentLetterContent;
}
public byte[] getExhibitTextContent() {
	return exhibitTextContent;
}
public void setExhibitTextContent(byte[] exhibitTextContent) {
	this.exhibitTextContent = exhibitTextContent;
}
public byte[] getExhibitHTMLContent() {
	return exhibitHTMLContent;
}
public void setExhibitHTMLContent(byte[] exhibitHTMLContent) {
	this.exhibitHTMLContent = exhibitHTMLContent;
}
public int getNoOfColumns() {
	return noOfColumns;
}
public void setNoOfColumns(int noOfColumns) {
	this.noOfColumns = noOfColumns;
}
public Long getImSignatureID() {
	return imSignatureID;
}
public void setImSignatureID(Long imSignatureID) {
	this.imSignatureID = imSignatureID;
}

}
