package com.markit.ms.rfa.bean.enumeration;

public enum RfaUploadTemplateRulesEnum {

	AGREEMENT_TYPE("UT_AGREEMENT_TYPE"),
	REF_MASTER_AGREEMENT_DATE("UT_REF_MASTER_AGREEMENT_DATE"),
	DEALER("UT_DEALER"),
	INVESTMENT_MANAGER("UT_INVESTMENT_MANAGER"),
	MASTERLIST_IDENTIFIER("UT_MASTERLIST_IDENTIFIER"),
	ACTIONS("UT_ACTIONS"),
	PARTY_B_CLIENT_IDENTIFIER("UT_PARTY_B_CLIENT_IDENTIFIER"),
	PARTYB_TRUE_LEGAL_NAME("UT_PARTYB_TRUE_LEGAL_NAME"),
	PARTYB_LEI("UT_PARTYB_LEI"),
	SLEEVE_TRUE_LEGAL_NAME("UT_SLEEVE_TRUE_LEGAL_NAME"),
	SLEEVE_CLIENT_IDENTIFIER("UT_SLEEVE_CLIENT_IDENTIFIER"),
	SLEEVE_LEI("UT_SLEEVE_LEI");


	private String name;
	
	private RfaUploadTemplateRulesEnum(String name){
		this.name = name;
	}
	
	public String getName(){
        return this.name;
    }
	
	public static RfaUploadTemplateRulesEnum fromString(String str){
		if (null == str){
			return null;
		}
		for (RfaUploadTemplateRulesEnum action : RfaUploadTemplateRulesEnum.values()){
			if (action.name.equalsIgnoreCase(str)) return action;
		}
		return null;
	}
}
