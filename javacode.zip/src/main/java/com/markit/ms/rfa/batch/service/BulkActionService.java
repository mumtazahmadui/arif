package com.markit.ms.rfa.batch.service;

import com.markit.ms.rfa.bean.BulkActionBean;

public abstract class BulkActionService {

	public final void preProcessing() {
		// TODO: If required in future requirements,
		// make an entry in the DB depicting that the action is started
	}

	public abstract void processBulkAction(BulkActionBean bulkActionBean) throws Exception;

	public final void postProcessing() {
		// TODO: If required in future requirement,
		// make an entry in the DB depicting that the action is completed
	}
}
