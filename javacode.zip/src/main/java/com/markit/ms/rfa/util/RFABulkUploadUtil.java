/*
 * 
 * Author: Neeraj Kumar Nirala
 * 
 * This class has utility functions to process conversion to Object from Upload RFA Template file.
 * 
 */
package com.markit.ms.rfa.util;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.bean.RFAUploadTemplateFile;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;

public class RFABulkUploadUtil {

	public static List<RfaBulkUploadRow> readXLSXFile(byte[] fileBytes,
			LinkedHashMap<String, RFAUploadTemplateField> identifierLabelMap,
			RFAUploadTemplateFile rfaUploadTemplateFile, RFAUploadTemplate rfaUploadTemplate,
			List<String> errorMessage) {

		List<RfaBulkUploadRow> listOfData = new ArrayList<>();
		boolean isFirstRow = true;
		LinkedHashMap<Integer, String> columnDataValues = new LinkedHashMap<Integer, String>();
		try {
			InputStream inputStream = new ByteArrayInputStream(fileBytes);
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();
			
			int rowEnd = getLastRowNum((XSSFSheet) datatypeSheet);
			int rowNum = 0;

			while (iterator.hasNext() && rowEnd-- >= 0) {
				Row currentRow = iterator.next();
					while (!(rowNum == currentRow.getRowNum())) {
						RfaBulkUploadRow data = new RfaBulkUploadRow();
						data.setRowNum(++rowNum);
						data.setUploadTemplateId(rfaUploadTemplateFile.getUploadTemplateId());
						data.setRfaUploadTemplate(rfaUploadTemplate);
						listOfData.add(data);
				}
				Iterator<Cell> cellIterator = currentRow.iterator();
				int index = 0;
				RfaBulkUploadRow data = new RfaBulkUploadRow();
				data.setRowNum(++rowNum);
				
				if (!isFirstRow) {
					data.setUploadTemplateId(rfaUploadTemplateFile.getUploadTemplateId());
					data.setRfaUploadTemplate(rfaUploadTemplate);
				}
				
				while (cellIterator.hasNext()) {
					Cell currentCell = cellIterator.next();

					if (isFirstRow) {
						for (Map.Entry<String, RFAUploadTemplateField> e : identifierLabelMap.entrySet()) {
							if (getCellValueAsString(currentCell).equalsIgnoreCase((e.getValue().getFieldLabel()))) {
								columnDataValues.put(index, e.getKey());
							} else if ((e.getValue().getAliasLabel() != null) && (getCellValueAsString(currentCell)
									.equalsIgnoreCase((e.getValue().getAliasLabel())))) {
								columnDataValues.put(index, e.getValue().getAliasLabel());
							}
						}

						index++;
					}

					if (!isFirstRow) {
						String label = columnDataValues.get(currentCell.getColumnIndex());
						data.setUploadTemplateId(rfaUploadTemplateFile.getUploadTemplateId());
						data.setRfaUploadTemplate(rfaUploadTemplate);
						String value = getCellValueAsString(currentCell);
						if (null != label && CommonUtil.isNotNull(value) && !value.isEmpty()) {
							switch (label) {
							case RFAConstants.AGREEMENT_TYPE:
								data.setAgreementType(value);
								break;
							case RFAConstants.REF_MASTER_AGREEMENT_DATE:
								if (currentCell.getCellType() == Cell.CELL_TYPE_NUMERIC
										&& DateUtil.isCellDateFormatted(currentCell)) {
									data.setAgreementDateFormatted(true);
								} else {
									data.setAgreementDateFormatted(false);
								}
								data.setAgreementDate(value);
								break;
							case RFAConstants.MASTERLIST_IDENTIFIER:
								data.setMlIdentifier(value);
								break;
							case RFAConstants.PARTYA_TRUE_LEGAL_NAME_FIELD:
								data.setPartyATrueLegalName(value);
								break;
							case RFAConstants.PARTYB_ACTION: {
								String actionRule = rfaUploadTemplate.getRule(RFAConstants.PARTYB_ACTION);
								if (BulkUploadAction.fromType(actionRule).equals(BulkUploadAction.BLANK))
									data.setAction(BulkUploadAction.fromType(value));
								break;
							}
							case RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD:
								data.setPartyBClientIdentifier(value);
								break;
							case RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD:
								data.setPartyBTrueLegalName(value);
								break;
							case RFAConstants.INVESTMENT_MANAGER:
								data.setInvestmentManager(value);
								break;
							case RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD:
								data.setSleeveTrueLegalName(value);
								break;
							case RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD:
								data.setSleeveClientIdentifier(value);
								break;
							case RFAConstants.PARTY_B_LEI:
								data.setPartyBLEI(value);
								break;
							default:
								Map<String, String> exhibitData;
								if (data.getExhibitData() == null) {
									exhibitData = new HashMap<String, String>();
									exhibitData.put(data.getRfaUploadTemplate().getFieldLabel(label), value);
									data.setExhibitData(exhibitData);
								} else
									data.getExhibitData().put(data.getRfaUploadTemplate().getFieldLabel(label), value);
								break;
							}
						}
					}

				}
				if (!isFirstRow)
					listOfData.add(data);
				else {
					isFirstRow = false;
					if (!checkMandatoryFieldIndentifier(columnDataValues, identifierLabelMap, rfaUploadTemplateFile,
							errorMessage))
						return null;
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return listOfData;
	}

	private static boolean checkMandatoryFieldIndentifier(LinkedHashMap<Integer, String> columnDataValues,
			LinkedHashMap<String, RFAUploadTemplateField> identifierLabelMap,
			RFAUploadTemplateFile rfaUploadTemplateFile, List<String> errorMessage) {

		List<String> listOfLabelsInFile = new ArrayList<>();

		for (Map.Entry<Integer, String> e : columnDataValues.entrySet()) {
			listOfLabelsInFile.add(e.getValue());
		}
		for (Map.Entry<String, RFAUploadTemplateField> e : identifierLabelMap.entrySet()) {
			if (e.getValue().getIsRequired() == 1) {
				if (!listOfLabelsInFile.contains(e.getKey())) {
					errorMessage.add(RFAConstants.MANDATORY_COLUMN + e.getValue().getFieldLabel() + RFAConstants.NOT_PRESENT);
				}
			}
		}
		if (errorMessage.isEmpty())
			return true;
		else {
			return false;
		}
	}

	public static String getCellValueAsString(Cell cell) {
		String strCellValue = null;
		if (cell != null) {
			switch (cell.getCellType()) {
			case Cell.CELL_TYPE_STRING:
				strCellValue = cell.toString();
				break;
			case Cell.CELL_TYPE_NUMERIC:
				if (DateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat dateFormat = new SimpleDateFormat(
							RFAConstants.RFA_BULK_UPLOAD_DEFAULT_DATE_FORMAT);
					strCellValue = dateFormat.format(cell.getDateCellValue());
				} else {
					Double value = cell.getNumericCellValue();
					if (value % 1 == 0) {
						Long longValue = value.longValue();
						strCellValue = new String(longValue.toString());
					} else
						strCellValue = new String(value.toString());
				}
				break;
			case Cell.CELL_TYPE_BOOLEAN:
				strCellValue = new String(new Boolean(cell.getBooleanCellValue()).toString());
				break;
			case Cell.CELL_TYPE_BLANK:
				strCellValue = "";
				break;
			}
		}
		return strCellValue;
	}

	public static RFAUploadTemplateField getRFAUploadTemplateField(RFAUploadTemplate rfaUploadTemplate,
			String fieldIdentifier) {

		if (rfaUploadTemplate != null) {
			List<RFAUploadTemplateField> templateFields = rfaUploadTemplate.getTemplateFields();
			for (Iterator iterator = templateFields.iterator(); iterator.hasNext();) {
				RFAUploadTemplateField rfaUploadTemplateField = (RFAUploadTemplateField) iterator.next();

				if (rfaUploadTemplateField.getFieldIdentifier().equalsIgnoreCase(fieldIdentifier))
					return rfaUploadTemplateField;

			}
		}
		return null;
	}

	public static int getLastRowNum(XSSFSheet sheet) {
		int lastRowIndex = -1;
		if (sheet.getPhysicalNumberOfRows() > 0) {
			// getLastRowNum() actually returns an index, not a row number
			lastRowIndex = sheet.getLastRowNum();

			// now, start at end of spreadsheet and work our way backwards until we find a
			// row having data
			for (; lastRowIndex >= 0; lastRowIndex--) {
				XSSFRow row = sheet.getRow(lastRowIndex);
				if (!isRowEmpty(row)) {
					break;
				}
			}
		}
		return lastRowIndex;
	}

	private static boolean isRowEmpty(XSSFRow row) {
		if (row == null) {
			return true;
		}

		int cellCount = row.getLastCellNum() + 1;
		for (int i = 0; i < cellCount; i++) {
			String cellValue = getCellValue(row, i);
			if (cellValue != null && cellValue.length() > 0) {
				return false;
			}
		}
		return true;
	}

	private static String getCellValue(XSSFRow row, int columnIndex) {
		String cellValue;
		XSSFCell cell = row.getCell(columnIndex);
		if (cell == null) {
			cellValue = null;
		} else {
			cellValue = getCellValueAsString(cell);
		}
		return cellValue;
	}
}
