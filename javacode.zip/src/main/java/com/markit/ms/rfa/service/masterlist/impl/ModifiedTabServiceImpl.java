package com.markit.ms.rfa.service.masterlist.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.bean.MasterlistDownload;
import com.markit.ms.rfa.service.masterlist.IModifiedTabService;
import com.markit.ms.rfa.service.masterlist.MasterlistDownloadUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class ModifiedTabServiceImpl implements IModifiedTabService {

	@Resource private QueryService<Grid> getActiveSleevesInMasterlist;
	
	@Override
	public void prepareModifiedTab(SXSSFWorkbook workbook, Map<String, CellStyle> cellstyles, List<MasterlistDownload> addedList, List<MasterlistDownload> removedList, String masterlistUpdateDateString, Set<String> modifiedTabColumnSet, String controlColumn, List<MasterlistDownload> modifiedList, Map<Long, Map<String, String>> modifiedListNewColumnMap, Map<Long, Map<String, String>> modifiedListOldColumnMap, Map<String, Map<String, String>> templateColumnsMap, Map<String, String> verticalColumnsValueMap) throws IllegalArgumentException, IllegalAccessException
	{
		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(0).createCell(0).setCellValue("Masterlist Update Date");
		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(0).getCell(0).setCellStyle(cellstyles.get("columnNameStyle"));
		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(0).createCell(1).setCellValue(masterlistUpdateDateString);

		int rowNum = 1;
		Map<String, String> verticalColumns = templateColumnsMap.get("verticalColumns");
		Map<String, String> modifiedSheetHorizontalColumns = templateColumnsMap.get("modifiedSheetHorizontalColumns");
		List<String> verticalColumnsKeys = new ArrayList<>(verticalColumns.keySet());
		List<String> verticalColumnsValues = new ArrayList<>(verticalColumns.values());
		List<String> horizontalColumnsKeys = new ArrayList<>(modifiedSheetHorizontalColumns.keySet());
		List<String> horizontalColumnsValues = new ArrayList<>(modifiedSheetHorizontalColumns.values());
		// 1) Set vertical columns
		for(;rowNum<=verticalColumns.size();rowNum++){
			workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum).createCell(0).setCellValue(verticalColumnsValues.get(rowNum-1));
			workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(0).setCellStyle(cellstyles.get("columnNameStyle"));
			if(null != addedList && !addedList.isEmpty()) {
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(1).setCellValue(verticalColumnsValueMap.get(verticalColumnsKeys.get(rowNum-1)));
			} else if(null != removedList && !removedList.isEmpty()) {
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(1).setCellValue(verticalColumnsValueMap.get(verticalColumnsKeys.get(rowNum-1)));
			} else {
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(1).setCellValue(verticalColumnsValueMap.get(verticalColumnsKeys.get(rowNum-1)));
			}
		}
		
		rowNum += 1;
		int colNum = 0;
		// 2) Set horizontal columns (excluding exhibit values)
		for(String column: horizontalColumnsValues){
			Row row = workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum);
        	if(null == row) {
        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum); 
        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum+1);
            	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum+2);
        	}
        	
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellStyle(cellstyles.get("headerStyle"));
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellValue(column);
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).createCell(colNum).setCellStyle(cellstyles.get("headerStyle"));
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).getCell(colNum).setCellValue("");
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+2).createCell(colNum).setCellStyle(cellstyles.get("headerStyle"));
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+2).getCell(colNum).setCellValue("");
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).addMergedRegion(new CellRangeAddress(rowNum,rowNum+2,colNum,colNum));
        	colNum++;
		}
		
		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellStyle(cellstyles.get("headerStyle"));
        workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellValue("OLD Values");
        workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum+1).createCell(colNum).setCellStyle(cellstyles.get("headerStyle"));
        workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).getCell(colNum).setCellValue("Linked Exhibit");
        
        
        if(modifiedTabColumnSet.size() > 0) {
        	// This will set Old Values - Linked Exhibit header correctly
        	for(int mergeIter = 1; mergeIter < modifiedTabColumnSet.size() + modifiedTabColumnSet.size() -1; mergeIter++) {
        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum+mergeIter).setCellStyle(cellstyles.get("headerStyle"));
        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).createCell(colNum+mergeIter).setCellStyle(cellstyles.get("headerStyle"));
        	}
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum+modifiedTabColumnSet.size()).setCellStyle(cellstyles.get("headerStyle"));
            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum+modifiedTabColumnSet.size()).setCellValue("CURRENT Values");
            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).createCell(colNum+modifiedTabColumnSet.size()).setCellStyle(cellstyles.get("headerStyle"));
            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).getCell(colNum+modifiedTabColumnSet.size()).setCellValue("Linked Exhibit");
            //This will set Current Values - Linked Exhibit header correctly
//            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum+modifiedTabColumnSet.size()+modifiedTabColumnSet.size()-1).setCellStyle(cellstyles.get("headerStyle"));
//            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).createCell(colNum+modifiedTabColumnSet.size()+modifiedTabColumnSet.size()-1).setCellStyle(cellstyles.get("headerStyle"));

            
        } else if(modifiedTabColumnSet.size() == 0) {
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum+1).setCellStyle(cellstyles.get("headerStyle"));
            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum+1).setCellValue("CURRENT Values");
            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).createCell(colNum+1).setCellStyle(cellstyles.get("headerStyle"));
            workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+1).getCell(colNum+1).setCellValue("Linked Exhibit");
        }
        
        rowNum += 2;
        Row row = workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum);
        if(null == row) {
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum);
        }
        int i=0;
        // 3) Place Exhibit column Headers for both old and new values
        for (String column : modifiedTabColumnSet) {
        	if(column.equalsIgnoreCase(controlColumn)) {
        		column = column + "*";
        	}
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum+i).setCellValue(column);
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum+i).setCellStyle(cellstyles.get("headerStyle"));
		    workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum+i+modifiedTabColumnSet.size()).setCellValue(column);
		    workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum+i+modifiedTabColumnSet.size()).setCellStyle(cellstyles.get("headerStyle"));
		    i++;
		}
        // 4) Merge Old Values, New Values & Linked Exhibit Headers
        if(i > 0 && colNum != i+colNum-1) {//CPM-36061 condition to restrict merge on single column
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).addMergedRegion(new CellRangeAddress(rowNum-2,rowNum-2,colNum,i+colNum-1));
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).addMergedRegion(new CellRangeAddress(rowNum-1,rowNum-1,colNum,i+colNum-1));
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).addMergedRegion(new CellRangeAddress(rowNum-2,rowNum-2,colNum+modifiedTabColumnSet.size(),i+colNum-1+modifiedTabColumnSet.size()));
        	workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).addMergedRegion(new CellRangeAddress(rowNum-1,rowNum-1,colNum+modifiedTabColumnSet.size(),i+colNum-1+modifiedTabColumnSet.size()));
        }
		
		if(null != modifiedList && modifiedList.size() > 0) {
	        rowNum += 1;
	        for (int k=0; k<modifiedList.size(); k++) {
	        	MasterlistDownload masterlistDownload = modifiedList.get(k);
	            
	        	Map<String, Object> sleeveDetailParams = Maps.newHashMap();
	    		sleeveDetailParams.put("entityId", masterlistDownload.getEntityId());
	    		sleeveDetailParams.put("masterAgreementId", masterlistDownload.getMasterAgreementId());
	        	Grid sleeveDetails = getActiveSleevesInMasterlist.executeQuery(sleeveDetailParams);
	        	int totalNonExhibitCols = 0;
	        	int startRowIdForParent = rowNum;
	        	
	        	for (int sleeveCounter = 0; sleeveCounter < sleeveDetails.size()+1; sleeveCounter++){
	        		colNum=0;
	        		if (sleeveCounter == 0) {
	        			totalNonExhibitCols = populateNonExhibitModifiedDataForParents(masterlistDownload, horizontalColumnsKeys, workbook, rowNum, colNum, cellstyles);
	        		}
	        		else if (sleeveCounter > 0) {
	        			com.markit.kyc.commons.service.query.domain.Grid.Row sleeveRow = (com.markit.kyc.commons.service.query.domain.Grid.Row) sleeveDetails.getRowList().get(sleeveCounter-1);
	        			populateNonExhibitModifiedDataForSleeves(masterlistDownload, horizontalColumnsKeys, workbook, rowNum+sleeveCounter, colNum, cellstyles, sleeveRow);
	        		}
	        		
	        	}
        	
	        	Map<String, String> oldColumnNameValueMap = modifiedListOldColumnMap.get(masterlistDownload.getPartybId());
	        	Map<String, String> newColumnNameValueMap = modifiedListNewColumnMap.get(masterlistDownload.getPartybId());
	        	int j=0;
	        	for (String columnName : modifiedTabColumnSet) {
	        		String oldColumnValue = oldColumnNameValueMap.get(columnName);
	        		String newColumnValue = newColumnNameValueMap.get(columnName);
	        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(j+totalNonExhibitCols).setCellValue(oldColumnValue);
	        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(j+totalNonExhibitCols).setCellStyle(cellstyles.get("columnValueStyle"));
	        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(j+totalNonExhibitCols+modifiedTabColumnSet.size()).setCellValue(newColumnValue);
	        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(j+totalNonExhibitCols+modifiedTabColumnSet.size()).setCellStyle(cellstyles.get("columnValueStyle"));
	        		if(sleeveDetails.size() > 0) {
	        			for (int sleeveCounter = 1; sleeveCounter <= sleeveDetails.getTotalRowCount(); sleeveCounter++){
	        				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+sleeveCounter).createCell(j+totalNonExhibitCols).setCellValue(oldColumnValue);
	        				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+sleeveCounter).getCell(j+totalNonExhibitCols).setCellStyle(cellstyles.get("columnValueStyle"));
	    	        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+sleeveCounter).createCell(j+totalNonExhibitCols+modifiedTabColumnSet.size()).setCellValue(newColumnValue);
	    	        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum+sleeveCounter).getCell(j+totalNonExhibitCols+modifiedTabColumnSet.size()).setCellStyle(cellstyles.get("columnValueStyle"));
	        			}
	        		}
				    j++;
				}
	        	
	        	
	        	int endRowIdOfParent = startRowIdForParent+sleeveDetails.size()+1;
	        	int startNonExhibitColumnNum = 0;
	        	int totalExhibitColumns = (modifiedTabColumnSet.size() * 2);
	        	int totalColumns = totalNonExhibitCols + totalExhibitColumns;
	        	int endNonExhibitColumnNum = totalColumns - totalExhibitColumns;
	        	if(endRowIdOfParent > startRowIdForParent +1 ) 
	        	{
	        		MasterlistDownloadUtil.mergeCellsForValues(workbook,RFAConstants.MODIFIED_SHEET,startRowIdForParent,endRowIdOfParent,startNonExhibitColumnNum,totalColumns,false);
	        	}
	        	rowNum = rowNum+sleeveDetails.size()+1;
	        }
		}
	}	
	
	private int populateNonExhibitModifiedDataForParents(MasterlistDownload masterlistDownload, List<String> horizontalColumnsKeys, SXSSFWorkbook workbook, 
			int rowNum, int colNum, Map<String, CellStyle> cellstyles) throws IllegalArgumentException, IllegalAccessException{
		
		String columnValue = "";
		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum);
				
		for (String column : horizontalColumnsKeys){
		
			if (!(column.equalsIgnoreCase(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD) || column.equalsIgnoreCase(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD))){
				Field field = ReflectionUtils.findField(masterlistDownload.getClass(), column);
				field.setAccessible(true);
	    		columnValue = field.get(masterlistDownload)!=null?field.get(masterlistDownload).toString():null;
	    		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellValue(columnValue);
	    		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellStyle(cellstyles.get("columnValueStyle"));
	    	}
			if (column.equalsIgnoreCase(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD) || column.equalsIgnoreCase(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD)){
				columnValue = "";
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellValue(columnValue);
	    		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellStyle(cellstyles.get("columnValueStyle"));
			}
			colNum++;
		}
		return colNum;
	}	
	
	private void populateNonExhibitModifiedDataForSleeves(MasterlistDownload masterlistDownload, List<String> horizontalColumnsKeys, SXSSFWorkbook workbook, 
			int rowNum, int colNum, Map<String, CellStyle> cellstyles, com.markit.kyc.commons.service.query.domain.Grid.Row sleeveRow) throws IllegalArgumentException, IllegalAccessException{
		
		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).createRow(rowNum);
		
		for (String column : horizontalColumnsKeys){
		
			String columnValue = "";
			
			if (column.equalsIgnoreCase(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD)){
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellValue(sleeveRow.get("sleeve_true_legal_name"));
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellStyle(cellstyles.get("columnValueStyle"));
			}
			else if (column.equalsIgnoreCase(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD)){
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellValue(sleeveRow.get("sleeve_client_identifier"));
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellStyle(cellstyles.get("columnValueStyle"));
			}
			else if (column.equalsIgnoreCase(RFAConstants.DATE_ADDED_STRING)){			
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellValue(sleeveRow.get("sleeve_date_added"));
				workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellStyle(cellstyles.get("columnValueStyle"));
			}
			else{
				Field field = ReflectionUtils.findField(masterlistDownload.getClass(), column);
				field.setAccessible(true);
        		columnValue = field.get(masterlistDownload)!=null?field.get(masterlistDownload).toString():null;
        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).createCell(colNum).setCellValue(columnValue);
        		workbook.getSheetAt(RFAConstants.MODIFIED_SHEET).getRow(rowNum).getCell(colNum).setCellStyle(cellstyles.get("columnValueStyle"));
			}
			
			colNum++;
		}
	}	
	
}
