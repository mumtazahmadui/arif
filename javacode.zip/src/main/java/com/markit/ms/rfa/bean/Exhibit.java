package com.markit.ms.rfa.bean;

import java.util.Date;
import java.util.List;

public class Exhibit {
	
	private Long id;
	private Long amendmentId;
	// List<PartyBEntity> To be used by UI only
	private List<PartyBEntity> partyBEntities;
	private List<ExhibitColumn> columns;
	private String textContent;
	private String htmlContent;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Long deleted;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getAmendmentId() {
		return amendmentId;
	}
	public void setAmendmentId(Long amendmentId) {
		this.amendmentId = amendmentId;
	}
	public List<ExhibitColumn> getColumns() {
		return columns;
	}
	public void setColumns(List<ExhibitColumn> columns) {
		this.columns = columns;
	}
	public String getTextContent() {
		return textContent;
	}
	public void setTextContent(String textContent) {
		this.textContent = textContent;
	}
	public String getHtmlContent() {
		return htmlContent;
	}
	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Long getDeleted() {
		return deleted;
	}
	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}
	public List<PartyBEntity> getPartyBEntities() {
		return partyBEntities;
	}
	public void setPartyBEntities(List<PartyBEntity> partyBEntities) {
		this.partyBEntities = partyBEntities;
	}
}
