package com.markit.ms.rfa.dao;

import java.util.List;

import com.markit.ms.rfa.bean.MasterlistTemplate;
import com.markit.ms.rfa.bean.MasterlistTemplateDownload;
import com.markit.ms.rfa.bean.TemplateField;
import com.markit.ms.rfa.dto.MasterlistTemplateSearchRequest;

/**
 * @author prashant.aggarwal
 *
 */
public interface IMasterlistTemplateDAO
{
	MasterlistTemplate saveMasterlistTemplate(MasterlistTemplate masterlistTemplate);
	
	MasterlistTemplate getMasterlistTemplateById(Long id);
	
	Long getCountMasterlistTemplateByName(String mlTemplateName,Long companyId);
	
	List<TemplateField> getTemplateFieldsByMLTemplateId(Long id);
	
	Integer deleteMasterListTemplateById(Long id);
	
	List<MasterlistTemplate> getMasterlistTemplateGrid(Long companyId, MasterlistTemplateSearchRequest templateSearchRequest);

	List<MasterlistTemplateDownload> getMasterlistTemplateColumns(Long mlTemplateId);

	Long getMasterlistTemplateByMasterlist(Long masterAgreementId);
	

}
