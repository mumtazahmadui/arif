package com.markit.ms.rfa.filter;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class DebugHeaderFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		System.out.println("DebugFilter header ** start");
		try {
			
			HttpServletRequest httpRequest = (HttpServletRequest)request;
			
			for (Enumeration<String> en = httpRequest.getHeaderNames(); en.hasMoreElements(); ) {
				
				String headerName = en.nextElement();
				String headerValue = httpRequest.getHeader(headerName);
				System.out.println(headerName + "\t" + headerValue);
				
			}
//				System.out.println(
//						ToStringBuilder.reflectionToString(request.getParameterMap(), ToStringStyle.SHORT_PREFIX_STYLE)
//				);
		} catch (Exception _ex) {
			_ex.printStackTrace();
		} finally {
			System.out.println("DebugFilter header ** end");
		}
		
		
		System.out.println("DebugFilter param ** start");
		try {
			
			
			for (Enumeration<String> en = request.getParameterNames(); en.hasMoreElements(); ) {
				
				String paramName = en.nextElement();
				String paramValue = request.getParameter(paramName);
				System.out.println(paramName + "\t" + paramValue);
				
			}
//				System.out.println(
//						ToStringBuilder.reflectionToString(request.getParameterMap(), ToStringStyle.SHORT_PREFIX_STYLE)
//				);
		} catch (Exception _ex) {
			_ex.printStackTrace();
		} finally {
			System.out.println("DebugFilter param ** end");
		}
		
		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

}
