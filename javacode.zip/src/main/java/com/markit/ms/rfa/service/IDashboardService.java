package com.markit.ms.rfa.service;

import com.markit.ms.rfa.bean.CompanyAmendmentStats;

public interface IDashboardService {
public CompanyAmendmentStats getCompanyAmendmentStats(long id) ;
}
