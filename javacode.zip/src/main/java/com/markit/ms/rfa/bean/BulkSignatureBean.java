package com.markit.ms.rfa.bean;

import java.util.List;

import com.markit.ms.common.bean.Signature;

public class BulkSignatureBean extends BulkActionBean {

	private List<Signature> signatureList;

	public List<Signature> getSignatureList() {
		return signatureList;
	}

	public void setSignatureList(List<Signature> signatureList) {
		this.signatureList = signatureList;
	}
}
