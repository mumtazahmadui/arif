package com.markit.ms.rfa.bean.enumeration;

public enum RFARequestType {

	ADDITION("Addition"), REMOVAL("Removal"), MODIFICATION_EVC("Modification - EVC"),
	MODIFICATION_FNC("Modification - FNC");

	private String name;

	private RFARequestType(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

}
