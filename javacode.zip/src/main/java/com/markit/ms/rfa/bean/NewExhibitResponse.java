package com.markit.ms.rfa.bean;

import java.util.List;
import java.util.Map;

public class NewExhibitResponse {
private String exhibitTextContent;
private String exhibitHTMLContent;
private List<Map<String, String>> columns;
private List<Map<String, String>> rows;
private Integer agreed;

public List<Map<String, String>> getRows() {
	return rows;
}
public void setRows(List<Map<String, String>> rows) {
	this.rows = rows;
}
public List<Map<String, String>> getColumns() {
	return columns;
}
public void setColumns(List<Map<String, String>> columns) {
	this.columns = columns;
}
public String getExhibitTextContent() {
	return exhibitTextContent;
}
public void setExhibitTextContent(String exhibitTextContent) {
	this.exhibitTextContent = exhibitTextContent;
}
public String getExhibitHTMLContent() {
	return exhibitHTMLContent;
}
public void setExhibitHTMLContent(String exhibitHTMLContent) {
	this.exhibitHTMLContent = exhibitHTMLContent;
}
public Integer getAgreed() {
	return agreed;
}
public void setAgreed(Integer agreed) {
	this.agreed = agreed;
}
}
