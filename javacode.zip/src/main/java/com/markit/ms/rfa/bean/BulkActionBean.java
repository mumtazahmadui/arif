package com.markit.ms.rfa.bean;

import java.util.List;

public class BulkActionBean {

	private long companyId;

	private long userId;

	private String companyType;

	private List<Long> rfaIdList;

	public long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(long companyId) {
		this.companyId = companyId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public List<Long> getRfaIdList() {
		return rfaIdList;
	}

	public void setRfaIdList(List<Long> rfaIdList) {
		this.rfaIdList = rfaIdList;
	}
}