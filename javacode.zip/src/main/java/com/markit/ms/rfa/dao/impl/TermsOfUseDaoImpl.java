package com.markit.ms.rfa.dao.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.dao.ITermsOfUseDao;
@Repository
public class TermsOfUseDaoImpl extends BaseDAOImpl implements ITermsOfUseDao {

	@Value("${SAVE_TERMS_OF_USE}")
	private String SAVE_TERMS_OF_USE;
	

	@Override
	public void updateTermsOfUse(Long fileId, String version, Long userId) {
		SqlParameterSource params  = new MapSqlParameterSource()
		.addValue("fileId", fileId)
		.addValue("version", version)
		.addValue("userId", userId);
		namedParameterJdbcTemplate.update(SAVE_TERMS_OF_USE, params);		
	}

	
}
