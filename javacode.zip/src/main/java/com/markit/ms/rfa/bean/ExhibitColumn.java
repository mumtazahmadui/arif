package com.markit.ms.rfa.bean;
import java.util.Date;
import java.util.List;

public class ExhibitColumn implements Comparable<ExhibitColumn>{
	
	private Long id;
	private String columnName;
	private Long columnIndex;
	private String columnStyle;
	private List<ExhibitCell> cells;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Long deleted;

	private boolean isControlColumn;
	
	private Long exhibitTemplateColId;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public Long getColumnIndex() {
		return columnIndex;
	}
	public void setColumnIndex(Long columnIndex) {
		this.columnIndex = columnIndex;
	}
	public String getColumnStyle() {
		return columnStyle;
	}
	public void setColumnStyle(String columnStyle) {
		this.columnStyle = columnStyle;
	}
	public List<ExhibitCell> getCells() {
		return cells;
	}
	public void setCells(List<ExhibitCell> cells) {
		this.cells = cells;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExhibitColumn other = (ExhibitColumn) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Long getDeleted() {
		return deleted;
	}
	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}
	@Override
	public int compareTo(ExhibitColumn o) {
		
		return this.columnIndex.compareTo(o.columnIndex);
	}
	
	public boolean isControlColumn() {
		return isControlColumn;
	}
	public void setControlColumn(boolean isControlColumn) {
		this.isControlColumn = isControlColumn;
	}
	
	public Long getExhibitTemplateColId() {
		return exhibitTemplateColId;
	}
	public void setExhibitTemplateColId(Long exhibitTemplateColId) {
		this.exhibitTemplateColId = exhibitTemplateColId;
	}
}
