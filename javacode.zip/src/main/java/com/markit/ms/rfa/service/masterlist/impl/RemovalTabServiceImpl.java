package com.markit.ms.rfa.service.masterlist.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.bean.MasterlistDownload;
import com.markit.ms.rfa.service.masterlist.IRemovalTabService;
import com.markit.ms.rfa.service.masterlist.MasterlistDownloadUtil;
import com.markit.ms.rfa.service.masterlist.RemovalTabServiceUtil;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class RemovalTabServiceImpl implements IRemovalTabService {

	@Override
	public void prepareRemovedTab(SXSSFWorkbook workbook, Map<String, CellStyle> cellstyles, List<MasterlistDownload> addedList, 
			List<MasterlistDownload> removedList, String masterlistUpdateDateString, Set<String> addRemoveTabscolumnSet, 
			String controlColumn, Map<Long, String> legalNameEntityMap, Map<String, Map<Long,Map<Long, Map<String, String>>>> removeTabMap, 
			Map<String, Map<String, String>> templateColumnsMap, Map<String, String> verticalColumnsValueMap)
	{
		
		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).createRow(0).createCell(0).setCellValue("Masterlist Update Date");
		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(0).getCell(0).setCellStyle(cellstyles.get("columnNameStyle"));
		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(0).createCell(1).setCellValue(masterlistUpdateDateString);
		
		int rowNum = 1;
		Map<String, String> verticalColumns = templateColumnsMap.get("verticalColumns");
		Map<String, String> horizontalColumns = templateColumnsMap.get("horizontalColumns");

		List<String> verticalColumnsKeys = new ArrayList<>(verticalColumns.keySet());
		List<String> verticalColumnsValues = new ArrayList<>(verticalColumns.values());
		List<String> horizontalColumnsKeys = new ArrayList<>(horizontalColumns.keySet());
		List<String> horizontalColumnsValues = new ArrayList<>(horizontalColumns.values());
		for(;rowNum<=verticalColumns.size();rowNum++){
			workbook.getSheetAt(RFAConstants.REMOVE_SHEET).createRow(rowNum).createCell(0).setCellValue(verticalColumnsValues.get(rowNum-1));
			workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).getCell(0).setCellStyle(cellstyles.get("columnNameStyle"));
			if(null != addedList && !addedList.isEmpty()) {
				workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(1).setCellValue(verticalColumnsValueMap.get(verticalColumnsKeys.get(rowNum-1)));
			} else if(null != removedList && !removedList.isEmpty()) {
				workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(1).setCellValue(verticalColumnsValueMap.get(verticalColumnsKeys.get(rowNum-1)));
			} else {
				workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(1).setCellValue(verticalColumnsValueMap.get(verticalColumnsKeys.get(rowNum-1)));
			}
		}
		
		rowNum += 1;
		
		int exhibitColumns = 0, nonExhibitColumns = 0, totalColumns = 0, cellNum=0;
		List<String> columnHeaderProcessed= new ArrayList<>();
        workbook.getSheetAt(RFAConstants.REMOVE_SHEET).createRow(rowNum);
        workbook.getSheetAt(RFAConstants.REMOVE_SHEET).createRow(rowNum+1);
        for(String column: horizontalColumnsValues){
        	if(columnHeaderProcessed.contains(column)) {
        		continue;
        	}
        	columnHeaderProcessed.add(column);
        	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(cellNum).setCellValue(column);
        	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).getCell(cellNum).setCellStyle(cellstyles.get("headerStyle"));
        	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum+1).createCell(cellNum).setCellValue("");
		    workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum+1).getCell(cellNum).setCellStyle(cellstyles.get("headerStyle"));
		    workbook.getSheetAt(RFAConstants.REMOVE_SHEET).addMergedRegion(new CellRangeAddress(rowNum,rowNum+1,cellNum,cellNum));
		    nonExhibitColumns++;
		    cellNum++;
        }
        
        for (String column : addRemoveTabscolumnSet) {
        	if(columnHeaderProcessed.contains(column)) {
        		continue;
        	}
        	if(column.equalsIgnoreCase(controlColumn)) {
        		column = column + "*";
        	}
        	if(column.equals(RFAConstants.DATE_ADDED_FIELD) || column.equals(RFAConstants.RFA_ID_FIELD))
        	{
        		columnHeaderProcessed.add(column);
        		if(column.equals(RFAConstants.DATE_ADDED_FIELD)){
        			column = RFAConstants.DATE_REMOVED_FIELD;
        		}
        		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(cellNum).setCellValue(column);
	        	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).getCell(cellNum).setCellStyle(cellstyles.get("headerStyle"));
	        	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum+1).createCell(cellNum).setCellValue("");
			    workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum+1).getCell(cellNum).setCellStyle(cellstyles.get("headerStyle"));
        		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).addMergedRegion(new CellRangeAddress(rowNum,rowNum+1,cellNum,cellNum));
        		nonExhibitColumns++;
        		cellNum++;
        	}
        }
        
        for(String columnName : addRemoveTabscolumnSet) 
		{
			if(columnHeaderProcessed.contains(columnName) 
					|| RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD.equals(columnName)
					|| RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equals(columnName)
					|| RFAConstants.PARTYB_LEI.equals(columnName)
					|| RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD.equals(columnName)
					|| RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD.equals(columnName)
					|| RFAConstants.RFA_ID_FIELD.equals(columnName)
					|| RFAConstants.DATE_ADDED_FIELD.equals(columnName)
			 ) 
			{
				continue;
			}
			exhibitColumns++;
    		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(cellNum).setCellValue("Linked Exhibit");
    		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).getCell(cellNum).setCellStyle(cellstyles.get("headerStyle"));
	    	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum+1).createCell(cellNum).setCellValue(columnName);
	    	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum+1).getCell(cellNum).setCellStyle(cellstyles.get("headerStyle"));
	    	cellNum++;
	    }
		
		totalColumns = exhibitColumns+nonExhibitColumns;
        //Merging "Linked Exhibit" heading across multiple cells for Removed Tab
        if(cellNum > horizontalColumnsValues.size() && exhibitColumns > 1) {
        	workbook.getSheetAt(RFAConstants.REMOVE_SHEET).addMergedRegion(new CellRangeAddress(rowNum,rowNum,totalColumns-exhibitColumns,cellNum-1));
        }
        if(null != removedList && removedList.size() > 0) 
        {
	        rowNum+=2;
	        List<String> legalNameAlreadyProcessed = new ArrayList<>();
	        for (int k=0; k<removedList.size(); k++) 
	        {
				MasterlistDownload masterlistDownload = removedList.get(k);
				String legalName = legalNameEntityMap.get(masterlistDownload.getParentEntityId());
				Boolean hideParentClientIdAndLei = true;
				if(legalNameAlreadyProcessed.contains(legalName)) {
					continue;
				}
				legalNameAlreadyProcessed.add(legalName);
				
				Map<Long, Map<Long, Map<String, String>>> parentEntityIdMap = removeTabMap.get(legalName);
	        	List<Long> parentEntityIds = new ArrayList<>(parentEntityIdMap.keySet());
				for (int y = parentEntityIds.size() - 1; y >= 0; y--) {
					Map<Long, Map<String, String>> entityIdMap = parentEntityIdMap.get(parentEntityIds.get(y));
					if (RemovalTabServiceUtil.isParentEntityRemoved(entityIdMap, parentEntityIds, y))
						hideParentClientIdAndLei = false;
					List<Map<String, String>> entityIdMapValues = new ArrayList<Map<String, String>>(entityIdMap.values());
					HashSet<String> dateAdded = new HashSet<String>();
					for (Map<String, String> mapValues : entityIdMapValues) {
						if(CommonUtil.isNotNull(mapValues.get(RFAConstants.DATE_ADDED_FIELD)))
						dateAdded.add(mapValues.get(RFAConstants.DATE_ADDED_FIELD));
					}
					List<Long> entityIds = new ArrayList<>(entityIdMap.keySet());
					//Start : If Sleeve entities removed in different dates then sort it on the Date Added
					if (CommonUtil.isNotNull(dateAdded) && dateAdded.size() > 1) {
						Map<Long, Date> entityIdWithModifyDate = new HashMap<Long, Date>();
						for (Long entityId : entityIds) {
							String modifyDateText = entityIdMap.get(entityId).get(RFAConstants.DATE_ADDED_FIELD);
							if (CommonUtil.isNotNull(modifyDateText)) {
								try {
									Date modifyDate = new SimpleDateFormat("dd-MMM-yyyy").parse(modifyDateText);
									entityIdWithModifyDate.put(entityId, modifyDate);
								} catch (ParseException e) {
									e.getMessage();
								}
							}
						}
								
						if (!entityIdWithModifyDate.isEmpty()) {
					
							LinkedList<Long> entityIdList= MasterlistDownloadUtil.sortAndOrder(entityIdWithModifyDate,parentEntityIds, y);
							entityIds=new ArrayList<Long>(entityIdList);
						}
								
						
					}
					//end
					int startRowIdForParent = rowNum;
	        	    
		        	for(int x = 0; x < entityIds.size() ; x++) 
		        	{
		        		if(entityIds.get(x).equals(parentEntityIds.get(y)))
		        		{
		        			Map<String, String> columnNameCheck = entityIdMap.get(entityIds.get(x));
		        			if(columnNameCheck.containsKey(RFAConstants.DATE_ADDED_FIELD)
		        				|| columnNameCheck.containsKey(RFAConstants.RFA_ID_FIELD)) {
		        				
		        			}
		        			else {
		        				continue;
		        			}
		        		}
		        		
		        		Map<String, String> columnNameValueMap = entityIdMap.get(entityIds.get(x));
		        		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).createRow(rowNum);
		        		cellNum=0;
		        		List<String> columnsProcessed = new ArrayList<>();
		        		
		        		//1. all custom columns
		        		for (String columnName : horizontalColumnsKeys)
		        		{
		        			String columnValue;
		        			if (hideParentClientIdAndLei && 
		        					(columnName.equalsIgnoreCase(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD) || 
		        					columnName.equalsIgnoreCase(RFAConstants.PARTYB_LEI)))
		        				columnValue = "";
		        			else
		        				columnValue= columnNameValueMap.get(columnName);
		        			columnsProcessed.add(columnName);
		        			workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(cellNum).setCellValue(columnValue);
			        		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).getCell(cellNum).setCellStyle(cellstyles.get("columnValueStyle"));
			        		cellNum++;
						}
		        		
		        		//2. adding Date Added and RFA ID
		        		for(String columnName : addRemoveTabscolumnSet) {
		        			if(columnsProcessed.contains(columnName)) {
		        				continue;
		        			}
		        			
		        			if(columnName.equals(RFAConstants.DATE_ADDED_FIELD) || columnName.equals(RFAConstants.RFA_ID_FIELD)){
		        				columnsProcessed.add(columnName);
		        				String columnValue = columnNameValueMap.get(columnName);
		        				workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(cellNum).setCellValue(columnValue);
				        		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).getCell(cellNum).setCellStyle(cellstyles.get("columnValueStyle"));
				        		cellNum++;
		        			}
		        		}
		        		
		        		//3. Adding Exhibits
		        		Map<String, String> exhibitColumnNameValueMap = entityIdMap.get(parentEntityIds.get(y));
		        		for(String columnName : addRemoveTabscolumnSet) 
		        		{
		        			if(columnsProcessed.contains(columnName) 
		        					|| exhibitColumnNameValueMap == null
		        					|| RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD.equals(columnName)
		        					|| RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD.equals(columnName)
		        					|| RFAConstants.PARTYB_LEI.equals(columnName)
		        					|| RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD.equals(columnName)
		        					|| RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD.equals(columnName)
		        					|| RFAConstants.RFA_ID_FIELD.equals(columnName)
		        					|| RFAConstants.DATE_ADDED_FIELD.equals(columnName)
		        			 ) 
		        			{
		        				continue;
		        			}
		        			String columnValue = exhibitColumnNameValueMap.get(columnName);
		        			workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).createCell(cellNum).setCellValue(columnValue);
			        		workbook.getSheetAt(RFAConstants.REMOVE_SHEET).getRow(rowNum).getCell(cellNum).setCellStyle(cellstyles.get("columnValueStyle"));
			        		cellNum++;
		        		}
		        		
			        	rowNum++;
		        	}
		        	int endRowIdOfParent = rowNum;
		        	int startNonExhibitColumnNum = 0;
		        	int endNonExhibitColumnNum = totalColumns-exhibitColumns;
		        	if(endRowIdOfParent > startRowIdForParent +1 ) 
		        	{
		        		MasterlistDownloadUtil.mergeCellsForValues(workbook,RFAConstants.REMOVE_SHEET,startRowIdForParent,endRowIdOfParent,startNonExhibitColumnNum,totalColumns,false);
		        	}
	        	}
			}
		}
			
	}
}
