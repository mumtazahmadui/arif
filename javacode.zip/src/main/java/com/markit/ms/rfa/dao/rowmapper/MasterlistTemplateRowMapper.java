package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.MasterlistTemplate;

public class MasterlistTemplateRowMapper implements RowMapper<MasterlistTemplate> {
	
	public MasterlistTemplate mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		MasterlistTemplate masterlistTemplate = new MasterlistTemplate();
		masterlistTemplate.setId(rs.getLong("id"));
		masterlistTemplate.setTemplateName(rs.getString("template_name"));
		masterlistTemplate.setCompanyId(rs.getLong("company_id"));		
		masterlistTemplate.setCreatedBy(rs.getLong("created_by"));
		masterlistTemplate.setModifiedBy(rs.getLong("modified_by"));		
		masterlistTemplate.setCreatedDate(rs.getDate("created_date"));
		masterlistTemplate.setModifiedDate(rs.getDate("modified_date"));
		
		return masterlistTemplate;
	}
}
