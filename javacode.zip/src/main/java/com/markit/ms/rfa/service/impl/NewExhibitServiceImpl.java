package com.markit.ms.rfa.service.impl;

import static com.markit.ms.common.util.CommonDownloadUtil.getCellStringValue;
import static com.markit.ms.rfa.util.RFAUtil.createBulkRequestParam;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.beust.jcommander.internal.Lists;
import com.beust.jcommander.internal.Maps;
import com.marketxs.util.Assert;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.rfa.bean.ExhibitCellValue;
import com.markit.ms.rfa.bean.NewExhibitRequest;
import com.markit.ms.rfa.bean.TemplateField;
import com.markit.ms.rfa.dao.INewExhibitDao;
import com.markit.ms.rfa.service.INewExhibitService;
import com.markit.ms.rfa.service.IPartyBService;
import com.markit.ms.rfa.service.IRfaFileService;
import com.markit.ms.rs.select.all.domain.BulkRequestParam;
import com.markit.ms.rs.select.all.domain.BulkRequestParamEnum;
import com.markit.ms.rs.select.all.domain.SelectAllConfig;
import com.markit.ms.rs.select.all.service.annotation.SelectAllMethod;
import com.markit.ms.rs.select.all.service.annotation.SelectAllParam;
import com.markit.ms.rs.select.all.service.intf.SelectAllService;

@Service 
public class NewExhibitServiceImpl implements INewExhibitService {
	
	private static Logger LOGGER = LoggerFactory.getLogger(NewExhibitServiceImpl.class);
	
	private static final String RFA_ID = "RFA ID";
	
	private static final String KEY_BULK_EXHIBIT_UPDATE = "BULK_EXHIBIT_UPDATE";
	
	public static final List<String> PARTYB_FIELDS = new ArrayList<String>(Arrays.asList("Party B True Legal Name", "Party B Client Identifier", "Party B Pre-LEI/LEI"));
	
	@Autowired
	private IPartyBService partyBService;
	
	@Resource
	private INewExhibitDao newExhibitDao;
	
	@Autowired
	private IFileService fileService;
	
	@Autowired
	private IRfaFileService rfaFileService;
	
	@Autowired
	private SelectAllService selectAllService;

	@Resource
	private SelectAllConfig bulkExhibitUpdateSelectAllConfig;
	
	@Resource
	private QueryService<Grid> getMltInfoByRfaId;
	
	@Resource
	private QueryService<Grid> getRfaPartyBAndExhibitColCount; 
	
	@PostConstruct
	public void postContructMethod() {
		Assert.notNull(bulkExhibitUpdateSelectAllConfig);
		bulkExhibitUpdateSelectAllConfig.setActionName(KEY_BULK_EXHIBIT_UPDATE);
		bulkExhibitUpdateSelectAllConfig.setSelectAllActionBean(this);
	}
	
	@Override
	@Async
	public Future<Long> updateExhibit(Long amendmentId, Long userId, Long exhibitId, NewExhibitRequest newExhibitRequest, boolean isBulkUpdate) {
		newExhibitDao.updateExhibit(amendmentId, userId, exhibitId, newExhibitRequest, isBulkUpdate);
		return new AsyncResult<Long>(amendmentId);
	}
	
	@Override
	@Async
	public Future<Long> updateExhibitSS(Long amendmentId, Long userId, Long exhibitId, NewExhibitRequest newExhibitRequest) {
		newExhibitDao.updateExhibitSS(amendmentId, userId, exhibitId, newExhibitRequest);
		return new AsyncResult<Long>(amendmentId);
	}

	@Override
	public Long getExhibitColId(Long amendmentId, String columnName) {
		long start = System.currentTimeMillis();
		Long result = newExhibitDao.getExhibitColId(amendmentId, columnName);
		LOGGER.info("### getExhibitColId amendmentId : " + amendmentId + " took : " + (System.currentTimeMillis() - start));
		return result;
	}

	@SuppressWarnings("unused")
	private boolean validateExhibitData(Long rfaId, Set<Long> columnIdList, Set<Long> partybEntityIdList) {
		return newExhibitDao.validateExhibitData(rfaId, columnIdList, partybEntityIdList);
	}
	
	private String getFirstVisibleKey(Map<String, TemplateField> fieldIdInfoMapDup){
		String visibleKey = null;
		for(String fieldId: fieldIdInfoMapDup.keySet()){
			if(fieldIdInfoMapDup.get(fieldId).getFieldVisibility()==1){
				visibleKey = fieldId;
				break;
			}				
		}
		return visibleKey;
	}
	
	@Override
	public Map<Long, NewExhibitRequest> getExhibitRequestMap(byte[] file, String fileName, List<Long> rfaIds) {
		Integer partyBIdsDynamicCount = -1;
		String firstVisibleKey = null;
		String trueLegalName = null;
		String clientId = null;
		XSSFWorkbook workbook = null;
		
		Map<String, TemplateField> fieldIdInfoMap = null;
		Map<String, TemplateField> fieldIdInfoMapDup = null;
		
		Map<String, Map<String, TemplateField>> fieldInfoRfaIdMap = getMltFieldInfoMapByRfaId(rfaIds);
		long start = System.currentTimeMillis();
		try {
			workbook = new XSSFWorkbook(new ByteArrayInputStream(file));
		} catch (IOException ioe) {
			throw new RuntimeException("IOException while reading data from the excel file");
		}
		XSSFSheet sheet = workbook.getSheetAt(0);
		Map<Long, NewExhibitRequest> exhibitRequestMap = new LinkedHashMap<>();

		Iterator<Row> rowIterator = sheet.iterator();
		while (rowIterator.hasNext()) {
			try {
				Row row = rowIterator.next();
				Iterator<Cell> cellIterator = row.cellIterator();
				while (cellIterator.hasNext()) {
					Cell cell = cellIterator.next();
					String cellValue = getCellStringValue(cell);
					Long currentRFAId = null;
					if (RFA_ID.equalsIgnoreCase(cellValue)) {
						
						partyBIdsDynamicCount = -1;
						cell = cellIterator.next();
						if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
							cell.setCellType(Cell.CELL_TYPE_STRING);
						}
						currentRFAId = Long.parseLong(getCellStringValue(cell));
						
						fieldIdInfoMap  = fieldInfoRfaIdMap.get(currentRFAId.toString());
						
						fieldIdInfoMapDup = new LinkedHashMap<>();
						fieldIdInfoMapDup.putAll(fieldIdInfoMap);
						fieldIdInfoMapDup.keySet().retainAll(PARTYB_FIELDS);
						fieldIdInfoMapDup.put("Action", new TemplateField("Action", "Action", 1, null));
						
						firstVisibleKey = getFirstVisibleKey(fieldIdInfoMapDup);
						
						for(String fieldId: fieldIdInfoMapDup.keySet()){
							if(fieldIdInfoMapDup.get(fieldId).getFieldVisibility()==1)
								partyBIdsDynamicCount++;
						}
						
						if (exhibitRequestMap.containsKey(currentRFAId)) {
							LOGGER.error("Excel contains invalid data for RFA ID: " + currentRFAId);
							throw new IllegalArgumentException();
						}
					}
					if (null != currentRFAId) {
						
						while (rowIterator.hasNext() && !fieldIdInfoMapDup.get(firstVisibleKey).getFieldLabel().
								equalsIgnoreCase(row.cellIterator().next().getStringCellValue())) {
							row = rowIterator.next();
						}
						NewExhibitRequest newExhibitRequest = new NewExhibitRequest();
						List<ExhibitCellValue> exhibitCellValueList = new ArrayList<>();
						int i = 1;
						Row nextRow = row;
						while (nextRow != null && nextRow.getCell(0) != null && nextRow.getCell(0).getStringCellValue() != null
								&& !RFA_ID.equalsIgnoreCase(nextRow.getCell(0).getStringCellValue())) {
							cellIterator = row.cellIterator();
							Map<String, Long> partyBMap = new HashMap<String, Long>();
							
							int trueLegalNameIndex = -1;
							int clientIdIndex = -1;
							
							while (cellIterator.hasNext()) {
								cell = cellIterator.next();
								cellValue = getCellStringValue(cell);
								
								if(cellValue.equalsIgnoreCase(fieldIdInfoMapDup.get("Party B True Legal Name").getFieldLabel())){
									trueLegalNameIndex = cell.getColumnIndex();
								}
								
								if(cellValue.equalsIgnoreCase(fieldIdInfoMapDup.get("Party B Client Identifier").getFieldLabel())){
									clientIdIndex = cell.getColumnIndex();
								}
									
									
								if (StringUtils.isNotBlank(cellValue)) {
									if (cell.getColumnIndex() > partyBIdsDynamicCount) {
										Long exhibitColumnId = getExhibitColId(currentRFAId, cellValue);
										nextRow = sheet.getRow(row.getRowNum() + i);
										if(trueLegalNameIndex > -1)
											 trueLegalName = nextRow.getCell(trueLegalNameIndex).getStringCellValue();
										if(clientIdIndex > -1)
											 clientId = nextRow.getCell(clientIdIndex).getStringCellValue();
										
										trueLegalName = trueLegalName!=null?trueLegalName:"";
										clientId = clientId!=null?clientId:"";
										
										Long partyBId = partyBMap.get(trueLegalName!=null?trueLegalName:"" +"+"+ clientId!=null?clientId:"");
										if (partyBId == null) {
											long s = System.currentTimeMillis();
											partyBId = partyBService.getPartyBIdByLegalNameAndClientId(trueLegalName, clientId, currentRFAId);
											LOGGER.info("### partyBService.getPartyBIdByLegalName took : " + (System.currentTimeMillis() - s));
											partyBMap.put(trueLegalName +"+"+ clientId, partyBId);
											trueLegalName = null;
											clientId = null;
										}
										ExhibitCellValue exhibitCellValue = new ExhibitCellValue();
										exhibitCellValue.setPartyBId(partyBId);
										exhibitCellValue.setExhibitColumnId(exhibitColumnId);
										String cellStringValue = getCellStringValue(nextRow.getCell(cell.getColumnIndex()));
										if (StringUtils.isBlank(cellStringValue)) {
											throw new IllegalArgumentException();
										}
										exhibitCellValue.setCellValue(cellStringValue);
										exhibitCellValueList.add(exhibitCellValue);
									}
								} else {
									break;
								}
							}
							i++;
							nextRow = sheet.getRow(row.getRowNum() + i);
							rowIterator.next();
						}
						newExhibitRequest.setCellValues(exhibitCellValueList);
						if (rfaIds.contains(currentRFAId)) {
							exhibitRequestMap.put(currentRFAId, newExhibitRequest);
						}
					}
				}
			} catch (RuntimeException rte) {
				LOGGER.error("Excel contains invalid data/metadata");
			}
		}
		LOGGER.info("### getExhibitRequestMap took : " + (System.currentTimeMillis() - start));
		return exhibitRequestMap;
	}

	@Override
	public Map<Long, NewExhibitRequest> validateExhibitData(Map<Long, NewExhibitRequest> exhibitRequestMap) {
		long start = System.currentTimeMillis();
		List<Long> rfaIdList = new ArrayList<Long>(exhibitRequestMap.keySet());
		Map<Long, NewExhibitRequest> validExhibitRequestMap = new LinkedHashMap<>();
		if (rfaIdList.isEmpty()) {
			return validExhibitRequestMap;
		}
		Grid data = getRfaPartyBAndExhibitColCount.executeQuery("rfaIdList", rfaIdList);
		Map<Long, Map<String, String>> map = Maps.newHashMap();
		data.getRows().forEach(m -> {
			map.put(Long.valueOf(m.get("ID")), m);
		});
		Set<Long> columnList = new LinkedHashSet<>();
		Set<Long> partybIdList = new LinkedHashSet<>();
		for (Map.Entry<Long, NewExhibitRequest> entry : exhibitRequestMap.entrySet()) {
			columnList.clear();
			partybIdList.clear();
			for (ExhibitCellValue exhibitCellValue : entry.getValue().getCellValues()) {
				columnList.add(exhibitCellValue.getExhibitColumnId());
				partybIdList.add(exhibitCellValue.getPartyBId());
			}
			Map<String, String> countMap = map.get(entry.getKey());
			if (MapUtils.isNotEmpty(countMap) && StringUtils.isNoneBlank(countMap.get("EXHIBIT_COL_CNT"), countMap.get("PARTYB_ENTITY_CNT"))
					&& columnList.size() == Integer.valueOf(countMap.get("EXHIBIT_COL_CNT"))
					&& partybIdList.size() == Integer.valueOf(countMap.get("PARTYB_ENTITY_CNT"))) {
				validExhibitRequestMap.put(entry.getKey(), entry.getValue());
			}
		}
		LOGGER.info("### validateExhibitData took : " + (System.currentTimeMillis() - start));
		return validExhibitRequestMap;
	}
	
	@Override
	@Transactional
	@SelectAllMethod(name = KEY_BULK_EXHIBIT_UPDATE, objectIdIndex = 0, objectIdType = Long.class)
	public void updateExhibit(Long amendmentId, @SelectAllParam(index = 1) NewExhibitRequest newExhibitRequest,
			@SelectAllParam(index = 2) Long userId) {
		newExhibitDao.updateExhibit(amendmentId, userId, null, newExhibitRequest, true);
	}

	@Override
	public Long bulkUpdateExhibitData(Long fileId, String fileName, Long userId, Long companyId) throws Exception {
		long s1 = System.currentTimeMillis();
		byte[] fileBytes = fileService.getFile(fileId, companyId);
		long s2 = System.currentTimeMillis();
		LOGGER.info("### fileService.getFile took : " + (s2 - s1));
		List<Long> validRfaIdList = rfaFileService.getRfaIdByFileId(fileId);
		long s3 = System.currentTimeMillis();
		LOGGER.info("### rfaFileService.getRfaIdByFileId took : " + (s3 - s2));
		
		Map<Long, NewExhibitRequest> exhibitRequestMap = getExhibitRequestMap(fileBytes, fileName, validRfaIdList);
		Map<Long, NewExhibitRequest> validExhibitRequestMap = validateExhibitData(exhibitRequestMap);

		List<BulkRequestParam> requestParamList = Lists.newArrayList();
		requestParamList.add(createBulkRequestParam(2, "userId", userId, BulkRequestParamEnum.PRIMITIVE));

		Map<Long, List<BulkRequestParam>> requestObjectParamMap = Maps.newLinkedHashMap();

		for (Map.Entry<Long, NewExhibitRequest> entry : validExhibitRequestMap.entrySet()) {
			requestObjectParamMap.put(entry.getKey(),
					Lists.newArrayList(createBulkRequestParam(1, "newExhibitRequest", entry.getValue(), BulkRequestParamEnum.JSON)));
		}
		return selectAllService.processRequest(bulkExhibitUpdateSelectAllConfig, requestParamList, requestObjectParamMap, userId, companyId);
	}
	
	private Map<String, Map<String, TemplateField>> getMltFieldInfoMapByRfaId(List<Long> rfaIdList){
		long start = System.currentTimeMillis();
		Map<String, Map<String, TemplateField>> fieldInfoRfaIdMap = new HashMap<String, Map<String, TemplateField>>();
		
		Map<String, Object> params = new HashMap<>();
		params.put("rfaIdList", rfaIdList);	
		Grid mltIdentifierLabelGrid = getMltInfoByRfaId.executeQuery(params);
		
		Map<String, List<Grid.Row>> fieldIdLabelInfoRowMap = new HashMap<>();
		for (Grid.Row row : mltIdentifierLabelGrid.getRowList()) {
			String key = row.get("RFA_ID");
			fieldIdLabelInfoRowMap.putIfAbsent(key, new ArrayList<Grid.Row>());
			fieldIdLabelInfoRowMap.get(key).add(row);
		}
		
		Set<String> rfaIds =  fieldIdLabelInfoRowMap.keySet();
		for(String rfaId : rfaIds){
			List<Grid.Row> fieldIdLabelInfoRows = fieldIdLabelInfoRowMap.get(rfaId);
			Map<String, TemplateField> fieldIdInfoMap= new HashMap<String, TemplateField>();
			
			for(Grid.Row fieldIdLabelInfoRow :fieldIdLabelInfoRows){
				Integer field_visibility = fieldIdLabelInfoRow.get("field_visibility")!=null? Integer.valueOf(fieldIdLabelInfoRow.get("field_visibility")): null;
				Integer field_order = fieldIdLabelInfoRow.get("field_order")!=null? Integer.valueOf(fieldIdLabelInfoRow.get("field_order")): null;
				
				TemplateField tempField = new TemplateField(fieldIdLabelInfoRow.get("field_identifier"), fieldIdLabelInfoRow.get("field_label"), field_visibility, field_order);
				
				fieldIdInfoMap.put(fieldIdLabelInfoRow.get("field_identifier"), tempField);
				fieldIdInfoMap.put("RFA ID", new TemplateField("RFA ID", "RFA ID", 1, null));				
			}
			fieldIdInfoMap = sortMapByFieldOrder(fieldIdInfoMap);
			fieldInfoRfaIdMap.put(rfaId, fieldIdInfoMap);			
		}
		LOGGER.info("### getMltFieldInfoMapByRfaId took : " + (System.currentTimeMillis() - start));
		return fieldInfoRfaIdMap;
	}
	
	private Map<String, TemplateField> sortMapByFieldOrder(Map<String, TemplateField> fieldIdInfoMap){
		
		Comparator<Map.Entry<String, TemplateField>> byFieldOrderComp = new Comparator<Map.Entry<String, TemplateField>>() {
	        public int compare(Map.Entry<String, TemplateField> left, Map.Entry<String, TemplateField> right) {
	        	TemplateField tf1 =  left.getValue();
	    		Integer fo1 = tf1.getFieldOrder();
	    		TemplateField tf2 =  right.getValue();
	    		Integer fo2 = tf2.getFieldOrder();
	            return (fo1==null)? (fo2==null?0:1)  : (fo2==null?-1:fo1.compareTo(fo2));
	        }
	    };

	    List<Map.Entry<String, TemplateField>> tfMEList = new ArrayList<Map.Entry<String, TemplateField>>();

	    tfMEList.addAll(fieldIdInfoMap.entrySet());

	    Collections.sort(tfMEList, byFieldOrderComp);
 		
		Map<String, TemplateField> fieldIdInfoMapOut = new LinkedHashMap();
	    for (Map.Entry<String, TemplateField> entry : tfMEList)
	    {
	    	fieldIdInfoMapOut.put( entry.getKey(), entry.getValue() );
	    }
	    return fieldIdInfoMapOut;
		
	}
}