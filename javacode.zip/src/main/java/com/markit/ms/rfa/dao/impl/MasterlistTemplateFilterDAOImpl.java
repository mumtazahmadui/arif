package com.markit.ms.rfa.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.dao.impl.BaseDAOImpl;
import com.markit.ms.rfa.dao.IMasterlistTemplateFilterDAO;

/**
 * @author prashant.aggarwal
 *
 */
@Repository
public class MasterlistTemplateFilterDAOImpl extends BaseDAOImpl implements IMasterlistTemplateFilterDAO
{
	@Value("${GET_MLTEMPLATE_NAMES_BY_COMPANYID}")
	private String GET_MLTEMPLATE_NAMES_BY_COMPANYID;

	@Override
	public List<Lookup> mlTemplateLookUp(Long companyId, String filterString) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyId", companyId)
				.addValue("filterString", "%"+filterString+"%");
		List<Map<String, Object>> mlTemplates  = namedParameterJdbcTemplate.queryForList(GET_MLTEMPLATE_NAMES_BY_COMPANYID, paramSource);

		List<Lookup> lookupList = new ArrayList<Lookup>();
		for(Map<String, Object> mlTemplate : mlTemplates){
			Lookup lookup = new Lookup();
			lookup.setId(new Long(((BigDecimal)mlTemplate.get("id")).longValue()));
			lookup.setValue((String)mlTemplate.get("template_name"));			
			lookupList.add(lookup);
		}

		return lookupList;
	}

}
