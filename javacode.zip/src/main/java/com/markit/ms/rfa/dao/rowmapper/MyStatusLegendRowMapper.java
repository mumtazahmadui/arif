package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.MyStatusLegend;

public class MyStatusLegendRowMapper implements RowMapper<List<MyStatusLegend>> {

	@Override
	public List<MyStatusLegend> mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		if (rs.getRow() == 0) throw new SQLException("MyStatusLegend result set should never return 0 rows");
		
		MyStatusLegend deskOne = new MyStatusLegend();
		MyStatusLegend deskTwo = new MyStatusLegend();
		
		
		deskOne.setLabel(rs.getString("deskOneLabel"));
		deskOne.setInitials(rs.getString("deskOneInitials"));
		deskOne.setRole(rs.getString("deskOneRole"));
		deskOne.setDeskLookupReviewDetail(rs.getString("deskOneLookupReviewDetail"));
		deskTwo.setLabel(rs.getString("deskTwoLabel"));
		deskTwo.setInitials(rs.getString("deskTwoInitials"));
		deskTwo.setRole(rs.getString("deskTwoRole"));
		deskTwo.setDeskLookupReviewDetail(rs.getString("deskTwoLookupReviewDetail"));
		
		List<MyStatusLegend> myStatusLegendList = new ArrayList<>();
		myStatusLegendList.add(deskOne);
		myStatusLegendList.add(deskTwo);
		return myStatusLegendList;
	}
	
}
