package com.markit.ms.rfa.command.notifier.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.markit.ms.common.bean.User;
import com.markit.ms.common.service.IUserService;
import com.markit.ms.rfa.bean.BulkEmailVelocityTemplateValues;
import com.markit.ms.rfa.bean.BulkNotificationBean;
import com.markit.ms.rfa.bean.RfaNotificationBean;
import com.markit.ms.rfa.command.notifier.BulkActionEmailNotifier;
import com.markit.ms.rfa.service.IMcsRedirectUrlGenerator;

@Component
public class RfaSuccessEmailNotifier extends BulkActionEmailNotifier {

	
	
	
	@Autowired
	IUserService userService;
	
	@Resource(name="rfaLoginEmailUrlGenerator")
	private IMcsRedirectUrlGenerator rfaLoginEmailUrlGenerator;

	
	public void sendEmailNotification(BulkNotificationBean bulkNotificationBean) throws Exception {

			RfaNotificationBean notification=(RfaNotificationBean)bulkNotificationBean;
			User user=userService.getUser(notification.getUserId());
			
			Map<String, Object> additionalParams = Maps.newHashMapWithExpectedSize(2);
			additionalParams.put("uploadId",notification.getUploadId());
			additionalParams.put("username",user.getFullName());
			additionalParams.put("login",rfaLoginEmailUrlGenerator.generateUrl(new HashMap<String,String>()));

			Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
			subjectVariables.put("subj_suffix",notification.getUploadId());
			
			rfaMailService.sendEmail(Lists.newArrayList(user.getEmail()), additionalParams, emailBodyTemplate, emailSubjectTemplate, subjectVariables);
		
	}


}