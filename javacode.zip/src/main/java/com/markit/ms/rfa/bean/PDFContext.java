package com.markit.ms.rfa.bean;


public class PDFContext {
private boolean ignoreBuySideSignaturePlaceholder;
private boolean ignoreSellSideSignaturePlaceholder;
private boolean datePinnedPlaceholder;
private String allowPartyBStatuses;
private String notAllowPartyBStatuses;
private String companyType;
public boolean isIgnoreBuySideSignaturePlaceholder() {
	return ignoreBuySideSignaturePlaceholder;
}
public void setIgnoreBuySideSignaturePlaceholder(
		boolean ignoreBuySideSignaturePlaceholder) {
	this.ignoreBuySideSignaturePlaceholder = ignoreBuySideSignaturePlaceholder;
}
public boolean isIgnoreSellSideSignaturePlaceholder() {
	return ignoreSellSideSignaturePlaceholder;
}
public void setIgnoreSellSideSignaturePlaceholder(
		boolean ignoreSellSideSignaturePlaceholder) {
	this.ignoreSellSideSignaturePlaceholder = ignoreSellSideSignaturePlaceholder;
}

public String getCompanyType() {
	return companyType;
}
public void setCompanyType(String companyType) {
	this.companyType = companyType;
}

public String getNotAllowPartyBStatuses() {
	return notAllowPartyBStatuses;
}
public void setNotAllowPartyBStatuses(String notAllowPartyBStatuses) {
	this.notAllowPartyBStatuses = notAllowPartyBStatuses;
}
public String getAllowPartyBStatuses() {
	return allowPartyBStatuses;
}
public void setAllowPartyBStatuses(String allowPartyBStatuses) {
	this.allowPartyBStatuses = allowPartyBStatuses;
}

public boolean isDatePinnedPlaceholder() {
	return datePinnedPlaceholder;
}
public void setDatePinnedPlaceholder(boolean datePinnedPlaceholder) {
	this.datePinnedPlaceholder = datePinnedPlaceholder;
}
}
