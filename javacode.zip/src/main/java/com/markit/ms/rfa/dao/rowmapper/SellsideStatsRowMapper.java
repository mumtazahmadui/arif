package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.CompanyAmendmentStats;
import com.markit.ms.rfa.bean.PendingTasks;
import com.markit.ms.rfa.bean.RequestStatus;

public class SellsideStatsRowMapper implements RowMapper<CompanyAmendmentStats> {

	@Override
	public CompanyAmendmentStats mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		CompanyAmendmentStats companyAmendmentStats = new CompanyAmendmentStats();
			RequestStatus requestStatus = new RequestStatus();
			PendingTasks pendingTasks = new PendingTasks();
			
			requestStatus.setCompleted(rs.getLong("Completed"));
			requestStatus.setReceived(rs.getLong("Received"));
			requestStatus.setDeleted(rs.getLong("Deleted"));
			requestStatus.setPartiallyCompleted(rs.getLong("PartiallyCompleted"));
			requestStatus.setRecalled(rs.getLong("Recalled"));
			requestStatus.setRejected(rs.getLong("Rejected"));
			companyAmendmentStats.setRequestStatus(requestStatus);
			
			pendingTasks.setPendingEsign(rs.getLong("ELECTRONIC_SIGNATURE"));
			pendingTasks.setPendingResponse(rs.getLong("PENDING_RESPONSE"));
			pendingTasks.setSendRFA(rs.getLong("SS_SEND_RFA"));
			companyAmendmentStats.setPendingTasks(pendingTasks);
			return companyAmendmentStats;
	}
}
