package com.markit.ms.rfa.controller;

import java.util.List;
import java.util.ListIterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseSearchResponse;
import com.markit.ms.common.util.DownloadUtil;
import com.markit.ms.rfa.bean.MasterlistTemplate;
import com.markit.ms.rfa.bean.TemplateField;
import com.markit.ms.rfa.dto.MasterlistTemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.IMasterlistTemplateService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

/**
 * @author prashant.aggarwal
 *
 */
@RestController
@RequestMapping(value = "/v1/masterlist_template")
@Api(value = "masterlist_template" , description = "Masterlist Template APIs")
public class MasterlistTemplateController {

	@Autowired
	private IMasterlistTemplateService templateService;

	@RequestMapping(method = RequestMethod.POST)
	public MasterlistTemplate saveMasterlistTemplate(
			@RequestBody MasterlistTemplate masterlistTemplate,
			HttpServletRequest request) throws RFAUIException {

		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);
		
		masterlistTemplate.setCompanyId(companyIdFromSession);
		masterlistTemplate.setCreatedBy(userIdFromSession);
		masterlistTemplate.setModifiedBy(userIdFromSession);
		
		List<TemplateField> templateFields = masterlistTemplate.getTemplateFields();
		
		ListIterator<TemplateField> itrTemplateFields = templateFields.listIterator();
		
		while(itrTemplateFields.hasNext()){
			TemplateField templateField = itrTemplateFields.next();
			TemplateField fieldNew = null;
			TemplateField fieldOld = null;
			if(templateField.getFieldIdentifier().equals("Party B True Legal Name") ||
					templateField.getFieldIdentifier().equals("Party B Pre-LEI/LEI") ||
					templateField.getFieldIdentifier().equals("Party B Client Identifier")){
				fieldNew = new TemplateField("New "+templateField.getFieldIdentifier(), "New "+templateField.getFieldLabel(), templateField.getFieldVisibility(),
						templateField.getFieldOrder(), templateField.getMlTemplateId());
				fieldOld = new TemplateField("Old "+templateField.getFieldIdentifier(), "Old "+templateField.getFieldLabel(), templateField.getFieldVisibility(),
						templateField.getFieldOrder(), templateField.getMlTemplateId());
				itrTemplateFields.add(fieldNew);
				itrTemplateFields.add(fieldOld);
			}
		}
		
		masterlistTemplate = templateService.saveMasterlistTemplate(masterlistTemplate);
		return masterlistTemplate;
	}

	@RequestMapping(value = "/{mlTemplateId}", method = RequestMethod.GET)
	public MasterlistTemplate getMasterlistTemplate(
			@PathVariable Long mlTemplateId) throws RFAException {

		MasterlistTemplate masterlistTemplate = templateService.getMasterlistTemplate(mlTemplateId);
		return masterlistTemplate;
	}

	@RequestMapping(value="/{mlTemplateId}",method = RequestMethod.DELETE)
	@ApiOperation(value = "Delete Masterlist Template")
	public void deleteMasterlistTemplate(@PathVariable Long mlTemplateId) throws RFAException{			
		templateService.deleteMasterListTemplateById(mlTemplateId);			
	}

	@RequestMapping(value="/search",method = RequestMethod.POST)
	@ApiOperation(value = "Get Masterlist Template Grid")
	public CommonBaseSearchResponse<MasterlistTemplate> getMasterlistTemplateGrid(@RequestBody MasterlistTemplateSearchRequest templateSearchRequest,HttpServletRequest request) throws Exception {

		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		List<MasterlistTemplate> masterlistTemplates = templateService.getMasterlistTemplateGrid(companyIdFromSession, templateSearchRequest);

		CommonBaseSearchResponse<MasterlistTemplate>  commonBaseSearchResponse = new CommonBaseSearchResponse<MasterlistTemplate>();
		commonBaseSearchResponse.setDataList(masterlistTemplates);

		if(masterlistTemplates.size()>0)
			commonBaseSearchResponse.setTotalCount(masterlistTemplates.get(0).getTotalRowCount());
		return commonBaseSearchResponse;        
	}
	
	@RequestMapping(value="/{mlTemplateId}/export", method = RequestMethod.GET)
	@ApiOperation(value = "Download Masterlist Template")
	public String downloadMasterlistTemplate(@PathVariable Long mlTemplateId, HttpServletResponse response,HttpServletRequest request) throws Exception {
    	String fileName = "Masterlist_Template.xlsx";
    	String aa = "";
    	DownloadUtil.downloadFileBySXSSFWorkbook(response, templateService.downloadMasterlistTemplate(mlTemplateId), fileName);
        return "";
    }

}