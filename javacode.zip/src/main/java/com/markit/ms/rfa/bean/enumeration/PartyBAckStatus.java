package com.markit.ms.rfa.bean.enumeration;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;


public enum PartyBAckStatus {

	ACCEPTED("Accepted", "PartyB marked as accepted by SS"),
	PENDING("Pending", "PartyB marked as pending by SS"),
	REJECTED("Rejected", "PartyB marked as rejected by SS"),
	WITHDRAWN("Withdrawn", "PartyB marked as withdrawn by BS"),
	ACCEPTED_SIGNED("Accepted Signed", "Accepted Signed by SS"),
	ACCEPTED_SENT("Accepted Sent", "Accepted Sent by SS"),
	REJECTED_SENT("Rejected Sent", "Rejected Sent by SS");
	
	private String name;
	private String description;
	
	private PartyBAckStatus(String name, String description){
		this.name = name;
		this.description = description;
	}
	
	
	public String getName()
    {
        return this.name;
    }
	
	public static PartyBAckStatus fromString(String str){
		if (str == null){
			return null;
		}
		for (PartyBAckStatus stat : PartyBAckStatus.values()){
			if (stat.name.equalsIgnoreCase(str)) return stat;
		}
		return null;
	}
    public static class PartyBAckStatusDeserializer extends JsonDeserializer<PartyBAckStatus> {

        @Override
        public PartyBAckStatus deserialize(JsonParser jp, DeserializationContext arg1) throws IOException, JsonProcessingException {
        	PartyBAckStatus taskDefId = PartyBAckStatus.valueOf(jp.getValueAsString());
            if (taskDefId != null) {
                return taskDefId;
            }
            throw new JsonMappingException("Invalid type");
        }

    }
}