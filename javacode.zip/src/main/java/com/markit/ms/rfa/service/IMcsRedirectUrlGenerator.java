package com.markit.ms.rfa.service;

import java.util.Map;

public interface IMcsRedirectUrlGenerator {

	String generateUrl(Map<String, String> queryStringParams) throws Exception;
}