package com.markit.ms.rfa.util;

import com.markit.ms.rfa.bean.PDFContext;

public class PDFContextGenerator {

	public static PDFContext getSellSideSendRFAContext() {
		PDFContext pdfContext = new PDFContext();
		pdfContext.setDatePinnedPlaceholder(true);
		pdfContext.setIgnoreBuySideSignaturePlaceholder(true);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(true);
		pdfContext.setCompanyType(RFAConstants.COMPANY_TYPE_SS);
		pdfContext.setAllowPartyBStatuses("Accepted Signed");
		pdfContext.setNotAllowPartyBStatuses(null);
		return pdfContext;
	}

	public static PDFContext getBuySideSendRFAContext() {
		PDFContext pdfContext = new PDFContext();
		pdfContext.setDatePinnedPlaceholder(true);
		pdfContext.setIgnoreBuySideSignaturePlaceholder(true);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(true);
		pdfContext.setCompanyType(RFAConstants.COMPANY_TYPE_BS);
		pdfContext.setAllowPartyBStatuses(null);
		pdfContext.setNotAllowPartyBStatuses(null);
		return pdfContext;
	}

	public static PDFContext getBuySideRFAIDContext() {
		PDFContext pdfContext = new PDFContext();
		pdfContext.setIgnoreBuySideSignaturePlaceholder(false);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(false);
		pdfContext.setCompanyType(RFAConstants.COMPANY_TYPE_BS);
		pdfContext.setAllowPartyBStatuses(null);
		pdfContext.setNotAllowPartyBStatuses("Accepted Sent|Rejected Sent|Withdrawn");
		return pdfContext;
	}

	public static PDFContext getSellSideRFAIDContext() {
		PDFContext pdfContext = new PDFContext();
		pdfContext.setIgnoreBuySideSignaturePlaceholder(true);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(false);
		pdfContext.setCompanyType(RFAConstants.COMPANY_TYPE_SS);
		pdfContext.setAllowPartyBStatuses(null);
		pdfContext.setNotAllowPartyBStatuses("Accepted Sent|Rejected Sent|Withdrawn");
		return pdfContext;
	}
	
	public static PDFContext getSellSideRFAIDSignedContext() {
		PDFContext pdfContext = new PDFContext();
		pdfContext.setIgnoreBuySideSignaturePlaceholder(true);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(false);
		pdfContext.setCompanyType(RFAConstants.COMPANY_TYPE_SS);
		pdfContext.setAllowPartyBStatuses("Accepted Signed");
		pdfContext.setNotAllowPartyBStatuses(null);
		return pdfContext;
	}
	
	public static PDFContext getBuySideEsignFrameContext() {
		PDFContext pdfContext = new PDFContext();
		pdfContext.setIgnoreBuySideSignaturePlaceholder(false);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(false);
		pdfContext.setCompanyType(RFAConstants.COMPANY_TYPE_BS);
		pdfContext.setAllowPartyBStatuses(null);
		pdfContext.setNotAllowPartyBStatuses(null);
		return pdfContext;
	}

	public static PDFContext getSellSideEsignFrameContext() {
		PDFContext pdfContext = new PDFContext();
		pdfContext.setIgnoreBuySideSignaturePlaceholder(true);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(false);
		pdfContext.setCompanyType(RFAConstants.COMPANY_TYPE_SS);
		pdfContext.setAllowPartyBStatuses(null);
		pdfContext.setNotAllowPartyBStatuses("Accepted Sent|Rejected Sent|Rejected|Pending|Withdrawn");
		return pdfContext;
	}
}
