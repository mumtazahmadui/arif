package com.markit.ms.rfa.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.dao.IRfaUploadTemplateFilterDao;
import com.markit.ms.rfa.service.IRfaUploadTemplateFilterService;

@Service
public class RfaUploadTemplateFilterServiceImpl implements IRfaUploadTemplateFilterService {

	@Autowired
	private IRfaUploadTemplateFilterDao filterDao;
	




	@Override
	public List<Lookup> uploadTemplateLookUp(Long companyId, String filterString) {
		List<Lookup> uploadTemplate = filterDao.getUploadTemplateLookup(companyId,filterString);
		return uploadTemplate;
	}




	@Override
	public Map<String, List<String>> getFilterValues() {
		Map<String, List<String>> filterValues = filterDao.getFilterValues();
		return filterValues;
	}




	@Override
	public Map<String, String> getDefaultValue() {
		 Map<String, String>  defaultValue = filterDao.getDefaultValue();
		return defaultValue;
	}
}
