package com.markit.ms.rfa.rfabulkupload.factory;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;

public interface FactoryActionChain {
	
	void setChainAndProcess(RfaBulkUploadRow rfaBulkUploadRow);
	
}
