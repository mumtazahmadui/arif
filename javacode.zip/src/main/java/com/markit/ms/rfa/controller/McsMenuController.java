package com.markit.ms.rfa.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping(value = "/mcs")
public class McsMenuController {

  @Resource
  private String mcsMenuXml;

  @RequestMapping(method = RequestMethod.POST)
  public @ResponseBody void keepAlive() {

    return; // No-op for debugging
  }

  @RequestMapping(method = RequestMethod.POST, value = "/menu", produces = "application/xml; charset=utf-8")
  public @ResponseBody String getXmlMenu() {

    return mcsMenuXml;

  }

}
