package com.markit.ms.rfa.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFASystemException;
import com.markit.ms.rfa.util.ErrorMessageBuilder;


public class BaseServiceImpl {

    @Autowired
    protected ErrorMessageBuilder messageBuilder;
 
    public String throwAppError(Exception exp, String errorCode, Object... params) throws RFAException {
        throw new RFAException(messageBuilder.buildErrorMessage(errorCode, params), exp);
    }

    public String throwAppError(String errorCode, Object... params) throws RFAException {
        throw new RFAException(messageBuilder.buildErrorMessage(errorCode, params));
    }

    public String throwAppError(String errorCode) throws RFAException {
        throw new RFAException(messageBuilder.buildErrorMessage(errorCode));
    }

    public String throwAppRuntimeError(String errorCode, Object... params) {
        throw new RFASystemException(messageBuilder.buildErrorMessage(errorCode, params));
    }

    public String throwAppRuntimeError(String errorCode) {
        throw new RFASystemException(messageBuilder.buildErrorMessage(errorCode));
    }

    public String throwAppRuntimeError(Exception exp, String errorCode, Object... params) throws RFAException {
        throw new RFASystemException(messageBuilder.buildErrorMessage(errorCode, params), exp);
    }

}
