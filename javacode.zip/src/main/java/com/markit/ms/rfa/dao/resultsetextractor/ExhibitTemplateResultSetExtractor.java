package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.bean.ExhibitTemplateColumn;
import com.markit.ms.rfa.util.CommonUtil;

public class ExhibitTemplateResultSetExtractor implements ResultSetExtractor<List<ExhibitTemplate>> {
	private boolean allowContent = true;
	public ExhibitTemplateResultSetExtractor (boolean allowContent) {
		this.allowContent = allowContent;
	}
	public List<ExhibitTemplate> extractData(ResultSet rs) throws SQLException {
		Map<Long, ExhibitTemplate> map = new LinkedHashMap<Long, ExhibitTemplate>();
		ExhibitTemplate exhibitTemplate = null;
		while (rs.next()) {
			Long id = rs.getLong("id");
			exhibitTemplate = map.get(id);
			if(null == exhibitTemplate) {
				exhibitTemplate = new ExhibitTemplate();
				exhibitTemplate.setId(rs.getLong("id"));
				exhibitTemplate.setName(rs.getString("name"));
				exhibitTemplate.setCompanyId(rs.getLong("companyid"));
				if(allowContent) {
					exhibitTemplate.setTextContent(CommonUtil.getValueFromBase64(rs.getBytes("text_content")));
					exhibitTemplate.setHtmlContent(CommonUtil.getValueFromBase64(rs.getBytes("html_content")));
				}
				exhibitTemplate.setCreatedBy(rs.getLong("created_by"));
				exhibitTemplate.setModifiedBy(rs.getLong("modified_by"));
				exhibitTemplate.setCreatedByString(rs.getString("created_by_string"));
				exhibitTemplate.setModifiedByString(rs.getString("modified_by_string"));
				exhibitTemplate.setCreatedDate(rs.getDate("created_date"));
				exhibitTemplate.setModifiedDate(rs.getDate("modified_date"));
				exhibitTemplate.setDeleted(rs.getLong("deleted"));
				exhibitTemplate.setAgreed(rs.getInt("agreed"));
				exhibitTemplate.setShowExhibitLink(Boolean.parseBoolean(rs.getString("showExhibitLink")));
				if(!allowContent){
					exhibitTemplate.setLinkedBy(rs.getLong("linked_by"));
					exhibitTemplate.setLinkedByString(rs.getString("linked_by_string"));
					exhibitTemplate.setLinkedDate(rs.getDate("linked_date"));
					exhibitTemplate.setAgreementDate(rs.getDate("agreementDate"));
					exhibitTemplate.setPartyATrueLegalName(rs.getString("partyATrueLegalName"));
					exhibitTemplate.setMasterlistIdentifier(rs.getString("masterlistIdentifier"));
				}
				map.put(id, exhibitTemplate);
			}
			if(allowContent){
				List<ExhibitTemplateColumn> columns = exhibitTemplate.getColumns();
				if(null == columns) {
					columns = new ArrayList<ExhibitTemplateColumn>();
					exhibitTemplate.setColumns(columns);
				}
				ExhibitTemplateColumn exhibitTemplateColumn = new ExhibitTemplateColumn();
				exhibitTemplateColumn.setId(rs.getLong("col_id"));
				exhibitTemplateColumn.setExhibitTemplateId(rs.getLong("rfa_exhibit_template_id"));
				exhibitTemplateColumn.setColumnName(rs.getString("column_name"));
				exhibitTemplateColumn.setColumnIndex(rs.getLong("column_index"));
				exhibitTemplateColumn.setColumnStyle(rs.getString("column_style"));
				exhibitTemplateColumn.setCreatedBy(rs.getLong("col_created_by"));
				exhibitTemplateColumn.setModifiedBy(rs.getLong("col_modified_by"));
				exhibitTemplateColumn.setCreatedByString(rs.getString("col_created_by_string"));
				exhibitTemplateColumn.setModifiedByString(rs.getString("col_modified_by_string"));
				exhibitTemplateColumn.setCreatedDate(rs.getDate("col_created_date"));
				exhibitTemplateColumn.setModifiedDate(rs.getDate("col_modified_date"));
				exhibitTemplateColumn.setDeleted(rs.getLong("col_deleted"));
				exhibitTemplateColumn.setControlColumn(rs.getInt("is_control_column") != 0 ? true : false );
				columns.add(exhibitTemplateColumn);
			}
		}
		return new ArrayList<ExhibitTemplate>(map.values());
	}
	
}
