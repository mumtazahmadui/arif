package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.util.CommonUtil;

public class MasterlistRowMapper implements RowMapper<Masterlist> {
	
	public Masterlist mapRow(ResultSet rs, int rowNum) throws SQLException {
		Masterlist masterlist = new Masterlist();
		masterlist.setId(rs.getLong("id"));
		masterlist.setMasterAgreementDate(rs.getDate("agreement_date"));
		masterlist.setMasterlistIdentifier(rs.getString("masterlist_identifier"));
		masterlist.setInvestmentManager(rs.getString("investment_manager"));
		masterlist.setPartyA(rs.getString("partyA"));
		masterlist.setLastUpdate(rs.getDate("modified_date"));
		masterlist.setCompanyId(rs.getLong("companyId"));
		masterlist.setAgreementType(rs.getString("agreement_type"));
		masterlist.setAgreementTypeId(rs.getLong("agreement_type_id"));
		masterlist.setMasterlistTemplateName(rs.getString("masterlist_template_name"));
		masterlist.setIsDeletable(rs.getBoolean("is_deletable"));
		if (CommonUtil.isNotNull(rs.getInt("totalRowCount"))) {
			masterlist.setTotalRowCount(rs.getInt("totalRowCount"));
		}
		return masterlist;
	}
}
