package com.markit.ms.rfa.controller;

import java.util.List;
import java.util.ListIterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.rfa.bean.TemplateField;
import com.markit.ms.rfa.dto.MasterlistTemplateSearchRequest;
import com.markit.ms.rfa.dto.RfaUploadTemplateSearchRequest;
import com.markit.ms.common.model.CommonBaseSearchResponse;
import com.markit.ms.common.util.DownloadUtil;
import com.markit.ms.rfa.bean.MasterlistTemplate;
import com.markit.ms.rfa.bean.RFAUploadTemplate;
import com.markit.ms.rfa.bean.RFAUploadTemplateField;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.IMasterlistTemplateService;
import com.markit.ms.rfa.service.IRfaUploadTemplateService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

/**
 * @author sucheta.krishali
 *
 */
@RestController
@RequestMapping(value = "/v1/upload_template")
@Api(value = "upload_template", description = "Upload Template APIs")
public class RFAUploadTemplateController {

	@Autowired
	private IRfaUploadTemplateService templateService;

	@RequestMapping(method = RequestMethod.POST)
	public RFAUploadTemplate saveUploadTemplate(@RequestBody RFAUploadTemplate uploadTemplate,
			HttpServletRequest request) throws RFAUIException {

		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);

		uploadTemplate.setCompanyId(companyIdFromSession);
		uploadTemplate.setCreatedBy(userIdFromSession);
		uploadTemplate.setModifiedBy(userIdFromSession);

		List<RFAUploadTemplateField> templateFields = uploadTemplate.getTemplateFields();

		ListIterator<RFAUploadTemplateField> itrTemplateFields = templateFields.listIterator();

		boolean isPartyBCI = false;
		boolean isPartyBTrueLegalName = false;
		boolean isSleeveClientIdentifier = false;
		boolean isSleeveTrueLegalName = false;

		boolean isSleeveTrueLegalNamePresent = false;
		boolean isSleeveClientIdentifierPresent = false;

		while (itrTemplateFields.hasNext()) {
			RFAUploadTemplateField templateField = itrTemplateFields.next();

			if (templateField.getFieldIdentifier().equals(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD)
					&& templateField.getEntityIdentifier() == 1)
				isPartyBTrueLegalName = true;

			if (templateField.getFieldIdentifier().equals(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD)
					&& templateField.getEntityIdentifier() == 1)
				isPartyBCI = true;

			if (templateField.getFieldIdentifier().equals(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD)) {
				isSleeveTrueLegalNamePresent = true;
				if (templateField.getEntityIdentifier() != null && templateField.getEntityIdentifier() == 1)
					isSleeveTrueLegalName = true;

			}

			if (templateField.getFieldIdentifier().equals(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD)) {
				isSleeveClientIdentifierPresent = true;
				if (templateField.getEntityIdentifier() != null && templateField.getEntityIdentifier() == 1)
					isSleeveClientIdentifier = true;

			}

		}

		if (!(isPartyBTrueLegalName ^ isPartyBCI)) {
			throw new RFAUIException(RFAConstants.RFA_UPLOAD_TEMPLATE_ENTITY_IDENTIFIER, HttpStatus.OK.toString());
		}

		if (isSleeveTrueLegalNamePresent || isSleeveClientIdentifierPresent) {
			if (!(isSleeveTrueLegalName ^ isSleeveClientIdentifier)) {
				throw new RFAUIException(RFAConstants.RFA_UPLOAD_TEMPLATE_SLEEVE, HttpStatus.OK.toString());

			}
		}
		uploadTemplate = templateService.saveUploadTemplate(uploadTemplate);
		return uploadTemplate;
	}

	@RequestMapping(value = "/{templateId}", method = RequestMethod.DELETE)
	@ApiOperation(value = "Delete Upload Template")
	public void deleteUploadTemplate(@PathVariable Long templateId) throws RFAException {
		templateService.deleteUploadTemplateById(templateId);
	}

	@RequestMapping(value = "/{templateId}", method = RequestMethod.GET)
	public RFAUploadTemplate getUploadTemplate(@PathVariable Long templateId) throws RFAException {

		RFAUploadTemplate uploadTemplate = templateService.getUploadTemplate(templateId);
		return uploadTemplate;
	}

	@RequestMapping(value = "/{templateId}", method = RequestMethod.PUT)
	public RFAUploadTemplate editUploadTemplate(@PathVariable Long templateId,
			@RequestBody RFAUploadTemplate uploadTemplate, HttpServletRequest request) throws RFAUIException {

		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		Long userIdFromSession = CommonUtil.getUserIdFromSession(request);

		uploadTemplate.setCompanyId(companyIdFromSession);
		uploadTemplate.setCreatedBy(userIdFromSession);
		uploadTemplate.setModifiedBy(userIdFromSession);
		uploadTemplate.setId(templateId);
		uploadTemplate = templateService.editUploadTemplate(uploadTemplate);
		return uploadTemplate;
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	@ApiOperation(value = "Get Upload Template Grid")
	public CommonBaseSearchResponse<RFAUploadTemplate> getUploadTemplateGrid(
			@RequestBody RfaUploadTemplateSearchRequest templateSearchRequest, HttpServletRequest request)
			throws Exception {

		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		List<RFAUploadTemplate> uploadTemplates = templateService.getUploadTemplateGrid(companyIdFromSession,
				templateSearchRequest);

		CommonBaseSearchResponse<RFAUploadTemplate> commonBaseSearchResponse = new CommonBaseSearchResponse<RFAUploadTemplate>();
		commonBaseSearchResponse.setDataList(uploadTemplates);

		if (uploadTemplates.size() > 0)
			commonBaseSearchResponse.setTotalCount(uploadTemplates.get(0).getTotalRowCount());
		return commonBaseSearchResponse;
	}

	@RequestMapping(value = "/{templateId}/export", method = RequestMethod.GET)
	@ApiOperation(value = "Download Upload Template")
	public String downloadUploadTemplate(@PathVariable Long templateId, HttpServletResponse response,
			HttpServletRequest request) throws Exception {
		String fileName = "Upload_Template.xlsx";
		DownloadUtil.downloadFileBySXSSFWorkbook(response, templateService.downloadUploadTemplate(templateId),
				fileName);
		return "";
	}

}