package com.markit.ms.rfa.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.markit.fileutil.common.domain.MCFile;
import com.markit.fileutil.file.service.IFileUtilService;
import com.markit.ms.rfa.dao.ITermsOfUseDao;
import com.markit.ms.rfa.service.ITermsOfUseService;
@Service
public class TermsOfUseServiceImpl implements ITermsOfUseService {

	@Resource IFileUtilService fileUtil;
	
	@Resource ITermsOfUseDao termsOfUseDao;
	
	@Override
	@Transactional
	public void saveTermsOfUse(byte[] fileBytes, String version, Long companyId, Long userId) throws Exception {
		MCFile file = fileUtil.saveFile("RFAtermsofuse.pdf", fileBytes, companyId, userId);
		termsOfUseDao.updateTermsOfUse(file.getFileId(),version,userId);
	}
	
}
