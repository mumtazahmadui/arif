package com.markit.ms.rfa.bean;

import java.util.Map;

import com.markit.ms.rfa.command.notifier.impl.SignatoryEmailNotifier.NotificationData;

public class BulkEmailVelocityTemplateValues {

	private String fname;

	private String email;
	private String login;
	private Map<String, String> rfaUrls;
	
	private Map<String, NotificationData> signatoryData;

	private String customMessage;
	
	private String senderName;
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getCustomMessage() {
		return customMessage;
	}

	public void setCustomMessage(String customMessage) {
		this.customMessage = customMessage;
	}

	public Map<String, NotificationData> getSignatoryData() {
		return signatoryData;
	}

	public void setSignatoryData(Map<String, NotificationData> signatoryData) {
		this.signatoryData = signatoryData;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Map<String, String> getRfaUrls() {
		return rfaUrls;
	}

	public void setRfaUrls(Map<String, String> rfaUrls) {
		this.rfaUrls = rfaUrls;
	}

}