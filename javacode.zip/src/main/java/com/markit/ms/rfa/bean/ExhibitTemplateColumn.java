package com.markit.ms.rfa.bean;

import java.util.Date;

public class ExhibitTemplateColumn {
	
	private Long id;
	private Long exhibitTemplateId;
	private String columnName;
	private Long columnIndex;
	private String columnStyle;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private String createdByString;
	private String modifiedByString;
	private Long deleted;
	private boolean isControlColumn;
	private boolean isReinitialized = false;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getExhibitTemplateId() {
		return exhibitTemplateId;
	}
	public void setExhibitTemplateId(Long exhibitTemplateId) {
		this.exhibitTemplateId = exhibitTemplateId;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public Long getColumnIndex() {
		return columnIndex;
	}
	public void setColumnIndex(Long columnIndex) {
		this.columnIndex = columnIndex;
	}
	public String getColumnStyle() {
		return columnStyle;
	}
	public void setColumnStyle(String columnStyle) {
		this.columnStyle = columnStyle;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCreatedByString() {
		return createdByString;
	}
	public void setCreatedByString(String createdByString) {
		this.createdByString = createdByString;
	}
	public String getModifiedByString() {
		return modifiedByString;
	}
	public void setModifiedByString(String modifiedByString) {
		this.modifiedByString = modifiedByString;
	}
	public Long getDeleted() {
		return deleted;
	}
	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}
	public boolean isControlColumn() {
		return isControlColumn;
	}
	public void setControlColumn(boolean isControlColumn) {
		this.isControlColumn = isControlColumn;
	}
	public boolean isReinitialized() {
		return isReinitialized;
	}
	public void setReinitialized(boolean isReinitialized) {
		this.isReinitialized = isReinitialized;
	}
}
