package com.markit.ms.rfa.service;

public interface ISignaturePlaceholderService
{
	Integer getBsSignaturePlaceholderCount(Long amenmentId);
	
	Integer getSsSignaturePlaceholderCount(Long amenmentId);
	
	Integer getBsSignatureCount(Long amenmentId);
	
	Integer getSsSignatureCount(Long amenmentId);
}
