package com.markit.ms.rfa.service;

import java.util.List;
import java.util.Map;

import com.markit.ms.common.model.CommonFileResponse;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.PartyBEntity;


public interface IAmendmentLettterPDFService {
	
	public CommonFileResponse generateErrorPDF(Long companyId, Map<String, List<PartyBEntity>> addPartyBErrorMap
			, Map<String, List<PartyBEntity>> removePartyBErrorMap, Map<String, List<PartyBEntity>> modifiedPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveRequestedOnAnotherRfaErrorMap, Map<String, List<PartyBEntity>> sleeveRemovalPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveExistsOnActiveTabErrorMap, Map<String, List<PartyBEntity>> sleeveParentNotOnActiveTabErrorMap
			, Map<String, List<PartyBEntity>> sleevesInProgressErrorMap
			, List<PartyBEntity> rejectedRecalledPartybList, Map<Long, AmendmentLetter> additionPlaceholderErrorMap
			, Map<Long, AmendmentLetter> removalPlaceholderErrorMap, Map<Long, AmendmentLetter> modificationPlaceholderErrorMap
			, Map<String, String> letterTemplateMap, Long userId) throws Exception;
}
