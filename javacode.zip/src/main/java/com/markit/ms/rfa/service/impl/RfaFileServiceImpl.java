package com.markit.ms.rfa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.dao.IRfaFileDao;
import com.markit.ms.rfa.service.IRfaFileService;

@Service
public class RfaFileServiceImpl implements IRfaFileService {
	
	@Autowired
	private IRfaFileDao rfaFileDao;

	@Override
	public void saveRfaFile(Long fileId, String action, Long userId) {
		rfaFileDao.saveRfaFile(fileId, action, userId);
	}

	@Override
	public void saveRfaFileToAmendment(Long fileId, List<Long> rfaIds) {
		for (Long rfaId : rfaIds) {
			rfaFileDao.saveRfaFileToAmendment(fileId, rfaId);
		}
	}

	@Override
	public List<Long> getRfaIdByFileId(Long fileId) {
		return rfaFileDao.getRfaIdByFileId(fileId);
	}
}
