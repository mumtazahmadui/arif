package com.markit.ms.rfa.dto;

import java.util.ArrayList;
import java.util.List;

import com.markit.ms.common.bean.User;

public class RfaEmailNotification {
	private List<User> emailRecipients;
	private List<Long> rfaIds;
	private boolean isESign;
	private boolean isWSign;
	private String customNotificationMessage;
	
	public boolean getIsESign() {
		return isESign;
	}

	public void setIsESign(boolean isESign) {
		this.isESign = isESign;
	}

	public boolean getIsWSign() {
		return isWSign;
	}

	public void setIsWSign(boolean isWSign) {
		this.isWSign = isWSign;
	}

	public String getCustomNotificationMessage() {
		return customNotificationMessage;
	}

	public void setCustomNotificationMessage(String customNotificationMessage) {
		this.customNotificationMessage = customNotificationMessage;
	}

	public RfaEmailNotification() {
		emailRecipients = new ArrayList<User>();
		rfaIds = new ArrayList<Long>();
	}
	
	public List<User> getEmailRecipients() {
		return emailRecipients;
	}
	public void setEmailRecipients(List<User> emailRecipients) {
		this.emailRecipients = emailRecipients;
	}
	public List<Long> getRfaIds() {
		return rfaIds;
	}
	public void setRfaIds(List<Long> rfaIds) {
		this.rfaIds = rfaIds;
	}	
}
