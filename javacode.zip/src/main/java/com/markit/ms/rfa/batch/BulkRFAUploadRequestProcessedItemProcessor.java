package com.markit.ms.rfa.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.transaction.support.TransactionTemplate;

import com.markit.kyc.security.service.userxs.ServiceUserSessionManager;
import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.Exhibit;
import com.markit.ms.rfa.bean.ExhibitCell;
import com.markit.ms.rfa.bean.ExhibitColumn;
import com.markit.ms.rfa.bean.ExhibitTemplateColumn;
import com.markit.ms.rfa.bean.ExhibitValueChange;
import com.markit.ms.rfa.bean.FundNameChange;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.SleeveEntityRequest;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IAmendmentLetterDao;
import com.markit.ms.rfa.dao.IEntityDao;
import com.markit.ms.rfa.dao.IRfaUploadTemplateDAO;
import com.markit.ms.rfa.service.IAmendmentContentModifier;
import com.markit.ms.rfa.service.IAmendmentLetterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

public class BulkRFAUploadRequestProcessedItemProcessor
		implements ItemProcessor<Map<Long, List<RfaBulkUploadRow>>, Map<Long, List<AmendmentLetter>>> {

	private static final Logger logger = LoggerFactory.getLogger(BulkRFAUploadRequestProcessedItemProcessor.class);

	private TransactionTemplate transactionTemplate;

	private Long companyId;

	private Long bulkRequestId;

	List<RfaBulkUploadRow> errorRowList;

	@Autowired
	IRfaUploadTemplateDAO uploadTemplateDAO;

	@Autowired
	private IAmendmentLetterService amendmentLetterService;

	@Autowired
	IAmendmentContentModifier amendmentContentModifier;

	@Autowired
	private IEntityDao entityDao;

	@Autowired
	private IAmendmentLetterDao amendmentLetterDao;

	@Value("#{jobParameters['mcpmCreateSleeveEntityUrl']}")
	private String mcpmCreateSleeveEntityUrl;

	@Resource(name = "rsServiceUserSessionManager")
	private ServiceUserSessionManager serviceUserSessionManager;

	@BeforeStep
	public void initializeValues(StepExecution stepExecution) {
		errorRowList = (List<RfaBulkUploadRow>) stepExecution.getJobExecution().getExecutionContext()
				.get("errorRowList");
		if (CommonUtil.isNull(errorRowList)) {
			errorRowList = new ArrayList<RfaBulkUploadRow>();
			stepExecution.getJobExecution().getExecutionContext().put("errorRowList", errorRowList);
		}
	}

	@Override
	public Map<Long, List<AmendmentLetter>> process(Map<Long, List<RfaBulkUploadRow>> map) throws Exception {

		AmendmentLetter amendmentLetter;
		Long companyId = null;
		RfaBulkUploadRow rfaBulkUploadRow = null;
		Map<Long, List<AmendmentLetter>> rfaList = new HashMap<Long, List<AmendmentLetter>>();
		List<AmendmentLetter> amendmentLetterList = new ArrayList<AmendmentLetter>();

		for (Long letterKey : map.keySet()) {

			List<RfaBulkUploadRow> listOfRfaRow = map.get(letterKey);

			List<PartyBEntity> partyBEntities = new ArrayList<PartyBEntity>();
			amendmentLetter = new AmendmentLetter();
			Exhibit exhibit = null;
			List<ExhibitColumn> exhibitColList = new ArrayList<ExhibitColumn>();
			ExhibitColumn exhibitCol = null;
			List<ExhibitCell> exhibitCellList = null;
			ExhibitCell exhibitCell = null;
			boolean isExhibitFullyValued = true;
			boolean hasSleeveForAddition = false;
			boolean hasSleeveForRemoval = false;
			Map<Long, RfaBulkUploadRow> rows = new HashMap<>();
			SleeveEntityRequest sleeveEntity = new SleeveEntityRequest();
			Map<Long, Exhibit> partyBExhibitMap = new HashMap<>();

			try {
				for (RfaBulkUploadRow rfaRow : listOfRfaRow) {
					for (BulkUploadAction action : rfaRow.getRequestIdentified()) {
						if (!letterKey.equals(rfaRow.getLetterTemplate().get(action).getId())) {
							// This is to check if there are different letter template and multiple action
							// on same partyB
							continue;
						}
						rfaBulkUploadRow = rfaRow;
						try {
							companyId = rfaRow.getLetterTemplate().get(action).getCompanyId();
							if (CommonUtil.isNotNull(rfaRow.getSleeveEntityId())
									&& (action == BulkUploadAction.SLEEVE_ADDITION)) {
								linkSleeveParentEntity(rfaRow, sleeveEntity);
							}
							amendmentLetter.setLetterTemplateId(rfaRow.getLetterTemplate().get(action).getId());
							amendmentLetter.setContent(rfaRow.getLetterTemplate().get(action).getContent());
							amendmentLetter.setCreatedBy(rfaRow.getLetterTemplate().get(action).getCreatedBy());
							amendmentLetter.setCreationFlow(RFAConstants.BULK);
							amendmentLetter.setMasterAgreement(rfaRow.getMasterAgreement());
							rows.put(rfaRow.getPartyBEntityId(), rfaRow);

							PartyBEntity partyBEntity = new PartyBEntity();
							Entity entity = new Entity();
							entity.setId(rfaRow.getPartyBEntityId());
							if (action == BulkUploadAction.ADDITION) {
								partyBEntity.setIsAdded(true);
								entity.setIsSleeve(0L);
							} else if (action == BulkUploadAction.FNC) {
								partyBEntity.setIsModified(true);
								partyBEntity.setIsAdded(true);
								entity.setIsSleeve(0L);
								setFundNameChange(partyBEntity, rfaRow);
							} else if (action == BulkUploadAction.EVC) {
								partyBEntity.setIsModified(true);
								partyBEntity.setIsAdded(true);
								entity.setIsSleeve(0L);
								ExhibitValueChange exhibitValueChange = new ExhibitValueChange();
								exhibitValueChange.setComment(RFAConstants.EVC_CHANGE_COMMENT);
								partyBEntity.setExhibitValueChange(exhibitValueChange);
							} else if (action == BulkUploadAction.SLEEVE_ADDITION) {
								entity.setIsSleeve(1L);
								partyBEntity.setIsAdded(true);
								hasSleeveForAddition = true;
								entity.setId(rfaRow.getSleeveEntityId());
								rows.put(rfaRow.getSleeveEntityId(), rfaRow);
							} else if (action == BulkUploadAction.REMOVAL) {
								entity.setIsSleeve(0L);
								partyBEntity.setIsAdded(false);
								partyBEntity.setIsModified(false);
							} else if (action == BulkUploadAction.SLEEVE_REMOVAL) {
								rows.put(rfaRow.getSleeveEntityId(), rfaRow);
								entity.setIsSleeve(1L);
								partyBEntity.setIsAdded(false);
								partyBEntity.setIsModified(false);
								entity.setId(rfaRow.getSleeveEntityId());
								hasSleeveForRemoval = true;
							}
							partyBEntity.setEntity(entity);
							partyBEntities.add(partyBEntity);

							List<Long> parentEntityIds = new ArrayList<Long>();
							parentEntityIds.add(partyBEntity.getEntity().getId());
							List<Long> masterAgreementIds = new ArrayList<Long>();
							masterAgreementIds.add(amendmentLetter.getMasterAgreement().getId());
							List<Entity> sleeveEntities = new ArrayList<>();
							if (partyBEntity.getEntity().getIsSleeve() == 0) {
								sleeveEntities = entityDao.getSleeveAccountsForParentEntities(companyId,
										masterAgreementIds, parentEntityIds);
							}
							if (sleeveEntities != null && sleeveEntities.size() > 0
									&& (partyBEntity.getEntity().getIsSleeve() == 0) && !partyBEntity.getIsAdded()) {
								hasSleeveForRemoval = true;
							}

							exhibit = new Exhibit();
							exhibitColList = new ArrayList<ExhibitColumn>();
							if (CommonUtil.isNull(exhibit.getColumns())
									&& (action != BulkUploadAction.FNC && action != BulkUploadAction.SLEEVE_REMOVAL)) {
								for (ExhibitTemplateColumn exhibitTemplateColumn : rfaRow.getExhibitTemplate()
										.getColumns()) {
									exhibitCol = new ExhibitColumn();
									exhibitCellList = new ArrayList<ExhibitCell>();
									exhibitCol.setColumnName(exhibitTemplateColumn.getColumnName());
									exhibitCol.setCells(exhibitCellList);
									exhibitColList.add(exhibitCol);
								}
								exhibit.setColumns(exhibitColList);
								boolean exhibitValued = false;
								for (ExhibitColumn column : exhibit.getColumns()) {
									String columnValue = "";
									if (rfaRow.getExhibitData() != null
											&& rfaRow.getExhibitData().get(column.getColumnName()) != null) {
										if (action != BulkUploadAction.SLEEVE_ADDITION) {
											columnValue = rfaRow.getExhibitData().get(column.getColumnName()).trim();
										}
										exhibitValued = true;
									}
									exhibitCell = new ExhibitCell();
									exhibitCell.setPartyBEntityId(partyBEntity.getEntity().getId());
									exhibitCell.setValue(columnValue);
									column.getCells().add(exhibitCell);
								}
								exhibit.setColumns(exhibitColList);
								if (CommonUtil.isNotNull(partyBExhibitMap.get(partyBEntity.getEntity().getId()))) {
									if (exhibitValued && action == BulkUploadAction.EVC) {
										partyBExhibitMap.put(partyBEntity.getEntity().getId(), exhibit);
									}
								} else {
									partyBExhibitMap.put(partyBEntity.getEntity().getId(), exhibit);
								}
							}
							if (!rfaRow.isExhibitFullyValued())
								isExhibitFullyValued = false;
						} catch (Exception e) {
							errorRowList.add(rfaBulkUploadRow);
							logger.error("Exception in creating PartyB list");
						}
					}
				}
				amendmentLetter.setExhibitValued(isExhibitFullyValued);
				amendmentLetter.setPartyBEntities(partyBEntities);
				amendmentLetter.setBulkRequestId(bulkRequestId);
				amendmentLetter.setExhibit(exhibit);
				amendmentLetter.setPartyBExhibitMap(partyBExhibitMap);
				amendmentLetter.setRfaBulkUploadRows(rows);

				if (hasSleeveForAddition || hasSleeveForRemoval) {
					String updatedContent = amendmentContentModifier.insertSleevePlaceholder(amendmentLetter);
					amendmentLetter.setContent(updatedContent);
				}
				String updatedContent = amendmentContentModifier.insertDatePinnedPlaceholder(amendmentLetter);
				amendmentLetter.setContent(updatedContent);
				amendmentLetterList.add(amendmentLetter);
				rfaList.put(amendmentLetter.getMasterAgreement().getId(), amendmentLetterList);
			} catch (Exception e) {
				errorRowList.add(rfaBulkUploadRow);
				logger.error("Exception in creating RFA");
				e.printStackTrace();
			}
		}

		return rfaList;

	}

	private PartyBEntity getNewPartyBForExhibit(Long partyBEntityId) {
		PartyBEntity exhibitPartyBEntity = new PartyBEntity();
		Entity exhibitEntity = new Entity();
		exhibitEntity.setId(partyBEntityId);
		exhibitPartyBEntity.setIsModified(true);
		exhibitPartyBEntity.setIsAdded(true);
		exhibitEntity.setIsSleeve(0L);
		ExhibitValueChange exhibitValueChange = new ExhibitValueChange();
		exhibitValueChange.setComment(RFAConstants.EVC_CHANGE_COMMENT);
		exhibitPartyBEntity.setExhibitValueChange(exhibitValueChange);
		exhibitPartyBEntity.setEntity(exhibitEntity);
		return exhibitPartyBEntity;
	}

	private void setFundNameChange(PartyBEntity partyBEntity, RfaBulkUploadRow rfaRow) {
		Entity entity = entityDao.getEntity(rfaRow.getPartyBEntityId(), rfaRow.getMasterAgreementId());

		Entity masterlistEntity = null;
		MapSqlParameterSource params = new MapSqlParameterSource()
				.addValue("master_agreement_id", rfaRow.getMasterAgreementId())
				.addValue("entity_id", rfaRow.getPartyBEntityId());
		masterlistEntity = amendmentLetterDao.getMasterlistEntity(rfaRow.getPartyBEntityId(),
				rfaRow.getMasterAgreementId());

		FundNameChange fundNameChange = new FundNameChange();
		fundNameChange.setCurrentClientIdentifier(masterlistEntity.getClientIdentifier());
		fundNameChange.setCurrentTrueLegalName(rfaRow.getPartyBTrueLegalName());
		fundNameChange.setCurrentLei(masterlistEntity.getLei());
		fundNameChange.setUpdateMcpmClientIdentifier(false);
		fundNameChange.setUpdateMcpmLegalName(false);
		fundNameChange.setUpdateMcpmLei(false);
		partyBEntity.setFundNameChange(fundNameChange);
	}

	private void linkSleeveParentEntity(RfaBulkUploadRow rfaBulkUploadRow, SleeveEntityRequest sleeveEntity) {
		Long parentEntityId = rfaBulkUploadRow.getPartyBEntityId();
		Boolean sleeveLinked = checkParentSleeveLinkage(parentEntityId, rfaBulkUploadRow.getSleeveEntityId(),
				companyId);
		if (CommonUtil.isNotNull(rfaBulkUploadRow.getSleeveEntityId()) && !sleeveLinked) {
			uploadTemplateDAO.linkSleeveAndParent(parentEntityId, rfaBulkUploadRow.getSleeveEntityId(), companyId);
		}
	}

	private Boolean checkParentSleeveLinkage(Long parentEntityId, Long sleeveEntityId, Long companyId) {
		Long SleeveParentEntityId = uploadTemplateDAO.getSleeveParentEntityId(sleeveEntityId, companyId);
		if (CommonUtil.isNotNull(SleeveParentEntityId) && SleeveParentEntityId.equals(parentEntityId))
			return true;
		else
			return false;
	}

	/* SPRING RELATED METHODS */
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

}
