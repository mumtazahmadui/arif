package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.common.bean.Entity;

public class AgreementDateResultSetExtractor implements
		ResultSetExtractor<List<Date>> {

	@Override
	public List<Date> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		List<Date> dates = new ArrayList<Date>();
		while(rs.next()){
			dates.add(rs.getDate("agreement_date"));
		}
		return dates;
	}

	
/*	@Override
	public List<Entity> extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		Map<Long, Entity> imMap = new HashMap<Long, Entity>();
		while(rs.next()){
			Entity entity = imMap.get(rs.getLong("entityid"));
			if(entity == null){
				entity = new Entity();
				entity.setName(rs.getString("legal_Name"));
				entity.setId(rs.getLong("entityid"));
				imMap.put(rs.getLong("entityid"), entity);
			}
		}
		List<Entity> entities = new ArrayList<Entity>(imMap.values());
		return entities;
	}*/
	
}
