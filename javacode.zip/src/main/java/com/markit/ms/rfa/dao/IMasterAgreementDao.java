package com.markit.ms.rfa.dao;

import java.sql.Date;
import java.util.List;

import com.markit.ms.common.model.MasterAgreementSearchRequest;
import com.markit.ms.rfa.bean.AmendmentStatusObject;
import com.markit.ms.rfa.bean.MasterAgreement;
import com.markit.ms.rfa.bean.MasterAgreementHistory;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;

public interface IMasterAgreementDao {
	public List<MasterAgreement> getMasterAgreements(long companyId, MasterAgreementSearchRequest searchRequest);
	public List<PartyBEntity> getExistingPartyBListForValidation(Long masterAgreementId, List<Long> partyBEntityIds,Long amendmentId);
	public MasterAgreementHistory getMasterAgreementHistory(Long companyId, Long agreementId);
	public Date getMasterAgreementDateById(Long masterAgreementId);
	public List<AmendmentStatusObject> getAmendmentStatusOfModifiedEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId);
	public String getAmendmentStatusOfFNCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId);
	public String getAmendmentStatusOfEVCEntityNotYetResponded(Long masterAgreementId, Long amendmentId, Long entityId);
	public String getMasterlistTrueLegalName(Long entityId, Long masterAgreementId);
	public String getRequestTypeForValidation(Long partybId);
	public String getMasterlistMlTemplateName(Long masterAgreementId);
	public String getMlTemplateWithSleeve(Long masterAgreementId);
	public String getMlTemplateWithSleeveByAmednment(Long amendmentId);
	public void updateMasterAgreement(Long amendmentId);
	public MasterAgreement getMasterAgreementById(Long masterAgreementId);
	public RfaBulkUploadRow checkMasterListExhibitLinkage (RfaBulkUploadRow rfaBulkUploadRow);
	public List<PartyBEntity> getExistingPartyBListForValidation(Long masterAgreementId, List<Long> partyBEntityIds,
			Long amendmentId, String callingSource);
}
