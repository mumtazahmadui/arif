package com.markit.ms.rfa.controller;

import static com.markit.ms.rfa.util.RFAConstants.CONTENT_TYPE_XLSX;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.markit.fileutil.common.domain.MCFile;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.domain.Grid.Row;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.util.CommonDownloadUtil;
import com.markit.ms.rfa.bean.NewExhibitRequest;
import com.markit.ms.rfa.bean.TemplateField;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.validator.impl.NextStepPdfGenerator;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.INewExhibitService;
import com.markit.ms.rfa.service.IRfaFileService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1/batches/templates")
@Api(value = "Batches" , description = "Batch APIs")
public class BatchController {
	
	private static Logger LOGGER = LoggerFactory.getLogger(BatchController.class);
			
	private static final int ADDIONTAL_INFO_INDEX = 3;
	
	private static final int HEADER_ROW_INDEX = 6;
	
	private static final String FILE_NAME = "Exhibit Template";
	
	private static final String SHEET_NAME = "BulkDownloadExhibitMetadata";
	
	private static final String TEMPLATE_NAME = "Export_Template.xlsx";
	
	private static final String RFA_ID = "RFA ID";
	
	private static final String EXHIBIT_VALUE = "exhibit-value";
	
	private static final String EXCEL_FILE = "xlsx";
	
	private static final String ACTION = "BULK_UPLOAD_EXHIBIT_TEMPLATE";
	
	private static final String EXHIBIT_UPLOAD_ERROR_MESSAGE = "Exhibit value(s) not provided in the bulk upload file. Following RFA(s) will remain in it's current state of 'Edit Linked Exhibit'.";
		
	@Autowired
	private IFileService fileService;
	
	@Autowired
	private IRfaFileService rfaFileService;
	
	@Autowired
	private INewExhibitService newExhibitService;
	
	@Autowired
	private NextStepPdfGenerator nextStepPdfGenerator;
	
	@Resource
	private QueryService<Grid> downloadExhibitTemplate;
	
	@Resource
	private QueryService<Grid> getCommonInfo;
	
	@Resource
	private QueryService<Grid> getMltIdentifierLabelMapByRfaId;
	
	@Resource
	private QueryService<Grid> getMltInfoByRfaId;
	
	@RequestMapping(method = RequestMethod.POST, produces = CONTENT_TYPE_XLSX)
	@ApiOperation(value = "Download Template")
	@ResponseStatus(value = HttpStatus.CREATED)
	public void downloadTemplate(@RequestBody List<Long> rfaIdList, @RequestParam String type, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		if (EXHIBIT_VALUE.equalsIgnoreCase(type)) {
			Long fileId = downloadExhibitTemplate(rfaIdList, request);
			WebUtils.addLocationHeaderToResponse(response, "/v1/company/" + companyId + "/files/download_file/" + fileId);
			return;
		}
		throw new IllegalArgumentException();
	}

	@RequestMapping(method = RequestMethod.POST, produces = CONTENT_TYPE_XLSX, params = "ie-9")
	@ApiOperation(value = "Download Template for IE9")
	public @ResponseBody ResponseEntity<String> downloadTemplateIE9(@RequestBody List<Long> rfaIdList, @RequestParam String type,
			HttpServletRequest request) throws Exception {
		if (EXHIBIT_VALUE.equalsIgnoreCase(type)) {
			Long fileId = downloadExhibitTemplate(rfaIdList, request);
			String result = "<textarea data-type=\"application/json\"> [{\"fileId\":\"" + fileId + "\"}]</textarea>";
			return new ResponseEntity<String>(result, HttpStatus.CREATED);
		}
		throw new IllegalArgumentException();
	}
	
	private Map<String, Map<String, TemplateField>> getMltFieldInfoMapByRfaId(List<Long> rfaIdList){
		long start = System.currentTimeMillis();
		Map<String, Map<String, TemplateField>> fieldInfoRfaIdMap = new HashMap<String, Map<String, TemplateField>>();
		
		Map<String, Object> params = new HashMap<>();
		params.put("rfaIdList", rfaIdList);	
		Grid mltIdentifierLabelGrid = getMltInfoByRfaId.executeQuery(params);
		
		Map<String, List<Grid.Row>> fieldIdLabelInfoRowMap = new HashMap<>();
		for (Row row : mltIdentifierLabelGrid.getRowList()) {
			String key = row.get("RFA_ID");
			fieldIdLabelInfoRowMap.putIfAbsent(key, new ArrayList<Grid.Row>());
			fieldIdLabelInfoRowMap.get(key).add(row);
		}
		
		Set<String> rfaIds =  fieldIdLabelInfoRowMap.keySet();
		for(String rfaId : rfaIds){
			List<Grid.Row> fieldIdLabelInfoRows = fieldIdLabelInfoRowMap.get(rfaId);
			Map<String, TemplateField> fieldIdInfoMap= new HashMap<String, TemplateField>();
			
			for(Grid.Row fieldIdLabelInfoRow :fieldIdLabelInfoRows){
				Integer field_visibility = fieldIdLabelInfoRow.get("field_visibility")!=null? Integer.valueOf(fieldIdLabelInfoRow.get("field_visibility")): null;
				Integer field_order = fieldIdLabelInfoRow.get("field_order")!=null? Integer.valueOf(fieldIdLabelInfoRow.get("field_order")): null;
				
				TemplateField tempField = new TemplateField(fieldIdLabelInfoRow.get("field_identifier"), fieldIdLabelInfoRow.get("field_label"), field_visibility, field_order);
				
				fieldIdInfoMap.put(fieldIdLabelInfoRow.get("field_identifier"), tempField);
				fieldIdInfoMap.put("RFA ID", new TemplateField("RFA ID", "RFA ID", 1, null));				
			}
			fieldIdInfoMap = sortMapByFieldOrder(fieldIdInfoMap);
			fieldInfoRfaIdMap.put(rfaId, fieldIdInfoMap);			
		}
		LOGGER.info("### getMltFieldInfoMapByRfaId took : " + (System.currentTimeMillis() - start));
		return fieldInfoRfaIdMap;
	}
	
	private Map<String, TemplateField> sortMapByFieldOrder(Map<String, TemplateField> fieldIdInfoMap){
		
		Comparator<Map.Entry<String, TemplateField>> byFieldOrderComp = new Comparator<Map.Entry<String, TemplateField>>() {
	        public int compare(Map.Entry<String, TemplateField> left, Map.Entry<String, TemplateField> right) {
	        	TemplateField tf1 =  left.getValue();
	    		Integer fo1 = tf1.getFieldOrder();
	    		TemplateField tf2 =  right.getValue();
	    		Integer fo2 = tf2.getFieldOrder();
	            return (fo1==null)? (fo2==null?0:1)  : (fo2==null?-1:fo1.compareTo(fo2));
	        }
	    };

	    List<Map.Entry<String, TemplateField>> tfMEList = new ArrayList<Map.Entry<String, TemplateField>>();

	    tfMEList.addAll(fieldIdInfoMap.entrySet());

	    Collections.sort(tfMEList, byFieldOrderComp);
 		
		Map<String, TemplateField> fieldIdInfoMapOut = new LinkedHashMap<String, TemplateField>();
	    for (Map.Entry<String, TemplateField> entry : tfMEList)
	    {
	    	fieldIdInfoMapOut.put( entry.getKey(), entry.getValue() );
	    }
	    return fieldIdInfoMapOut;
		
	}

	private Long downloadExhibitTemplate(List<Long> rfaIdList, HttpServletRequest request) {
		
		Long userId = CommonUtil.getUserIdFromSession(request);
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		Map<String, Object> params = new HashMap<>();
		params.put("rfaIdList", rfaIdList);
		
		Grid exhibitTemplateGrid = downloadExhibitTemplate.executeQuery(params);
		Map<String, List<Grid.Row>> exhibitTemplateRowMap = new HashMap<>();
		for (Row row : exhibitTemplateGrid.getRowList()) {
			String key = row.get(RFA_ID);
			exhibitTemplateRowMap.putIfAbsent(key, new ArrayList<Grid.Row>());
			exhibitTemplateRowMap.get(key).add(row);
		}
		Grid commonInfoGrid = getCommonInfo.executeQuery(params);
		Map<String, List<Grid.Row>> commonInfoRowMap = new HashMap<>();
		for (Row row : commonInfoGrid.getRowList()) {
			String key = row.get(RFA_ID);
			commonInfoRowMap.putIfAbsent(key, new ArrayList<Grid.Row>());
			commonInfoRowMap.get(key).add(row);
		}

		Map<String, Map<String, TemplateField>> fieldInfoRfaIdMap = getMltFieldInfoMapByRfaId(rfaIdList);
		
		InputStream inputStream = AmendmentLetterBulkActionController.class.getClassLoader().getResourceAsStream(TEMPLATE_NAME);
		byte[] bytes = CommonDownloadUtil.exportGridToExcel(exhibitTemplateRowMap, commonInfoRowMap, ADDIONTAL_INFO_INDEX, HEADER_ROW_INDEX,
				SHEET_NAME, FILE_NAME, inputStream, fieldInfoRfaIdMap);
		MCFile mcFile = fileService.saveFile(FILE_NAME + "." + EXCEL_FILE, bytes, companyId, userId);
		return mcFile.getFileId();
	}
	
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@ApiOperation(value = "Upload Exhibit Template")
	public @ResponseBody ResponseEntity<String> uploadExhibitTemplate(@RequestParam List<Long> rfaIdList, @RequestParam String type,
			@RequestParam String fileName, @RequestParam final MultipartFile file, HttpServletResponse response, HttpServletRequest request)
			throws Exception {

		if (EXHIBIT_VALUE.equalsIgnoreCase(type)) {
			Long userId = CommonUtil.getUserIdFromSession(request);
			Long companyId = CommonUtil.getCompanyIdFromSession(request);

			if(!FilenameUtils.isExtension(fileName,EXCEL_FILE)){
				throw new RFAUIException(RFAConstants.INCORRECT_FILE_EXTENSION, HttpStatus.OK.toString());
			}
			MCFile mcFile = fileService.saveFile(fileName + "." + EXCEL_FILE, file.getBytes(), companyId, userId);
			Long fileId = mcFile.getFileId();
			rfaFileService.saveRfaFile(fileId, ACTION, userId);

			List<Long> invalidRfaIds = getInvalidRfaIds(rfaIdList, fileName, file.getBytes());
			rfaIdList.removeAll(invalidRfaIds);
			rfaFileService.saveRfaFileToAmendment(fileId, rfaIdList);

			WebUtils.addLocationHeaderToResponse(response, "/v1/company/" + companyId + "/files/download_file/" + fileId);
			Long errorFileId = generateErrorPdf(type, invalidRfaIds, userId, companyId);

			HttpStatus httpStatus = HttpStatus.CREATED;
			if (errorFileId != null) {
				response.addHeader("Error-Location", "/v1/company/" + companyId + "/files/download_file/" + errorFileId);
				httpStatus = HttpStatus.OK;
			}
			return new ResponseEntity<String>(httpStatus);
		} else {
			throw new IllegalArgumentException();
		}
	}
	
	@ResponseStatus(HttpStatus.CREATED)
	@RequestMapping(method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE, params = "ie-9", produces=MediaType.TEXT_HTML_VALUE)
	@ApiOperation(value = "Upload Exhibit Template")
	public @ResponseBody ResponseEntity<String> uploadExhibitTemplateIE9(@RequestParam List<Long> rfaIdList, @RequestParam String type,
			@RequestParam String fileName, @RequestParam final MultipartFile file, HttpServletResponse response, HttpServletRequest request)
			throws Exception {

		if (EXHIBIT_VALUE.equalsIgnoreCase(type)) {
			Long userId = CommonUtil.getUserIdFromSession(request);
			Long companyId = CommonUtil.getCompanyIdFromSession(request);
			if(!FilenameUtils.isExtension(fileName,EXCEL_FILE)){
				String result = "<textarea data-type=\"application/json\"> {\"msg\":\""+RFAConstants.INCORRECT_FILE_EXTENSION+"\" ,\"errorCode\":\""+HttpStatus.CONFLICT+"\"}</textarea>";
				return new ResponseEntity<String>(result,  HttpStatus.OK );
			}
			MCFile mcFile = fileService.saveFile(fileName + "." + EXCEL_FILE, file.getBytes(), companyId, userId);
			Long fileId = mcFile.getFileId();
			rfaFileService.saveRfaFile(fileId, ACTION, userId);

			List<Long> invalidRfaIds = getInvalidRfaIds(rfaIdList, fileName, file.getBytes());
			rfaIdList.removeAll(invalidRfaIds);
			rfaFileService.saveRfaFileToAmendment(fileId, rfaIdList);

			Long errorFileId = generateErrorPdf(type, invalidRfaIds, userId, companyId);

			String result = "<textarea data-type=\"application/json\"> [{\"fileId\":\"" + fileId + "\"," + "\"errorFileId\":\"" + errorFileId
					+ "\"}]</textarea>";
			return new ResponseEntity<String>(result, errorFileId != null ? HttpStatus.OK : HttpStatus.CREATED);
		} else {
			throw new IllegalArgumentException();
		}
	}

	private List<Long> getInvalidRfaIds(List<Long> rfaIdList, String fileName, byte[] bytes) throws Exception {
		List<Long> invalidRfaIds = new ArrayList<>();
		Map<Long, NewExhibitRequest> exhibitRequestMap = newExhibitService.getExhibitRequestMap(bytes, fileName, rfaIdList);
		Map<Long, NewExhibitRequest> validExhibitRequestMap = newExhibitService.validateExhibitData(exhibitRequestMap);
		for (Long rfaId : rfaIdList) {
			if (!validExhibitRequestMap.containsKey(rfaId)) {
				invalidRfaIds.add(rfaId);
			}
		}
		return invalidRfaIds;
	}
	
	private Long generateErrorPdf(String action, List<Long> invalidRfaIds, Long userId, Long companyId) throws Exception {
		Long fileId = null;
		if (CollectionUtils.isNotEmpty(invalidRfaIds)) {
			byte[] pdfContent = nextStepPdfGenerator.generatePdf(EXHIBIT_UPLOAD_ERROR_MESSAGE, invalidRfaIds,
					BulkActionValidationType.fromType(action), companyId, userId);
			fileId = fileService.saveFile(pdfContent, companyId, "amendmentNextStepValidationError", userId).getFileId();
		}
		return fileId;
	}
}