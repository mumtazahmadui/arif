package com.markit.ms.rfa.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.dao.IExhibitTemplateFilterDAO;
import com.markit.ms.rfa.service.IExhibitTemplateFilterService;

@Service
public class ExhibitTemplateFilterServiceImpl implements IExhibitTemplateFilterService {
	
	@Autowired
	IExhibitTemplateFilterDAO exhibitTemplateFilterDAO;

	@Override
	public List<Lookup> nameLookup(Long id, String filterString) {
		return exhibitTemplateFilterDAO.nameLookup(id, filterString);
	}

	@Override
	public List<Lookup> linkedByLookup(Long id, String filterString) {
		return exhibitTemplateFilterDAO.linkedByLookup(id, filterString);
	}

	@Override
	public List<Lookup> createdByLookup(Long id, String filterString) {
		return exhibitTemplateFilterDAO.createdByLookup(id, filterString);
	}

	@Override
	public List<Lookup> partyALegalNameLookup(Long id, String filterString)
	{
		return exhibitTemplateFilterDAO.partyALegalNameLookup(id, filterString);
	}

	@Override
	public List<String> refIsdaDateLookup(Long id, String filterString)
	{
		return exhibitTemplateFilterDAO.refIsdaDateLookup(id, filterString);
	}

	@Override
	public List<Lookup> masterlistIdentifierLookup(Long id, String filterString)
	{
		return exhibitTemplateFilterDAO.masterlistIdentifierLookup(id, filterString);
	}
}
