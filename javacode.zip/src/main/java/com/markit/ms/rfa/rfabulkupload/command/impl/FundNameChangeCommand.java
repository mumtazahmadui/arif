package com.markit.ms.rfa.rfabulkupload.command.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.bean.enumeration.BulkUploadAction;
import com.markit.ms.rfa.dao.IEntityDao;
import com.markit.ms.rfa.rfabulkupload.chain.ActionChain;
import com.markit.ms.rfa.rfabulkupload.command.ActionCommand;
import com.markit.ms.rfa.rfabulkupload.command.CommonValidator;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Component
public class FundNameChangeCommand implements ActionCommand {

	@Autowired
	private CommonValidator commonValidator;

	@Autowired
	private IEntityDao entityDao;

	public void execute(RfaBulkUploadRow rfaBulkUploadRow, ActionChain nextChain) {
		
		Boolean entityExistsForInFlightRfa = commonValidator.checkIfEntityExistingInAnotherRfa(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false, RFAConstants.FNC);
		
		if (entityExistsForInFlightRfa) {
			rfaBulkUploadRow.setPartyBExistsInAnotherRfa(entityExistsForInFlightRfa);
			return;
		}

		Entity entity = entityDao.getEntity(rfaBulkUploadRow.getPartyBEntityId(),
				rfaBulkUploadRow.getMasterAgreementId());

		Boolean entityExistsInMasterlist = commonValidator.checkIfEntityExistInMasterList(rfaBulkUploadRow,
				rfaBulkUploadRow.getPartyBEntityId(), rfaBulkUploadRow.getMasterAgreementId(), false);

		if (!entityExistsInMasterlist && rfaBulkUploadRow.getRequestIdentified().size() == 0) {
			Map<String, String> placeHolderMap = new HashMap<String, String>();
			placeHolderMap.put("entityIdentifier", rfaBulkUploadRow.getPartyBIdentifierField().getFieldLabel());
			placeHolderMap.put("requestType", "FNC");
			rfaBulkUploadRow.addError(RFAConstants.PARTYB_DOESNT_EXIST_IN_MASTERLIST, placeHolderMap);
		}

		if (verifyDifferentNames(entity, rfaBulkUploadRow) && entityExistsInMasterlist && !entityExistsForInFlightRfa) {
			rfaBulkUploadRow.getRequestIdentified().add(BulkUploadAction.FNC);
		}
	}

	/**
	 * Verifies the true legal name of the existing entity and the bulk upload row
	 * are different. This must be true for a FNC.
	 * <p>
	 * Note: FNC is only applicable for true legal name in bulk upload, not client
	 * identifier. This is different from the UI behavior, but a business
	 * requirement.
	 * 
	 * @param existingEntity
	 * @param rfaBulkUploadRow
	 * @return boolean
	 */
	private Boolean verifyDifferentNames(Entity existingEntity, RfaBulkUploadRow rfaBulkUploadRow) {
		if (CommonUtil.isNotNull(rfaBulkUploadRow.getUploadTemplateField(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD))
				&& CommonUtil.isNotNull(existingEntity)
				&& rfaBulkUploadRow.getUploadTemplateField(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD)
						.getEntityIdentifier() == 1
				&& CommonUtil.isNotEqual(existingEntity.getTrueLegalName(),
						rfaBulkUploadRow.getPartyBTrueLegalName())) {
			return true;
		}
		return false;
	}

}
