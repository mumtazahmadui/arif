package com.markit.ms.rfa.bean;

import java.util.Date;

public class Masterlist {

	private Long id;
	private Date masterAgreementDate;
	private String investmentManager;
	private String partyA;
	private String masterlistIdentifier;
	private Date lastUpdate;
	private Long companyId;
	private String agreementType;
	private Long agreementTypeId;
	private String masterlistTemplateName;
	private Boolean isDeletable;
	private Integer totalRowCount;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Date getMasterAgreementDate() {
		return masterAgreementDate;
	}
	public void setMasterAgreementDate(Date masterAgreementDate) {
		this.masterAgreementDate = masterAgreementDate;
	}
	public String getInvestmentManager() {
		return investmentManager;
	}
	public void setInvestmentManager(String investmentManager) {
		this.investmentManager = investmentManager;
	}
	public String getPartyA() {
		return partyA;
	}
	public void setPartyA(String partyA) {
		this.partyA = partyA;
	}
	public String getMasterlistIdentifier() {
		return masterlistIdentifier;
	}
	public void setMasterlistIdentifier(String masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}
	public Date getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getAgreementType() {
		return agreementType;
	}
	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}
	public Long getAgreementTypeId() {
		return agreementTypeId;
	}
	public void setAgreementTypeId(Long agreementTypeId) {
		this.agreementTypeId = agreementTypeId;
	}
	public String getMasterlistTemplateName() {
		return masterlistTemplateName;
	}
	public void setMasterlistTemplateName(String masterlistTemplateName) {
		this.masterlistTemplateName = masterlistTemplateName;
	}
	public Boolean getIsDeletable() {
		return isDeletable;
	}
	public void setIsDeletable(Boolean isDeletable) {
		this.isDeletable = isDeletable;
	}
	public Integer getTotalRowCount() {
		return totalRowCount;
	}
	public void setTotalRowCount(Integer totalRowCount) {
		this.totalRowCount = totalRowCount;
	}
}
