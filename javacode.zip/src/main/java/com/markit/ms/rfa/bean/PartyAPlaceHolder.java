package com.markit.ms.rfa.bean;

public class PartyAPlaceHolder {
private String partyAText;

public String getPartyAText() {
	return partyAText;
}
public void setPartyAText(String partyAText) {
	this.partyAText = partyAText;
}

}
