package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.common.bean.Lookup;

public interface ILetterTemplateFilterService {
	public List<Lookup> nameLookup(Long id, String filterString);
	public List<Lookup> lastEditedByLookup(Long id, String filterString);
	public List<Lookup> createdByLookup(Long id, String filterString);
}
