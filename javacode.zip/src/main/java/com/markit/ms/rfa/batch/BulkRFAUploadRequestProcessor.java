package com.markit.ms.rfa.batch;

import java.lang.reflect.Method;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.support.TransactionTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.ms.rfa.bean.RfaBulkUploadRow;
import com.markit.ms.rfa.rfabulkupload.template.RFABulkUploadProcessTemplate;
import com.markit.ms.rs.select.all.domain.SelectAllConfig;

public class BulkRFAUploadRequestProcessor implements ItemProcessor<RfaBulkUploadRow, RfaBulkUploadRow> {

	private static final Logger logger = LoggerFactory.getLogger(BulkRFAUploadRequestProcessor.class);
	
	@Autowired
	RFABulkUploadProcessTemplate bulkUploadProcessTemplate;

	private Long batchId;

	private String configBeanName;

	private String bulkRequestId;

	private SelectAllConfig selectAllConfig;

	private TransactionTemplate transactionTemplate;

	private Method selectAllMethod;

	private Long templateId;

	private Map<Integer, Object> mapOfParams;

	private ObjectMapper objectMapper;

	@PostConstruct
	public void postContructMethod() {

	}

	@Override
	public RfaBulkUploadRow process(RfaBulkUploadRow rfaBulkUploadRow) throws Exception {

		rfaBulkUploadRow = bulkUploadProcessTemplate.rfaBulkUploadProcess(rfaBulkUploadRow);
		return rfaBulkUploadRow;

	}

	/* SPRING RELATED METHODS */
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public void setConfigBeanName(String configBeanName) {
		this.configBeanName = configBeanName;
	}

	public void setBulkRequestId(String bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}
}