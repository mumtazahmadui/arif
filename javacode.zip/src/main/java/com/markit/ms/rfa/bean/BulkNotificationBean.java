package com.markit.ms.rfa.bean;

import java.util.List;

import com.markit.ms.common.bean.User;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;

public class BulkNotificationBean extends BulkActionBean {

	private List<User> emailRecipients;
	
	private BulkActionValidationType bulkActionValidationType;

	public List<User> getEmailRecipients() {
		return emailRecipients;
	}

	public void setEmailRecipients(List<User> emailRecipients) {
		this.emailRecipients = emailRecipients;
	}

	public BulkActionValidationType getBulkActionValidationType() {
		return bulkActionValidationType;
	}

	public void setBulkActionValidationType(BulkActionValidationType bulkActionValidationType) {
		this.bulkActionValidationType = bulkActionValidationType;
	}
}