package com.markit.ms.rfa.rfabulkupload.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.rfa.rfabulkupload.factory.impl.AdditionActionChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.AdditionAndModificationActionChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.AdditionAndRemovalActionChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.AllActionsChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.ApplicationDeterminesActionChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.EvcModificationActionChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.FncModificationActionChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.ModifyActionChain;
import com.markit.ms.rfa.rfabulkupload.factory.impl.RemoveActionChain;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class ActionFactory {

	@Autowired
	private AllActionsChain allActionsChain;

	@Autowired
	ApplicationDeterminesActionChain applicationDeterminesActionChain;

	@Autowired
	AdditionActionChain additionActionChain;

	@Autowired
	ModifyActionChain modifyActionChain;

	@Autowired
	FncModificationActionChain fncActionChain;

	@Autowired
	EvcModificationActionChain evcActionChain;

	@Autowired
	RemoveActionChain removeActionChain;

	@Autowired
	AdditionAndModificationActionChain additionAndModificationActionChain;

	@Autowired
	AdditionAndRemovalActionChain additionAndRemovalActionChain;

	public FactoryActionChain getActionChain(String rule) {
		switch (rule) {
		case RFAConstants.APPLICATION_DETERMINES: {
			return applicationDeterminesActionChain;
		}
		case RFAConstants.ALL_ACIION: {
			return allActionsChain;
		}
		case RFAConstants.ADDITION:
		case RFAConstants.BLANK_ADD: {
			return additionActionChain;
		}
		case RFAConstants.MODIFICATIONS: {
			return modifyActionChain;
		}
		case RFAConstants.FNC: {
			return fncActionChain;
		}
		case RFAConstants.EVC: {
			return evcActionChain;
		}
		case RFAConstants.REMOVAL:
		case RFAConstants.BLANK_REMOVE: {
			return removeActionChain;
		}
		case RFAConstants.ADDITION_MODIFICATION: {
			return additionAndModificationActionChain;
		}
		case RFAConstants.ADDITION_REMOVAL: {
			return additionAndRemovalActionChain;
		}
		}

		return null;
	}

}
