package com.markit.ms.rfa.dto;

import java.util.List;

import com.markit.ms.common.bean.User;

@Deprecated()
/**
 * 
 * @author joseph.howe
 * Use RfaEmailNotification going forward.
 */
public class BulkEmailNotification {

	List<User> signatories;
	List<Long> rfaIds;
	
	public List<User> getSignatories() {
		return signatories;
	}
	public void setSignatories(List<User> signatories) {
		this.signatories = signatories;
	}
	public List<Long> getRfaIds() {
		return rfaIds;
	}
	public void setRfaIds(List<Long> rfaIds) {
		this.rfaIds = rfaIds;
	}

}
