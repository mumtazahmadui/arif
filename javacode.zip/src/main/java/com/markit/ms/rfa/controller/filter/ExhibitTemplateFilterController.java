package com.markit.ms.rfa.controller.filter;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.rfa.service.IExhibitTemplateFilterService;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
@RestController
@RequestMapping(value = "v1/company")
@Api(value="Exhibit", description= "Exhibit Template Filter APIs")
public class ExhibitTemplateFilterController {
	 //TODO-Sajil The null check for filterString should be moved to an intercepter 
	@Autowired
	IExhibitTemplateFilterService exhibitTemplateFilterService;
	
	@RequestMapping(value = "{id}/exhibit_template_filter/template_name", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on exhibit template name")
	public CommonBaseResponse<List<Lookup>> templateNamesLookup(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = exhibitTemplateFilterService.nameLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}

	@RequestMapping(value = "{id}/exhibit_template_filter/linkedBy", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on exhibit last edited by")
	public CommonBaseResponse<List<Lookup>> filterLinkedBy(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = exhibitTemplateFilterService.linkedByLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/exhibit_template_filter/created_by", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on exhibit created by")
	public CommonBaseResponse<List<Lookup>> filterCreatedBy(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = exhibitTemplateFilterService.createdByLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/exhibit_template_filter/partyALegalName", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on exhibit created by")
	public CommonBaseResponse<List<Lookup>> filterPartyALegalName(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = exhibitTemplateFilterService.partyALegalNameLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/exhibit_template_filter/refIsdaDate", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on exhibit created by")
	public CommonBaseResponse<List<String>> filterRefIsdaDate(@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<String>> commonBaseResponse = new CommonBaseResponse<List<String>>();
		List<String> list = exhibitTemplateFilterService.refIsdaDateLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
	@RequestMapping(value = "{id}/exhibit_template_filter/masterlist_identifier", method = RequestMethod.GET)
	@ApiOperation(value = "Filter on exhibit created by")
	public CommonBaseResponse<List<Lookup>> filterMasterlistIdentifier (@PathVariable Long id, @RequestParam(required=false) String filterString,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		if(null == filterString) {
			filterString = "";
		}
		CommonBaseResponse<List<Lookup>> commonBaseResponse = new CommonBaseResponse<List<Lookup>>();
		List<Lookup> list = exhibitTemplateFilterService.masterlistIdentifierLookup(companyIdFromSession, filterString);
		commonBaseResponse.setData(list);
		return commonBaseResponse;
	}
	
}
