package com.markit.ms.rfa.bean;

public class AmendmentDownloadTransitionLog {

	private Long userId;
	private String ipAddress;
	private Long amendmentId;	
	private Long downloadId;
	private String eventName;
	private Long fileId;
	private int noOfPages;
	private String docId;
	
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public Long getAmendmentId() {
		return amendmentId;
	}
	public void setAmendmentId(Long amendmentId) {
		this.amendmentId = amendmentId;
	}
	public Long getDownloadId() {
		return downloadId;
	}
	public void setDownloadId(Long downloadId) {
		this.downloadId = downloadId;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public Long getFileId() {
		return fileId;
	}
	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}
	public int getNoOfPages() {
		return noOfPages;
	}
	public void setNoOfPages(int noOfPages) {
		this.noOfPages = noOfPages;
	}
	
	
}
