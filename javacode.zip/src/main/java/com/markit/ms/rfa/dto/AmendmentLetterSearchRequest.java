package com.markit.ms.rfa.dto;

import java.util.List;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.common.model.CommonBaseSearchRequest;
import com.markit.ms.rfa.bean.enumeration.CompanyType;
//TODO rename this package to com.markit.ms.rfa.dto

public class AmendmentLetterSearchRequest extends CommonBaseSearchRequest
{
    private List<String> agreementDate;
    private List<Lookup> investmentManager;
    private List<String> masterlistIdentifier;
    private List<Lookup> partyA;
    private List<Lookup> partyBAccount;
    private List<String> actionOnPartyB;
    private List<String> requestStatus;
    private CompanyType companyType;
    private String task;
    private List<Long> reviewData;
    private List<String> partyBClientIdentifier;
    private List<String> submitDate;
    private List<String> partyBLei;
    private List<String> agreementType;
    private List<String> myStatus;
    private List<Long> rfaIds;
    
    public List<String> getPartyBLei() {
		return partyBLei;
	}
	public void setPartyBLei(List<String> partyBLei) {
		this.partyBLei = partyBLei;
	}
	public List<String> getAgreementType() {
		return agreementType;
	}
	public void setAgreementType(List<String> agreementType) {
		this.agreementType = agreementType;
	}
	public List<String> getMyStatus() {
		return myStatus;
	}
	public void setMyStatus(List<String> myStatus) {
		this.myStatus = myStatus;
	}
	public List<Long> getRfaIds() {
		return rfaIds;
	}
	public void setRfaIds(List<Long> rfaIds) {
		this.rfaIds = rfaIds;
	}

	public List<String> getAgreementDate() {
		return agreementDate;
	}
	public void setAgreementDate(List<String> agreementDate) {
		this.agreementDate = agreementDate;
	}
	public List<Lookup> getInvestmentManager() {
		return investmentManager;
	}
	public void setInvestmentManager(List<Lookup> investmentManager) {
		this.investmentManager = investmentManager;
	}
	public List<String> getMasterlistIdentifier() {
		return masterlistIdentifier;
	}
	public void setMasterlistIdentifier(List<String> masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}
	public List<Lookup> getPartyA() {
		return partyA;
	}
	public void setPartyA(List<Lookup> partyA) {
		this.partyA = partyA;
	}
	public List<Lookup> getPartyBAccount() {
		return partyBAccount;
	}
	public void setPartyBAccount(List<Lookup> partyBAccount) {
		this.partyBAccount = partyBAccount;
	}
	public List<String> getActionOnPartyB() {
		return actionOnPartyB;
	}
	public void setActionOnPartyB(List<String> actionOnPartyB) {
		this.actionOnPartyB = actionOnPartyB;
	}
	public List<String> getRequestStatus() {
		return requestStatus;
	}
	public void setRequestStatus(List<String> requestStatus) {
		this.requestStatus = requestStatus;
	}
	public CompanyType getCompanyType() {
		return companyType;
	}
	public void setCompanyType(CompanyType companyType) {
		this.companyType = companyType;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public List<Long> getReviewData() {
		return reviewData;
	}
	public void setReviewData(List<Long> reviewData) {
		this.reviewData = reviewData;
	}
	public List<String> getPartyBClientIdentifier() {
		return partyBClientIdentifier;
	}
	public void setPartyBClientIdentifier(List<String> partyBClientIdentifier) {
		this.partyBClientIdentifier = partyBClientIdentifier;
	}
	public List<String> getSubmitDate() {
		return submitDate;
	}
	public void setSubmitDate(List<String> submitDate) {
		this.submitDate = submitDate;
	}

}
