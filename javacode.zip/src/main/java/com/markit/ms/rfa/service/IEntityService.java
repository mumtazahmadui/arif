package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.common.bean.Entity;
import com.markit.ms.common.model.CommonBaseSearchRequest;
public interface IEntityService {
	public List<Entity> getAllEntities(Long companyId, String filterString, CommonBaseSearchRequest searchRequest);
	public List<Entity> getAllSleeveEntities(Long companyId, String filterString, Long offSet, Long pageSize);
	public List<Entity> getSleeveAccountsForParentEntities(Long companyId, List<Long> masterlistIds, List<Long> parentEntityIds);
	public List<Entity> getMcpmChildEntities(Long companyId, Long parentEntityId);
	public Entity getParentEntity(Long entityId);
	public Entity getPartyAEntity(String legalName);
}
