package com.markit.ms.rfa.util;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Maps;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.ms.common.constants.PartyBPlaceholderConstants;
import com.markit.ms.rfa.bean.PDFContext;

public class PlaceholderUtil {
	public static Map<String, Object> preparePlaceholderParams(Long amendmentId) {
		Set<String> filterNames = new HashSet<String>();
		filterNames.add(PartyBPlaceholderConstants.AMENDMENT_ID);
		filterNames.add(PartyBPlaceholderConstants.NOT_ALLOWED_PARTYB_STATUS);
		
		Map<String,String> filter =  Maps.newHashMap();
		filter.put(PartyBPlaceholderConstants.AMENDMENT_ID, ""+amendmentId);
		filter.put(PartyBPlaceholderConstants.NOT_ALLOWED_PARTYB_STATUS, "Accepted Sent|Rejected Sent|Withdrawn");
		Map<String, Object> params = WebUtils.createParamsFromFilters(filter,filterNames);
		return params;
	}
	public static Map<String, Object> preparePlaceholderParamsForPDF(Long amendmentId, PDFContext pdfContext) {
		Set<String> filterNames = new HashSet<String>();
		filterNames.add(PartyBPlaceholderConstants.AMENDMENT_ID);
		filterNames.add(PartyBPlaceholderConstants.NOT_ALLOWED_PARTYB_STATUS);
		filterNames.add(PartyBPlaceholderConstants.ALLOWED_PARTYB_STATUS);
		
		Map<String,String> filter =  Maps.newHashMap();
		filter.put(PartyBPlaceholderConstants.AMENDMENT_ID, ""+amendmentId);
		filter.put(PartyBPlaceholderConstants.NOT_ALLOWED_PARTYB_STATUS, pdfContext.getNotAllowPartyBStatuses());
		filter.put(PartyBPlaceholderConstants.ALLOWED_PARTYB_STATUS,pdfContext.getAllowPartyBStatuses());
		Map<String, Object> params = WebUtils.createParamsFromFilters(filter,filterNames);
		return params;
	}
	public static Map<String, Object> preparePlaceholderParamsForExhibitPDF(Long exhibitId, PDFContext pdfContext) {
		Set<String> filterNames = new HashSet<String>();
		filterNames.add(PartyBPlaceholderConstants.EXHIBIT_ID);
		filterNames.add(PartyBPlaceholderConstants.NOT_ALLOWED_PARTYB_STATUS);
		filterNames.add(PartyBPlaceholderConstants.ALLOWED_PARTYB_STATUS);
		
		Map<String,String> filter =  Maps.newHashMap();
		filter.put(PartyBPlaceholderConstants.EXHIBIT_ID, ""+exhibitId);
		filter.put(PartyBPlaceholderConstants.NOT_ALLOWED_PARTYB_STATUS, pdfContext.getNotAllowPartyBStatuses());
		filter.put(PartyBPlaceholderConstants.ALLOWED_PARTYB_STATUS,pdfContext.getAllowPartyBStatuses());
		
		Map<String, Object> params = WebUtils.createParamsFromFilters(filter,filterNames);
		return params;
	}
}
