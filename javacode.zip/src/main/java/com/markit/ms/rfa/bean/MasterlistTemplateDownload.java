package com.markit.ms.rfa.bean;

public class MasterlistTemplateDownload {
	
	private Long mlTemplateId;
	
	private String mlTemplateName;

	private String fieldIdentifier;
	
	private String fieldLabel;
	
	public Long getMlTemplateId() {
		return mlTemplateId;
	}

	public void setMlTemplateId(Long mlTemplateId) {
		this.mlTemplateId = mlTemplateId;
	}

	public String getMlTemplateName() {
		return mlTemplateName;
	}

	public void setMlTemplateName(String mlTemplateName) {
		this.mlTemplateName = mlTemplateName;
	}

	public String getFieldIdentifier() {
		return fieldIdentifier;
	}

	public void setFieldIdentifier(String fieldIdentifier) {
		this.fieldIdentifier = fieldIdentifier;
	}

	public String getFieldLabel() {
		return fieldLabel;
	}

	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}
}
