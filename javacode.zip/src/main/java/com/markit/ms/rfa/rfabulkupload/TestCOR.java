package com.markit.ms.rfa.rfabulkupload;

public class TestCOR {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//AllActionsActionChain actionChain = new AllActionsActionChain();
//		ApplicationDeterminesActionChain actionChain = new ApplicationDeterminesActionChain();
		/*RfaBulkUploadRow rfaBulkUploadRow = new RfaBulkUploadRow();
		actionChain.action.process(rfaBulkUploadRow);*/
	}

}
