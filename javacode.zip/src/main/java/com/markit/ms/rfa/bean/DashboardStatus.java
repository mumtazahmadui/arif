package com.markit.ms.rfa.bean;

public class DashboardStatus {

	private Long draft;
	private Long completed;
	private Long submitted;
	private Long partialCompleted;
	private Long recalled;
	private Long pendingExibit;
	private Long pendingSignature;
	
	public Long getDraft() {
		return draft;
	}
	public void setDraft(Long draft) {
		this.draft = draft;
	}
	public Long getCompleted() {
		return completed;
	}
	public void setCompleted(Long completed) {
		this.completed = completed;
	}
	public Long getSubmitted() {
		return submitted;
	}
	public void setSubmitted(Long submitted) {
		this.submitted = submitted;
	}
	public Long getPartialCompleted() {
		return partialCompleted;
	}
	public void setPartialCompleted(Long partialCompleted) {
		this.partialCompleted = partialCompleted;
	}
	public Long getRecalled() {
		return recalled;
	}
	public void setRecalled(Long recalled) {
		this.recalled = recalled;
	}
	public Long getPendingExibit() {
		return pendingExibit;
	}
	public void setPendingExibit(Long pendingExibit) {
		this.pendingExibit = pendingExibit;
	}
	public Long getPendingSignature() {
		return pendingSignature;
	}
	public void setPendingSignature(Long pendingSignature) {
		this.pendingSignature = pendingSignature;
	}
	
}
