package com.markit.ms.rfa.dao.resultsetextractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.dto.McpmEntityUpdate;

public class McpmEntityResultSetExtractor implements ResultSetExtractor<List<McpmEntityUpdate>> {

	public List<McpmEntityUpdate> extractData(ResultSet rs) throws SQLException {
		List<McpmEntityUpdate> entitiesToBeUpdated = null;
		McpmEntityUpdate entityToBeUpdated = null;
		while (rs.next()) {
			if (entitiesToBeUpdated == null) {
				entitiesToBeUpdated = new ArrayList<McpmEntityUpdate>();
			}

			entityToBeUpdated = new McpmEntityUpdate();
			entityToBeUpdated.setEntityId(rs.getLong("ENTITY_ID"));

			entityToBeUpdated.setMonikerName(rs.getString("CLIENT_IDENTIFIER"));
			entityToBeUpdated.setLegalName(rs.getString("LEGAL_NAME"));
			entityToBeUpdated.setLei(rs.getString("LEI"));

			entitiesToBeUpdated.add(entityToBeUpdated);
		}
		return entitiesToBeUpdated;
	}

}
