package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.rfa.bean.AmendmentChangeAudit;
import com.markit.ms.rfa.bean.AmendmentCommentAudit;

public interface IAmendmentChangeService {

	public void saveRfaCommentAudit(List<AmendmentCommentAudit> commentAuditList, Long amendmentId, String source,
			String partyType,String query);

	public void saveRfaChangeLogAudit(List<AmendmentChangeAudit> changeAuditList, Long amendmentId, String source,
			String partyType,String query);

}
