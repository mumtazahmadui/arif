package com.markit.ms.rfa.bean;

public class OnBoardingReviewData {
	private long onBoarding_review_id;
	private long review_id;
    private String updateBy;
    private boolean editable;
	public long getOnBoarding_review_id() {
		return onBoarding_review_id;
	}
	public void setOnBoarding_review_id(long onBoarding_review_id) {
		this.onBoarding_review_id = onBoarding_review_id;
	}
	public long getReview_id() {
		return review_id;
	}
	public void setReview_id(long review_id) {
		this.review_id = review_id;
	}
	public String getUpdateBy() {
		return updateBy;
	}
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}
	public boolean getEditable() {
		return editable;
	}
	public void setEditable(boolean editable) {
		this.editable = editable;
	}
}
