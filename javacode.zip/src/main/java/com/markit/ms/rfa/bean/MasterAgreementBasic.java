package com.markit.ms.rfa.bean;

import java.util.Date;

public class MasterAgreementBasic {

	private Date agreementDate;
	private String investmentManager;
	private String partyA;
	private String masterlistIdentifier;
	
	public Date getAgreementDate() {
		return agreementDate;
	}
	public void setAgreementDate(Date agreementDate) {
		this.agreementDate = agreementDate;
	}
	public String getInvestmentManager() {
		return investmentManager;
	}
	public void setInvestmentManager(String investmentManager) {
		this.investmentManager = investmentManager;
	}
	public String getPartyA() {
		return partyA;
	}
	public void setPartyA(String partyA) {
		this.partyA = partyA;
	}
	public String getMasterlistIdentifier() {
		return masterlistIdentifier;
	}
	public void setMasterlistIdentifier(String masterlistIdentifier) {
		this.masterlistIdentifier = masterlistIdentifier;
	}		
	
	
}
