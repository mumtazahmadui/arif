package com.markit.ms.rfa.bean;



public class AmendmentStatusObject {
	private String amendmentStatus;
	private String requestType;
	public String getAmendmentStatus() {
		return amendmentStatus;
	}
	public void setAmendmentStatus(String amendmentStatus) {
		this.amendmentStatus = amendmentStatus;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
}
