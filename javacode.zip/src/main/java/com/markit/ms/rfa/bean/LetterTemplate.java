package com.markit.ms.rfa.bean;

import java.util.Date;

public class LetterTemplate {
	
	private Long id;
	private String name;
	private Long companyId;
	private String content;
	private Boolean isActiveVersion;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private String createdByString;
	private String modifiedByString;
	private Long deleted;
	private int agreed;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Boolean getIsActiveVersion() {
		return isActiveVersion;
	}
	public void setIsActiveVersion(Boolean isActiveVersion) {
		this.isActiveVersion = isActiveVersion;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getCreatedByString() {
		return createdByString;
	}
	public void setCreatedByString(String createdByString) {
		this.createdByString = createdByString;
	}
	public String getModifiedByString() {
		return modifiedByString;
	}
	public void setModifiedByString(String modifiedByString) {
		this.modifiedByString = modifiedByString;
	}
	public Long getDeleted() {
		return deleted;
	}
	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}
	public int getAgreed() {
		return agreed;
	}
	public void setAgreed(int agreed) {
		this.agreed = agreed;
	}
}