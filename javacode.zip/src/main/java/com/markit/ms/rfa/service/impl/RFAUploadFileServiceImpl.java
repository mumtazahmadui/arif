package com.markit.ms.rfa.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.Lookup;
import com.markit.ms.rfa.bean.RFATemplateNames;
import com.markit.ms.rfa.bean.RFAUploadFile;
import com.markit.ms.rfa.dao.IRfaUploadFileDAO;
import com.markit.ms.rfa.dto.RfaUploadFileSearchRequest;
import com.markit.ms.rfa.service.IRfaUploadFileService;

/**
 * @author sucheta.krishali
 *
 */
@Service
public class RFAUploadFileServiceImpl implements IRfaUploadFileService {

	@Autowired
	IRfaUploadFileDAO uploadFileDAO;

	@Override
	public List<RFAUploadFile> getUploadFileGrid(Long companyId, RfaUploadFileSearchRequest uploadFileSearchRequest) {
		List<RFAUploadFile> uploadFiles = uploadFileDAO.getUploadFileGrid(companyId, uploadFileSearchRequest);
		return uploadFiles;
	}

	@Override
	public List<Lookup> getFilterUploadedBy(Long companyId, String filterString) {
		List<Lookup>  uploadedByList = uploadFileDAO.getFilterUploadedBy(companyId, filterString);
		return uploadedByList;
	}
	
	
	
	@Override
	public List<Lookup> getFilterProcessingStatus(Long companyId, String filterString) {
		List<Lookup>  statusList = uploadFileDAO.getFilterProcessingStatus(companyId, filterString);
		return statusList;

	}
	@Override
	public List<Lookup> getTemplateNamesByCompany(Long companyId){
		List<Lookup>  rfaTemplateList = uploadFileDAO.getTemplateNamesByCompany(companyId);
		return rfaTemplateList;

	}

}
