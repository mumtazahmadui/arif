package com.markit.ms.rfa.placeholders.request;

import java.util.List;

public class SSPartyBTableRequest {
private List<SSResponse> ssResponses;
private String placeHolderType;
public List<SSResponse> getSsResponses() {
	return ssResponses;
}

public void setSsResponses(List<SSResponse> ssResponses) {
	this.ssResponses = ssResponses;
}


public String getPlaceHolderType() {
	return placeHolderType;
}

public void setPlaceHolderType(String placeHolderType) {
	this.placeHolderType = placeHolderType;
}
}
