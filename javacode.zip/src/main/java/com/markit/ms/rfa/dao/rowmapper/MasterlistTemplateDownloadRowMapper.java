package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.Masterlist;
import com.markit.ms.rfa.bean.MasterlistTemplateDownload;

public class MasterlistTemplateDownloadRowMapper implements RowMapper<MasterlistTemplateDownload> {
	
	public MasterlistTemplateDownload mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		MasterlistTemplateDownload mlTemplate = new MasterlistTemplateDownload();
		mlTemplate.setMlTemplateId(rs.getLong("id"));
		mlTemplate.setMlTemplateName(rs.getString("ml_template_name"));
		mlTemplate.setFieldIdentifier(rs.getString("field_identifier"));
		mlTemplate.setFieldLabel(rs.getString("field_name"));
		
		return mlTemplate;
	}
}