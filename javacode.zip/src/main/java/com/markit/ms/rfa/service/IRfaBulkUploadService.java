package com.markit.ms.rfa.service;

import com.markit.ms.rfa.bean.RfaBulkUploadRow;

/**
 * @author prashant.aggarwal
 *
 */
public interface IRfaBulkUploadService {
	
	public void determineActionOnMl(RfaBulkUploadRow rfaBulkUploadRow);
	public RfaBulkUploadRow determineMLExhibitLinkage(RfaBulkUploadRow rfaBulkUploadRow);
	public RfaBulkUploadRow determineLetterTemplate(RfaBulkUploadRow rfaBulkUploadRow);

}
