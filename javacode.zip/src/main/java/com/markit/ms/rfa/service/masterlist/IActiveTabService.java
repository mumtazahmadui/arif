package com.markit.ms.rfa.service.masterlist;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.markit.ms.rfa.bean.MasterlistDownload;

public interface IActiveTabService {

	public void prepareActiveTab(SXSSFWorkbook workbook, Map<String, CellStyle> cellstyles, List<MasterlistDownload> addedList, 
			List<MasterlistDownload> removedList, String masterlistUpdateDateString, Set<String> addRemoveTabscolumnSet, String controlColumn, 
			Map<Long, String> legalNameEntityMap, Map<String,Map<Long, Map<Long, Map<String, String>>>> activeTabMap, Map<String, 
			Map<String, String>> templateColumnsMap, Map<String, String> verticalColumnsValueMap);	
	
}