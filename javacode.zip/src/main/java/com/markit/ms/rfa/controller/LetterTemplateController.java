package com.markit.ms.rfa.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.model.CommonBaseRequest;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.model.CommonBaseSearchResponse;
import com.markit.ms.rfa.bean.LetterTemplate;
import com.markit.ms.rfa.dto.TemplateSearchRequest;
import com.markit.ms.rfa.exception.RFAUIException;
import com.markit.ms.rfa.service.ILetterTemplateService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;
import com.wordnik.swagger.annotations.Api;

@RestController
@RequestMapping(value = "/v1/company")
@Api(value = "lettertemplate" , description = "Letter Template controller")
public class LetterTemplateController {
	
	@Autowired
	private ILetterTemplateService letterTemplateService;
	
	@RequestMapping(value="/{companyId}/letter_template",method = RequestMethod.POST)
	public CommonBaseResponse<LetterTemplate> saveLetterTemplate(@PathVariable Long companyId
			, @RequestBody CommonBaseRequest<LetterTemplate> commonBaseRequest,HttpServletRequest request) throws RFAUIException {
			CommonBaseResponse<LetterTemplate> commonBaseResponse = new CommonBaseResponse<LetterTemplate>();
			LetterTemplate letterTemplateRequest = updateTemplateWithCompanyId(commonBaseRequest, request);
			LetterTemplate letterTemplate =  letterTemplateService.saveLetterTemplate(letterTemplateRequest);
			if(null == letterTemplate) {
				commonBaseResponse.setFailed();
				//commonBaseResponse.setMessage(RFAConstants.LETTER_TEMPLATE_ALREADY_EXIST);
				throw new RFAUIException(RFAConstants.LETTER_TEMPLATE_ALREADY_EXIST, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
			}
			commonBaseResponse.setData(letterTemplate);
			return commonBaseResponse;
	}
	private LetterTemplate updateTemplateWithCompanyId(
			CommonBaseRequest<LetterTemplate> commonBaseRequest,
			HttpServletRequest request) {
		LetterTemplate letterTemplate = commonBaseRequest.getData();
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		letterTemplate.setCompanyId(companyIdFromSession);
		return letterTemplate;
	}
	@RequestMapping(value="/{companyId}/letter_template",method = RequestMethod.PUT)
	public CommonBaseResponse<LetterTemplate> updateLetterTemplate(@PathVariable Long companyId
			, @RequestBody CommonBaseRequest<LetterTemplate> commonBaseRequest,HttpServletRequest request) throws RFAUIException {
			LetterTemplate letterTemplateRequest = updateTemplateWithCompanyId(commonBaseRequest, request);
			CommonBaseResponse<LetterTemplate> commonBaseResponse = new CommonBaseResponse<LetterTemplate>();
			LetterTemplate letterTemplate =  letterTemplateService.updateLetterTemplate(letterTemplateRequest);
			if(null == letterTemplate) {
				commonBaseResponse.setFailed();
				throw new RFAUIException(RFAConstants.LETTER_TEMPLATE_ALREADY_EXIST, RFAConstants.RFA_EXCEPTION_RESPONSE_CODE);
			}
			commonBaseResponse.setData(letterTemplate);
			return commonBaseResponse;
	}
	//TODO-Sajil This method should return void.
	@RequestMapping(value="/{companyId}/letter_template/{letterTemplateId}",method = RequestMethod.DELETE)
	public CommonBaseResponse<LetterTemplate> deleteLetterTemplate(@PathVariable Long companyId, @PathVariable Long letterTemplateId,HttpServletRequest request){
			Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
			CommonBaseResponse<LetterTemplate> commonBaseResponse = new CommonBaseResponse<LetterTemplate>();
			LetterTemplate letterTemplate =  letterTemplateService.deleteLetterTemplate(letterTemplateId,companyIdFromSession);
			commonBaseResponse.setData(letterTemplate);
			return commonBaseResponse;
	}
	
	@RequestMapping(value = "{companyId}/letter_template/{letterTemplateId}", method = RequestMethod.GET)
	public CommonBaseResponse<LetterTemplate> getLetterTemplateById(@PathVariable Long companyId, @PathVariable Long letterTemplateId,HttpServletRequest request){
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		LetterTemplate letterTemplate = letterTemplateService.getLetterTemplateById(letterTemplateId,companyIdFromSession);
		CommonBaseResponse<LetterTemplate> response = new CommonBaseResponse<LetterTemplate>();
		response.setData(letterTemplate);
		return response;
	}
		
	@RequestMapping(value="/{companyId}/letter_template",method = RequestMethod.GET)
	public CommonBaseResponse<List<LetterTemplate>> getLetterTemplates(@PathVariable Long companyId,HttpServletRequest request){
			Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
			CommonBaseResponse<List<LetterTemplate>> commonBaseResponse = new CommonBaseResponse<List<LetterTemplate>>();
			List<LetterTemplate> letterTemplates =  letterTemplateService.getAllLetterTemplatesByCompanyId(companyIdFromSession);
			commonBaseResponse.setData(letterTemplates);
			return commonBaseResponse;
	}
	
	@RequestMapping(value="/{companyId}/letter_template/search",method = RequestMethod.POST)
	public CommonBaseSearchResponse<LetterTemplate> searchLetterTemplate(@PathVariable Long companyId, @RequestBody TemplateSearchRequest letterTemplateSearchRequest,HttpServletRequest request){
			Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
			List<LetterTemplate> letterTemplateList = letterTemplateService.getLetterTemplateGrid(companyIdFromSession, letterTemplateSearchRequest);
			Long totalCount = letterTemplateService.getLetterTemplateGridTotalCount(companyIdFromSession, letterTemplateSearchRequest);
	    	CommonBaseSearchResponse<LetterTemplate> commonBaseSearchResponse = new CommonBaseSearchResponse<LetterTemplate>();
	    	commonBaseSearchResponse.setDataList(letterTemplateList);
	    	commonBaseSearchResponse.setTotalCount(totalCount);
	    	return commonBaseSearchResponse;   
	}
}