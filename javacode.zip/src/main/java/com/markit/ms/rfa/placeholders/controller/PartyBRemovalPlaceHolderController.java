package com.markit.ms.rfa.placeholders.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.security.UserUtils;
import com.markit.ms.common.constants.PartyBPlaceholderConstants;
import com.markit.ms.rfa.placeholders.request.BSPartyBTableRequest;
import com.markit.ms.rfa.placeholders.request.SSPartyBTableRequest;
import com.markit.ms.rfa.placeholders.response.PartyBTableResponse;
import com.markit.ms.rfa.security.McpmUserxsDetails;
import com.markit.ms.rfa.security.domain.McpmUser;
import com.markit.ms.rfa.service.IPartyBPlaceholderService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PlaceholderUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
@RestController
@RequestMapping(value = "/v1/amendmentLetters/{amendmentId}/partyBRemovalPlaceHolder")
@Api(value = "amendmentLetters" , description = "Amendment Letter APIs")
public class PartyBRemovalPlaceHolderController {
	@Resource private IPartyBPlaceholderService partyBPlaceholderService;
	@Resource private QueryService<Grid> partyBRemovalTableRows;
	@Resource private QueryService<Grid> partyBRemovalTableColumns;
		
	@RequestMapping(method = RequestMethod.GET)
    @ApiOperation(value = "GET Placeholder Party B Addition")
    public @ResponseBody PartyBTableResponse getPartyBTable(@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception{
		McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		McpmUser mcpmUser = mcpmUserxsDetails.getEffectiveUser();
		
		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("amendmentId",amendmentId);
		queryParams.put(PartyBPlaceholderConstants.HIDE_SS_COLUMN, mcpmUser.getCompanyType().equals("SS") ? 0 : 1);
		Grid columns = partyBRemovalTableColumns.executeQuery(queryParams);
		
		Map<String, Object> params = PlaceholderUtil.preparePlaceholderParams(amendmentId);
		Grid rows = partyBRemovalTableRows.executeQuery(params);
		List<Map<String,String>> lineBreaks = partyBPlaceholderService.getLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER);
		List<Map<String,String>> previousLineBreaks = partyBPlaceholderService.getPreviousLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER);
		PartyBTableResponse partyBTable = new PartyBTableResponse();
		partyBTable.setColumns(columns.getRows());
		partyBTable.setRows(rows.getRows());
		partyBTable.setLineBreaks(lineBreaks);
		partyBTable.setPreviousLineBreaks(previousLineBreaks);
		partyBTable.setPlaceHolderType(PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER);
		return partyBTable;
    }
	
	
	@RequestMapping(value = "lineBreaks", method = RequestMethod.POST)
    @ApiOperation(value = "Update Party B Addition From Buy side")
	@ResponseStatus(value=HttpStatus.CREATED)
	@Transactional
    public void updatePartyBTable(@PathVariable Long amendmentId, 
    		HttpServletRequest request, 
    		HttpServletResponse response,
    		@RequestBody BSPartyBTableRequest bsPartyBTableRequest) throws Exception{
				Long userId = CommonUtil.getUserIdFromSession(request);
				partyBPlaceholderService.updateBSLineBreaks(amendmentId, userId, PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER , bsPartyBTableRequest);
				partyBPlaceholderService.updateAmendment(amendmentId, userId);
    }
	@RequestMapping(value = "ssResponses", method = RequestMethod.PUT)
	@ApiOperation(value = "Update Party B Addition From Sell side")
	@ResponseStatus(value=HttpStatus.CREATED)
	public void updatePartyBTableSS(@PathVariable Long amendmentId, 
			HttpServletRequest request, 
			HttpServletResponse response,
			@RequestBody SSPartyBTableRequest ssPartyBTableRequest) throws Exception{
			ssPartyBTableRequest.setPlaceHolderType(PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER);
			Long userId = CommonUtil.getUserIdFromSession(request);
			partyBPlaceholderService.updateSSResponse(amendmentId, userId, ssPartyBTableRequest);
			partyBPlaceholderService.updateAmendmentBySsResponse(amendmentId, userId);
			partyBPlaceholderService.updateAmendmentStatusAndNextStep(amendmentId);
			partyBPlaceholderService.updateAmendment(amendmentId, userId);
	}
}
