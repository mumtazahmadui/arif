package com.markit.ms.rfa.service.impl;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.markit.ms.rfa.bean.ExhibitTemplate;
import com.markit.ms.rfa.bean.ExhibitTemplateColumn;
import com.markit.ms.rfa.dao.IExhibitTemplateDAO;
import com.markit.ms.rfa.dto.TemplateSearchRequest;
import com.markit.ms.rfa.service.IExhibitTemplateService;
import com.markit.ms.rfa.util.CommonUtil;

@Service
public class ExhibitTemplateServiceImpl implements IExhibitTemplateService{
	
	@Autowired
	IExhibitTemplateDAO exhibitTemplateDAO;
	
	//@Autowired
	//private IAmendmentLetterService amendmentLetterService;
	
	@Override
	@Transactional
	public ExhibitTemplate saveExhibitTemplate(ExhibitTemplate exhibitTemplate) {
		Long id = exhibitTemplateDAO.getExhibitTemplateByName(exhibitTemplate.getCompanyId(), exhibitTemplate.getName());
		if(null != id) {
			exhibitTemplate = null;
		} else {
			exhibitTemplate = exhibitTemplateDAO.saveExhibitTemplate(exhibitTemplate);
		}
		return exhibitTemplate;
	}
	
	@Override
	public Integer validateExhibitTemplateColumns(ExhibitTemplate exhibitTemplate, Boolean forExhibitTemplateCreation, long userId)
	{

		Iterator<ExhibitTemplateColumn> iterator = exhibitTemplate.getColumns().iterator();
		
		while (iterator.hasNext()) {
			ExhibitTemplateColumn exhibitTemplateColumn = iterator.next();
			if(exhibitTemplateColumn == null){
		        iterator.remove();
		    }
		}
		
		if(null != exhibitTemplate.getColumns()) {
    		List<ExhibitTemplateColumn> exhibitTemplateColumnList = exhibitTemplate.getColumns();
    		for(int i = 0; i < exhibitTemplateColumnList.size(); i++){
    			for(int j = i+1; j < exhibitTemplateColumnList.size(); j++){

    				String columnName = exhibitTemplateColumnList.get(i).getColumnName().replaceAll("[^a-zA-Z0-9 ]", "").trim();
    				String nextColumnName = exhibitTemplateColumnList.get(j).getColumnName().replaceAll("[^a-zA-Z0-9 ]", "").trim();
    				if((columnName.length() == 0 && exhibitTemplateColumnList.get(i).getColumnName().length() > 0) ||
    						(nextColumnName.length() == 0 && exhibitTemplateColumnList.get(j).getColumnName().length() > 0)){
    					return 2;
    				}
    				if(columnName.equalsIgnoreCase(nextColumnName)){
    					return 3;
    				}

    			}
    		}
    		
    		if(!forExhibitTemplateCreation){
    			return exhibitTemplateDAO.validateExhibitTemplateColumns(exhibitTemplate, userId);
    		}
    	}
		return 1;
	}
	
	@Override
	@Transactional
	public ExhibitTemplate updateExhibitTemplate(ExhibitTemplate exhibitTemplate) {
		Long id = exhibitTemplateDAO.getExhibitTemplateByName(exhibitTemplate.getCompanyId(), exhibitTemplate.getName());
		if(null != id && CommonUtil.isNotEqual(String.valueOf(id), String.valueOf(exhibitTemplate.getId()))) {
			return null;
		}
		exhibitTemplate = exhibitTemplateDAO.updateExhibitTemplate(exhibitTemplate);
		return exhibitTemplate;
	}
	
	@Override
	@Transactional
	public ExhibitTemplate deleteExhibitTemplate(Long id, Long companyId) {
		return exhibitTemplateDAO.deleteExhibitTemplate(id,companyId);
	}
	
	@Override
	public List<ExhibitTemplate> getAllExhibitTemplatesByCompanyId(Long companyId) {
		return exhibitTemplateDAO.getAllExhibitTemplatesByCompanyId(companyId);
	}
	
	@Override
	public List<ExhibitTemplate> getExhibitTemplateGrid(Long companyId, TemplateSearchRequest exhibitTemplateSearchRequest) {
		return exhibitTemplateDAO.getExhibitTemplateGrid(companyId, exhibitTemplateSearchRequest);
	}

	@Override
	public Long getExhibitTemplateGridTotalCount(Long companyId, TemplateSearchRequest exhibitTemplateSearchRequest) {
		return exhibitTemplateDAO.getExhibitTemplateGridTotalCount(companyId, exhibitTemplateSearchRequest);
	}

	@Override
	public ExhibitTemplate getExhibitTemplateById(Long exhibitTemplateId,Long companyId) {
		return exhibitTemplateDAO.getExhibitTemplateById(exhibitTemplateId, 0L,companyId);
	}
	
	@Override
	public ExhibitTemplate getExhibitTemplateByMasterAgreementId(Long masterAgreementId, Long companyId){
		return exhibitTemplateDAO.getExhibitTemplateByMasterAgreementId(masterAgreementId, 0L, companyId);
	}
	
	@Override
	public void linkMasterlistToExhibitTemplate(Long exhibitTemplateId, Long masterAgreementId, Long companyId, Long userId) {
		exhibitTemplateDAO.linkMasterlistToExhibitTemplate(exhibitTemplateId, masterAgreementId, companyId, userId);
		//amendmentLetterService.createExhibit(masterAgreementId, null, userId);
	}
}
