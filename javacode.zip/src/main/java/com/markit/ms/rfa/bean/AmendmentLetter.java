package com.markit.ms.rfa.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.markit.ms.rfa.bean.AmendmentSignData.SignHoverData;
import com.markit.ms.rfa.bean.enumeration.AmendmentStatus;

public class AmendmentLetter {

	private Long id;
	private List<PartyBEntity> partyBEntities;
	private List<PartyBEntity> partyBAdded;
	private List<PartyBEntity> partyBModification;
	private List<PartyBEntity> partyBRemoved;
	private List<PartyBEntity> partyBWithdrawn;
	private List<PartyBEntity> partyBRejected;
	private List<PartyBEntity> partyBPending;
	private List<PartyBEntity> partyBAccepted;
	private MasterAgreement masterAgreement;
	private String name;
	private Date dateSigned;
	private Long IMSignature;
	private Long partyASignature;
	private Long letterTemplateId;
	private Long exhibitTemplateId;
	private Exhibit exhibit;
	private String content;
	private AmendmentStatus amendmentStatus;
	private AmendmentStatus amendmentStatusSS;
	private Long fileId;
	private Long signFileId;
	private Boolean isDummy;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private Long modifiedBy;
	private Long deleted;
	private Boolean exhibitValued;
	private LetterTemplate letterTemplate;
	@JsonIgnore
	private Long bulkRequestId;
	@JsonIgnore
	private Map<Long, RfaBulkUploadRow> rfaBulkUploadRows;
	@JsonIgnore
	private Map<Long, Exhibit> partyBExhibitMap;
	@Transient
	private NextActions nextActions;
	private Date submitedDate;
	private boolean history;
	private ReviewData reviewData;
	private String bsNextStep;
	private String ssNextStep;
	private int amendmentDeskOneStatus;
	private int amendmentDeskTwoStatus;

	private int bsSignPlaceholderCount;
	private int eSigncount;
	private int wSignCount;
	private String wSignStatus;
	private List<SignHoverData> eSignHoverMetadata;
	private List<SignHoverData> wSignHoverMetadata;
	private int ssSignPlaceholderCount;

	private Integer signedCount;

	private Integer ignoreExhibit;

	private String creationFlow;

	private String mlTemplatename;

	private Long mlCompanyID;
	
	private String comment;
	
	private boolean agreed;
	
	private List<AmendmentCommentAudit> commentlog;
	
	private List<AmendmentChangeAudit> changelog;
	
	private Long totalCount;
	
	private Boolean signDisabled;

	public AmendmentLetter() {

		partyBEntities = new ArrayList<PartyBEntity>();
		partyBAdded = new ArrayList<PartyBEntity>();
		partyBModification = new ArrayList<PartyBEntity>();
		partyBRemoved = new ArrayList<PartyBEntity>();
		partyBWithdrawn = new ArrayList<PartyBEntity>();
		partyBRejected = new ArrayList<PartyBEntity>();
		partyBPending = new ArrayList<PartyBEntity>();
		partyBAccepted = new ArrayList<>();
	}

	public Integer getIgnoreExhibit() {
		return ignoreExhibit;
	}

	public void setIgnoreExhibit(Integer ignoreExhibit) {
		this.ignoreExhibit = ignoreExhibit;
	}

	public LetterTemplate getLetterTemplate() {
		return letterTemplate;
	}

	public void setLetterTemplate(LetterTemplate letterTemplate) {
		this.letterTemplate = letterTemplate;
	}

	public Date getDateSigned() {
		return dateSigned;
	}

	public void setDateSigned(Date dateSigned) {
		this.dateSigned = dateSigned;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<PartyBEntity> getPartyBEntities() {
		return partyBEntities;
	}

	public void setPartyBEntities(List<PartyBEntity> partyBEntities) {
		this.partyBEntities = partyBEntities;
	}

	public MasterAgreement getMasterAgreement() {
		return masterAgreement;
	}

	public void setMasterAgreement(MasterAgreement masterAgreement) {
		this.masterAgreement = masterAgreement;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getIMSignature() {
		return IMSignature;
	}

	public void setIMSignature(Long iMSignature) {
		IMSignature = iMSignature;
	}

	public Long getPartyASignature() {
		return partyASignature;
	}

	public void setPartyASignature(Long partyASignature) {
		this.partyASignature = partyASignature;
	}

	public Long getLetterTemplateId() {
		return letterTemplateId;
	}

	public void setLetterTemplateId(Long letterTemplateId) {
		this.letterTemplateId = letterTemplateId;
	}

	public Long getExhibitTemplateId() {
		return exhibitTemplateId;
	}

	public void setExhibitTemplateId(Long exhibitTemplateId) {
		this.exhibitTemplateId = exhibitTemplateId;
	}

	public Exhibit getExhibit() {
		return exhibit;
	}

	public void setExhibit(Exhibit exhibit) {
		this.exhibit = exhibit;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public AmendmentStatus getAmendmentStatus() {
		return amendmentStatus;
	}

	public void setAmendmentStatus(AmendmentStatus amendmentStatus) {
		this.amendmentStatus = amendmentStatus;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public Boolean getIsDummy() {
		return isDummy;
	}

	public void setIsDummy(Boolean isDummy) {
		this.isDummy = isDummy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Long getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Long getDeleted() {
		return deleted;
	}

	public void setDeleted(Long deleted) {
		this.deleted = deleted;
	}

	public NextActions getNextActions() {
		return nextActions;
	}

	public void setNextActions(NextActions nextActions) {
		this.nextActions = nextActions;
	}

	public Boolean getExhibitValued() {
		return exhibitValued;
	}

	public void setExhibitValued(Boolean exhibitValued) {
		this.exhibitValued = exhibitValued;
	}

	public List<PartyBEntity> getPartyBAdded() {
		return partyBAdded;
	}

	public void setPartyBAdded(List<PartyBEntity> partyBAdded) {
		this.partyBAdded = partyBAdded;
	}

	public List<PartyBEntity> getPartyBRemoved() {
		return partyBRemoved;
	}

	public void setPartyBRemoved(List<PartyBEntity> partyBRemoved) {
		this.partyBRemoved = partyBRemoved;
	}

	public List<PartyBEntity> getPartyBWithdrawn() {
		return partyBWithdrawn;
	}

	public void setPartyBWithdrawn(List<PartyBEntity> partyBWithdrawn) {
		this.partyBWithdrawn = partyBWithdrawn;
	}

	public Date getSubmitedDate() {
		return submitedDate;
	}

	public void setSubmitedDate(Date submitedDate) {
		this.submitedDate = submitedDate;
	}

	public List<PartyBEntity> getPartyBRejected() {
		return partyBRejected;
	}

	public void setPartyBRejected(List<PartyBEntity> partyBRejected) {
		this.partyBRejected = partyBRejected;
	}

	public List<PartyBEntity> getPartyBPending() {
		return partyBPending;
	}

	public void setPartyBPending(List<PartyBEntity> partyBPending) {
		this.partyBPending = partyBPending;
	}

	public Long getSignFileId() {
		return signFileId;
	}

	public void setSignFileId(Long signFileId) {
		this.signFileId = signFileId;
	}

	public ReviewData getReviewData() {
		return reviewData;
	}

	public void setReviewData(ReviewData reviewData) {
		this.reviewData = reviewData;
	}

	public AmendmentStatus getAmendmentStatusSS() {
		return amendmentStatusSS;
	}

	public void setAmendmentStatusSS(AmendmentStatus amendmentStatusSS) {
		this.amendmentStatusSS = amendmentStatusSS;
	}

	public String getBsNextStep() {
		return bsNextStep;
	}

	public void setBsNextStep(String bsNextStep) {
		this.bsNextStep = bsNextStep;
	}

	public String getSsNextStep() {
		return ssNextStep;
	}

	public void setSsNextStep(String ssNextStep) {
		this.ssNextStep = ssNextStep;
	}

	public boolean isHistory() {
		return history;
	}

	public void setHistory(boolean history) {
		this.history = history;
	}

	public List<PartyBEntity> getPartyBModification() {
		return partyBModification;
	}

	public void setPartyBModification(List<PartyBEntity> partyBModification) {
		this.partyBModification = partyBModification;
	}

	public int getBsSignPlaceholderCount() {
		return bsSignPlaceholderCount;
	}

	public void setBsSignPlaceholderCount(int bsSignPlaceholderCount) {
		this.bsSignPlaceholderCount = bsSignPlaceholderCount;
	}

	public int getSsSignPlaceholderCount() {
		return ssSignPlaceholderCount;
	}

	public void setSsSignPlaceholderCount(int ssSignPlaceholderCount) {
		this.ssSignPlaceholderCount = ssSignPlaceholderCount;
	}

	public Integer getSignedCount() {
		return signedCount;
	}

	public void setSignedCount(Integer signedCount) {
		this.signedCount = signedCount;
	}

	public String getCreationFlow() {
		return creationFlow;
	}

	public void setCreationFlow(String creationFlow) {
		this.creationFlow = creationFlow;
	}

	public String getMlTemplatename() {
		return mlTemplatename;
	}

	public void setMlTemplatename(String mlTemplatename) {
		this.mlTemplatename = mlTemplatename;
	}

	public Long getMlCompanyID() {
		return mlCompanyID;
	}

	public void setMlCompanyID(Long mlCompanyID) {
		this.mlCompanyID = mlCompanyID;
	}

	/**
	 * Places sleeves at the end of the list to ensure parents are inserted first.
	 * This allows sleeves to reference their parent's party b id at insertion time.
	 */
	public void sortSleevesForInsertion() {
		Collections.sort(partyBEntities, new SleeveSort());
	}

	/**
	 * Places sleeves at the end of the list to ensure parents are inserted first.
	 * This allows sleeves to reference their parent's party b id at insertion time.
	 */
	public class SleeveSort implements Comparator<PartyBEntity> {

		@Override
		public int compare(PartyBEntity o1, PartyBEntity o2) {
			if (o1.getEntity().getIsSleeve() > o2.getEntity().getIsSleeve())
				return 1;
			else if (o1.getEntity().getIsSleeve() < o2.getEntity().getIsSleeve())
				return -1;
			else
				return 0;
		}

	}

	public Long getBulkRequestId() {
		return bulkRequestId;
	}

	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}

	public Map<Long, RfaBulkUploadRow> getRfaBulkUploadRows() {
		return rfaBulkUploadRows;
	}

	public void setRfaBulkUploadRows(Map<Long, RfaBulkUploadRow> rfaBulkUploadRows) {
		this.rfaBulkUploadRows = rfaBulkUploadRows;
	}

	public Map<Long, Exhibit> getPartyBExhibitMap() {
		return partyBExhibitMap;
	}

	public void setPartyBExhibitMap(Map<Long, Exhibit> partyBExhibitMap) {
		this.partyBExhibitMap = partyBExhibitMap;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public boolean isAgreed() {
		return agreed;
	}

	public void setAgreed(boolean agreed) {
		this.agreed = agreed;
	}

	public List<AmendmentCommentAudit> getCommentlog() {
		return commentlog;
	}

	public void setCommentlog(List<AmendmentCommentAudit> commentlog) {
		this.commentlog = commentlog;
	}

	public List<AmendmentChangeAudit> getChangelog() {
		return changelog;
	}

	public void setChangelog(List<AmendmentChangeAudit> changelog) {
		this.changelog = changelog;
	}

	public List<PartyBEntity> getPartyBAccepted() {
		return partyBAccepted;
	}

	public void setPartyBAccepted(List<PartyBEntity> partyBAccepted) {
		this.partyBAccepted = partyBAccepted;
	}

	public int getAmendmentDeskOneStatus() {
		return amendmentDeskOneStatus;
	}

	public void setAmendmentDeskOneStatus(int amendmentDeskOneStatus) {
		this.amendmentDeskOneStatus = amendmentDeskOneStatus;
	}

	public int getAmendmentDeskTwoStatus() {
		return amendmentDeskTwoStatus;
	}

	public void setAmendmentDeskTwoStatus(int amendmentDeskTwoStatus) {
		this.amendmentDeskTwoStatus = amendmentDeskTwoStatus;
	}
	
	public int geteSigncount() {
		return eSigncount;
	}

	public void seteSigncount(int eSigncount) {
		this.eSigncount = eSigncount;
	}

	public int getwSignCount() {
		return wSignCount;
	}

	public void setwSignCount(int wSignCount) {
		this.wSignCount = wSignCount;
	}

	public List<SignHoverData> geteSignHoverMetadata() {
		return eSignHoverMetadata;
	}

	public void seteSignHoverMetadata(List<SignHoverData> eSignHoverMetadata) {
		this.eSignHoverMetadata = eSignHoverMetadata;
	}

	public List<SignHoverData> getwSignHoverMetadata() {
		return wSignHoverMetadata;
	}

	public void setwSignHoverMetadata(List<SignHoverData> wSignHoverMetadata) {
		this.wSignHoverMetadata = wSignHoverMetadata;
	}

	public String getwSignStatus() {
		return wSignStatus;
	}

	public void setwSignStatus(String wSignStatus) {
		this.wSignStatus = wSignStatus;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public Boolean getSignDisabled() {
		return signDisabled;
	}

	public void setSignDisabled(Boolean signDisabled) {
		this.signDisabled = signDisabled;
	}
	
	
}
