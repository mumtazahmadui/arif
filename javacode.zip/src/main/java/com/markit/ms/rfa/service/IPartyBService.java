package com.markit.ms.rfa.service;

import java.util.List;

import com.markit.ms.rfa.bean.PartyBEntity;

public interface IPartyBService {
	public List<PartyBEntity> withdrawPartyB(Long userId, List<PartyBEntity> partyBEntityList);
	public void copyPartyBEntitiesToSnap(Long amendmentId, Long userId);
	public Long getPartyBIdByLegalName(String legalName, Long amendmentId);
	public Long getPartyBIdByLegalNameAndClientId(String legalName, String clientId, Long amendmentId);
	public List<PartyBEntity> getSleevesInProgress(Long parentEntityId, Long masterlistId);
}
