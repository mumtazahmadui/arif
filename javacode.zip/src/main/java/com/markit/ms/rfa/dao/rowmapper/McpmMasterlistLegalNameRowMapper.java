package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.rfa.bean.McpmMasterlistLegalNameMapper;

public class McpmMasterlistLegalNameRowMapper implements RowMapper<McpmMasterlistLegalNameMapper> {

	@Override
	public McpmMasterlistLegalNameMapper mapRow(ResultSet rs, int rowNum) throws SQLException {
		McpmMasterlistLegalNameMapper mcpmMasterlistLegalNameMapper = new McpmMasterlistLegalNameMapper();
		mcpmMasterlistLegalNameMapper.setMasterlistLegalName(rs.getString("masterlist_legal_name"));
		mcpmMasterlistLegalNameMapper.setMcpmLegalName(rs.getString("mcpm_legal_name"));
		return mcpmMasterlistLegalNameMapper;
	}
}
