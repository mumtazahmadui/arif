package com.markit.ms.rfa.security;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.springframework.security.core.userdetails.UserDetails;

import com.google.common.base.Preconditions;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.marketxs.userxs.session.api.SessionException;
import com.marketxs.userxs.session.api.SessionService;
import com.marketxs.userxs.session.objects.interfaces.AccountTicket;
import com.markit.kyc.security.UserxsUser;
import com.markit.kyc.security.service.UserDetailsService;
import com.markit.ms.rfa.security.domain.McpmUser;
import com.markit.ms.rfa.security.repository.McpmSecurityUserRepository;

public class UserDetailsServiceImpl implements UserDetailsService {

	private static final long DEFAULT_MAX_CACHE_SIZE = 25000;
    private static final int DEFAULT_CACHE_EVICT_SECONDS = 5*60; // 5 minutes    
	
	private McpmSecurityUserRepository repository;
	@Resource SessionService sessionService;
	private LoadingCache<UserxsUser, UserDetails> mcpmSecurityUserRepositoryCache = CacheBuilder.newBuilder()
			.maximumSize(DEFAULT_MAX_CACHE_SIZE)
			.expireAfterWrite(DEFAULT_CACHE_EVICT_SECONDS, TimeUnit.SECONDS)
	        .build(new CacheLoader<UserxsUser, UserDetails>() {
				@Override
				public UserDetails load(UserxsUser userXS) throws Exception {
					return doLoadUser(userXS);
				}
	        });
	

	@PostConstruct
	public void init() {
		Preconditions.checkNotNull(repository);
	}

	@Override
	public UserDetails loadUser(UserxsUser userXS) {
		try {
			return mcpmSecurityUserRepositoryCache.get(userXS);
		} catch (ExecutionException _ex) {
			if (_ex.getCause() instanceof RuntimeException) throw (RuntimeException)_ex.getCause();
			else 											throw new RuntimeException(_ex.getCause());
		}
	}
	
	private UserDetails doLoadUser(UserxsUser userXS) {

		McpmUser mcpmUser = repository.findByAccountUniqueId(userXS.getAccountUniqueId());
		String ticketId = userXS.getTicketId();
		long loggedInTime = 0;
		try {
			AccountTicket ticket = sessionService.validateTicket(ticketId);
			loggedInTime = ticket.getCreationTime();
		} catch (SessionException e) {
			throw (RuntimeException)e.getCause();
		}
		return new McpmUserxsDetails(mcpmUser, userXS, loggedInTime);
	}
	
	/* SPRING RELATHER METHODS */

	public void setRepository(McpmSecurityUserRepository repository) {
		this.repository = repository;
	}
	
}
