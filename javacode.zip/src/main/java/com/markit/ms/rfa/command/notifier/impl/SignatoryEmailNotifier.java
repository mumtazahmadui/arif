package com.markit.ms.rfa.command.notifier.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.domain.Grid.Row;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.bean.User;
import com.markit.ms.common.util.TemplateTypeEnum;
import com.markit.ms.rfa.bean.BulkEmailVelocityTemplateValues;
import com.markit.ms.rfa.bean.BulkNotificationBean;
import com.markit.ms.rfa.bean.BulkSignatoryNotificationBean;
import com.markit.ms.rfa.command.notifier.BulkActionEmailNotifier;
import com.markit.ms.rfa.service.IDeskReviewService;
import com.markit.ms.rfa.service.IMcsRedirectUrlGenerator;

@Component
public class SignatoryEmailNotifier extends BulkActionEmailNotifier {

	@Resource(name = "signatoryEmailUrlGenerator")
	private IMcsRedirectUrlGenerator signatoryEmailUrlGenerator;

	@Autowired
	IDeskReviewService deskReviewService;
	
	@Resource 
	protected QueryService<Grid> getIMsForRFAIds;
	
	@Override
	public void sendEmailNotification(BulkNotificationBean bulkNotificationBean) throws Exception {
		BulkSignatoryNotificationBean bulkSignatoryNotificationBean = (BulkSignatoryNotificationBean)bulkNotificationBean;
		Map<String, NotificationData> emailTemplateUrlParams = Maps.newHashMap();
		Map<Long, String> rfaIdsWithIMsMap = generateIMNames(bulkNotificationBean.getRfaIdList());
		NotificationData notificationData = null;
		for (Long rfaId : bulkNotificationBean.getRfaIdList()) {
			notificationData = new NotificationData();
			notificationData.setImName(rfaIdsWithIMsMap.get(rfaId));
			notificationData.setUrl(signatoryEmailUrlGenerator.generateUrl(ImmutableMap.of("amendment_id", String.valueOf(rfaId))));
			emailTemplateUrlParams.put(String.valueOf(rfaId), notificationData);
		}
		
		Map<String, Object> subjectVariables = Maps.newHashMapWithExpectedSize(1);
		subjectVariables.put("subj_suffix", generateSubjectText(bulkSignatoryNotificationBean));
		for (User user : bulkNotificationBean.getEmailRecipients()) {
			BulkEmailVelocityTemplateValues velocityObj = new BulkEmailVelocityTemplateValues();
			velocityObj.setSignatoryData(emailTemplateUrlParams);
			velocityObj.setFname(user.getFname());
			velocityObj.setEmail(user.getEmail());
			velocityObj.setCustomMessage(bulkSignatoryNotificationBean.getCustomNotificationMessage());
			velocityObj.setSenderName(bulkSignatoryNotificationBean.getSenderName());
			velocityObj
					.setLogin(deskReviewService.generateUrl(getFilterCriteriaJson(bulkNotificationBean.getRfaIdList()),
							bulkSignatoryNotificationBean.getUserId(), TemplateTypeEnum.RFA_SIGNATORY_NOTIFICATION));
			rfaMailService.sendEmailWithCC(Lists.newArrayList(velocityObj.getEmail()), ImmutableMap.of("velObj", velocityObj), emailBodyTemplate,
					emailSubjectTemplate, subjectVariables, bulkSignatoryNotificationBean.getNotifiedBy());
		}
	}

	private Map<Long, String> generateIMNames(List<Long> rfaIds) {
		Map<String, Object> params = new HashMap<>();
		params.put("rfaIds", rfaIds);
		Map<Long, String> imNamesMap = new HashMap<Long, String>();
		Grid userEmails = getIMsForRFAIds.executeQuery(params);
		for(Row row : userEmails.getRowList()) {
			imNamesMap.put(Long.valueOf(row.get("id")), row.get("name"));
		}
		return imNamesMap;
	}

	private String generateSubjectText(BulkSignatoryNotificationBean bulkNotificationBean) {
		StringBuilder stringBuilder = new StringBuilder("<");
		if(bulkNotificationBean.isESign()) {
			stringBuilder.append("E-Sign");
		} 
		if(bulkNotificationBean.isWSign()) {
			if(stringBuilder.toString().contains("E-Sign")) {
				stringBuilder.append("/");
			}
			stringBuilder.append("Wet Sign");
		}
		stringBuilder.append(">");
		return stringBuilder.toString();
	}
	
	public static class NotificationData {
		private String url;
		private String imName;
		public String getUrl() {
			return url;
		}
		public void setUrl(String url) {
			this.url = url;
		}
		public String getImName() {
			return imName;
		}
		public void setImName(String imName) {
			this.imName = imName;
		}
	}

	public QueryService<Grid> getGetIMsForRFAIds() {
		return getIMsForRFAIds;
	}

	public void setGetIMsForRFAIds(QueryService<Grid> getIMsForRFAIds) {
		this.getIMsForRFAIds = getIMsForRFAIds;
	}
	
	private String getFilterCriteriaJson(List<Long> rfaIds) {

		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("rfaId", rfaIds);

		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.create();

		return gson.toJson(resultMap);

	}
	
}