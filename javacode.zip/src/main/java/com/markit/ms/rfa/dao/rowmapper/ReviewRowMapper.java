package com.markit.ms.rfa.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.markit.ms.rfa.bean.LegalReviewData;
import com.markit.ms.rfa.bean.OnBoardingReviewData;
import com.markit.ms.rfa.bean.ReviewData;

public class ReviewRowMapper implements ResultSetExtractor<ReviewData> {
	private int reviewType = 0;
	public ReviewRowMapper(int reviewType) {
		this.reviewType = reviewType;
	}
	@Override
	public ReviewData extractData(ResultSet rs) throws SQLException,
			DataAccessException {
		ReviewData reviewData = new ReviewData();
		if(rs.next()) {
		Long reviewId = rs.getLong("review_id");
		String updatedBy = rs.getString("updated_by");
		boolean editable = rs.getInt("is_editable") != 0? true : false;
		if(reviewType == 2) {
			LegalReviewData legalReview = new LegalReviewData();
			legalReview.setLegal_review_id(reviewId);
			legalReview.setEditable(editable);
			legalReview.setReview_id(reviewType);
			legalReview.setUpdateBy(updatedBy);
			reviewData.setLegal(legalReview);
		} else {
			OnBoardingReviewData onBoardingReviewData = new OnBoardingReviewData();
			onBoardingReviewData.setOnBoarding_review_id(reviewId);
			onBoardingReviewData.setEditable(editable);
			onBoardingReviewData.setReview_id(reviewType);
			onBoardingReviewData.setUpdateBy(updatedBy);
			reviewData.setOnboarding(onBoardingReviewData);
		}
		}
		return reviewData;
	}

}
