package com.markit.ms.rfa.bean;

public class RfaBulkUploadedData {
	private Long id;
	private Long bulkRequestId;
	private Long partyBId;
	private String partyBTrueLegalName;
	private String partyBClientIdentifier;
	private String partyBLEI;
	private String sleeveTrueLegalName;
	private String sleeveClientIdentifier;
	private String rawPartyBTrueLegalName;
	private String rawPartyBClientIdentifier;
	private String rawPartyBLEI;
	private String rawSleeveTrueLegalName;
	private String rawSleeveClientIdentifier;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getBulkRequestId() {
		return bulkRequestId;
	}
	public void setBulkRequestId(Long bulkRequestId) {
		this.bulkRequestId = bulkRequestId;
	}
	public Long getPartyBEntityId() {
		return partyBId;
	}
	public void setPartyBId(Long partyBId) {
		this.partyBId = partyBId;
	}
	public String getPartyBTrueLegalName() {
		return partyBTrueLegalName;
	}
	public void setPartyBTrueLegalName(String partyBTrueLegalName) {
		this.partyBTrueLegalName = partyBTrueLegalName;
	}
	public String getPartyBClientIdentifier() {
		return partyBClientIdentifier;
	}
	public void setPartyBClientIdentifier(String partyBClientIdentifier) {
		this.partyBClientIdentifier = partyBClientIdentifier;
	}
	public String getPartyBLEI() {
		return partyBLEI;
	}
	public void setPartyBLEI(String partyBLEI) {
		this.partyBLEI = partyBLEI;
	}
	public String getSleeveTrueLegalName() {
		return sleeveTrueLegalName;
	}
	public void setSleeveTrueLegalName(String sleeveTrueLegalName) {
		this.sleeveTrueLegalName = sleeveTrueLegalName;
	}
	public String getSleeveClientIdentifier() {
		return sleeveClientIdentifier;
	}
	public void setSleeveClientIdentifier(String sleeveClientIdentifier) {
		this.sleeveClientIdentifier = sleeveClientIdentifier;
	}
	public String getRawPartyBTrueLegalName() {
		return rawPartyBTrueLegalName;
	}
	public void setRawPartyBTrueLegalName(String rawPartyBTrueLegalName) {
		this.rawPartyBTrueLegalName = rawPartyBTrueLegalName;
	}
	public String getRawPartyBClientIdentifier() {
		return rawPartyBClientIdentifier;
	}
	public void setRawPartyBClientIdentifier(String rawPartyBClientIdentifier) {
		this.rawPartyBClientIdentifier = rawPartyBClientIdentifier;
	}
	public String getRawPartyBLEI() {
		return rawPartyBLEI;
	}
	public void setRawPartyBLEI(String rawPartyBLEI) {
		this.rawPartyBLEI = rawPartyBLEI;
	}
	public String getRawSleeveTrueLegalName() {
		return rawSleeveTrueLegalName;
	}
	public void setRawSleeveTrueLegalName(String rawSleeveTrueLegalName) {
		this.rawSleeveTrueLegalName = rawSleeveTrueLegalName;
	}
	public String getRawSleeveClientIdentifier() {
		return rawSleeveClientIdentifier;
	}
	public void setRawSleeveClientIdentifier(String rawSleeveClientIdentifier) {
		this.rawSleeveClientIdentifier = rawSleeveClientIdentifier;
	}



}
