package com.markit.ms.rfa.service.masterlist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class MasterlistDownloadUtil {

	public static LinkedList<Long> sortAndOrder(Map<Long, Date> entityIdWithModifyDate,List<Long> parentEntityIds ,int y)
	{
		
		List<Entry<Long, Date>> sortedMap = sortEntityIdModifyDateMap(entityIdWithModifyDate);
		int firstParent=0;
		LinkedList<Long> entityIdList =new LinkedList<Long>();

		for (Map.Entry<Long, Date> entry : sortedMap) {
  			Long entityId=entry.getKey();
			Date date= entry.getValue();
			Long parentEntityId=parentEntityIds.get(y);
			Date parentEntityIdDate=entityIdWithModifyDate.get(parentEntityIds.get(y));
			if(parentEntityIdDate.equals(date))
			{
				if(entityId.equals(parentEntityId))
					firstParent=y;
				else
					entityIdList.addFirst(entityId);
			}
			else
				entityIdList.add(entityId);							
			
		}
		entityIdList.addFirst(parentEntityIds.get(firstParent));	
		
		return entityIdList;
		
	}
	
	private static List<Entry<Long, Date>> sortEntityIdModifyDateMap(Map<Long, Date> entityIdWithModifyDate) {
		Set<Entry<Long, Date>> set = entityIdWithModifyDate.entrySet();
        List<Entry<Long, Date>> list = new ArrayList<Entry<Long, Date>>(set);
        Collections.sort( list, new Comparator<Map.Entry<Long, Date>>()
        {
            public int compare( Map.Entry<Long, Date> o1, Map.Entry<Long, Date> o2 )
            {
                return (o2.getValue()).compareTo( o1.getValue() );
            }
        } );
        return list;
    }

	public static void mergeCellsForValues(SXSSFWorkbook workbook,int sheetNum, int startRowIdForParent, int endRowIdOfParent,int fromColumNum, int toColumnNum,boolean isExhibit )
	{
		Map<String,Integer> startCounterForValue = new HashMap<>();
    	Map<String,Integer> endCounterForValue = new HashMap<>();
    	for(int iterCol = fromColumNum; iterCol < toColumnNum; iterCol++ )
    	{
  
    		
    		for(int iterRow = startRowIdForParent; iterRow < endRowIdOfParent; iterRow++){    			
    			String value=null;
    			if(workbook.getSheetAt(sheetNum).getRow(iterRow).getCell(iterCol) !=null)
    				 value = workbook.getSheetAt(sheetNum).getRow(iterRow).getCell(iterCol).getStringCellValue();
    			endCounterForValue.put(value, iterRow);
    			if(!startCounterForValue.containsKey(value)) {
    				startCounterForValue.put(value,iterRow);
    			}
    			
    		
    		}
    	
    		
    		List<String> allValuesInColumn = new ArrayList<>(startCounterForValue.keySet());
    		for(String aValue : allValuesInColumn) {
    			Integer startIndex = startCounterForValue.get(aValue);
    			Integer endIndex = endCounterForValue.get(aValue);
    			
    			if(startIndex < endIndex) {
        			for(int iter = startIndex+1; iter < endIndex; iter++) {
        				workbook.getSheetAt(sheetNum).getRow(iter).getCell(iterCol).setCellValue("");
        			}
        			workbook.getSheetAt(sheetNum).addMergedRegion(new CellRangeAddress(startIndex,endIndex,iterCol,iterCol));
    			}
    		}
    		startCounterForValue.clear();
    		endCounterForValue.clear();
    	}
	}	
	
}
