package com.markit.ms.rfa.bean;

public class AmendmentHistory {
private String name;
private String dateSigned;
private Long fileId;
public Long getFileId() {
	return fileId;
}
public void setFileId(Long fileId) {
	this.fileId = fileId;
}
public String getDateSigned() {
	return dateSigned;
}
public void setDateSigned(String dateSigned) {
	this.dateSigned = dateSigned;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
}
