package com.markit.ms.rfa.util;

import java.util.ArrayList;
import java.util.List;

public class RFAConstants {
	public static String DESTINATION_URL = "/home/link/MDE.MDE.Welcome?app=rfa";
	public static String LETTER_TEMPLATE_ALREADY_EXIST = "Letter Template already exist with this name. Please choose a different name.";
	public static String MASTERLIST_TEMPLATE_ALREADY_EXIST = "Masterlist template name exists. Please enter new name.";
	public static String MASTERLIST_TEMPLATE_DOESNT_EXIST = "Masterlist Template doesn't exists with the given id.";
	public static String EXHIBIT_TEMPLATE_ALREADY_EXIST = "Exhibit Template already exist with this name. Please choose a different name.";
	public static String AMENDMENT_LETTER_RECALL_FAILURE = "Amendment Letter can't be recalled as Counterparty has already actioned on it.";
	public static String PARTYB_WITHDRAW_FAILURE = "Selected PartyB accounts can't be withdrawn.";
	public static String RFA_EXCEPTION_RESPONSE_CODE = "400";
	public static final String PARTYB_TRUE_LEGAL_NAME_FIELD = "Party B True Legal Name";
	public static final String PARTYB_CLIENT_IDENTIFIER_FIELD = "Party B Client Identifier";
	public static final String PARTYB_LEI_FIELD = "Pre-LEI/LEI";
	public static String PARTYB_ACCOUNT_TRUE_LEGAL_NAME_FIELD = "Party B Account True Legal Name";
	public static String PARTYB_ACCOUNT_CLIENT_IDENTIFIER_FIELD = "Party B Account Client Identifier";
	public static String PARTYB_ACCOUNT_LEI_FIELD = "Party B Account Pre-LEI/LEI";
	public static final String SLEEVE_CLIENT_IDENTIFIER_FIELD = "Sleeve Client Identifier";
	public static final String SLEEVE_TRUE_LEGAL_NAME_FIELD = "Sleeve True Legal Name";
	public static String DATE_ADDED_FIELD = "Date Added";
	public static String DATE_REMOVED_FIELD = "Removed Date";
	public static String DATE_ADDED_STRING = "addedDateString";
	public static String RFA_ID_FIELD = "RFA ID";
	public static String COMPANY_TYPE_SS = "SS";
	public static String COMPANY_TYPE_BS = "BS";
	public static String EVENT_NAME_E_SIGN_BS = "BS_E_SIGNATURE";
	public static String EVENT_NAME_E_SIGN_SS = "SS_E_SIGNATURE";
	public static String EVENT_NAME_W_SIGN_BS = "BS_WET_SIGNATURE";
	public static String EVENT_NAME_W_SIGN_SS = "SS_WET_SIGNATURE";
	public static String EVENT_NAME_PRINT_DOWNLOAD_BS = "BS_PRINT_DOWNLOAD";
	public static String EVENT_NAME_PRINT_DOWNLOAD_SS = "SS_PRINT_DOWNLOAD";
	public static String EVENT_NAME_DELETED_BS = "BS_DELETED";


	public static String SS_COMPANY_ACTION_ONLY = "The attempted action is only valid for Sellside companies.";
	public static String BS_COMPANY_ACTION_ONLY = "The attempted action is only valid for Buyside companies.";
	public static String RFA_RECEIVED_STATUS = "Received";
	public static String RFA_REJECTED_STATUS = "Rejected";
	public static String NOT_YET_RESPONDED_STATUS = "NOT_YET_RESPONDED";
	public static final String MODIFICATION_FUND_NAME_CHANGE = "Modification - Fund Name Change";
	public static final String MODIFICATION_EXHIBIT_VALUE_CHANGE = "Modification - Exhibit Value Change";
	public static final String REMOVAL = "Removal";
	public static final String MASTERLIST_IDENTIFIER = "Masterlist Identifier";
	public static final String REF_MASTER_AGREEMENT_DATE = "Reference Master Agreement Date";
	public static final String AGREEMENT_TYPE = "Agreement Type";
	public static final String DEALER = "Dealer";
	public static final String PARTY_B_LEI = "Party B Pre-LEI/LEI";
	public static final String INVESTMENT_MANAGER = "Investment Manager";
	public static final String PARTYA_TRUE_LEGAL_NAME_FIELD = "Party A True Legal Name";
	public static String COUNTERPATY_NAME = "Counterparty Name";
	public static String PARTYB_LEI = "Party B Pre-LEI/LEI";
	public static String OLD_LEGAL_NAME = "Old Party B True Legal Name";
	public static String NEW_LEGAL_NAME = "New Party B True Legal Name";
	public static String OLD_CLIENT_IDENTIFIER = "Old Party B Client Identifier";
	public static String NEW_CLIENT_IDENTIFIER = "New Party B Client Identifier";
	public static String OLD_LEI = "Old Party B Pre-LEI/LEI";
	public static String NEW_LEI = "New Party B Pre-LEI/LEI";
	public static final String PARTYB_ACTION = "Action";
	public static final String ACTION = "Action";
	public static String IS_SLEEVE = "Sleeve";
	public static String MASTERLIST_EXISTS_WITH_AGREEMENT_TYPE = "Masterlist already exists with the agreement type";
	public static String INCORRECT_FILE_EXTENSION = "Incorrect file format. Please upload excel workbook";
	public static String INCORRECT_WSIGFILE_EXTENSION = "Incorrect file format. Please upload permitted formats";
	public static String WSIG_UPLOAD_MISMATCH = "Uploaded file doesn't match with original RFA document";
	public static String LEGACY = "Legacy";
	public static String LEGACY_NO_AGREEMENT_TYPE_WITH_SLEEVE = "Legacy No Agreement Type With Sleeve";
	public static String LEGACY_WITH_AGREEMENT_TYPE_WITH_SLEEVE = "Legacy With Agreement Type With Sleeve";
	public static String RFA_UPLOAD_TEMPLATE_SLEEVE = "Select either Sleeve True Legal Name OR Sleeve Client Identifier as Entity Identifier";
	public static String RFA_UPLOAD_TEMPLATE_ENTITY_IDENTIFIER = "Select either Party B True Legal Name OR Party B Client Identifier as Entity Identifier";
	public static String RFA_UPLOAD_TEMPLATE_EXISTS = "Upload Template name exists. Please enter new name.";
	public static String RFA_UPLOAD_TEMPLATE_SLEEVE_BOTH_PRESENT = " should be present";
	public static String AND = "/";
	public static final String DUPLICATE_INFORMATION_PROVIDED_FOR_SLEEVE = "Duplicate information is provided for ${sleeveLabel} in this record.";
	public static final String DUPLICATE_INFORMATION_PROVIDED_FOR_RECORD = "Duplicate account with differing information provided.";
	public static final String ENTITY_TRUE_LEGAL_NAME = "True Legal Name";
	public static final String CLIENT_IDENTIFIER = "Client Identifier";
	public static final String ANOTHER_ENTITY_EXISTS = "Another legal entity exists with the same ${existingFieldInMCPM} as the input provided for ${fieldLabel}";
	public static final String SLEEVE_TAGGED_TO_ANOTHER_PARENT = "${sleeveIdentifier} already tagged to another ${partybIdentifier} on Active Tab of the Masterlist";

	public static String RFA_UPLOAD_TEMPLATE_DOESNT_EXIST = "Upload Template doesn't exists with the given id.";
	public static String RFA_UPLOAD_TEMPLATE_FIELDS_DONT_EXIST = "Upload Template Fields don't exist with the given id.";
	public static String RFA_UPLOAD_CONFLICTING_ACTION = "${requestType} cannot be actioned on this ${entityIdentifier} due to another conflicting request in this upload file.";

	public static String INCORRECT_ERROR_LIST = "Incorrect List of Error for error file";
	public static String MANDATORY_FIELD_AGREEMENT_DATE_MISSING = "Agreement Date is missing";
	public static String MANDATORY_FIELD_PARTYA_MISSING = "Party A is missing";
	public static String MANDATORY_FIELD_AGREEMENT_TYPE_MISSING = "Agreement Type is missing";

	public static String DATE_FORMATTING_ERROR = "Different date format specified in upload template. Please provide date in ";
	public static String NO_INPUT_PROVIDED = "No input provided for ";
	public static String NOT_FOUND_IN_MCPM = "${fieldLabel} not found in Counterparty Manager";
	public static final String RFA_LETTER_TEMPLATE_DOESNT_EXIST = "Letter Template for ${requestType} not found in the Letter Template Library. Please contact MCPM Support at IHS Markit - mcpmsupport@ihsmarkit.com";
	public static final String RFA_EXHIBIT_LINKAGE_DOESNT_EXIST = "No exhibit linked with this Masterlist. Please contact MCPM Support at IHS Markit - mcpmsupport@ihsmarkit.com";
	public static final String RFA_INVALID_ACTION = "Invalid Action specified";

	public static final String APPLICATION_DETERMINES = "Application Determines";
	public static final String ALL_ACIION = "All actions";
	public static final String ADDITION = "Addition";
	public static final String MODIFICATIONS = "Modifications";
	public static final String BLANK_ADD = "Add";
	public static final String FNC = "FNC";
	public static final String EVC = "EVC";

	public static final String BLANK_REMOVE = "Remove";
	public static final String ADDITION_REMOVAL = "Addition and Removal";
	public static final String ADDITION_MODIFICATION = "Addition and Modifications";

	public static final String BULK_UPLOAD_STATUS_ERROR = "Error";
	public static final String BULK_UPLOAD_STATUS_COMPLETE = "Completed";
	public static final String BULK_UPLOAD_STATUS_INPROGRESS = "In Progress";

	public static final String MASTER_AGREEMENT_NOT_FOUND = "Unable to identify this Masterlist with the provided inputs";

	public static final String RFA_BULK_UPLOAD_DEFAULT_DATE_FORMAT = "dd/MM/yyyy";
	public static final String RFA_T_Z_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final String RFA_DD_MMM_YYYY_DATE_TIME_FORMAT = "dd-MMM-yyyy HH:mm:ss";

	public static List<String> defaultExhibitFields = new ArrayList<String>() {
		{
			add(RFAConstants.PARTYB_TRUE_LEGAL_NAME_FIELD);
			add(RFAConstants.PARTYB_CLIENT_IDENTIFIER_FIELD);
			add(RFAConstants.PARTYB_LEI_FIELD);
			add(RFAConstants.SLEEVE_TRUE_LEGAL_NAME_FIELD);
			add(RFAConstants.SLEEVE_CLIENT_IDENTIFIER_FIELD);
			add(RFAConstants.PARTYB_ACTION);
			add(RFAConstants.PARTYB_LEI);

		}
	};

	public static String EXHIBIT_TEMPLATE_COLUMN_VALIDATION_FAILURE = "Exhibit Template column name already exists.";

	public static String EXHIBIT_TEMPLATE_DUPLICATE_COLUMN = "Exhibit Template have duplicate columns, please choose unique name for each column.";

	public static String EXHIBIT_INVALID_COLUMN_NAME = "Incorrect column Header. Must have at least one alphanumeric character";

	///// UPDATE BS NEXT STEP / TASK
	public static String ACTION_SAVE = "SAVE";
	public static String ACTION_UPDATE = "UPDATE";
	public static String ACTION_EXHIBIT_UPDATE = "EDIT_EXHIBIT";
	public static String ACTION_EXHIBIT_TEMPLAT_UPDATE = "EDIT_EXHIBIT_TEMPLATE";
	public static String ACTION_RECALL = "RECALL";
	public static String ACTION_REJECT = "REJECT";
	public static String ACTION_DELETE = "DELETE";
	public static String ACTION_EDIT_DRAFT = "EDIT_DRAFT";
	public static String ACTION_SIGN = "SIGN";
	public static String ACTION_SEND_RFA = "SEND_RFA";
	public static String ACTION_SS_UPDATE = "SS_UPDATE";
	public static String ACTION_SS_SIGN = "SS_SIGN";
	public static String ACTION_SS_SEND_RFA = "SS_SEND_RFA";

	// HTML PARSER PARAMS
	public static String DATE_PINNED_SS_SENT_COUNT = "DATE_PINNED_SS_SENT_COUNT";
	public static String DATE_PINNED_FIRST_BS_SIG_DATE = "DATE_PINNED_FIRST_BS_SIG_DATE";
	public static String BS_SIGNATURE_GRID = "BS_SIGNATURE_GRID";
	public static String BS_SIGNATURE_COUNT = "BS_SIGNATURE_COUNT";
	public static String SS_SIGNATURE_GRID = "SS_SIGNATURE_GRID";
	public static String SS_SIGNATURE_COUNT = "SS_SIGNATURE_COUNT";
	public static String NAME_TO_USE = "True/Legal Name";

	public static final String CONTENT_TYPE_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

	// Download Masterlist Sheet
	public static final int ACTIVE_SHEET = 0;
	public static final int REMOVE_SHEET = 1;
	public static final int MODIFIED_SHEET = 2;
	public static final String REF_TABLE = "Ref Table";
	public static final String BULK = "Bulk";

	public static final String CAA = "CAA";
	public static final String ACA = "ACA";

	public static final String RULES_PARTYB_CLIENT_IDENTIFIER = "Party B / Account Client Identifier in Upload File";
	public static final String RULES_PARTYB_TRUE_LEGAL_NAME = "Party B / Account Name in Upload File";
	public static final String RULES_PARTYB_LEI = "Party B / Account LEI in Upload File";
	public static final String RULES_SLEEVE_TRUE_LEGAL_NAMES = "Sleeve / Sub-Account Name in Upload File";
	public static final String RULES_SLEEVE_CLIENT_IDENTIFIER = "Sleeve / Sub-Account Client Identifier in Upload File";
	public static final String AGRREEMENT_TYPE_ERROR = "TriParty Agreements (ACA, CAA) are not currently supported";
	public static final String AGRREEMENT_TYPE_NOT_PRESENT = "Invalid input for ${fieldLabel}";
	public static final String PARTY_A_DOES_NOT_EXIST = "${fieldLabel} does not exist";

	public static final String MANDATORY_COLUMN = "Mandatory column ";
	public static final String NOT_PRESENT = " is not present";

	public static final String PARTYB_ALREADY_ADDED_IN_ANOTHER_RFA = "Requested ${entityIdentifier} for ${requestType} is in progress for this Masterlist in RFA - ${rfaId}";
	public static final String PARENT_NOT_ACTIVE_IN_MASTER_LIST = "Sleeve requested for addition does not have Parent Account active on Masterlist";

	public static final String REQUEST_TYPE_NOT_IDENTIFIED = "Unable to identify the type of request for the given row";
	public static final String NO_VALID_REQUEST_TYPE_IDENTIFIED = "No valid Request Type (Addition, FNC, EVC) identified for this Masterlist";

	public static final String REQUESTED_ACTION_MISMATCH = " Action not applicable to the given row ";
	public static final String ALREADY_IN_MASTERLIST = "${entityIdentifier} requested for ${requestType} already exists on Active tab of this Masterlist";
	// public static final String ALREADY_EXIST_IN_MASTERLIST = " already exists on
	// Active tab of Masterlist";
	public static final String ALREADY_EXIST_IN_MCPM = " already exists in Counterparty Manager";

	public static final String PLACEHOLDER_NOT_FOUND_IN_LETTER_TEMPLATE = "Placeholder is not found in the Letter Template identified by the system for this ${requestType}";
	public static final String NO_CONTENT_IN_LETTER_TEMPLATE = "No content associated with this letter template";
	public static final String EXHIBIT_VALUE_IS_BLANK = "Exhibit value is set as blank";
	public static final String EVC_CHANGE_COMMENT = "Exhibit Value Updated";
	public static final String SLEEVE_ADDITION = "Sleeve Addition";
	public static final String PARTYB = "PartyB";
	public static final String SLEEVE = "Sleeve";
	public static final String PARTYB_DOESNT_EXIST_IN_MASTERLIST = "${entityIdentifier} requested for ${requestType} cannot be actioned as it does not exist on Active tab of this Masterlist";
	public static final String PARTYB_EXIST_IN_REMOVE_TAB_IN_MASTERLIST = "${entityIdentifier} requested for ${requestType} already exists on Removed tab of this Masterlist";

	public static final String SLEEVE_REMOVAL = "Sleeve Removal";
	public static final String REQUEST_TYPE = "Request Type ";
	public static final String CANNOT_BE_ACTIONED = " cannot be actioned on this ";
	public static final String DUE_TO_ANOTHER_REQUEST = " due to another conflicting request in this upload file";

	public static final String SLEEVE_IN_PROGRESS = "Request cannot be processed as request to add sleeve / remove sleeve / trading account is in-flight in another RFA";

	public static final String EXCEPTION_CASE = "Record failed to process due to missing or incomplete Counterparty Manager Entity Data.Please contact mcpmsupport@ihsmarkit.com for further assistance.";

	public static final String SIGNATORY = "Signatory";
	public static final String ACCEPTED = "Accepted";
	public static final String REJECTED = "Rejected";

}
