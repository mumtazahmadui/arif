package com.markit.ms.rfa.command.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.domain.Grid.Row;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.rfa.bean.BulkValidationBean;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.command.validator.impl.NextStepPdfGenerator;

@Component
public class BulkActionValidationInvoker {
	
	@Resource
	private Map<String, BulkActionValidator> validatorMap;
	
	@Autowired
	NextStepPdfGenerator nextStepPdfGenerator;
	
	public BulkActionValidationInvoker(){}
	
	/**	
	 * This method generates Grid of valid RFAs for the UI with additional attributes based on the selected BulkActionValidationType.
	 * 
	 * @param validationBean Bean used for validating RFA IDs.
	 * @return A grid most suitable for displaying on the UI.
	 */
	public Grid invoke(BulkValidationBean validationBean){
		BulkActionValidator validator = validatorMap.get(validationBean.getValidationType().toString());
		return validator.validate(validationBean);
	}	
	
	/**
	 * This method is used for generating a generic next step error PDF for bulk actions. 
	 * 
	 * @param rfaIds The list of RFA IDs to be validated.
	 * @param actionType The bulk action being performed.
	 * @param companyId The corresponding company ID from UserXS session.
	 * @param userId The corresponding user ID from the UserXS session.
	 * @return A generic error PDF to display to the user explaining that the
	 * @throws Exception
	 */
	public byte[] invoke(List<Long> rfaIds, BulkActionValidationType actionType, Long companyId, 
			Long userId, String companyType) throws Exception{
		BulkActionValidator validator = validatorMap.get(actionType.toString());
		BulkValidationBean validationBean  = new BulkValidationBean();
		validationBean.setCompanyId(companyId);
		validationBean.setUserId(userId);
		validationBean.setCompanyType(companyType);
		validationBean.setValidationType(actionType);
		validationBean.setRfaIdList(rfaIds);
		Grid grid = validator.validate(validationBean);
		List<Long> validRfaIds = convertValidRfaIdsToList(grid);
		rfaIds.removeAll(validRfaIds);
		return nextStepPdfGenerator.generatePdf(rfaIds, actionType, companyId, userId);
	}
	
	public List<Signature> invoke(List<Signature> signatureList, Long companyId, String companyType){
		BulkActionValidator validator = validatorMap.get(BulkActionValidationType.E_SIGN.toString());
		return validator.validate(signatureList, companyType, companyId);
	}
	
	/**
	 * This method converts the standard Grid returned by the invoker into a List<Long> of RFA IDs. 
	 * 
	 * @param grid The grid returned by the invoker.
	 * @return A List of the valid RFA IDs. 
	 */
	public List<Long> convertValidRfaIdsToList(Grid grid){
		List<Long> rfaIds = new ArrayList<Long>();
		for(Row row : grid.getRowList()){
			rfaIds.add(new Long(row.get("validRfaId")));
		}
		return rfaIds;
	}
	
	public Map<String, BulkActionValidator> getValidatorMap() {
		return validatorMap;
	}

	public void setValidatorMap(Map<String, BulkActionValidator> validatorMap) {
		this.validatorMap = validatorMap;
	}	
}