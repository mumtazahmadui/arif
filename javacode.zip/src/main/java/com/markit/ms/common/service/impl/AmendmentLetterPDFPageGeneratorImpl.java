package com.markit.ms.common.service.impl;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.common.service.IAmendmentLetterPDFPageGenerator;
import com.markit.ms.common.service.IHTMLParser;
import com.markit.ms.common.service.IPartyBPlaceHolderTableGenerator;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PDFUtil;
import com.markit.ms.rfa.util.QRCodeUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class AmendmentLetterPDFPageGeneratorImpl implements
		IAmendmentLetterPDFPageGenerator {
	private static final String TEMPLATE_NAME = "report/template/amendmentLetterPDF.vm";
	private static final String COMMENT_TEMPLATE_NAME = "report/template/amendmentLetterCommentPDF.vm";
	@Resource 
    private VelocityEngine velocityEngine;

    @Autowired
    IHTMLParser htmParser;
	
    @Resource private QueryService<byte[]> selectAmendmentContent;
    
    @Resource private IPartyBPlaceHolderTableGenerator partyBTableGenerator;
    
    @Resource private QueryService<byte[]> selectAmendmentComment;
    
	@Override
	public byte[] getAmendmentLetterPDF(
			Long amendmentId, PDFContext pdfContext) throws Exception {

	    return generateAmendmentPDF(amendmentId, pdfContext, false);
	}

	private byte[] generateAmendmentPDF(Long amendmentId, PDFContext pdfContext, boolean synchronous)
			throws UnsupportedEncodingException, Exception {
		VelocityContext context = new VelocityContext();
        Properties p = new Properties();
        p.setProperty("resource.loader", "class");
        p.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
        p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");     
    
        Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId", amendmentId);

		String amendmentLetterContent = CommonUtil.convertToUTF8(selectAmendmentContent.executeQuery(params));
		
		amendmentLetterContent = CommonUtil.addLocationTagPdf(amendmentLetterContent);
		amendmentLetterContent = CommonUtil.updateAmpersandAndBRTag(amendmentLetterContent);
		if(synchronous) {
			amendmentLetterContent = htmParser.generateAmendmentLetterHTMLSynchronous(amendmentLetterContent, amendmentId, pdfContext);
		} else {
			amendmentLetterContent = htmParser.generateAmendmentLetterHTML(amendmentLetterContent, amendmentId, pdfContext);
		}
        
        amendmentLetterContent =  CommonUtil.updateAmpersandAndBRTag(amendmentLetterContent);
        context.put("amendmentContent",amendmentLetterContent);
        
        int widthInInches = PDFUtil.calculateWidth(0);
        context.put("size",  widthInInches + "in 11in");
        context.put("columnPixel", PDFUtil.COLUMN_WIDTH + "px");
        context.put("width", widthInInches -1 + "in");
        context.put("footerdata",QRCodeUtil.getQRCode(amendmentId.toString(), 60));
        
        String datepinned = "";
		
		datepinned = getDatePinned(amendmentId,pdfContext);
        context.put("datepinned", datepinned);
         
        velocityEngine.init(p);
        Template template = velocityEngine.getTemplate(TEMPLATE_NAME);
        StringWriter writer = new StringWriter();
        template.merge(context, writer);
        PDFServiceImpl pdfService = new PDFServiceImpl();
        String html = PDFUtil.stripNonValidXMLCharacters(writer.toString());
        byte[] amendmentPDF= pdfService.convert(html);	
		return amendmentPDF;
	}

	private String getDatePinned(Long amendmentId, PDFContext pdfContext) {
		if(!pdfContext.isDatePinnedPlaceholder()){
			return "";
		}
		Map<String,Object> datePinnedMap= htmParser.generateDatePinned(amendmentId);
		Long ssSentRFACount = (Long)datePinnedMap.get(RFAConstants.DATE_PINNED_SS_SENT_COUNT);
		String datepinnedISOUtc = (String)datePinnedMap.get(RFAConstants.DATE_PINNED_FIRST_BS_SIG_DATE);
		String datepinned = "";
		
		if(ssSentRFACount > 0){
			DateTime dateTime = new DateTime();
			datepinned = dateTime.toString("dd-MMM-yyyy");
		} else {
			DateTime dateTime = new DateTime(datepinnedISOUtc, DateTimeZone.forID("America/New_York") );
			datepinned = dateTime.toString("dd-MMM-yyyy");
		}
		return "<span style=\"font-size: 24px;\">"+ datepinned  + "</span><br/>";
	}

	@Override
	public byte[] getAmendmentLetterPDFSynchronous(Long amendmentId,
			PDFContext pdfContext) throws Exception {
		return generateAmendmentPDF(amendmentId, pdfContext, true);
	}

	@Override
	public byte[] getLetterCommentPDF(Long amendmentId ,QueryService<byte[]> selectComment) throws Exception {
		String amendmentLetterComment = htmParser.generateCommentTable(amendmentId,selectComment);
		if(amendmentLetterComment==null||amendmentLetterComment.trim().isEmpty()) {
			return null;
		}
		VelocityContext context = new VelocityContext();
		Properties p = new Properties();
		p.setProperty("resource.loader", "class");
		p.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
		p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");     

		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId", amendmentId);

		amendmentLetterComment =  CommonUtil.updateAmpersandAndBRTag(amendmentLetterComment);
		context.put("appendix",amendmentLetterComment);

		int widthInInches = PDFUtil.calculateWidth(0);
		context.put("size",  widthInInches + "in 11in");
		context.put("columnPixel", PDFUtil.COLUMN_WIDTH + "px");
		context.put("width", widthInInches -1 + "in");
		context.put("footerdata",QRCodeUtil.getQRCode(amendmentId.toString(), 60));

		velocityEngine.init(p);
		Template template = velocityEngine.getTemplate(COMMENT_TEMPLATE_NAME);
		StringWriter writer = new StringWriter();
		template.merge(context, writer);
		PDFServiceImpl pdfService = new PDFServiceImpl();
		String html = PDFUtil.stripNonValidXMLCharacters(writer.toString());
		byte[] amendmentPDF= pdfService.convert(html);	
		return amendmentPDF;
	}


	
}
