package com.markit.ms.common.service.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.Resource;

import org.apache.commons.codec.binary.Base64;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.esign.util.SignatureGenerator;
import com.markit.ms.common.constants.PartyBPlaceholderConstants;
import com.markit.ms.common.service.IHTMLParser;
import com.markit.ms.common.service.IPartyBPlaceHolderTableGenerator;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.NewExhibitResponse;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.bean.PartyAPlaceHolder;
import com.markit.ms.rfa.placeholders.response.PartyBTableResponse;
import com.markit.ms.rfa.service.IMasterAgreementService;
import com.markit.ms.rfa.service.IPartyAPlaceholderService;
import com.markit.ms.rfa.service.IPartyBPlaceholderService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PlaceholderUtil;
import com.markit.ms.rfa.util.RFAConstants;

@Service
public class HTMLParserImpl implements IHTMLParser{
	
	private static final Logger logger = LoggerFactory.getLogger(HTMLParserImpl.class.getName());
	@Autowired
	private IMasterAgreementService masterAgreementService;

	@Resource private IPartyAPlaceholderService partyAPlaceholderService;
	@Resource private QueryService<Grid> partyBAdditionTableRows;
	@Resource private QueryService<Grid> partyBAdditionTableColumns;
	
	@Resource private QueryService<Grid> partyBRemovalTableRows;
	@Resource private QueryService<Grid> partyBRemovalTableColumns;
	
	@Resource private QueryService<Grid> sleeveAdditionTableRows;
	@Resource private QueryService<Grid> sleeveAdditionTableColumns;
	
	@Resource private QueryService<Grid> sleeveRemovalTableRows;
	@Resource private QueryService<Grid> sleeveRemovalTableColumns;

	@Resource private IPartyBPlaceHolderTableGenerator partyBPlaceHolderTableGenerator;
	@Resource private IPartyBPlaceholderService partyBPlaceholderService;

	@Resource private QueryService<Grid> partyBExhibitValueChangeTableRows;
	@Resource private QueryService<Grid> partyBExhibitValueChangeTableColumns;
	
	@Resource private QueryService<Grid> partyBFundNameChangeTableRows;
	@Resource private QueryService<Grid> partyBFundNameChangeTableColumns;
	
	
    @Resource private QueryService<byte[]> selectExhibitTextContent;
	@Resource private QueryService<Grid> selectExhibitColumns;
	@Resource private QueryService<Grid> selectExhibitRows;
	
	
	@Resource private QueryService<Grid> bsSignatures;
	@Resource private QueryService<Grid> ssSignatures;
	@Resource private SignatureGenerator signatureGenerator;
	@Resource private QueryService<String> getBSFirstSignDate;
	@Resource private QueryService<Long> getSSSendRFACount;
	@Resource private QueryService<byte[]> selectAmendmentContent;
    @Resource private QueryService<byte[]> selectAmendmentComment;
	
	@Resource private QueryService<Long> selectAmendmentSSSignaturePlaceholderCount;
	@Resource private QueryService<Long> selectAmendmentBSSignaturePlaceholderCount;
	
	public static final String AMENDMENT_PLACEHOLDER_ID_DATE_PINNED= "date_pinned";
	public static final String AMENDMENT_PLACEHOLDER_ID_PARTYA = "partyARelations";
	public static final String AMENDMENT_PLACEHOLDER_ID_PARTYB_ADDED = "partyBAddition";
	public static final String AMENDMENT_PLACEHOLDER_ID_PARTYB_REMOVED = "partyBRemoval";
	public static final String AMENDMENT_PLACEHOLDER_ID_SLEEVE_ADDED = "sleeveAddition";
	public static final String AMENDMENT_PLACEHOLDER_ID_SLEEVE_REMOVED = "sleeveRemoval";
	public static final String AMENDMENT_PLACEHOLDER_ID_PARTYB_EXHIBIT_VALUE_CHANGE = "exhibit_value_change";
	public static final String AMENDMENT_PLACEHOLDER_ID_PARTYB_FUND_NAME_CHANGE = "fund_name_change";
	public static final String AMENDMENT_PLACEHOLDER_ID_BS_SIGNATURE = "bs_signature";
	public static final String AMENDMENT_PLACEHOLDER_ID_SS_SIGNATURE = "ss_signature";
	public static final String AMENDMENT_PLACEHOLDER_ID_BS_SIGNATURE_TEXT = "BuySide Signature";
	public static final String AMENDMENT_PLACEHOLDER_ID_SS_SIGNATURE_TEXT = "SellSide Signature";
	@Override
	public String generateAmendmentLetterHTML(final String amendmentLetterContent,final Long amendmentId,final PDFContext pdfContext) throws Exception {
		
		final Document doc = Jsoup.parse(amendmentLetterContent);
		
		ExecutorService executorService = Executors.newFixedThreadPool(7);
		
		
		Future<String> futureDatePlaceHolderA = executorService.submit(new Callable<String>() {
		    public String call() throws UnsupportedEncodingException {
		    	return getPartyAPlaceholder(amendmentId);
		    }
		});
		
		Future<PartyBTableResponse> futurePartyBAdditionPlaceholder = executorService.submit(new Callable<PartyBTableResponse>() {
		    public PartyBTableResponse call() {
		    		PartyBTableResponse partyBTableResponse = getPartyBAdditionTable(amendmentId, pdfContext);
					return partyBTableResponse;
		    }
		});
		
		Future<PartyBTableResponse> futurePartyBRemovalPlaceHolder = executorService.submit(new Callable<PartyBTableResponse>() {
		    public PartyBTableResponse call() {
		    	return getPartyBRemovalTable(amendmentId, pdfContext);
		    }
		});
		
		Future<PartyBTableResponse> futureSleeveAdditionPlaceholder = executorService.submit(new Callable<PartyBTableResponse>() {
		    public PartyBTableResponse call() {
		    		PartyBTableResponse partyBTableResponse = getSleeveAdditionTable(amendmentId, pdfContext);
					return partyBTableResponse;
		    }
		});
		
		Future<PartyBTableResponse> futureSleeveRemovalPlaceHolder = executorService.submit(new Callable<PartyBTableResponse>() {
		    public PartyBTableResponse call() {
		    	return getSleeveRemovalTable(amendmentId, pdfContext);
		    }
		});
		
		Future<PartyBTableResponse> futurePartyBEVCPlaceholder = executorService.submit(new Callable<PartyBTableResponse>() {
		    public PartyBTableResponse call() {
		    		return getPartyBExhibitValueChangeTable(amendmentId, pdfContext);
		    }
		});
		
		Future<PartyBTableResponse> futurePartyBFNCPlaceholder = executorService.submit(new Callable<PartyBTableResponse>() {
		    public PartyBTableResponse call() {
		    	return getPartyBFundNameChangeTable(amendmentId, pdfContext);
		    }
		});
		
		Future<Map<String, Object>> futureBSSignaturePlaceholder = executorService.submit(new Callable<Map<String,Object>>() {
		    public Map<String, Object> call() {
				return generateBSSignatures(amendmentId);
		    }
		});
		
		
		Future<Map<String, Object>> futureSSSignaturePlaceholder = executorService.submit(new Callable<Map<String, Object>>() {
		    public Map<String, Object> call() {
		    	return generateSSSignatures(amendmentId);
		    }
		});
		
		logger.info("Reading datepinned");
		//Map<String,Object> datePinnedMap = futureDatePinned.get();
		logger.info("Reading partyARelationString");
		String partyARelationString = futureDatePlaceHolderA.get();
		logger.info("Reading partyBTableResponseAddition");
		PartyBTableResponse partyBTableResponseAddition = futurePartyBAdditionPlaceholder.get();
		logger.info("Reading partyBTableResponseRemoval");
		PartyBTableResponse partyBTableResponseRemoval = futurePartyBRemovalPlaceHolder.get();
		logger.info("Reading sleeveTableResponseAddition");
		PartyBTableResponse sleeveTableResponseAddition = futureSleeveAdditionPlaceholder.get();
		logger.info("Reading sleeveTableResponseRemoval");
		PartyBTableResponse sleeveTableResponseRemoval = futureSleeveRemovalPlaceHolder.get();
		logger.info("Reading partyBTableResponseEVC");
		PartyBTableResponse partyBTableResponseEVC = futurePartyBEVCPlaceholder.get();
		logger.info("Reading partyBTableResponseFNC");
		PartyBTableResponse partyBTableResponseFNC = futurePartyBFNCPlaceholder.get();
		logger.info("Reading bsSignature");
		Map<String, Object> bsSignature = futureBSSignaturePlaceholder.get();
		logger.info("Reading ssSignature");
		Map<String, Object> ssSignature = futureSSSignaturePlaceholder.get();
		
		// Build HTML
		logger.info("Replacing placeholders in HTML");
		replaceDatePinnedPlaceholder(doc);
		replacePlaceHolderA(amendmentId, doc, partyARelationString);
		replacePartyBAdditionPlaceholder(amendmentId, doc, pdfContext,partyBTableResponseAddition);
		replacePartyBRemovalPlaceholder(amendmentId, doc, pdfContext,partyBTableResponseRemoval);
		replaceSleeveAdditionPlaceholder(amendmentId, doc, pdfContext,sleeveTableResponseAddition);
		replaceSleeveRemovalPlaceholder(amendmentId, doc, pdfContext,sleeveTableResponseRemoval);
		replacePartyBExhibitValueChangePlaceholder(amendmentId, doc, pdfContext, partyBTableResponseEVC);
		replacePartyBFundNameChangePlaceholder(amendmentId, doc, pdfContext, partyBTableResponseFNC);
		replaceBSSignaturePlaceholder(amendmentId, doc, pdfContext, (Grid)bsSignature.get(RFAConstants.BS_SIGNATURE_GRID),(Long) bsSignature.get(RFAConstants.BS_SIGNATURE_COUNT));
		replaceSSSignaturePlaceholder(amendmentId, doc, pdfContext,(Grid)ssSignature.get(RFAConstants.SS_SIGNATURE_GRID),(Long) ssSignature.get(RFAConstants.SS_SIGNATURE_COUNT));
		logger.info("Replaced placeholders in HTML");
		executorService.shutdown();
		return doc.getElementsByTag("body").get(0).html();
	}

	private void replaceDatePinnedPlaceholder(Document doc) {
		
			Element elementDatePinned = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_DATE_PINNED);
			while(elementDatePinned != null) {
				elementDatePinned.remove();
				elementDatePinned = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_DATE_PINNED);
			}
	}


	private void replaceBSSignaturePlaceholder(Long amendmentId, Document doc,
			PDFContext pdfContext, Grid signatureBSGrid, Long bsPlaceHolderCount) {
		generateSignatures(doc, 
				signatureBSGrid, 
				AMENDMENT_PLACEHOLDER_ID_BS_SIGNATURE, 
				AMENDMENT_PLACEHOLDER_ID_BS_SIGNATURE_TEXT, 
				pdfContext.isIgnoreBuySideSignaturePlaceholder(),
				bsPlaceHolderCount);
		
	}
	
	@Override
	public Integer getSignaturePlaceholderCount(Long amendmentId, String placeholderId) throws IOException
	{
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId", amendmentId);
		String amendmentLetterContent = CommonUtil.convertToUTF8(selectAmendmentContent.executeQuery(params));
		String html = CommonUtil.convertToUTF8(amendmentLetterContent.getBytes());
		Document doc = Jsoup.parse(html);
		Element signaturePlaceholder = null;

		int index = 1;
		Integer count = 0;
		while(true){
			signaturePlaceholder = doc.getElementById(placeholderId + "[" + index + "]");
			if(signaturePlaceholder != null){
				index ++;
				count ++;
			} else {
				break;
			}
		}
		
		return count;
	}
	
	@Override
	public Integer getSignaturePlaceholderCount(String amendmentLetterContent, int isBsCompany) throws IOException
	{
		String html = CommonUtil.convertToUTF8(amendmentLetterContent.getBytes());
		Document doc = Jsoup.parse(html);
		Element signaturePlaceholder = null;
		String placeholderId = null;
		if(isBsCompany == 0){
			placeholderId = AMENDMENT_PLACEHOLDER_ID_SS_SIGNATURE;
		} else if (isBsCompany == 1){
			placeholderId = AMENDMENT_PLACEHOLDER_ID_BS_SIGNATURE;
		}
		int index = 1;
		Integer count = 0;
		while(true){
			signaturePlaceholder = doc.getElementById(placeholderId + "[" + index + "]");
			if(signaturePlaceholder != null){
				index ++;
				count ++;
			} else {
				break;
			}
		}
		
		return count;
	}

	private void generateSignatures(Document doc, 
			Grid signatureBSGrid,
			String placeholderId, 
			String placeholderText, 
			boolean ignorePlaceholder, 
			Long placeHolderCount) {
		List<Map<String,String>> signatureData = signatureBSGrid.getRows();
		Element signaturePlaceholder = null;
		Element previousSignaturePlaceholder = null;
		Element previousSignaturePlaceholderDiv = null;
		String previousIndex = null;
		Element signatureDiv = null;
		int[] stickyBit = new int[placeHolderCount.intValue()+1];
		for(Map<String,String> signature : signatureData) {
			String name = signature.get("NAME");
			String title = signature.get("TITLE");
			String email = signature.get("EMAIL");
			String signatureDate = signature.get("CALENDAR_DATE");
			String signStyle = signature.get("SIGN_STYLE");
			String signText = signature.get("SIGN_TEXT");
			String index = signature.get("PLACEHOLDER_INDEX");
			stickyBit[Integer.parseInt(index)] = 1;
			signaturePlaceholder = doc.getElementById(placeholderId + "[" + index + "]");
			if(previousSignaturePlaceholder != signaturePlaceholder){
				signaturePlaceholder.wrap("<span style=\"display:inline-block;\" id=\"div_" +placeholderId + "[" + index + "]"+ "\"></span>");
				signatureDiv = doc.getElementById("div_"+placeholderId + "[" + index + "]");
				
				if(previousSignaturePlaceholder !=null) {
					if(!ignorePlaceholder)
						previousSignaturePlaceholderDiv.append(generateSignaturePlaceHolderHTML(placeholderText,
								previousIndex));
					previousSignaturePlaceholder.remove();
				}
			}
			
			DateTime dateTime = new DateTime(signatureDate, DateTimeZone.forID("America/New_York") );
			String signatureDateForImage = dateTime.toString("dd-MM-yy hh:mm:ss aa");
			
			byte[] image = signatureGenerator.generateSignatureImage(signText, name , name, title, email, signStyle != null ? Integer.parseInt(signStyle) : 1, signatureDateForImage);
			String encodedImage = Base64.encodeBase64String(image);
			if(signatureDiv != null) {
				String imageTag = "<img src=\"data:image/gif;base64," + encodedImage + "\"><br>";
				signatureDiv.append(imageTag);
			}
		
			previousSignaturePlaceholder = signaturePlaceholder;
			previousIndex = index;
			previousSignaturePlaceholderDiv = signatureDiv;
		}
		if(previousSignaturePlaceholder !=null) {
			if(!ignorePlaceholder)
				signatureDiv.append(generateSignaturePlaceHolderHTML(placeholderText, previousIndex));
			previousSignaturePlaceholder.remove();
		}
		
		for(int placeholderIndex = 1; placeholderIndex <= placeHolderCount ; placeholderIndex++) {
			if(stickyBit[placeholderIndex] == 0){
				signaturePlaceholder = doc.getElementById(placeholderId + "[" + placeholderIndex + "]");
				if(!ignorePlaceholder)
					signaturePlaceholder.before(generateSignaturePlaceHolderHTML(placeholderText, ""+placeholderIndex));
				signaturePlaceholder.remove();
			}
		}
	}

	private String generateSignaturePlaceHolderHTML(String placeholderText,
			String previousIndex) {
		return "<span style=\"color:#00598c;margin-right: 60px;\"><b>" +placeholderText + "[" + previousIndex + "]</b></span>";
	}

	private void replaceSSSignaturePlaceholder(Long amendmentId, Document doc,
			PDFContext pdfContext, Grid signatureSSGrid, Long ssPlaceHolderCount) {
		generateSignatures(doc, 
				signatureSSGrid, 
				AMENDMENT_PLACEHOLDER_ID_SS_SIGNATURE, 
				AMENDMENT_PLACEHOLDER_ID_SS_SIGNATURE_TEXT, 
				pdfContext.isIgnoreSellSideSignaturePlaceholder(),
				ssPlaceHolderCount);
		}

	private void replacePartyBFundNameChangePlaceholder(Long amendmentId,
			Document doc, PDFContext pdfContext ,PartyBTableResponse partyBTableResponse) throws UnsupportedEncodingException {
		Element elementPartyBAddition = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_FUND_NAME_CHANGE);
		if(elementPartyBAddition != null) {
			String partyBAdditionTableString = partyBPlaceHolderTableGenerator.getPartyBPlaceholderHTML(partyBTableResponse, pdfContext);
			elementPartyBAddition.after(partyBAdditionTableString);
			elementPartyBAddition.remove();
		}
	}

	private void replacePartyBExhibitValueChangePlaceholder(Long amendmentId,
			Document doc, PDFContext pdfContext, PartyBTableResponse partyBTableResponse) throws UnsupportedEncodingException {
		Element elementPartyBAddition = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_EXHIBIT_VALUE_CHANGE);
		if(elementPartyBAddition != null) {
			String partyBAdditionTableString = partyBPlaceHolderTableGenerator.getPartyBPlaceholderHTML(partyBTableResponse, pdfContext);
			elementPartyBAddition.after(partyBAdditionTableString);
			elementPartyBAddition.remove();
		}
	}

	private void replacePartyBAdditionPlaceholder(Long amendmentId, Document doc, PDFContext pdfContext, PartyBTableResponse partyBTableResponse)
			throws UnsupportedEncodingException {
		Element elementPartyBAddition = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_ADDED);
		if(elementPartyBAddition != null) {
			String partyBAdditionTableString = partyBPlaceHolderTableGenerator.getPartyBPlaceholderHTML(partyBTableResponse, pdfContext);
			elementPartyBAddition.after(partyBAdditionTableString);
			elementPartyBAddition.remove();
		}
	}
	
	private void replacePartyBRemovalPlaceholder(Long amendmentId, Document doc, PDFContext pdfContext, PartyBTableResponse partyBTableResponse)
			throws UnsupportedEncodingException {
		Element elementPartyBAddition = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_REMOVED);
		if(elementPartyBAddition != null) {
			String partyBAdditionTableString = partyBPlaceHolderTableGenerator.getPartyBPlaceholderHTML(partyBTableResponse, pdfContext);
			elementPartyBAddition.after(partyBAdditionTableString);
			elementPartyBAddition.remove();
		}
	}
	
	private void replaceSleeveAdditionPlaceholder(Long amendmentId, Document doc, PDFContext pdfContext, PartyBTableResponse partyBTableResponse)
			throws UnsupportedEncodingException {
		Element elementSleeveAddition = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_SLEEVE_ADDED);
		if(elementSleeveAddition != null) {
			String sleeveAdditionTableString = partyBPlaceHolderTableGenerator.getPartyBPlaceholderHTML(partyBTableResponse, pdfContext);
			elementSleeveAddition.after(sleeveAdditionTableString);
			elementSleeveAddition.remove();
		}
	}
	
	private void replaceSleeveRemovalPlaceholder(Long amendmentId, Document doc, PDFContext pdfContext, PartyBTableResponse partyBTableResponse)
			throws UnsupportedEncodingException {
		Element elementSleeveRemoval = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_SLEEVE_REMOVED);
		if(elementSleeveRemoval != null) {
			String sleeveRemovalTableString = partyBPlaceHolderTableGenerator.getPartyBPlaceholderHTML(partyBTableResponse, pdfContext);
			elementSleeveRemoval.after(sleeveRemovalTableString);
			elementSleeveRemoval.remove();
		}
	}

	private void replacePlaceHolderA(Long amendmentId, Document doc, String partyARelationString) {
		Element elementPartyA = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYA);
		if(elementPartyA != null) {
			elementPartyA.after(partyARelationString);
			elementPartyA.remove();
		}
	}
	
	private PartyBTableResponse getPartyBAdditionTable(Long amendmentId, PDFContext pdfContext) {
		
		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("amendmentId",amendmentId);
		queryParams.put(PartyBPlaceholderConstants.HIDE_SS_COLUMN, pdfContext.getCompanyType().equals(RFAConstants.COMPANY_TYPE_SS) ? 0 : 1);		
		Grid columns = partyBAdditionTableColumns.executeQuery(queryParams);
		
		Map<String,Object> params = PlaceholderUtil.preparePlaceholderParamsForPDF(amendmentId, pdfContext);
		Grid rows = partyBAdditionTableRows.executeQuery(params);
		rows = CommonUtil.decodeGridRows(rows, Arrays.asList("Reason for Rejection/Pending"));
		List<Map<String,String>> lineBreaks = partyBPlaceholderService.getLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_ADDITION_PLACEHOLDER);
		List<Map<String, String>> previousLineBreaks = partyBPlaceholderService.getPreviousLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_ADDITION_PLACEHOLDER);

		PartyBTableResponse partyBTable = new PartyBTableResponse();
		partyBTable.setColumns(columns.getRows());
		partyBTable.setRows(rows.getRows());
		partyBTable.setLineBreaks(lineBreaks);
		partyBTable.setPreviousLineBreaks(previousLineBreaks);
		partyBTable.setPlaceHolderType(PartyBPlaceholderConstants.PARTYB_ADDITION_PLACEHOLDER);
		return partyBTable;
	}
	

	private PartyBTableResponse getPartyBRemovalTable(Long amendmentId, PDFContext pdfContext) {
		
		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("amendmentId",amendmentId);
		queryParams.put(PartyBPlaceholderConstants.HIDE_SS_COLUMN, pdfContext.getCompanyType().equals(RFAConstants.COMPANY_TYPE_SS) ? 0 : 1);
		Grid columns = partyBRemovalTableColumns.executeQuery(queryParams);
		
		Map<String,Object> params = PlaceholderUtil.preparePlaceholderParamsForPDF(amendmentId, pdfContext);
		Grid rows = partyBRemovalTableRows.executeQuery(params);
		rows = CommonUtil.decodeGridRows(rows, Arrays.asList("Reason for Rejection/Pending"));
		List<Map<String,String>> lineBreaks = partyBPlaceholderService.getLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER);
		List<Map<String, String>> previousLineBreaks = partyBPlaceholderService.getPreviousLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER);

		PartyBTableResponse partyBTable = new PartyBTableResponse();
		partyBTable.setColumns(columns.getRows());
		partyBTable.setRows(rows.getRows());
		partyBTable.setLineBreaks(lineBreaks);
		partyBTable.setPreviousLineBreaks(previousLineBreaks);
		partyBTable.setPlaceHolderType(PartyBPlaceholderConstants.PARTYB_REMOVAL_PLACEHOLDER);
		return partyBTable;
	}
	
	private PartyBTableResponse getSleeveAdditionTable(Long amendmentId, PDFContext pdfContext) {
		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("amendmentId",amendmentId);
		queryParams.put(PartyBPlaceholderConstants.HIDE_SS_COLUMN, pdfContext.getCompanyType().equals(RFAConstants.COMPANY_TYPE_SS) ? 0 : 1);
		Grid columns = sleeveAdditionTableColumns.executeQuery(queryParams);
		
		Map<String,Object> params = PlaceholderUtil.preparePlaceholderParamsForPDF(amendmentId, pdfContext);
		Grid rows = sleeveAdditionTableRows.executeQuery(params);
		rows = CommonUtil.decodeGridRows(rows, Arrays.asList("Reason for Rejection/Pending"));
		List<Map<String,String>> lineBreaks = partyBPlaceholderService.getLineBreaks(amendmentId, PartyBPlaceholderConstants.SLEEVE_ADDITION_PLACEHOLDER);
		List<Map<String, String>> previousLineBreaks = partyBPlaceholderService.getPreviousLineBreaks(amendmentId, PartyBPlaceholderConstants.SLEEVE_ADDITION_PLACEHOLDER);

		PartyBTableResponse partyBTable = new PartyBTableResponse();
		partyBTable.setColumns(columns.getRows());
		partyBTable.setRows(rows.getRows());
		partyBTable.setLineBreaks(lineBreaks);
		partyBTable.setPreviousLineBreaks(previousLineBreaks);
		partyBTable.setPlaceHolderType(PartyBPlaceholderConstants.SLEEVE_ADDITION_PLACEHOLDER);
		return partyBTable;
	}
	

	private PartyBTableResponse getSleeveRemovalTable(Long amendmentId, PDFContext pdfContext) {
		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("amendmentId",amendmentId);
		queryParams.put(PartyBPlaceholderConstants.HIDE_SS_COLUMN, pdfContext.getCompanyType().equals(RFAConstants.COMPANY_TYPE_SS) ? 0 : 1);
		Grid columns = sleeveAdditionTableColumns.executeQuery(queryParams);
		
		Map<String,Object> params = PlaceholderUtil.preparePlaceholderParamsForPDF(amendmentId, pdfContext);
		Grid rows = sleeveRemovalTableRows.executeQuery(params);
		rows = CommonUtil.decodeGridRows(rows, Arrays.asList("Reason for Rejection/Pending"));
		List<Map<String,String>> lineBreaks = partyBPlaceholderService.getLineBreaks(amendmentId, PartyBPlaceholderConstants.SLEEVE_REMOVAL_PLACEHOLDER);
		List<Map<String, String>> previousLineBreaks = partyBPlaceholderService.getPreviousLineBreaks(amendmentId, PartyBPlaceholderConstants.SLEEVE_REMOVAL_PLACEHOLDER);

		PartyBTableResponse partyBTable = new PartyBTableResponse();
		partyBTable.setColumns(columns.getRows());
		partyBTable.setRows(rows.getRows());
		partyBTable.setLineBreaks(lineBreaks);
		partyBTable.setPreviousLineBreaks(previousLineBreaks);
		partyBTable.setPlaceHolderType(PartyBPlaceholderConstants.SLEEVE_REMOVAL_PLACEHOLDER);
		return partyBTable;
	}

	private PartyBTableResponse getPartyBExhibitValueChangeTable(Long amendmentId, PDFContext pdfContext) {
		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("amendmentId",amendmentId);
		queryParams.put(PartyBPlaceholderConstants.HIDE_SS_COLUMN, pdfContext.getCompanyType().equals(RFAConstants.COMPANY_TYPE_SS) ? 0 : 1);		
		Grid columns = partyBExhibitValueChangeTableColumns.executeQuery(queryParams);
		
		Map<String,Object> params = PlaceholderUtil.preparePlaceholderParamsForPDF(amendmentId, pdfContext);
		Grid rows = partyBExhibitValueChangeTableRows.executeQuery(params);
		rows = CommonUtil.decodeGridRows(rows, Arrays.asList("Reason for Rejection/Pending"));
		List<Map<String,String>> lineBreaks = partyBPlaceholderService.getLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_EXHIBIT_VALUE_CHANGE_PLACEHOLDER);
		List<Map<String, String>> previousLineBreaks = partyBPlaceholderService.getPreviousLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_EXHIBIT_VALUE_CHANGE_PLACEHOLDER);

		PartyBTableResponse partyBTable = new PartyBTableResponse();
		partyBTable.setColumns(columns.getRows());
		partyBTable.setRows(rows.getRows());
		partyBTable.setLineBreaks(lineBreaks);
		partyBTable.setPreviousLineBreaks(previousLineBreaks);
		partyBTable.setPlaceHolderType(PartyBPlaceholderConstants.PARTYB_EXHIBIT_VALUE_CHANGE_PLACEHOLDER);
		return partyBTable;
	}
	
	private PartyBTableResponse getPartyBFundNameChangeTable(Long amendmentId, PDFContext pdfContext) {
		
		Map<String, Object> queryParams = new HashMap<>();
		queryParams.put("amendmentId",amendmentId);
		queryParams.put(PartyBPlaceholderConstants.HIDE_SS_COLUMN, pdfContext.getCompanyType().equals(RFAConstants.COMPANY_TYPE_SS) ? 0 : 1);		
		Grid columns = partyBFundNameChangeTableColumns.executeQuery(queryParams);
		
		Map<String,Object> params = PlaceholderUtil.preparePlaceholderParamsForPDF(amendmentId, pdfContext);
		Grid rows = partyBFundNameChangeTableRows.executeQuery(params);
		rows = CommonUtil.decodeGridRows(rows, Arrays.asList("Reason for Rejection/Pending"));
		List<Map<String,String>> lineBreaks = partyBPlaceholderService.getLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_FUND_NAME_CHANGE_PLACEHOLDER);
		List<Map<String, String>> previousLineBreaks = partyBPlaceholderService.getPreviousLineBreaks(amendmentId, PartyBPlaceholderConstants.PARTYB_FUND_NAME_CHANGE_PLACEHOLDER);

		PartyBTableResponse partyBTable = new PartyBTableResponse();
		partyBTable.setColumns(columns.getRows());
		partyBTable.setRows(rows.getRows());
		partyBTable.setLineBreaks(lineBreaks);
		partyBTable.setPreviousLineBreaks(previousLineBreaks);
		partyBTable.setPlaceHolderType(PartyBPlaceholderConstants.PARTYB_FUND_NAME_CHANGE_PLACEHOLDER);
		return partyBTable;
	}
	public static Boolean hasPartyBAdditionPlaceholder(AmendmentLetter amendmentLetter) throws UnsupportedEncodingException{
		String html = CommonUtil.convertToUTF8(amendmentLetter.getContent().getBytes());
		Document doc = Jsoup.parse(html);
		Element elementPartyBAdded = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_ADDED);
		if (elementPartyBAdded != null){
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public Boolean hasPartyAPlaceholder(Long amendmentId) throws UnsupportedEncodingException{
		 Map<String, Object> params = Maps.newHashMap();
			params.put("amendmentId", amendmentId);
		String html = CommonUtil.convertToUTF8(selectAmendmentContent.executeQuery(params));
		Document doc = Jsoup.parse(html);
		Element elementPartyBAdded = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYA);
		if (elementPartyBAdded != null){
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public static Boolean hasPartyBRemovalPlaceholder(AmendmentLetter	amendmentLetter) throws UnsupportedEncodingException{
		String html = CommonUtil.convertToUTF8(amendmentLetter.getContent().getBytes());
		Document doc = Jsoup.parse(html);
		Element elementPartyBRemoved = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_REMOVED);
		if (elementPartyBRemoved != null){
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public static Boolean hasPartyBFundNameChangePlaceholder(AmendmentLetter	amendmentLetter) throws UnsupportedEncodingException{
		String html = CommonUtil.convertToUTF8(amendmentLetter.getContent().getBytes());
		Document doc = Jsoup.parse(html);
		Element elementPartyBModification = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_FUND_NAME_CHANGE);
		if (elementPartyBModification != null){
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	public static Boolean hasPartyBExhibitValueChangePlaceholder(AmendmentLetter	amendmentLetter) throws UnsupportedEncodingException{
		String html = CommonUtil.convertToUTF8(amendmentLetter.getContent().getBytes());
		Document doc = Jsoup.parse(html);
		Element elementPartyBModification = doc.getElementById(AMENDMENT_PLACEHOLDER_ID_PARTYB_EXHIBIT_VALUE_CHANGE);
		if (elementPartyBModification != null){
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
	
	private String getPartyAPlaceholder(Long amendmentId) throws UnsupportedEncodingException {
		Map<String, Object> params = Maps.newHashMap();
		params.put("amendmentId",amendmentId);
		PartyAPlaceHolder partyAPlaceHolder = partyAPlaceholderService.getPartyAPlaceholder(amendmentId);
		return CommonUtil.convertToUTF8(partyAPlaceHolder.getPartyAText().getBytes());
	}
	

	@Override
	public String generateExhibitTable(Long amendmentId, Long exhibitId, PDFContext pdfContext) throws Exception{
				NewExhibitResponse exhibitResponse = new NewExhibitResponse();
				Map<String, Object> params = new HashMap<>();
				params.put("exhibitId",exhibitId);
				params.put("amendmentId",amendmentId);
				byte[] exhibitContent = selectExhibitTextContent.executeQuery(params);
				String exhibitTextContentString = CommonUtil.convertToUTF8(exhibitContent);
				exhibitTextContentString = CommonUtil.updateAmpersandAndBRTag(exhibitTextContentString);
				Document doc = Jsoup.parse(exhibitTextContentString);
				
				Grid columns = selectExhibitColumns.executeQuery(params);
				
				
				params = PlaceholderUtil.preparePlaceholderParamsForExhibitPDF(exhibitId,pdfContext);
						
			    Grid rows = selectExhibitRows.executeQuery(params);
				exhibitResponse.setColumns(columns.getRows());
				if(rows != null)
				exhibitResponse.setRows(rows.getRows());
				String exhibitTableRespone = partyBPlaceHolderTableGenerator.getExhitHTML(exhibitResponse, pdfContext);
				doc.getElementsByTag("body").append(exhibitTableRespone);
				
				return doc.getElementsByTag("body").get(0).html();
	}

	@Override
	public String generateAmendmentLetterHTMLSynchronous(
			String amendmentLetterContent, Long amendmentId,
			PDFContext pdfContext) throws Exception {
	final Document doc = Jsoup.parse(amendmentLetterContent);

		logger.info("Reading datepinned");
		//Map<String,Object> datePinnedMap = generateDatePinned(amendmentId);
		logger.info("Reading partyARelationString");
		String partyARelationString = getPartyAPlaceholder(amendmentId);
		logger.info("Reading partyBTableResponseAddition");
		PartyBTableResponse partyBTableResponseAddition = getPartyBAdditionTable(amendmentId, pdfContext);
		logger.info("Reading partyBTableResponseRemoval");
		PartyBTableResponse partyBTableResponseRemoval = getPartyBRemovalTable(amendmentId, pdfContext);
		logger.info("Reading sleeveTableResponseAddition");
		PartyBTableResponse sleeveTableResponseAddition = getSleeveAdditionTable(amendmentId, pdfContext);
		logger.info("Reading sleeveTableResponseRemoval");
		PartyBTableResponse sleeveTableResponseRemoval = getSleeveRemovalTable(amendmentId, pdfContext);
		logger.info("Reading partyBTableResponseEVC");
		PartyBTableResponse partyBTableResponseEVC = getPartyBExhibitValueChangeTable(amendmentId, pdfContext);
		logger.info("Reading partyBTableResponseFNC");
		PartyBTableResponse partyBTableResponseFNC = getPartyBFundNameChangeTable(amendmentId, pdfContext);
		logger.info("Reading bsSignature");
		Map<String, Object> bsSignature = generateBSSignatures(amendmentId);
		logger.info("Reading ssSignature");
		Map<String, Object> ssSignature = generateSSSignatures(amendmentId);
		
		// Build HTML
		logger.info("Replacing placeholders in HTML");
		replaceDatePinnedPlaceholder(doc);
		replacePlaceHolderA(amendmentId, doc, partyARelationString);
		replacePartyBAdditionPlaceholder(amendmentId, doc, pdfContext,partyBTableResponseAddition);
		replacePartyBRemovalPlaceholder(amendmentId, doc, pdfContext,partyBTableResponseRemoval);
		replaceSleeveAdditionPlaceholder(amendmentId, doc, pdfContext,sleeveTableResponseAddition);
		replaceSleeveRemovalPlaceholder(amendmentId, doc, pdfContext,sleeveTableResponseRemoval);
		replacePartyBExhibitValueChangePlaceholder(amendmentId, doc, pdfContext, partyBTableResponseEVC);
		replacePartyBFundNameChangePlaceholder(amendmentId, doc, pdfContext, partyBTableResponseFNC);
		replaceBSSignaturePlaceholder(amendmentId, doc, pdfContext, (Grid)bsSignature.get(RFAConstants.BS_SIGNATURE_GRID),(Long) bsSignature.get(RFAConstants.BS_SIGNATURE_COUNT));
		replaceSSSignaturePlaceholder(amendmentId, doc, pdfContext,(Grid)ssSignature.get(RFAConstants.SS_SIGNATURE_GRID),(Long) ssSignature.get(RFAConstants.SS_SIGNATURE_COUNT));
	
		return doc.getElementsByTag("body").get(0).html();
	}

	private Map<String, Object> generateSSSignatures(Long amendmentId) {
		Grid signatureSSGrid = ssSignatures.executeQuery("amendmentId", amendmentId);
		Long ssPlaceHolderCount = selectAmendmentSSSignaturePlaceholderCount.executeQuery("amendmentId",amendmentId);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(RFAConstants.SS_SIGNATURE_GRID, signatureSSGrid);
		map.put(RFAConstants.SS_SIGNATURE_COUNT, ssPlaceHolderCount);
		return map;
	}
	private Map<String, Object> generateBSSignatures(
			final Long amendmentId) {
		Grid signatureBSGrid = bsSignatures.executeQuery("amendmentId", amendmentId);
		Long bsPlaceHolderCount = selectAmendmentBSSignaturePlaceholderCount.executeQuery("amendmentId",amendmentId);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put(RFAConstants.BS_SIGNATURE_GRID, signatureBSGrid);
		map.put(RFAConstants.BS_SIGNATURE_COUNT, bsPlaceHolderCount);
		return map;
	}
	public Map<String, Object> generateDatePinned(
			final Long amendmentId) {
		Long ssSentRFACount = getSSSendRFACount.executeQuery("amendmentId", amendmentId);
    	String datepinnedISOUtc = getBSFirstSignDate.executeQuery("amendmentId", amendmentId);
    	Map<String,Object> returnObject = new HashMap<String,Object>();
    	returnObject.put(RFAConstants.DATE_PINNED_SS_SENT_COUNT, ssSentRFACount);
    	returnObject.put(RFAConstants.DATE_PINNED_FIRST_BS_SIG_DATE, datepinnedISOUtc);
    	return returnObject;
	}
	
	@Override
	public String generateCommentTable(Long amendmentId, QueryService<byte[]> selectComment) throws Exception{
		Map<String, Object> params = new HashMap<>();
		params.put("amendmentId",amendmentId);
		String amendmentLetterContent = CommonUtil.convertToUTF8(selectComment.executeQuery(params));
		amendmentLetterContent = CommonUtil.updateAmpersandAndBRTag(amendmentLetterContent);
		Document doc = Jsoup.parse(amendmentLetterContent);
		doc.getElementsByTag("body");
		return doc.getElementsByTag("body").get(0).html();
	}
	
}
