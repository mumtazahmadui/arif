package com.markit.ms.common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.service.EmailFilterMetadataService;
import com.wordnik.swagger.annotations.Api;


/**
 * This class handle api calls to get filter data for emails
 * 
 * @since RFA5.0
 *
 */
@RestController
@RequestMapping("v1/filter/")
@Api(value = "emailFilter", description = "Email Filter APIs")
public class EmailFilterMetadataController {

	@Autowired
	EmailFilterMetadataService emailFilterService;
	
	/**
	 * gets JSON of filter
	 * @return
	 */
	@RequestMapping(value = "grid/{filterId}", method = RequestMethod.GET)
	public String getFilterData(HttpServletRequest request, HttpServletResponse response,@PathVariable Long filterId) {
		return emailFilterService.getFiltersByFilterToken(filterId);
	}

}
