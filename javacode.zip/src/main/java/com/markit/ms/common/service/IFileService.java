package com.markit.ms.common.service;

import com.markit.ms.common.bean.McFile;
import com.markit.fileutil.common.domain.MCFile;


public interface IFileService {
	public byte[] getFile(Long fileId, Long companyId);

	public MCFile saveFile(byte[] signedDocument, Long companyId,
			String newOriginalFilePrefix, Long userId);

	public McFile getMcFile(Long fileId, Long companyId);

	public MCFile saveFile(String fileName, byte[] file, Long companyId, Long userId);
}
