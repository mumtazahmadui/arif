package com.markit.ms.common.controller;

import java.io.DataOutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.markit.ms.common.bean.McFile;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.service.IFileServiceValidatorService;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/v1/company")
@Api(value = "files", description = "File APIs")
public class FileController {
	
	@Autowired
    private IFileService fileService;
	
	@Autowired
    private IFileServiceValidatorService fileServiceValidatorService;	
	
	@RequestMapping(value = "{companyId}/files/download_file/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	@ApiOperation(value = "Download File")
	public @ResponseBody void downloadFile(@PathVariable Long companyId, @PathVariable Long id
			, HttpServletResponse response,HttpServletRequest request) throws Exception
    {
		Long companyIdFromSession = CommonUtil.getCompanyIdFromSession(request);
		McFile mcFile = fileService.getMcFile(id, companyIdFromSession);
		String fileName = mcFile.getFileName();
		String mimeType = mcFile.getMimeType();
		byte[] fileBytes = fileService.getFile(id, companyIdFromSession);
        response.setContentType(mimeType);
        response.setHeader("Content-disposition", "attachment; filename=\"" + fileName + "\"");
        DataOutputStream dataOutStream = new DataOutputStream(response.getOutputStream());
        dataOutStream.write(fileBytes);
        dataOutStream.flush();
    }
	
	@RequestMapping(value = "{companyId}/files/open_file/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	@ApiOperation(value = "Download File")
	public @ResponseBody void openFile(@PathVariable Long companyId, @PathVariable Long id
			, HttpServletResponse response,HttpServletRequest request) throws Exception
    {
		
		McFile mcFile = fileService.getMcFile(id, companyId);
		String mimeType = mcFile.getMimeType();
		String fileName = mcFile.getFileName();
		byte[] fileBytes = fileService.getFile(id, mcFile.getCompanyId());
        response.setContentType(mimeType);
        response.setHeader("Content-disposition", "inline; filename=\"" + fileName + "\"");
        DataOutputStream dataOutStream = new DataOutputStream(response.getOutputStream());
        dataOutStream.write(fileBytes);
        dataOutStream.flush();
    }
}
