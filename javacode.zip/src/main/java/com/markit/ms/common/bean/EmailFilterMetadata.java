package com.markit.ms.common.bean;

import java.sql.Date;

/**
 * Holds filter criteria details provided with email
 * <p>
 * Table (RFA_EMAIL_EVENT_METADATA)
 * </p>
 * 
 * @since RFA5.0
 */
public class EmailFilterMetadata {

	private Long id;
	private Long createdBy;
	private Date createdDate;
	private String event;

	private String filterCriteria;

	private Long templateId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	/**
	 * 
	 * get JSON string of filter criteria
	 */
	public String getFilterCriteria() {
		return filterCriteria;
	}

	/**
	 * set filter criteria in JSON string format
	 */
	public void setFilterCriteria(String filterCriteria) {
		this.filterCriteria = filterCriteria;
	}

	public Long getTemplateId() {
		return templateId;
	}

	/**
	 * set template Id of O360 DB for Email Templates
	 */
	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

}
