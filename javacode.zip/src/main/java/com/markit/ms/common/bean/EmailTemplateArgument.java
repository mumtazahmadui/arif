package com.markit.ms.common.bean;

import java.io.Serializable;

/***
 * Holds the parameters of Template Arguments to replace placeholders in Email Template.
 * <p>
 * Table (O360_EMAIL_TEMPLATE_ARGS)
 * </p>
 * @since RFA5.0
 */
public class EmailTemplateArgument implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long mailId;

	private String mapKey;
	private String type;
	private Object mapValue;
	private String mapValueClass;

	public Long getMailId() {
		return mailId;
	}

	public void setMailId(Long mailId) {
		this.mailId = mailId;
	}

	public String getMapKey() {
		return mapKey;
	}

	public void setMapKey(String mapKey) {
		this.mapKey = mapKey;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Object getMapValue() {
		return mapValue;
	}

	public void setMapValue(Object mapValue) {
		this.mapValue = mapValue;
	}

	public String getMapValueClass() {
		return mapValueClass;
	}

	public void setMapValueClass(String mapValueClass) {
		this.mapValueClass = mapValueClass;
	}

}
