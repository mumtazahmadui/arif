package com.markit.ms.common.dao;

import java.util.List;

import com.markit.ms.common.bean.EmailMaster;
import com.markit.ms.common.bean.TemplateDetails;
import com.markit.ms.common.util.TemplateTypeEnum;

/***
 * This class provide dao operations with O360 database
 * 
 * @since RFA5.0
 */
public interface EmailDao {

	/**
	 * persists <code>EmailMaster</code> in database
	 * 
	 * @param email holds parameters for email to be send
	 * @return unique id generated after persist
	 */
	Long saveMail(EmailMaster email);

	/**
	 * 
	 * @param templateType <code>TemplateTypeEnum</code> uniquely defines each
	 *                     template
	 * @return template details except velocity template content
	 */
	TemplateDetails getTemplateDetails(TemplateTypeEnum templateType);

	/**
	 * 
	 * @param templateType <code>TemplateTypeEnum</code> uniquely defines each
	 *                     template
	 * @return template content
	 */
	String getTemplate(TemplateTypeEnum templateType);

	/**
	 * updates <code>EmailMaster</code> status and retries in database
	 * 
	 * @param mailBean
	 */
	void updateMailStatus(EmailMaster mailBean);

	/**
	 * 
	 * @param template id
	 * @return template content
	 */
	String getTemplate(Long templateId);
	
	/**
	 * 
	 * @param mailIds
	 * @return
	 * list of email master object containg template args if template id exists
	 */
	List<EmailMaster> getEmail(List<Long> mailIds);
}
