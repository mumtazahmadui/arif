package com.markit.ms.common.service;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Map;

import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.ms.rfa.bean.PDFContext;

public interface IHTMLParser {
public String generateAmendmentLetterHTML(String amendmentLetterContent, Long amendmentId, PDFContext pdfContext) throws  Exception;
public String generateExhibitTable(Long amendmentId, Long exhibitId, PDFContext pdfContext) throws Exception;
Integer getSignaturePlaceholderCount(Long amendmentId, String placeholderId) throws IOException;
	
	Integer getSignaturePlaceholderCount(String amendmentLetterContent,int isBsCompany) throws IOException;
	public String generateAmendmentLetterHTMLSynchronous(
			String amendmentLetterContent, Long amendmentId,
			PDFContext pdfContext) throws Exception;
	public Map<String, Object> generateDatePinned(Long amendmentId);
	public Boolean hasPartyAPlaceholder(Long amendmentId) throws UnsupportedEncodingException;
	public String generateCommentTable(Long amendmentId,QueryService<byte[]> selectComment) throws Exception;
}
