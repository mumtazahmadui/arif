package com.markit.ms.common.service;

import java.util.List;
import java.util.Map;

public interface IRFAMailService {

	void sendEmail(List<String> emailList, Map<String, Object> additionalParams, String bodyTemplate, String subTemplate) throws Exception;

	void sendEmail(List<String> emailList, Map<String, Object> additionalParams, String bodyTemplate, String subTemplate,
			Map<String, Object> subjectVariables) throws Exception;

	void sendEmailWithCC(List<String> emailList, Map<String, Object> additionalParams, String bodyTemplate, String subTemplate,
			Map<String, Object> subjectVariables, String ccEmail) throws Exception;
}
