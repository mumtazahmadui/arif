package com.markit.ms.common.service;

import java.util.Map;

import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;

/**
 * This class provides method for mail send processing
 * 
 * @since RFA5.0
 *
 */
public interface EmailProcessService {

	/**
	 * 
	 * @param simpleMailMessage
	 * @param bodyTemplate
	 * @param bodyVariables
	 */
	void sendEmail(SimpleMailMessage simpleMailMessage, String bodyTemplate, Map<String, Object> bodyVariables)
			throws MailException;

	/**
	 * 
	 * @param bodyTemplate
	 * @param bodyVariables
	 * @return
	 */
	String getPreview(String bodyTemplate, Map<String, Object> bodyVariables);

}
