package com.markit.ms.common.dao;

import com.markit.ms.common.bean.EmailFilterMetadata;

/**
 * 
 * @since RFA5.0
 */
public interface EmailFilterMetadataDao {

	/**
	 * Persists the attributes of <code>EmailFilterMetadata</code> reference in
	 * database
	 * 
	 * @return The unique id which represents filter criteria
	 */
	Long generateFilterToken(EmailFilterMetadata metadata);
	

	/**
	 * 
	 * @param filterToken unique id representing filter criteria in database
	 * @return
	 * JSON representation of filter criteria
	 */
	String getFiltersByFilterToken(Long filterToken);

}
