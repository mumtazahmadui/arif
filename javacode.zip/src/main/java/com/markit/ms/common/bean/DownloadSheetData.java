package com.markit.ms.common.bean;

import java.util.List;

public class DownloadSheetData {
	private int sheet;
	private int rowDataStart;
	private String[] headers;
	private List objectList;

	public DownloadSheetData() {
		sheet = 0;
	}

	public DownloadSheetData(int sheet, List objectList, String[] headers,
			int rowDataStart) {
		this.sheet = sheet;
		this.objectList = objectList;
		this.headers = headers;
		this.rowDataStart = rowDataStart;
	}

	public int getSheet() {
		return sheet;
	}

	public void setSheet(int sheet) {
		this.sheet = sheet;
	}

	public int getRowDataStart() {
		return rowDataStart;
	}

	public void setRowDataStart(int rowDataStart) {
		this.rowDataStart = rowDataStart;
	}

	public String[] getHeaders() {
		return headers;
	}

	public void setHeaders(String[] headers) {
		this.headers = headers;
	}

	public List getObjectList() {
		return objectList;
	}

	public void setObjectList(List objectList) {
		this.objectList = objectList;
	}

}
