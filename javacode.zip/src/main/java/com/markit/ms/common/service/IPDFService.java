package com.markit.ms.common.service;

public interface IPDFService {

	  public byte[] convert(String htmlBytes);
	
}
