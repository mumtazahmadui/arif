package com.markit.ms.common.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.markit.ms.common.bean.MasterAgreementLookup;
import com.markit.ms.rfa.bean.MasterlistValidatorBean;

public interface IRfaLookupDao {
	List<MasterAgreementLookup> masterAgreementsLookupData(Long companyId, String brokerName, Date agreementDate, String agreementType, String additionalInfo);
	Map<String, String> getExhibitByPartBAndML(Long partyBEntityId, Long masterAgreementId);
	MasterlistValidatorBean getMasterAgreementByDetails(String partyATrueLegalName, String agreementType,
			Date agreementDateFormatted, String investmentManager, String mlIdentifier, Long companyId);
}
