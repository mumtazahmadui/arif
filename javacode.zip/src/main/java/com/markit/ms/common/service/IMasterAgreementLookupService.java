package com.markit.ms.common.service;

import java.util.Date;

import com.markit.ms.common.bean.MasterAgreementLookup;

public interface IMasterAgreementLookupService {

	MasterAgreementLookup getMasterAgreementLookup(String partyATrueLegalName, String agreementType,
			Date agreementDateFormatted, String mlIdentifier, Long companyId);
}
