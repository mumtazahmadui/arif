package com.markit.ms.common.model.validation;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ValidationErrorDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private List<FieldErrorDTO> fieldErrors = new ArrayList<FieldErrorDTO>();
	
	private String message;
 
    public void addFieldError(String path, String message) {
        FieldErrorDTO error = new FieldErrorDTO(path, message);
        fieldErrors.add(error);
    }

	public List<FieldErrorDTO> getFieldErrors() {
		return fieldErrors;
	}

	public void setFieldErrors(List<FieldErrorDTO> fieldErrors) {
		this.fieldErrors = fieldErrors;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
