package com.markit.ms.common.bean;

import java.util.Date;

public class MasterAgreementLookup {
	
	private Long id;
	
	private String externalPartyAName;
	
	private String agreementType;
	
	private Date masterAgreementDate;
	
	private Long imEntityId;
	
	private String additionalInfo;
	
	private Long entityId;
	
	private long masterAgreementId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getExternalPartyAName() {
		return externalPartyAName;
	}

	public void setExternalPartyAName(String externalPartyAName) {
		this.externalPartyAName = externalPartyAName;
	}

	public String getAgreementType() {
		return agreementType;
	}

	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}

	public Date getMasterAgreementDate() {
		return masterAgreementDate;
	}

	public void setMasterAgreementDate(Date masterAgreementDate) {
		this.masterAgreementDate = masterAgreementDate;
	}

	public Long getImEntityId() {
		return imEntityId;
	}

	public void setImEntityId(Long imEntityId) {
		this.imEntityId = imEntityId;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public long getMasterAgreementId() {
		return masterAgreementId;
	}

	public void setMasterAgreementId(long masterAgreementId) {
		this.masterAgreementId = masterAgreementId;
	}
}
