package com.markit.ms.common.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.User;
import com.markit.ms.common.constants.PermissionConstants;
import com.markit.ms.common.dao.IUserDao;
import com.markit.ms.common.service.ICompanyService;
import com.markit.ms.common.service.IUserService;

@Service
public class UserServiceImpl implements IUserService {
	
	@Autowired
	private IUserDao userDao;
	
	@Autowired
	private ICompanyService companyService;

	@Override
	public User getUser(long id) {
		return userDao.getUser(id);
	}
	
	@Override
	public List<String> getAllUsersForCompanyByPermissionName(Long entityId, List<String> permissionName) {
		Long companyId = companyService.getCompanyIdByEntityId(entityId);
		return userDao.getAllUsersForCompanyByPermissionName(companyId, permissionName);
	}
	
	@Override
	public List<User> getAllUsersForCompanyByPermissionNameWithPagination(
			Long companyId, List<String> permissionName, Long fromRow, Long pageSize) {
		return userDao.getAllUsersForCompanyByPermissionNameWithPagination(companyId, permissionName, fromRow, pageSize);
	}

	@Override
	public List<User> getUsersOfCompanyByPermissionName(Long companyId, List<String> permissions) {
		return userDao.getUsersOfCompanyByPermissionName(companyId, permissions);
	}
	
	@Override
	public List<User> getUsersByIds(List<Long> userIds) {
		return userDao.getUsersByIds(userIds);
	}

	@Override
	public List<User> getOtherUsersOfCompanyByPermissionName(Long companyId, List<String> permissions, Long userId) {
		return userDao.getOtherUsersOfCompanyByPermissionName(companyId, permissions,userId);
	}

	@Override
	public List<User> getOtherUsersOfCompanyForEscalation(Long companyId, Long userId) {
				
		return userDao.getOtherUsersOfCompanyByPermissionName(companyId, PermissionConstants.SS_RFA_WRITE_PERMISSIONS,
				userId);
	}
	
}
