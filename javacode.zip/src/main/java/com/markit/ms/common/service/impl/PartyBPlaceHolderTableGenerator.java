package com.markit.ms.common.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.stereotype.Service;

import com.markit.ms.common.service.IPartyBPlaceHolderTableGenerator;
import com.markit.ms.rfa.bean.NewExhibitResponse;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.placeholders.response.PartyBTableResponse;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.RFAConstants;
@Service
public class PartyBPlaceHolderTableGenerator implements IPartyBPlaceHolderTableGenerator{

	@Override
	public String getPartyBPlaceholderHTML(
			PartyBTableResponse partyBTableResponse, PDFContext pdfContext) throws UnsupportedEncodingException {
		List<Map<String, String>> columns= partyBTableResponse.getColumns();
		List<Map<String, String>> rows= partyBTableResponse.getRows();
		List<Map<String, String>> lineBreaks= partyBTableResponse.getLineBreaks();
		List<Map<String, String>> previouslineBreaks= partyBTableResponse.getPreviousLineBreaks();
		return generateTable(columns, rows, lineBreaks,
				previouslineBreaks, pdfContext);
	}
	
	private List<Map<String, String>> sortListofMapsForIndex(List<Map<String, String>> columns){		
		Collections.sort(columns, new Comparator<Map<String, String>>() {
			public int compare(Map<String,String> o1, Map<String,String> o2) {
				return Integer.valueOf((String)o1.get("INDEX")!=null?(String)o1.get("INDEX"):"-1").
						compareTo(Integer.valueOf((String)o2.get("INDEX")!=null?(String)o2.get("INDEX"):"-1"));				
			};
		});
		
		return columns;
	}

	private String generateTable(List<Map<String, String>> columns, List<Map<String, String>> rows,
			List<Map<String, String>> lineBreaks,
			List<Map<String, String>> previouslineBreaks, PDFContext pdfContext)
			throws UnsupportedEncodingException {
		
		List<Map<String, String>> sortedColumns = sortListofMapsForIndex(columns);
		
		StringBuffer html = new StringBuffer();
		//1. Get non hidden columns for table
		String [] columnNames = new String[sortedColumns.size()];
		String [] columnLabels = new String[sortedColumns.size()];
		int NO_OF_COLUMNS = 0;
		for(Map<String,String> columnMap : sortedColumns){
			if(columnMap.get("HIDDEN").equals("0")) {
				//int index = Integer.parseInt(columnMap.get("INDEX"));
				columnNames[NO_OF_COLUMNS] = columnMap.get("NAME");
				columnLabels[NO_OF_COLUMNS] = columnMap.get("LABEL");
				NO_OF_COLUMNS++;
			}
		}
	
		//2. Split / Sort Rows
		Map<String, List<Map<String, String>>> columnHeaderTable = splitSortRows(rows, pdfContext);
		
		Map<String, String> lineBreaksTableMap = getlineBreaks(lineBreaks);
		
		Map<String, String> showHeaderMap = getShowHeaderMap(lineBreaks);
		
		//List<String> previousLineBreaks = getPreviouslineBreaks(previouslineBreaks);

		Long TABLE_COUNT = 1L;
		StringBuffer PLACEHOLER_TEXT = new StringBuffer();
	//	StringBuffer PREVIOUS_LINE_TEXT = generatePreviousLineText(previousLineBreaks);
	//	PLACEHOLER_TEXT.append(PREVIOUS_LINE_TEXT);
		for( String headerText: columnHeaderTable.keySet()) {
			List<Map<String, String>> columnHeaderTableRows = columnHeaderTable.get(headerText);
			
			if(columnHeaderTableRows != null && columnHeaderTableRows.size() > 0) {
					
				StringBuffer HEADER_TEXT = generateTableHeaderText(headerText);

				StringBuffer TABLE_HEADER = generateColumnHeader(columnLabels,
						NO_OF_COLUMNS);

				StringBuffer TABLE_BODY = generateTableBody(columnNames, columnLabels,
						NO_OF_COLUMNS, columnHeaderTableRows);

				StringBuffer TABLE = generateFullTables(TABLE_HEADER,
						TABLE_BODY);
				
			
				
				String showHeaderValue = showHeaderMap.get(TABLE_COUNT + "");
				
				if(showHeaderValue == null) {
					PLACEHOLER_TEXT.append(HEADER_TEXT);
				} else {
					PLACEHOLER_TEXT.append(CommonUtil.convertToUTF8(showHeaderValue.getBytes()));
				}
				
				PLACEHOLER_TEXT.append(TABLE);
				
				String LINE_BREAK = getLineBreak(lineBreaksTableMap, TABLE_COUNT);
				PLACEHOLER_TEXT.append(LINE_BREAK).append("<br>");
				TABLE_COUNT++;
				
			}
			
		}
		html.append(PLACEHOLER_TEXT);
		return html.toString();
	}

	private Map<String, String> getShowHeaderMap(
			List<Map<String, String>> lineBreaks) {
		Map<String,String> map = new TreeMap<String,String>();
		if(lineBreaks == null) {
			return map;
		}
			for(Map<String,String> linBreak : lineBreaks) {
				map.put(linBreak.get("LINE_BREAK_INDEX"), linBreak.get("SHOW_HEADER_TEXT"));
			}
		return map;
	}

	private String getLineBreak(Map<String, String> lineBreaksTableMap,
			Long TABLE_COUNT)
			throws UnsupportedEncodingException {
		String lineBreak = lineBreaksTableMap.get(TABLE_COUNT + "");
		if(lineBreak != null) {
			return CommonUtil.convertToUTF8(lineBreak.getBytes());
		}
		return "";
	}

	private StringBuffer generatePreviousLineText(
			List<String> previousLineBreaks) throws UnsupportedEncodingException {
		StringBuffer buffer = new StringBuffer();
		for(String previousLineBreak : previousLineBreaks) {
			buffer.append(CommonUtil.convertToUTF8(previousLineBreak.getBytes()));
		}
		return buffer;
	}

	private List<String> getPreviouslineBreaks(
			List<Map<String, String>> previouslineBreaks) {
		List<String> list = new ArrayList<String>();
		if(previouslineBreaks == null) {
			return list;
		}
		for(Map<String,String> previousline : previouslineBreaks) {
			list.add(previousline.get("LINE_BREAK_TEXT"));
		}
		return list;
	}

	private Map<String, String> getlineBreaks(List<Map<String, String>> lineBreaks) {
		Map<String,String> map = new TreeMap<String,String>();
		if(lineBreaks == null) {
			return map;
		}
			for(Map<String,String> linBreak : lineBreaks) {
				map.put(linBreak.get("LINE_BREAK_INDEX"), linBreak.get("LINE_BREAK_TEXT"));
			}
		return map;
	}

	private StringBuffer generateFullTables(StringBuffer TABLE_HEADER,
			StringBuffer TABLE_BODY) {
		StringBuffer TABLE = new StringBuffer();
		TABLE.append("<table>")
		.append(TABLE_HEADER)
		.append(TABLE_BODY)
		.append("</table>");
		return TABLE;
	}

	private StringBuffer generateTableHeaderText(String headerText) {
		StringBuffer HEADER_HTML = new StringBuffer();
		HEADER_HTML.append("<div>")
		.append(headerText)
		.append("</div>");
		return HEADER_HTML;
	}

	private StringBuffer generateColumnHeader(String[] columnLabels,
			int NO_OF_COLUMNS) {
		StringBuffer TABLE_HEADER = new StringBuffer();
		TABLE_HEADER.append("<thead>")
		.append("<tr>");
		for(int i=0; i<NO_OF_COLUMNS;i++) {
			TABLE_HEADER.append("<td>")
			.append(columnLabels[i])
			.append("</td>");
		}
		TABLE_HEADER.append("</tr>")
		.append("</thead>");
		return TABLE_HEADER;
	}
	
	private StringBuffer generateTableBody(String[] columnNames, String[] columnLabels,
			int NO_OF_COLUMNS, List<Map<String, String>> columnHeaderTableRows) {
		StringBuffer TABLE_BODY = new StringBuffer();
		int rowspan=0;
		int remainingSpannedRows=0;
		TABLE_BODY.append("<tbody>");
		for(Map<String,String> columnHeaderRow : columnHeaderTableRows) {
			if (columnHeaderRow.containsKey("EXHIBIT_ROWSPAN") && remainingSpannedRows < 1){
				rowspan = columnHeaderRow.get("EXHIBIT_ROWSPAN") != null ? new Integer(columnHeaderRow.get("EXHIBIT_ROWSPAN")) : 1;
				remainingSpannedRows = rowspan;
			}
				
			
			if (rowspan > 1 && remainingSpannedRows == rowspan) {
				generateFirstSpannedExhibitRow(columnHeaderRow, rowspan,TABLE_BODY, 
						NO_OF_COLUMNS, columnNames, columnLabels);
				remainingSpannedRows--; 
			}
			else if (rowspan > 1 && remainingSpannedRows > 0){
				generatePreceedingSpannedExhibitRow(columnHeaderRow, TABLE_BODY, 
						NO_OF_COLUMNS, columnNames, columnLabels);
				remainingSpannedRows--;
			}
			else {
				generateStandardExhibitRow(columnHeaderRow, TABLE_BODY, NO_OF_COLUMNS, columnNames, columnLabels);
				remainingSpannedRows--;
			}
		}
		TABLE_BODY.append("</tbody>");
		return TABLE_BODY;
	}
	
	private StringBuffer generateStandardExhibitRow(Map<String, String> columnHeaderRow,
			StringBuffer TABLE_BODY, int NO_OF_COLUMNS, String[] columnNames, String[] columnLabels){

		TABLE_BODY.append("<tr>");
		for(int columnIndex=0 ; columnIndex< NO_OF_COLUMNS ; columnIndex++) {
			String columnHeader = columnLabels[columnIndex];
			String columnName = columnNames[columnIndex];
			String columnValue = columnHeaderRow.get(columnName);
			if(null!= columnValue && columnHeader.equalsIgnoreCase("Sell Side Response") && columnValue.equals("Accepted Signed")) {
				columnValue = "Accepted";
			}
			TABLE_BODY.append("<td>")
			.append(columnValue!=null?columnValue:"")
			.append("</td>");
		}
		TABLE_BODY.append("</tr>");
		return TABLE_BODY;
	}
		
	private StringBuffer generateFirstSpannedExhibitRow(Map<String, String> columnHeaderRow, int rowspan,
			StringBuffer TABLE_BODY, int NO_OF_COLUMNS, String[] columnNames, String[] columnLabels){
		
		TABLE_BODY.append("<tr>");
		for(int columnIndex=0 ; columnIndex< NO_OF_COLUMNS ; columnIndex++) {
			String columnHeader = columnLabels[columnIndex];
			String columnName = columnNames[columnIndex];
			String columnValue = columnHeaderRow.get(columnName);
			if(null!= columnValue && columnHeader.equalsIgnoreCase("Sell Side Response") && columnValue.equals("Accepted Signed")) {
				columnValue = "Accepted";
			}
			if (!RFAConstants.defaultExhibitFields.contains(columnName)){
				TABLE_BODY.append("<td rowspan=" + rowspan + ">")
				.append(columnValue!=null?columnValue:"")
				.append("</td>");
			}
			else {
				TABLE_BODY.append("<td>")
				.append(columnValue!=null?columnValue:"")
				.append("</td>");
			}
		}
		TABLE_BODY.append("</tr>");
		return TABLE_BODY;
	}
	
	private StringBuffer generatePreceedingSpannedExhibitRow(Map<String, String> columnHeaderRow,
			StringBuffer TABLE_BODY, int NO_OF_COLUMNS, String[] columnNames, String[] columnLabels){

		TABLE_BODY.append("<tr>");
		for(int columnIndex=0 ; columnIndex< NO_OF_COLUMNS ; columnIndex++) {
			String columnHeader = columnLabels[columnIndex];
			String columnName = columnNames[columnIndex];
			String columnValue = columnHeaderRow.get(columnName);
			if(null!= columnValue && columnHeader.equalsIgnoreCase("Sell Side Response") && columnValue.equals("Accepted Signed")) {
				columnValue = "Accepted";
			}
			if (RFAConstants.defaultExhibitFields.contains(columnName)){
				TABLE_BODY.append("<td>")
				.append(columnValue!=null?columnValue:"")
				.append("</td>");
			}
		}
		TABLE_BODY.append("</tr>");
		return TABLE_BODY;
	}
	
	private Map<String, List<Map<String, String>>> splitSortRows(
			List<Map<String, String>> rows, PDFContext pdfContext) {
		Map<String,List<Map<String, String>>> columnHeaderTable = new TreeMap<String,List<Map<String, String>>>();
		String BLANK = "";
		for(Map<String,String> row : rows){
			String headerText = row.get("HEADER_TEXT");

			//List<Map<String,String>> row = new ArrayList<Map<String,String>>();
			if(isBlankHeaderText(headerText)) { // Create null table
				List<Map<String,String>> existingRows = columnHeaderTable.get(BLANK);
				if(existingRows == null) {
					existingRows = new ArrayList<Map<String,String>> ();
				}
				existingRows.add(row);
				columnHeaderTable.put(BLANK, existingRows);
			} else {
				List<Map<String,String>> existingRows = columnHeaderTable.get(headerText);
				if(existingRows == null) {
					existingRows = new ArrayList<Map<String,String>> ();
				}
				existingRows.add(row);
				columnHeaderTable.put(headerText, existingRows);
			}
		}
		return columnHeaderTable;
	}
	
private boolean isBlankHeaderText(String headerText) {
	return headerText == null || headerText.equals("");
}

@Override
public String getExhitHTML(NewExhibitResponse newExhibitResponse, PDFContext pdfContext)
		throws UnsupportedEncodingException {
	List<Map<String, String>> columns= newExhibitResponse.getColumns();
	List<Map<String, String>> rows= newExhibitResponse.getRows();
	return generateTable(columns, rows, null,
			null, pdfContext);
}

}
