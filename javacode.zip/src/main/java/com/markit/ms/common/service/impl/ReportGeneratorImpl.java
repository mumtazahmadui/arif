package com.markit.ms.common.service.impl;

import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.esign.PdfSigner;
import com.markit.ms.common.dao.IUserDao;
import com.markit.ms.common.service.IAmendmentLetterPDFPageGenerator;
import com.markit.ms.common.service.IExhibitPDFPageGenerator;
import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.common.service.ISignatureService;
import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;
import com.markit.ms.rfa.service.IExhibitService;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PDFUtil;

@Service
public class ReportGeneratorImpl implements IReportGenerator {

	private static final Logger logger = LoggerFactory.getLogger(ReportGeneratorImpl.class.getName());
	private static final String AMENDMENT_LETTER_VALIDATION_ERROR_TEMPLATE_NAME = "report/template/amendment_letter_validation_error_pdf.vm";
	private static final String EMPTY_DOC_TEMPLATE_NAME = "report/template/amendmentLetterEmptyPDF.vm";
	private static final String BULK_ACTION_VALIDATION_ERROR_TEMPLATE_NAME = "report/template/bulk_action_next_step_validation_error_pdf.vm";

    @Autowired private IExhibitService exhibitService;
    @Autowired private IUserDao userDao;
    @Resource private IExhibitPDFPageGenerator exhibitPDFPageGenerator;
    @Resource private IAmendmentLetterPDFPageGenerator amendmentLetterPDFPageGenerator;
    @Autowired private ISignatureService signatureService;
    @Resource private PdfSigner pdfSigner;
	@Resource private VelocityEngine velocityEngine;
    @Resource private QueryService<byte[]> selectAmendmentComment;
    @Resource private QueryService<byte[]> selectExhibitComment;
	
	@Override
	public byte[] getPDFContent(final Long amendmentId, final PDFContext pdfContext) throws Exception{
		
		ExecutorService pdfExecutor = Executors.newFixedThreadPool(2);
		byte[] fullPDF = null;
		try {
		Future<byte[]> amendmentFuture = pdfExecutor.submit(new Callable<byte[]>(){
			public byte[] call() throws Exception {
				logger.info("Generating Amendment Letter PDF");
				return amendmentLetterPDFPageGenerator.getAmendmentLetterPDF(amendmentId, pdfContext);
				
			}
		});
		
		Future<byte[]> exhibitFuture = pdfExecutor.submit(new Callable<byte[]>(){
			public byte[] call() throws Exception {
				logger.info("Generating Exhibit Letter PDF");
				return exhibitPDFPageGenerator.generateExhibitPDF(amendmentId, pdfContext);	
			}
		});
		
		Future<byte[]> amendmentCommentFuture = pdfExecutor.submit(new Callable<byte[]>(){
			public byte[] call() throws Exception {
				logger.info("Generating Amendment comment PDF");
				return amendmentLetterPDFPageGenerator.getLetterCommentPDF(amendmentId,selectAmendmentComment);	
			}
		});
		
		Future<byte[]> exhibitCommentFuture = pdfExecutor.submit(new Callable<byte[]>(){
			public byte[] call() throws Exception {
				logger.info("Generating Exhibit Letter PDF");
				return amendmentLetterPDFPageGenerator.getLetterCommentPDF(amendmentId,selectExhibitComment);	
			}
		});
		
		byte[] amendmentLetterPDF = amendmentFuture.get();
		
		logger.info("Generated Amendment Letter PDF");
		byte[] exhibitPDF = exhibitFuture.get();
		logger.info("Generated Exhibit Letter PDF");
		byte[] amendmentAppendixPDF = amendmentCommentFuture.get();
		logger.info("Generated Letter appendix PDF");
		byte[] exhibitAppendixPDF = exhibitCommentFuture.get();
		logger.info("Generated exhibit appendix PDF");
		
		fullPDF  = amendmentLetterPDF;
		 if(exhibitPDF != null) {
	        	logger.info("Merging Exhibit Letter PDF");
	        	fullPDF = PDFUtil.merge(fullPDF,exhibitPDF);
	        	logger.info("Merged Exhibit Letter PDF");
	        }
		if(amendmentAppendixPDF != null) {
        	logger.info("Merging appendix Letter PDF");
        	fullPDF = PDFUtil.merge(fullPDF,amendmentAppendixPDF);
        	logger.info("Merged appendix Letter PDF");
        }
        if(exhibitAppendixPDF != null) {
        	logger.info("Merging Exhibit appendix Letter PDF");
        	fullPDF = PDFUtil.merge(fullPDF,exhibitAppendixPDF);
        	logger.info("Merged Exhibit appendix Letter PDF");
        }
        
        pdfExecutor.shutdown();
		} catch (Exception exception) {
			pdfExecutor.shutdown();
			throw exception;
		}
    	return fullPDF;
	}



	@Override
	public byte[] getPDFContentSychronous(final Long amendmentId, final PDFContext pdfContext) throws Exception{
		
		byte[] fullPDF = null;
		byte[] amendmentLetterPDF =amendmentLetterPDFPageGenerator.getAmendmentLetterPDFSynchronous(amendmentId, pdfContext);				
		byte[] exhibitPDF = exhibitPDFPageGenerator.generateExhibitPDF(amendmentId, pdfContext);	
		byte[] amendmentComment = amendmentLetterPDFPageGenerator.getLetterCommentPDF(amendmentId,selectAmendmentComment);	
		byte[] exhibitComment = amendmentLetterPDFPageGenerator.getLetterCommentPDF(amendmentId,selectExhibitComment);	
	
		fullPDF  = amendmentLetterPDF;
        if(exhibitPDF != null) {
        	logger.info("Merging Exhibit Letter PDF");
        	fullPDF = PDFUtil.merge(amendmentLetterPDF,exhibitPDF);
        	logger.info("Merged Exhibit Letter PDF");
        }
        if(amendmentComment != null) {
        	logger.info("Merging appendix Letter PDF");
        	fullPDF = PDFUtil.merge(fullPDF,amendmentComment);
        	logger.info("Merged appendix Letter PDF");
        }
        if(exhibitComment != null) {
        	logger.info("Merging Exhibit appendix Letter PDF");
        	fullPDF = PDFUtil.merge(fullPDF,exhibitComment);
        	logger.info("Merged Exhibit appendix Letter PDF");
        }
    	return fullPDF;
	}


	

	@Override
	public byte[] appendEmptyPDFDocumentTo(byte[] originalDocument) throws Exception{
        VelocityContext context = new VelocityContext();
        Properties p = new Properties();
        p.setProperty("resource.loader", "class");
        p.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
        p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        int widthInInches = PDFUtil.calculateWidth(0);
        
        context.put("size",  widthInInches + "in 11in");
        context.put("columnPixel", PDFUtil.COLUMN_WIDTH + "px");
        context.put("width", widthInInches -1 + "in");
        
        velocityEngine.init(p);
        Template template = velocityEngine.getTemplate(EMPTY_DOC_TEMPLATE_NAME);
        StringWriter writer = new StringWriter();
        template.merge(context, writer);
        PDFServiceImpl pdfService = new PDFServiceImpl();
        String html = PDFUtil.stripNonValidXMLCharacters(writer.toString());
    	byte[] emptyDocument =  pdfService.convert(html);	
    	return PDFUtil.merge(originalDocument,emptyDocument);
	}
	
	


	@Override
	public byte[] getValidationErrorPDFContent(Map<String, List<PartyBEntity>> addPartyBErrorMap
			, Map<String, List<PartyBEntity>> removePartyBErrorMap, Map<String, List<PartyBEntity>> modifiedPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveRequestedOnAnotherRfaErrorMap, Map<String, List<PartyBEntity>> sleeveRemovalPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveExistsOnActiveTabErrorMap, Map<String, List<PartyBEntity>> sleeveParentNotOnActiveTabErrorMap
			, Map<String, List<PartyBEntity>> sleevesInProgressErrorMap
			, List<PartyBEntity> rejectedRecalledPartybList, Map<Long, AmendmentLetter> additionPlaceholderErrorMap
			, Map<Long, AmendmentLetter> removalPlaceholderErrorMap, Map<Long, AmendmentLetter> modificationPlaceholderErrorMap
			, Map<String, String> letterTemplateMap) throws Exception {
        VelocityContext context = new VelocityContext();
        Properties p = new Properties();
        p.setProperty("resource.loader", "class");
        p.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
        p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        
        context.put("addPartyBErrorMap", addPartyBErrorMap);
        context.put("removePartyBErrorMap", removePartyBErrorMap);
        context.put("modifiedPartyBErrorMap", modifiedPartyBErrorMap);
        context.put("sleeveRequestedOnAnotherRfaErrorMap", sleeveRequestedOnAnotherRfaErrorMap);
        context.put("sleeveRemovalPartyBErrorMap", sleeveRemovalPartyBErrorMap);
        context.put("sleeveExistsOnActiveTabErrorMap", sleeveExistsOnActiveTabErrorMap);
        context.put("sleeveParentNotOnActiveTabErrorMap", sleeveParentNotOnActiveTabErrorMap);
        context.put("sleevesInProgressErrorMap", sleevesInProgressErrorMap);
        context.put("rejectedRecalledPartybList", rejectedRecalledPartybList);
        context.put("additionPlaceholderErrorMap", additionPlaceholderErrorMap);
        context.put("removalPlaceholderErrorMap", removalPlaceholderErrorMap);
        context.put("modificationPlaceholderErrorMap", modificationPlaceholderErrorMap);
        context.put("letterTemplateMap", letterTemplateMap);
        context.put("CommonUtil", new CommonUtil());
        
        velocityEngine.init(p);
        Template template = velocityEngine.getTemplate(AMENDMENT_LETTER_VALIDATION_ERROR_TEMPLATE_NAME);
        StringWriter writer = new StringWriter();
        template.merge(context, writer);
        PDFServiceImpl pdfService = new PDFServiceImpl();
        String html = PDFUtil.stripNonValidXMLCharacters(writer.toString());
    	return pdfService.convert(html);	
	}

	@Override
	public byte[] getNextStepValidationErrorPDFContent(List<AmendmentLetter> invalidAmendmentLetters, BulkActionValidationType validationType){
        return generateErrorPDFContent(null, invalidAmendmentLetters, validationType);     
	}
	
	@Override
	public byte[] generateErrorPDFContent(String errorMessage, List<AmendmentLetter> invalidAmendmentLetters, BulkActionValidationType validationType) {
		VelocityContext context = new VelocityContext();
		Properties p = new Properties();
		p.setProperty("resource.loader", "class");
		p.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
		p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");

		context.put("invalidRfaIds", invalidAmendmentLetters);
		context.put("validationType", validationType.getName());
		if (StringUtils.isNotBlank(errorMessage)) {
			context.put("errorMessage", errorMessage);
		}
		velocityEngine.init(p);
		Template template = velocityEngine.getTemplate(BULK_ACTION_VALIDATION_ERROR_TEMPLATE_NAME);
		StringWriter writer = new StringWriter();
		template.merge(context, writer);
		PDFServiceImpl pdfService = new PDFServiceImpl();
		String html = PDFUtil.stripNonValidXMLCharacters(writer.toString());
		return pdfService.convert(html);
	}
}
