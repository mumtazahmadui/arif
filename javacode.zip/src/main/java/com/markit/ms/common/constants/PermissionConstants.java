package com.markit.ms.common.constants;

import java.util.Arrays;
import java.util.List;

public class PermissionConstants {
	public static final String BS_RFA = "bs.rfa";
	public static final String BS_RFA_SIGNATORY = "bs.rfa.signatory";
	public static final String SS_RFA = "ss.rfa";
	public static final String SS_RFA_SIGNATORY = "ss.rfa.signatory";
	public static final String SS_RFA_READ = "ss.rfa.read";

	public static final List<String> SS_RFA_WRITE_PERMISSIONS = Arrays.asList(SS_RFA, SS_RFA_SIGNATORY,
			"ss.rfa.onboarding", "ss.rfa.kyc", "ss.rfa.tax", "ss.rfa.legal", "ss.rfa.credit", "ss.rfa.operations",
			"ss.rfa.manager");

}
