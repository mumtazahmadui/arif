package com.markit.ms.common.service;

public interface IFileServiceValidatorService {
public boolean validateFileAccess(Long fileId, Long companyId);
}
