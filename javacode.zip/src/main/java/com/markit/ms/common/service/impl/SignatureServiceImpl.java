package com.markit.ms.common.service.impl;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

import com.google.common.collect.Maps;
import com.markit.fileutil.common.domain.MCFile;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.kyc.esign.PdfSigner;
import com.markit.kyc.esign.util.EsignDocUtil;
import com.markit.kyc.security.service.userxs.ServiceUserSessionManager;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.dao.IUserDao;
import com.markit.ms.common.dao.SignatureServiceDao;
import com.markit.ms.common.service.IFileService;
import com.markit.ms.common.service.IReportGenerator;
import com.markit.ms.common.service.ISignatureService;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.dto.McpmEntityUpdate;
import com.markit.ms.rfa.util.PDFContextGenerator;

@Service
public class SignatureServiceImpl implements ISignatureService {

	private static final Logger logger = LoggerFactory.getLogger(SignatureServiceImpl.class.getName());
	@Autowired
	private SignatureServiceDao signatureServiceDao;
	@Autowired
	private PdfSigner pdfSigner;
	@Autowired
	private IFileService fileService;
	@Autowired
	private IReportGenerator reportService;
	@Autowired
	private IUserDao userDao;

	@Resource
	IReportGenerator reportGenerator;

	@Resource(name = "rsServiceUserSessionManager")
	private ServiceUserSessionManager serviceUserSessionManager;

	@Value("${mcpm.entityUpdateUrl}")
	String mcpmEntityUpdateUrl;

	public void setFileService(IFileService fileService) {
		this.fileService = fileService;
	}

	public void setPdfSigner(PdfSigner pdfSigner) {
		this.pdfSigner = pdfSigner;
	}

	@Override
	@Transactional
	public Signature saveSignature(Signature signature, Long originalFileId, String newFilePrefix, String loginName,Long loginTime, byte[] content) throws Exception {

		logger.info("Saving signature in DB");
		Signature signatureObject = signatureServiceDao.saveSignature(signature,loginTime);

		if (signature.getCompanyType().equalsIgnoreCase("BS")) {
			List<McpmEntityUpdate> mcpmEntitiesDetail = signatureServiceDao.getEntitiesForUpdate(signature.getAmendmentId());
			if (mcpmEntitiesDetail != null && mcpmEntitiesDetail.size() > 0 && mcpmEntitiesDetail.get(0).getEntityId() != null
					&& mcpmEntitiesDetail.get(0).getEntityId() != 0L) {
				this.updateMcpmEntity(mcpmEntitiesDetail, signature.getCompanyId(), loginName);
			}
		}

		logger.info("Saved signature in DB");
		PDFContext pdfContext;
		logger.info("Preparing PDF");
		if (!signature.isSellSide())
			pdfContext = PDFContextGenerator.getBuySideEsignFrameContext();
		else
			pdfContext = PDFContextGenerator.getSellSideEsignFrameContext();
		pdfContext.setIgnoreBuySideSignaturePlaceholder(true);
		pdfContext.setIgnoreSellSideSignaturePlaceholder(true);
		
		byte[] signedPDF = null;
		
		if("E_SIGN".equals(signature.getSignType())){
			signedPDF = reportGenerator.getPDFContentSychronous(signature.getAmendmentId(), pdfContext);// fileService.getFile(originalFileId,
		}else if ("W_SIGN".equals(signature.getSignType())){
			signedPDF = content;
		}
		
																											// signature.getCompanyId());
		logger.info("PDF prepared");
		String digest = EsignDocUtil.getDigest(signedPDF);
		logger.info("Digest created");
		int signedPDFPages = EsignDocUtil.getNoOfPages(signedPDF);
		logger.info("PDF prepared");
		logger.info("Saving secured file");
		MCFile signedMcFile = fileService.saveFile(signedPDF, signature.getCompanyId(), newFilePrefix, signature.getUserId());
		logger.info("Saved secured file");
		logger.info("Updating hashcode and file");
		signatureServiceDao.updateFileIdAndHashCode(signedMcFile.getFileId(), signatureObject.getId(), digest, signedPDFPages);
		logger.info("Updated hashcode and file");
		return signatureObject;
	}

	public Map<String, String> prepareAuditDetailsMap(Signature signature) {

		Map<String, String> auditDetailsMap = new HashMap<String, String>();
		if (signature.getName() != null)
			auditDetailsMap.put("Name", signature.getName());
		if (signature.getUserId() != null)
			auditDetailsMap.put("UserID", signature.getUserId() + "");

		if (signature.getTitle() != null)
			auditDetailsMap.put("Title", signature.getTitle());
		auditDetailsMap.put("CompanyID", signature.getCompanyId() + "");
		if (signature.getContactNumber() != null)
			auditDetailsMap.put("ContactNumber", signature.getContactNumber());
		if (signature.getEmail() != null)
			auditDetailsMap.put("ContactEmail", signature.getEmail());
		if (signature.getSignatureDate() != null)
			auditDetailsMap.put("SignDate", signature.getSignatureDate().toString());
		if (signature.getSignature() != null)
			auditDetailsMap.put("Signature", signature.getSignature());
		auditDetailsMap.put("SignatureStyle", signature.getSignStyle() + "");
		return auditDetailsMap;
	}

	@Override
	public Signature getSignature(Long id) throws Exception {
		return signatureServiceDao.getSignature(id);
	}

	@Override
	public void freezeSellSideSignatures(Long amendmentId) {
		signatureServiceDao.freezeSellSideSignatures(amendmentId);
	}

	private void updateMcpmEntity(List<McpmEntityUpdate> mcpmEntitiesDetail, Long companyId, String email) {
		Map<String, Object> uriParams = Maps.newHashMap();
		uriParams.put("company", companyId);
		HttpStatus httpStatus = null;
		for (McpmEntityUpdate entity : mcpmEntitiesDetail) {
			try {								
				uriParams.put("entity", entity.getEntityId());
				entity.setUpdatedBy(email);

				String auth = serviceUserSessionManager.validateSession().getOwnerName() + ":"
						+ serviceUserSessionManager.validateSession().getTicketId().getBytes();
				byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
				String authHeader = "Basic " + new String(encodedAuth);
				
				RequestEntity<McpmEntityUpdate> requestEntity = RequestEntity.put(new UriTemplate(mcpmEntityUpdateUrl).expand(uriParams))
						.header(HttpHeaders.AUTHORIZATION, WebUtils.createBasicAuthHeaderValue(serviceUserSessionManager.validateSession().getOwnerName(), serviceUserSessionManager.validateSession().getTicketId().getBytes()))
						.contentType(org.springframework.http.MediaType.APPLICATION_JSON).body(entity);

				RestTemplate restTemplate = new RestTemplate();
				httpStatus = restTemplate.exchange(requestEntity, String.class).getStatusCode();

				logger.error(httpStatus.toString());
			} catch (Exception e) {
				logger.error("Updating entity " + entity.getEntityId() + " failed.");
			}
		}
	}

}
