package com.markit.ms.common.task;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.ms.common.bean.EmailMaster;
import com.markit.ms.common.service.EmailService;
import com.markit.ms.common.util.EmailTemplateConstants.EmailStatus;;

/**
 * This class gets email master data sends mail
 * 
 * @since RFA5.0
 *
 */
public class SendEmailTask implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(SendEmailTask.class);
	
	volatile List<Long> mailIds;
	volatile Long templateId;

	EmailService emailService;

	public SendEmailTask(EmailService emailService, List<Long> mailIds, Long templateId) {
		this.mailIds = mailIds;
		this.templateId = templateId;
		this.emailService=emailService;
	}

	@Override
	public void run() {

		String template = null;
		if (templateId != null) {
			template = emailService.getTemplate(templateId);
		}

		List<EmailMaster> emails = emailService.getEmail(mailIds);
		EmailMaster email;
		for (int i = 0; i < emails.size(); i++) {
			email = emails.get(i);
			email.setTemplateContent(template);

			try {
				emailService.sendMail(email);
				email.setStatus(EmailStatus.SENT.status);
				emailService.updateMailStatus(email);
				LOGGER.debug("mail successfully send : templateId::mailid : "+templateId + "::" +email.getId());
			} catch (Exception exp) {
				email.setRetries(email.getRetries() + 1);
				email.setStatus(EmailStatus.FAILED.status);
				emailService.updateMailStatus(email);
				LOGGER.error("error sending mail : templateId::mailid : "+templateId + "::" +email.getId());
			}

		}
	}

}
