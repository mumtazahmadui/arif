package com.markit.ms.common.service;

import java.util.List;
import java.util.Map;

import com.markit.ms.rfa.bean.AmendmentLetter;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.bean.PartyBEntity;
import com.markit.ms.rfa.bean.enumeration.BulkActionValidationType;

public interface IReportGenerator {

	public byte[] getPDFContent(Long amendmentId, PDFContext pdfContext) throws Exception;

	public byte[] getValidationErrorPDFContent(Map<String, List<PartyBEntity>> addPartyBErrorMap
			, Map<String, List<PartyBEntity>> removePartyBErrorMap, Map<String, List<PartyBEntity>> modifiedPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveAdditionPartyBErrorMap, Map<String, List<PartyBEntity>> sleeveRemovalPartyBErrorMap
			, Map<String, List<PartyBEntity>> sleeveExistsOnActiveTabErrorMap, Map<String, List<PartyBEntity>> sleeveParentNotOnActiveTabErrorMap
			, Map<String, List<PartyBEntity>> sleevesInProgressErrorMap
			, List<PartyBEntity> rejectedRecalledPartybList, Map<Long, AmendmentLetter> additionPlaceholderErrorList
			, Map<Long, AmendmentLetter> removalPlaceholderErrorList, Map<Long, AmendmentLetter> modificationPlaceholderErrorMap
			, Map<String, String> letterTemplateMap) throws Exception;

	byte[] appendEmptyPDFDocumentTo(byte[] originalDocument) throws Exception;

	byte[] getPDFContentSychronous(Long amendmentId, PDFContext pdfContext)
			throws Exception;
	
	byte[] getNextStepValidationErrorPDFContent(List<AmendmentLetter> invalidAmendmentLetters, BulkActionValidationType validationType);

	byte[] generateErrorPDFContent(String errorMessage, List<AmendmentLetter> invalidAmendmentLetters, BulkActionValidationType validationType);
}
