package com.markit.ms.common.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.User;
import com.markit.ms.common.dao.IUserDao;

@Repository
public class UserDaoImpl extends BaseDAOImpl implements IUserDao {
	
	@Value("${GET_USER}")
	private String GET_USER;
	
	@Value("${GET_COMPANYID_BY_ENTITYID}")
	private String GET_COMPANYID_BY_ENTITYID;
	
	@Value("${GET_ALL_USERS_FOR_COMPANY_BY_PERMISSION_NAME}")
	private String GET_ALL_USERS_FOR_COMPANY_BY_PERMISSION_NAME;
	
	@Value("${GET_ALL_USERS_FOR_COMPANY_BY_PERMISSION_NAME_WITH_PAGINATION}")
	private String GET_ALL_USERS_FOR_COMPANY_BY_PERMISSION_NAME_WITH_PAGINATION;
	
	@Value("${GET_USERS_OF_COMPANY_BY_PERMISSION_NAMES}")
	private String GET_USERS_OF_COMPANY_BY_PERMISSION_NAMES;
	
	@Value("${GET_USER_BY_IDS}")
	private String GET_USER_BY_IDS;
	
	@Value("${GET_OTHERUSERS_OF_COMPANY_BY_PERMISSION_NAMES}")
	private String GET_OTHERUSERS_OF_COMPANY_BY_PERMISSION_NAMES;
	
	@Override
	public User getUser(long id) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("id", id);
		
		User user = null;
		try{
			user = namedParameterJdbcTemplate.queryForObject(GET_USER, paramSource, new UserMapper());
		} catch(EmptyResultDataAccessException error){
			user = null;
		}
		return user;
	}
	
	private static final class UserMapper implements RowMapper<User> {
		@Override
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User user = new User();
			user.setUserId(rs.getLong("uid"));
			user.setCompanyId(rs.getLong("companyid"));
			user.setCompanyName(rs.getString("companyname"));
			user.setUserName(rs.getString("username"));
			user.setPhone(rs.getString("phone"));
			user.setEmail(rs.getString("email"));
			user.setTitle(rs.getString("title"));
			user.setCompanyType(rs.getString("type"));
			user.setFullName(rs.getString("fullName"));
			return user;
		}
	}
	
	private static final class BasicUserMapper implements RowMapper<User> {
		@Override
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {
			User user = new User();
			user.setUserId(rs.getLong("uid"));
			user.setUserName(rs.getString("username"));
			user.setEmail(rs.getString("email"));
			user.setFname(rs.getString("fname"));
			return user;
		}
	}
	
	@Override
	public List<String> getAllUsersForCompanyByPermissionName(Long companyId, List<String> permissionName) {
		SqlParameterSource paramSource = null;
		paramSource = new MapSqlParameterSource().addValue("companyid", companyId).addValue("pname", permissionName);
		List<String> emailList = namedParameterJdbcTemplate.queryForList(GET_ALL_USERS_FOR_COMPANY_BY_PERMISSION_NAME, paramSource, String.class);
		return emailList;
	}
	
	@Override
	public List<User> getAllUsersForCompanyByPermissionNameWithPagination(
			Long companyId, List<String> permissionName, Long fromRow, Long pageSize) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
			.addValue("companyid", companyId)
			.addValue("offset", fromRow)
			.addValue("page_size", pageSize)
			.addValue("pname", permissionName);
		List<User> emailList = namedParameterJdbcTemplate.query(
				GET_ALL_USERS_FOR_COMPANY_BY_PERMISSION_NAME_WITH_PAGINATION, paramSource, new BasicUserMapper());
		return emailList;
	}

	@Override
	public List<User> getUsersOfCompanyByPermissionName(Long companyId, List<String> permissions) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("companyid", companyId)
				.addValue("pname", permissions);
			List<User> emailList = namedParameterJdbcTemplate.query(
					GET_USERS_OF_COMPANY_BY_PERMISSION_NAMES, paramSource, new BasicUserMapper());
			return emailList;
		}

	@Override
	public List<User> getUsersByIds(List<Long> userIds) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("ids", userIds);
		return namedParameterJdbcTemplate.query(
				GET_USER_BY_IDS, paramSource, new BasicUserMapper());
	}
	
	@Override
	public List<User> getOtherUsersOfCompanyByPermissionName(Long companyId, List<String> permissions, Long userId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("userId", userId)
				.addValue("companyid", companyId)
				.addValue("pname", permissions);
		return namedParameterJdbcTemplate.query(
					GET_OTHERUSERS_OF_COMPANY_BY_PERMISSION_NAMES, paramSource, new BasicUserMapper());
	}
}
