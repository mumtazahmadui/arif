package com.markit.ms.common.dao;

import com.markit.ms.common.bean.McFile;

public interface IFileDao {
public McFile getFile(Long fileId);
public McFile saveFile(McFile file);
}
