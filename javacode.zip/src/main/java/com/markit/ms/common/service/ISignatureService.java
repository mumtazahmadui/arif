package com.markit.ms.common.service;

import java.util.Map;

import com.markit.ms.common.bean.Signature;

public interface ISignatureService {

	Signature saveSignature(Signature signature, Long originalFileId,
			String newFilePrefix, String loginName,Long loginTime, byte[] content) throws Exception;
	Signature getSignature(Long id) throws Exception;
	public  Map<String, String> prepareAuditDetailsMap(Signature signature);
	void freezeSellSideSignatures(Long amendmentId);
}
