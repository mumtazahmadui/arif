package com.markit.ms.common.dao.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.markit.ms.common.bean.Lookup;

public class LookupRowMapper implements RowMapper<Lookup> {
	
	public Lookup mapRow(ResultSet rs, int rowNum) throws SQLException {
		Lookup lookup = new Lookup();
		lookup.setId(rs.getLong("id"));
		lookup.setValue(rs.getString("value"));
		return lookup;
	}
}
