package com.markit.ms.common.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.markit.ms.common.service.EmailProcessService;

/**
 * This class provides method implementation for mail send process
 * 
 * @since RFA5.0
 *
 */
@Service
public class EmailProcessServiceImpl implements EmailProcessService {

	private class RFAMimeMessagePreparator implements MimeMessagePreparator {

		private final SimpleMailMessage msg;
		private final String bodyTemplate;
		private final Map<String, Object> bodyVar;
		private final boolean isHtml;

		public RFAMimeMessagePreparator(SimpleMailMessage msg, String bodyTemplate, Map<String, Object> bodyVar) {
			this.msg = msg;
			this.bodyTemplate = bodyTemplate;
			this.bodyVar = bodyVar;
			isHtml = true;
		}

		@Override
		public void prepare(MimeMessage mimeMessage) throws Exception {
			final MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true);
			message.setTo(msg.getTo());
			message.setFrom(msg.getFrom());

			if (msg.getReplyTo() != null)
				message.setReplyTo(msg.getReplyTo());
			else
				message.setReplyTo(msg.getFrom());

			if (msg.getCc() != null && msg.getCc().length > 0) {
				message.setCc(msg.getCc());
			}
			if (msg.getBcc() != null && msg.getBcc().length > 0) {
				message.setBcc(msg.getBcc());
			}

			message.setSubject(msg.getSubject());

			String originalBody = applyTemplate(bodyTemplate, bodyVar, isHtml);

			message.setText(originalBody, isHtml);
		}
	}

	private static final Logger logger = LoggerFactory.getLogger(EmailProcessService.class);
	private static final String PARAM_TO_ESCAPE_PATTERN = "^(([^<>]*[>][^<]*)|([^<>]*[<][^>]*))$";

	@Autowired
	private VelocityEngine velocityEngineResourceContent;
	@Autowired
	private JavaMailSender mailSender;

	private static final String ENCODING_UTF8 = "UTF-8";

	private static final ObjectMapper objectMapper = new ObjectMapper() {
		{
			configure(JsonGenerator.Feature.QUOTE_FIELD_NAMES, false);
			configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
			configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
		}
	};

	/**
	 * Sends e-mail using Velocity template for the body and the properties passed
	 * in as Velocity variables.
	 */
	@Override
	public void sendEmail(SimpleMailMessage simpleMailMessage, String bodyTemplate, Map<String, Object> bodyVariables)
			throws MailException {
		try {
			logger.info("Starting send email");
			mailSender.send(new RFAMimeMessagePreparator(simpleMailMessage, bodyTemplate, bodyVariables));
			logger.info("Sent - final");
		} catch (final MailException e) {
			logger.error("Exception in sending mail", e);
			throw e;
		}
	}

	@Override
	public String getPreview(String bodyTemplate, Map<String, Object> bodyVariables) {
		return applyTemplate(bodyTemplate, bodyVariables, true);
	}

	private String applyTemplate(String template, Map<String, Object> variables, boolean escapeHtml) {
		variables.put("objectMapper", objectMapper);
		Map<String, Object> finalVariables = variables;
		if (escapeHtml) {
			finalVariables = escapeHtmlInVariables(variables);
		}

		/**
		 * replace each template placeholder with provided arguments
		 */
		return VelocityEngineUtils.mergeTemplateIntoString(velocityEngineResourceContent, template, ENCODING_UTF8,
				finalVariables);
	}

	/**
	 * Escapes HTML in variables only if they contain '<' or '>' and not both. This
	 * prevents breaking result HTML.
	 */
	private static Map<String, Object> escapeHtmlInVariables(Map<String, Object> variables) {

		return new HashMap<>(Maps.transformValues(variables, input -> {
			if ((input instanceof String) && (((String) input).matches(PARAM_TO_ESCAPE_PATTERN))) {
				return StringEscapeUtils.escapeHtml4((String) input);
			} else {
				return input;
			}
		}));
	}
}
