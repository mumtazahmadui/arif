package com.markit.ms.common.service;

import com.markit.ms.rfa.bean.PDFContext;


public interface IExhibitPDFPageGenerator {
	public byte[] generateExhibitPDF(Long exhibitId, PDFContext context) throws Exception;
}
