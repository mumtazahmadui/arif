package com.markit.ms.common.util;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.web.util.WebUtils;
import com.markit.ms.rfa.bean.TemplateField;

public class CommonDownloadUtil {

private static final Logger LOGGER = LoggerFactory.getLogger(CommonDownloadUtil.class);

	private static final String EMPTY = "";

	private static final String NEW_LINE = "\n";

	private static final String CARRIAGE_RETURN = "\r";

	private static final String ROW_KEY = "ROW_KEY";

	private static final String COLUMN_KEY = "COLUMN_KEY";

	private static final String COLUMN_VALUE = "COLUMN_VALUE";
	
	private static final String SHEET_PASSWORD = "EXHIBIT_SHEET";

	private static final String DATE_FIELD = "Report Generated On";
	
	public static final String CONTENT_TYPE_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	
	public static final List<String> PARTYB_FIELDS = new ArrayList<String>(Arrays.asList("Party B True Legal Name", "Party B Client Identifier", "Party B Pre-LEI/LEI", "Action"));
	public static final List<String> COMMON_FIELDS = new ArrayList<String>(Arrays.asList("Agreement Type", "Investment Manager", "Masterlist Identifier", "Party A True Legal Name"));

	public static void exportGridToExcel(Map<String, List<Grid.Row>> dataRowMap, Map<String, List<Grid.Row>> commonInfoRowMap
			, Integer commonInfoIndex, Integer headerRowIndex, String sheetName, String fileName, InputStream inputStream
			, Map<String, Map<String, TemplateField>> fieldInfoRfaIdMap, HttpServletResponse response) {
		Workbook workbook = createWorkbook(dataRowMap, commonInfoRowMap, commonInfoIndex, headerRowIndex, sheetName, inputStream, fieldInfoRfaIdMap);
		// Write the workbook to the response output stream
		response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

		String filename = new StringBuilder(fileName).append(".xlsx").toString();
		response.setHeader("Content-Disposition", "attachment; filename=" + getAttachmentFileName(filename));
		WebUtils.setCacheControlHeaders(response);
		try (ServletOutputStream outStream = response.getOutputStream()) {
			workbook.write(outStream);
		} catch (IOException e) {
			LOGGER.error("Exception caught during File download!", e);
		}
	}

	public static byte[] exportGridToExcel(Map<String, List<Grid.Row>> dataRowMap, Map<String, List<Grid.Row>> commonInfoRowMap,
			Integer commonInfoIndex, Integer headerRowIndex, String sheetName, String fileName, InputStream inputStream,
			Map<String, Map<String, TemplateField>> fieldIdInfoRfaIdMap) {
		Workbook workbook = createWorkbook(dataRowMap, commonInfoRowMap, commonInfoIndex, headerRowIndex, sheetName, inputStream, fieldIdInfoRfaIdMap);
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		byte[] bytes;
		try {
			workbook.write(bos);
			bytes = bos.toByteArray();
		} catch (IOException ioe) {
			throw new RuntimeException("IOException while writing error file to bytes array");
		} finally {
			try {
				bos.close();
			} catch (IOException e) {
				IOUtils.closeQuietly(bos);
			}
		}
		return bytes;
	}
	
	/*private static Workbook createWorkbook(Map<String, List<Grid.Row>> dataRowMap, Map<String, List<Grid.Row>> commonInfoRowMap,
			Integer commonInfoIndex, Integer headerRowIndex, String sheetName, InputStream inputStream, Map<String, Map<String, TemplateField>> fieldIdInfoRfaIdMap) {
		Workbook workbook;
		try {
			workbook = new XSSFWorkbook(inputStream);
		} catch (IOException e) {
			throw new IllegalArgumentException("Exception while loading template" + e);
		}
		Sheet sheet = workbook.getSheetAt(0);
		sheet.protectSheet(SHEET_PASSWORD);
		workbook.setSheetName(0, sheetName);
		
		Set<String> dataKey = dataRowMap.keySet();
		for (String key : dataKey) {
			Integer commonIdsDynamicCount = 0;
			Map<String, TemplateField> fieldIdInfoMap  = fieldIdInfoRfaIdMap.get(key);
			Map<String, TemplateField> fieldIdInfoMapDup = new HashMap<>(fieldIdInfoMap);
			fieldIdInfoMapDup.keySet().retainAll(COMMON_FIELDS);
			
			for(String fieldId: fieldIdInfoMapDup.keySet()){
				if(fieldIdInfoMapDup.get(fieldId).getFieldVisibility()==1)
					commonIdsDynamicCount++;
			}
			List<Grid.Row> dataRowList = dataRowMap.get(key);
			List<Grid.Row> commonInfoRowList = commonInfoRowMap.get(key);
			Integer newIndex = exportGridToExcel(workbook, sheet, dataRowList, commonInfoRowList
					, commonInfoIndex, headerRowIndex, fieldIdInfoMap);
			commonInfoIndex = newIndex + 3;
			headerRowIndex = newIndex + 6 + commonIdsDynamicCount;
		}
		return workbook;
	}*/
	
	private static Workbook createWorkbook(Map<String, List<Grid.Row>> dataRowMap, Map<String, List<Grid.Row>> commonInfoRowMap,
			Integer commonInfoIndex, Integer headerRowIndex, String sheetName, InputStream inputStream, Map<String, Map<String, TemplateField>> fieldIdInfoRfaIdMap) {
		Workbook workbook;
		Integer newIndex  = 0;
		
		try {
			workbook = new XSSFWorkbook(inputStream);
		} catch (IOException e) {
			throw new IllegalArgumentException("Exception while loading template" + e);
		}
		Sheet sheet = workbook.getSheetAt(0);
		sheet.protectSheet(SHEET_PASSWORD);
		workbook.setSheetName(0, sheetName);
		
		Set<String> dataKey = dataRowMap.keySet();
		for (String key : dataKey) {
			Integer commonIdsDynamicCount = 0;
			Map<String, TemplateField> fieldIdInfoMap  = fieldIdInfoRfaIdMap.get(key);
			Map<String, TemplateField> fieldIdInfoMapDup = new HashMap<>(fieldIdInfoMap);
			fieldIdInfoMapDup.keySet().retainAll(COMMON_FIELDS);
			
			for(String fieldId: fieldIdInfoMapDup.keySet()){
				if(fieldIdInfoMapDup.get(fieldId).getFieldVisibility()==1)
					commonIdsDynamicCount++;
			}
			List<Grid.Row> dataRowList = dataRowMap.get(key);
			List<Grid.Row> commonInfoRowList = commonInfoRowMap.get(key);
			
			headerRowIndex = newIndex + 6 + commonIdsDynamicCount; 
			newIndex = exportGridToExcel(workbook, sheet, dataRowList, commonInfoRowList
					, commonInfoIndex, headerRowIndex, fieldIdInfoMap);
			commonInfoIndex = newIndex + 3;
			
		}
		return workbook;
	}

	private static Integer exportGridToExcel(Workbook workbook, Sheet sheet, List<Grid.Row> dataRowList
			, List<Grid.Row> commonInfoRowList, Integer commonInfoIndex, Integer headerRowIndex
			, Map<String, TemplateField> fieldIdInfoMap) {

		String columnLabel = null;
		Integer columnVisibility = null;
		Map<String, Integer> rowKeyMap = new HashMap<>();
		Map<String, Integer> columnKeyMap = new HashMap<>();
		Integer colIndex = 0;
		Integer rowIndex = headerRowIndex + 1;
		Integer newIndex = headerRowIndex;

		Row firstRow = sheet.createRow(0);
		Cell firstCell = firstRow.createCell(0);
		firstCell.setCellValue("Bulk Download Date ");
		Cell secondCell = firstRow.createCell(1);
		secondCell.setCellValue(getFormattedCurrentDate("dd-MMM-YYYY hh:mm:ss zzz"));
		
		Row headerRow = sheet.createRow(headerRowIndex);
		newIndex++;
		
		Font font = workbook.createFont();
		font.setBoldweight(Font.BOLDWEIGHT_BOLD);
		
		XSSFCellStyle headerStyle = getHeaderColumnStyle(workbook, font);
		
		XSSFCellStyle commonInfoColumnStyle = getCommonInfoColumnStyle(workbook, font);
		firstCell.setCellStyle(commonInfoColumnStyle);
		
		CellStyle dataColumnStyle = getDataColumnStyle(workbook);
		secondCell.setCellStyle(dataColumnStyle);
		
		CellStyle exhibitDataColumnStyle = getExhibitDataColumnStyle(workbook);
		
		if(null != commonInfoRowList && commonInfoRowList.size() > 0) {
			Set<String> columns = commonInfoRowList.get(0).getColumns();
			int i = 0;
			for (String column : columns) {
				Row commonInfoRow = sheet.getRow(i + commonInfoIndex);
				if(null == commonInfoRow) {
					commonInfoRow = sheet.createRow(i + commonInfoIndex);
				}
				Cell commonInfoCellName = commonInfoRow.createCell(0);
				Cell commonInfoCellValue = commonInfoRow.createCell(1);
				String columnValue = commonInfoRowList.get(0).getEntryValue(column);
				if (DATE_FIELD.equalsIgnoreCase(column)) {
					columnValue = getFormattedCurrentDate("dd-MMM-YYYY");
				}
				
				if(fieldIdInfoMap.get(column)!=null){
					columnLabel = fieldIdInfoMap.get(column).getFieldLabel();
					columnVisibility = fieldIdInfoMap.get(column).getFieldVisibility();
				}
				if(columnVisibility==1){
					commonInfoCellName.setCellValue(columnLabel);
					commonInfoCellName.setCellStyle(commonInfoColumnStyle);
					commonInfoCellValue.setCellValue(columnValue);
					commonInfoCellValue.setCellStyle(dataColumnStyle);
					columnLabel = null;
					columnVisibility = -1;
					i++;
				}
				
			}
		}
		
		int columnCount = 0;
		for (Grid.Row dataGridRow : dataRowList) {
			Map<String, String> data = dataGridRow.getData();

			String rowKey = data.get(ROW_KEY);
			String columnKey = data.get(COLUMN_KEY);
			String columnValue = data.get(COLUMN_VALUE);

			if (null != rowKey && null == rowKeyMap.get(rowKey)) {
				Row dataRow = sheet.createRow(rowIndex);
				newIndex++;
				rowKeyMap.put(rowKey, rowIndex);
				colIndex = writeColumnValues(columnKeyMap, colIndex, headerRow
						, headerStyle, dataColumnStyle, data, dataRow, fieldIdInfoMap);
				rowIndex++;
				columnCount++;
			} else if (null == rowKey) {
				Row dataRow = sheet.createRow(rowIndex);
				newIndex++;
				colIndex = writeColumnValues(columnKeyMap, colIndex, headerRow
						, headerStyle, dataColumnStyle, data, dataRow, fieldIdInfoMap);
				rowIndex++;
				columnCount++;
			}
			if (null != columnKey && null == columnKeyMap.get(columnKey)) {
				columnKeyMap.put(columnKey, colIndex);
				Cell cell = headerRow.createCell(colIndex);
				cell.setCellValue(columnKey);
				cell.setCellStyle(headerStyle);
				colIndex++;
				columnCount++;
			}
			
			if(null != columnKey) {
				Integer currentRowIndex = rowKeyMap.get(rowKey);
				Integer currentColumnIndex = columnKeyMap.get(columnKey);
				
				Row row = sheet.getRow(currentRowIndex);
				Cell cell = row.createCell(currentColumnIndex);
				cell.setCellValue(columnValue);
				cell.setCellStyle(exhibitDataColumnStyle);
			}
		}
		
		for(int i=0; i<columnCount; i++) {
			workbook.getSheetAt(0).setColumnWidth(i, 7000);
		}
		
		return newIndex;
	}

	private static CellStyle getDataColumnStyle(Workbook workbook) {
		CellStyle dataColumnStyle = workbook.createCellStyle();
		dataColumnStyle.setWrapText(true);
		dataColumnStyle.setBorderBottom(CellStyle.BORDER_THIN);
		dataColumnStyle.setBorderTop(CellStyle.BORDER_THIN);
		dataColumnStyle.setBorderRight(CellStyle.BORDER_THIN);
		dataColumnStyle.setBorderLeft(CellStyle.BORDER_THIN);
		dataColumnStyle.setLocked(true);
		return dataColumnStyle;
	}
	
	private static CellStyle getExhibitDataColumnStyle(Workbook workbook) {
		CellStyle dataColumnStyle = workbook.createCellStyle();
		dataColumnStyle.setWrapText(true);
		dataColumnStyle.setBorderBottom(CellStyle.BORDER_THIN);
		dataColumnStyle.setBorderTop(CellStyle.BORDER_THIN);
		dataColumnStyle.setBorderRight(CellStyle.BORDER_THIN);
		dataColumnStyle.setBorderLeft(CellStyle.BORDER_THIN);
		dataColumnStyle.setLocked(false);
		return dataColumnStyle;
	}

	private static XSSFCellStyle getCommonInfoColumnStyle(Workbook workbook, Font font) {
		XSSFCellStyle commonInfoColumnStyle = (XSSFCellStyle) workbook.createCellStyle();
		commonInfoColumnStyle.setFont(font);
		commonInfoColumnStyle.setWrapText(true);
		commonInfoColumnStyle.setFillForegroundColor(new XSSFColor(Color.YELLOW));
		commonInfoColumnStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		commonInfoColumnStyle.setBorderBottom(CellStyle.BORDER_THIN);
		commonInfoColumnStyle.setBorderTop(CellStyle.BORDER_THIN);
		commonInfoColumnStyle.setBorderRight(CellStyle.BORDER_THIN);
		commonInfoColumnStyle.setBorderLeft(CellStyle.BORDER_THIN);
		commonInfoColumnStyle.setLocked(true);
		return commonInfoColumnStyle;
	}

	private static XSSFCellStyle getHeaderColumnStyle(Workbook workbook, Font font) {
		XSSFCellStyle headerStyle = (XSSFCellStyle) workbook.createCellStyle();
		headerStyle.setAlignment(CellStyle.ALIGN_CENTER);
		headerStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		headerStyle.setFont(font);
		headerStyle.setWrapText(true);
		headerStyle.setFillForegroundColor(new XSSFColor(Color.LIGHT_GRAY));
		headerStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
		headerStyle.setBorderBottom(CellStyle.BORDER_THIN);
		headerStyle.setBorderTop(CellStyle.BORDER_THIN);
		headerStyle.setBorderRight(CellStyle.BORDER_THIN);
		headerStyle.setBorderLeft(CellStyle.BORDER_THIN);
		headerStyle.setLocked(true);
		return headerStyle;
	}

	private static Integer writeColumnValues(Map<String, Integer> columnKeyMap, Integer colIndex
			, Row headerRow, CellStyle headerCellStyle, CellStyle dataColumnStyle, Map<String, String> data
			, Row dataRow, Map<String, TemplateField> fieldIdInfoMap) {
		int i = 0;
		
		Map<String, TemplateField> fieldIdInfoMapDup = new LinkedHashMap<>();
		fieldIdInfoMapDup.putAll(fieldIdInfoMap);
		fieldIdInfoMapDup.keySet().retainAll(PARTYB_FIELDS);		
		fieldIdInfoMapDup.put("Action", new TemplateField("Action", "Action", 1, null));
		
		Set<String> idSet = fieldIdInfoMapDup.keySet();
		
		for(String id: idSet){
			if (data.containsKey(id) && fieldIdInfoMapDup.get(id).getFieldVisibility() == 1) {
				if (null == columnKeyMap.get(id)) {
					String formattedColumnName = fieldIdInfoMapDup.get(id).getFieldLabel();
					if(null != formattedColumnName) {
						columnKeyMap.put(id, colIndex);
						Cell cell = headerRow.createCell(colIndex);
						cell.setCellValue(formattedColumnName);
						cell.setCellStyle(headerCellStyle);
						colIndex++;
					}
				}
				Cell cell = dataRow.createCell(i);
				cell.setCellValue(data.get(id));
				cell.setCellStyle(dataColumnStyle);
				i++;
			}
			
		}
		return colIndex;
	}
	
	public static String getFormattedCurrentDate(String format) {
		SimpleDateFormat df = new SimpleDateFormat(format);
		return df.format(new Date());
	}
	
	public static String getCellStringValue(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_BOOLEAN:
			return String.valueOf(cell.getBooleanCellValue());
		case Cell.CELL_TYPE_NUMERIC:
			return new DataFormatter().formatCellValue(cell);
		default:
			return removeLineBreaks(cell.getStringCellValue());
		}
	}

	public static String removeLineBreaks(String value) {
		return value != null ? value.trim().replaceAll(CARRIAGE_RETURN, EMPTY).replaceAll(NEW_LINE, EMPTY) : value;
	}

	private static String getAttachmentFileName(String filename) {
		if (filename != null && filename.matches(".*\\s+.*")) {
			return "\"" + filename + "\"";
		}
		return filename;
	}
}