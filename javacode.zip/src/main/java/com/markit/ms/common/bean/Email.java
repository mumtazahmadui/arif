package com.markit.ms.common.bean;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

/***
 * Holds the details for Email.
 * 
 * @since RFA5.0
 */
public class Email {

	private List<String> ccEmailId = new ArrayList<>();
	private List<String> bccEmailId = new ArrayList<>();
	
	private Map<String, Object> subTemplateArgsMap = new HashMap<>();
	private Map<String, Object> templateArgsMap = new HashMap<>();


	public List<String> getCcEmailId() {
		return ccEmailId;
	}

	public void setCcEmailId(List<String> ccEmailId) {
		this.ccEmailId = ccEmailId;
	}

	@JsonProperty("ccEmailId")
	public String getCcEmailIdString() {
		return String.join(",", ccEmailId);
	}

	public List<String> getBccEmailId() {
		if (bccEmailId == null) {
			bccEmailId = new ArrayList<>();
		}
		return bccEmailId;
	}

	@JsonProperty("bccEmailId")
	public String getBccEmailIdString() {
		return String.join(",", bccEmailId);
	}

	public void setBccEmailId(List<String> bccEmailId) {
		this.bccEmailId = bccEmailId;
	}

	/**
	 * 
	 * @return
	 * arguments for template
	 */
	public Map<String, Object> getTemplateArgsMap() {
		return templateArgsMap;
	}

	/**
	 * sets arguments to be provided in template
	 * @param templateArgsMap
	 */
	public void setTemplateArgsMap(Map<String, Object> templateArgsMap) {
		this.templateArgsMap = templateArgsMap;
	}
	
	/**
	 * 
	 * @return
	 * arguments for subject
	 */
	public Map<String, Object> getSubTemplateArgsMap() {
		return subTemplateArgsMap;
	}

	/**
	 * sets arguments to be provided in subject
	 * @param subTemplateArgsMap
	 */
	public void setSubTemplateArgsMap(Map<String, Object> subTemplateArgsMap) {
		this.subTemplateArgsMap = subTemplateArgsMap;
	}
}
