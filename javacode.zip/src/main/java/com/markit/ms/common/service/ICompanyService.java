package com.markit.ms.common.service;

public interface ICompanyService {
	public Long getCompanyIdByEntityId(Long entityId);
	public String getCompanyIdType(Long companyId);
}
