package com.markit.ms.common.model;

public class MasterAgreementSearchRequest extends CommonBaseSearchRequest
{
    private Boolean masterListLinked;

	public Boolean getMasterListLinked() {
		return masterListLinked;
	}

	public void setMasterListLinked(Boolean masterlistLinked) {
		this.masterListLinked = masterlistLinked;
	}
}
