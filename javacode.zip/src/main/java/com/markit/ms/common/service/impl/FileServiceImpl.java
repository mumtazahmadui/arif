package com.markit.ms.common.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.kyc.domain.document.File;
import com.markit.kyc.service.FileSystemService;
import com.markit.ms.common.bean.McFile;
import com.markit.ms.common.dao.IFileDao;
import com.markit.ms.common.service.IFileService;
import com.markit.fileutil.common.domain.FileDetails;
import com.markit.fileutil.common.domain.MCFile;
import com.markit.fileutil.file.service.IFileUtilService;
import com.markit.ms.rfa.exception.RFASystemException;
@Service("fileSystemService")
public class FileServiceImpl implements IFileService,FileSystemService {
	
	private static final String PDF_FILE = "pdf";
	@Autowired
	IFileDao fileDao;
	@Resource
	IFileUtilService fileUtil;
	private static final String FILE_PATH= "/opt/mdeapp/mc_files/";
	private static final String EXCLUDED = "[\\\\<>:\\*\\?\\|\"/]";	
	private static final Logger log = Logger.getLogger(FileServiceImpl.class.getName());
	
	@Override
	public byte[] getFile(Long fileId, Long companyId)  {
		FileDetails fileDetails = new FileDetails();
		fileDetails.setFileId(fileId);
		fileDetails.setCompanyId(companyId.toString());
		fileDetails.setFilePath(FILE_PATH);
		try {
		byte[] content = fileUtil.getFileContent(fileDetails);
		return content;
		} catch (Exception e) {
			throw new RFASystemException(e);
		}
	}
	
	@Override
	public MCFile saveFile(byte[] signedDocument, Long companyId, String newOriginalFilePrefix,Long userId) {
		try {
		newOriginalFilePrefix = newOriginalFilePrefix.contains("\\")?newOriginalFilePrefix.substring(newOriginalFilePrefix.lastIndexOf("\\")+1,newOriginalFilePrefix.length()):newOriginalFilePrefix;
		newOriginalFilePrefix = newOriginalFilePrefix.replaceAll(EXCLUDED, "");
		MCFile file = fileUtil.saveFile(newOriginalFilePrefix+ "." + PDF_FILE, signedDocument, companyId, userId);
		return file;
		} catch (Exception exception) {
			log.error("Error Saving File :" +exception.getStackTrace());
			throw new RFASystemException(exception);
		} 
	}
	
	@Override
	public MCFile saveFile(String fileName, byte[] file, Long companyId, Long userId) {
		try {
			MCFile mcFile = fileUtil.saveFile(fileName, file, companyId, userId);
			return mcFile;
		} catch (Exception exception) {
			log.error("Error Saving File :" +exception.getStackTrace());
			throw new RFASystemException(exception);
		} 
	}
		
	@Override
	public McFile getMcFile(Long fileId, Long companyId)  {
		McFile mcFile = fileDao.getFile(fileId);
		return mcFile;
	}

	@Override
	public long create(String folderPath, String fileName, String contentType, byte[] fileContent, Long createdBy, Map<String, String> fileProperties) {
		try {
			return fileUtil.saveFile(fileName, fileContent, Long.valueOf(fileProperties.get("companyId")), createdBy).getStoredFileId().longValue();
		} catch (NumberFormatException exception) {
			log.error("Error Saving File :" + exception.getStackTrace());
			throw new RFASystemException(exception);
		} catch (Exception exception) {
			log.error("Error Saving File :" + exception.getStackTrace());
			throw new RFASystemException(exception);
		}

	}

	@Override
	public void delete(File file) {
		throw new UnsupportedOperationException();
		
	}

	@Override
	public File retreive(long fileId) {
		throw new UnsupportedOperationException();
	}

	@Override
	public File update(File file) {
		throw new UnsupportedOperationException();
	}
}
