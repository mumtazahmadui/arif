package com.markit.ms.common.service.impl;

import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.markit.ms.common.service.IMcpmEmailService;

@Component
public class McpmEmailServiceImpl implements IMcpmEmailService {


	private final VelocityEngine velocityEngine;
	private final JavaMailSender mailSender;

	private static final String ENCODING_UTF8 = "UTF-8";

	@Autowired
	public McpmEmailServiceImpl(VelocityEngine velocityEngine, JavaMailSender mailSender) {
		this.velocityEngine = velocityEngine;
		this.mailSender = mailSender;
	}

	/**
	 * Sends email based on subject template and body template
	 * 
	 * @param msg
	 * @param subjectTemplate
	 * @param subjectVariables
	 * @param bodyTemplate
	 * @param bodyVariables
	 * @param isHtml
	 */
	public void sendEmail(final SimpleMailMessage msg, final String subjectTemplate, final Map<String, Object> subjectVariables,
			final String bodyTemplate, final Map<String, Object> bodyVariables, final boolean isHtml, final String ccEmail) throws Exception {

		try {
			MimeMessagePreparator preparator = new MimeMessagePreparator() {
				public void prepare(MimeMessage mimeMessage) throws Exception {
					MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
					message.setTo(msg.getTo());
					message.setFrom(msg.getFrom());
					if(null!=ccEmail) {
						message.addCc(ccEmail);
					}
					if(subjectTemplate != null){
						String subject = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, subjectTemplate, ENCODING_UTF8, subjectVariables);
						message.setSubject(StringUtils.substring(subject, 0, 255));
					}else{
						message.setSubject(msg.getSubject());
					}

					if(bodyTemplate == null){
						throw new Exception("Email body template can't be empty");
					}
					
					String body = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, bodyTemplate, ENCODING_UTF8, bodyVariables);

					message.setText(body, isHtml);
				}
			};

			mailSender.send(preparator);
		} catch (Exception e) {
			throw e;
		}
	}
}
