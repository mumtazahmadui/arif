package com.markit.ms.common.service;

import java.io.UnsupportedEncodingException;

import com.markit.ms.rfa.bean.NewExhibitResponse;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.placeholders.response.PartyBTableResponse;

public interface IPartyBPlaceHolderTableGenerator {

	public String getPartyBPlaceholderHTML(PartyBTableResponse partyBTableResponse, PDFContext pdfContext) throws UnsupportedEncodingException;
	public String getExhitHTML(NewExhibitResponse newExhibitResponse, PDFContext pdfContext) throws UnsupportedEncodingException;

}
