package com.markit.ms.common.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.MasterAgreementLookup;
import com.markit.ms.common.dao.IRfaLookupDao;
import com.markit.ms.rfa.bean.MasterlistValidatorBean;
import com.markit.ms.rfa.dao.rowmapper.MasterlistValidatorBeanRowMapper;
import com.markit.ms.rfa.util.CommonUtil;

@Repository
public class RfaLookupDaoImpl extends BaseDAOImpl implements IRfaLookupDao {

	@Value("${GET_EXHIBIT_COL_VALUE}")
	private String GET_EXHIBIT_COL_VALUE;

	@Value("${GET_MASTER_AGREEMENT_LOOKUP_DATA}")
	private String GET_MASTER_AGREEMENT_LOOKUP_DATA;

	@Value("${GET_MASTER_AGREEMENT_BY_DETAILS}")
	private String GET_MASTER_AGREEMENT_BY_DETAILS;

	@Override
	public List<MasterAgreementLookup> masterAgreementsLookupData(Long companyId, String brokerName, Date agreementDate,
			String agreementType, String additionalInfo) {

		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("companyId", companyId)
				.addValue("brokerName", brokerName).addValue("agreementDate", agreementDate)
				.addValue("agreementType", agreementType).addValue("additionalInfo", additionalInfo);

		List<Map<String, Object>> mAgreementData = namedParameterJdbcTemplate
				.queryForList(GET_MASTER_AGREEMENT_LOOKUP_DATA, paramSource);

		List<MasterAgreementLookup> masterAgreementLookupList = new ArrayList<MasterAgreementLookup>();
		for (Map<String, Object> mAgreement : mAgreementData) {
			MasterAgreementLookup lookup = new MasterAgreementLookup();
			lookup.setId(((BigDecimal) mAgreement.get("id")).longValue());
			lookup.setExternalPartyAName((String) mAgreement.get("external_partya_name"));
			lookup.setAgreementType((String) mAgreement.get("agreement_type"));
			lookup.setMasterAgreementDate((Date) mAgreement.get("agreement_date"));
			if (mAgreement.get("im_entity_id") != null)
				lookup.setImEntityId(((BigDecimal) mAgreement.get("im_entity_id")).longValue());
			lookup.setAdditionalInfo((String) mAgreement.get("additional_info"));
			if (mAgreement.get("entity_id") != null)
				lookup.setEntityId(((BigDecimal) mAgreement.get("entity_id")).longValue());
			if (mAgreement.get("master_agreement_id") != null)
				lookup.setMasterAgreementId(((BigDecimal) mAgreement.get("master_agreement_id")).longValue());
			masterAgreementLookupList.add(lookup);
		}
		return masterAgreementLookupList;
	}

	@Override
	public Map<String, String> getExhibitByPartBAndML(Long partyBEntityId, Long masterAgreementId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("entityId", partyBEntityId)
				.addValue("agreementId", masterAgreementId);

		List<Map<String, Object>> exhibitData = namedParameterJdbcTemplate.queryForList(GET_EXHIBIT_COL_VALUE,
				paramSource);

		Map<String, String> exhibitMap = new HashMap<String, String>();

		for (Map<String, Object> exhibit : exhibitData) {
			exhibitMap.put(exhibit.get("column_name").toString(), exhibit.get("value").toString());
		}

		return exhibitMap;
	}

	@Override
	public MasterlistValidatorBean getMasterAgreementByDetails(String partyATrueLegalName, String agreementType,
			Date agreementDateFormatted, String investmentManager, String mlIdentifier, Long companyId) {
		StringBuilder where = new StringBuilder();
		MapSqlParameterSource paramSource = new MapSqlParameterSource();
		paramSource.addValue("partyATrueLegalName", partyATrueLegalName);
		paramSource.addValue("agreementType", agreementType);
		paramSource.addValue("agreementDate", agreementDateFormatted);
		paramSource.addValue("investmentManager", investmentManager);
		paramSource.addValue("mlIdentifier", mlIdentifier);
		paramSource.addValue("companyId", companyId);
		List<MasterlistValidatorBean> masterlists = null;
		if (CommonUtil.isNotNull(investmentManager)) {
			where.append(" AND im.legal_name = :investmentManager");
		}
		if (CommonUtil.isNotNull(mlIdentifier)) {
			where.append(" AND masterlist_identifier = :mlIdentifier");
		}
		String query = GET_MASTER_AGREEMENT_BY_DETAILS.replace("#where", where);
		try {
			masterlists = namedParameterJdbcTemplate.query(query, paramSource, new MasterlistValidatorBeanRowMapper());
			if (masterlists.size() > 1 || masterlists.size() == 0) {
				return null;
			}
			return masterlists.get(0);
		} catch (EmptyResultDataAccessException error) {
			return null;
		}
	}

}
