package com.markit.ms.common.bean;

import java.util.Date;

public class EntitySortDetails {

	Long rfaId;
	Date date;
	public Long getRfaId() {
		return rfaId;
	}
	public void setRfaId(Long rfaId) {
		this.rfaId = rfaId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	
	
}
