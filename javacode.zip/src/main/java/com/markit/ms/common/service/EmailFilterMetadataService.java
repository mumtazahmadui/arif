package com.markit.ms.common.service;

import com.markit.ms.common.util.TemplateTypeEnum;

/**
 * 
 * This class provides method for filter criteria in database
 * 
 * @since RFA5.0
 */
public interface EmailFilterMetadataService {

	/**
	 * Inserts filter criteria in database
	 * @return
	 * The unique id which represents filter criteria
	 */
	Long generateFilterToken(Long loggedInUser, String event, String filterJson, TemplateTypeEnum templateType);

	/**
	 * 
	 * @param filterToken
	 * @return
	 * JSON string of filter criteria
	 */
	String getFiltersByFilterToken(Long filterToken);
	
	/**
	 * This method fetches the filter criteria json from filter token and deserialize the json
	 * @param <T> the type of the desired object
	 * @param filterToken unique id which represents filter criteria
	 * @param classOfT class of type T
	 * @return
	 * the object of type T
	 */
	<T> T getFilters(Long filterToken, Class<T> classOfT);

}
