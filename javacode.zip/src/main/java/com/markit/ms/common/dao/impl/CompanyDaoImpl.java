package com.markit.ms.common.dao.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.dao.ICompanyDao;
import com.markit.ms.rfa.dao.rowmapper.CompanyTypeRowMapper;

@Repository
public class CompanyDaoImpl extends BaseDAOImpl implements ICompanyDao {
	
	@Value("${GET_COMPANYID_BY_ENTITYID}")
	private String GET_COMPANYID_BY_ENTITYID;
	
	@Value("${GET_COMPANY_TYPE}")
	private String GET_COMPANY_TYPE;
	
	@Override
	public Long getCompanyIdByEntityId(Long entityId)
	{
		Long companyId = null;
		SqlParameterSource paramSource = null;
		paramSource = new MapSqlParameterSource().addValue("entityid", entityId);
		companyId = namedParameterJdbcTemplate.queryForObject(GET_COMPANYID_BY_ENTITYID, paramSource, Long.class);
		return companyId;
	}

	@Override
	public String getCompanyIdType(Long companyId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("companyid", companyId);
		String companyType = namedParameterJdbcTemplate.queryForObject(GET_COMPANY_TYPE, paramSource, new CompanyTypeRowMapper());
		return companyType;
	}
}
