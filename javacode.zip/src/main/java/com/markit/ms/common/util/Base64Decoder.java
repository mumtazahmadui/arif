package com.markit.ms.common.util;

import org.apache.commons.codec.binary.Base64;

/**
Utility related to Base64 Decoding
*/
public class Base64Decoder {
	
	/**
	Gets decoded base64 byte array  
	Base64 Decoding of given byte array	
	*/
	public static byte[]  getDecodedString(byte[] base64Byte) {
		byte [] decodedBytes = Base64.decodeBase64(base64Byte);
		return decodedBytes;
	}
}
