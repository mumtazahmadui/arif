package com.markit.ms.common.util;

/**
 * Template Type details, which uniquely represents each template in database
 * <br> Table (REF_EMAIL_TEMPLATE_TYPE)
 * @since RFA5.0
 */
public enum TemplateTypeEnum {
	
	RFA_DUE_DILIGENCE_NOTIFICATION("RFA_DESK_NOTIFICATION","WITHOUT_PIN","DESK NOTIFICATION"),
	RFA_CUSTOM_NOTIFICATION("RFA_DESK_NOTIFICATION","WITHOUT_PIN","CUSTOM NOTIFICATION"),
	RFA_SIGNATORY_NOTIFICATION("RFA_DESK_NOTIFICATION","WITHOUT_PIN","SIGNATORY NOTIFICATION");
	
	/**
	 * Table (EMAIL_TEMPLATE_GROUP)
	 * Column (GROUP_NAME)
	 */
	public String groupName;
	
	/**
	 * Table (O360_EMAIL_TEMPLATES)
	 * Column (OFF_PLATFORM_CODE)
	 */
	public String platformCode;

	public String eventDesc;
	
	private TemplateTypeEnum(String groupName,String platformCode,String eventDesc){
		this.groupName = groupName;	
		this.platformCode = platformCode;	
		this.eventDesc = eventDesc;	
	}	
	
}
