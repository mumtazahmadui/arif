package com.markit.ms.common.bean;

import java.util.Date;
import java.util.List;



public class Signature {
	private Long userId;
	private Long companyId;
	private Long id;
	private String companyType;
	private Long amendmentId;
	private List<Integer> placeholdersSigned;
	//
	private String name;
	private String title;
	private String contactNumber;
	private String email;
	private int signStyle;
	private String signText;
	private String companyName;
	private String acceptDate;
	private String signatureDate;
	private String calendarDate;
	private String signTextDate;
	private String companyDate;
	private String titleDate;
	private boolean isSellSide;
	private String signature;
	private Date createdDate;
	private Date modifiedDate;
	private Long createdBy;
	private String ipAddress;
	private String signType;
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Long getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Long createdBy) {
		this.createdBy = createdBy;
	}
	public Long getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Long modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public int getDeleted() {
		return deleted;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}

	private Long modifiedBy;
	private int deleted;
		
	public String getAcceptDate() {
		return acceptDate;
	}
	public void setAcceptDate(String acceptDate) {
		this.acceptDate = acceptDate;
	}
	public String getCalendarDate() {
		return calendarDate;
	}
	public void setCalendarDate(String calendarDate) {
		this.calendarDate = calendarDate;
	}
	public String getSignTextDate() {
		return signTextDate;
	}
	public void setSignTextDate(String signTextDate) {
		this.signTextDate = signTextDate;
	}
	public String getCompanyDate() {
		return companyDate;
	}
	public void setCompanyDate(String companyDate) {
		this.companyDate = companyDate;
	}
	public String getTitleDate() {
		return titleDate;
	}
	public void setTitleDate(String titleDate) {
		this.titleDate = titleDate;
	}
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSignatureDate() {
		return signatureDate;
	}
	public void setSignatureDate(String signatureDate) {
		this.signatureDate = signatureDate;
	}
	public boolean isSellSide() {
		return isSellSide;
	}
	public void setSellSide(boolean isSellSide) {
		this.isSellSide = isSellSide;
	}
	public int getSignStyle() {
		return signStyle;
	}
	public void setSignStyle(int signStyle) {
		this.signStyle = signStyle;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getSignature() {
		return signature;
	}
	public void setSignature(String signature) {
		this.signature = signature;
	}
	public String getCompanyType() {
		return companyType;
	}
	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}
	public Long getAmendmentId() {
		return amendmentId;
	}
	public void setAmendmentId(Long amendmentId) {
		this.amendmentId = amendmentId;
	}
	public List<Integer> getPlaceholdersSigned() {
		return placeholdersSigned;
	}
	public void setPlaceholdersSigned(List<Integer> placeholdersSigned) {
		this.placeholdersSigned = placeholdersSigned;
	}
	public String getSignText() {
		return signText;
	}
	public void setSignText(String signText) {
		this.signText = signText;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getSignType() {
		return signType;
	}
	public void setSignType(String signType) {
		this.signType = signType;
	}
	

}
