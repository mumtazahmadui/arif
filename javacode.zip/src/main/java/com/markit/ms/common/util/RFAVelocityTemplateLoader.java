package com.markit.ms.common.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

import org.apache.commons.collections.ExtendedProperties;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.resource.Resource;
import org.apache.velocity.runtime.resource.loader.ResourceLoader;

public class RFAVelocityTemplateLoader extends ResourceLoader {

	/**
	 * This is abstract in the base class, so we need it
	 * 
	 * @param configuration
	 */
	public void init(ExtendedProperties configuration) {
		if (log.isTraceEnabled()) {
			log.trace("ClasspathResourceLoader : initialization complete.");
		}
	}

	/**
	 * Get an InputStream so that the Runtime can build a template with it.
	 *
	 * @param templateStream
	 *            name of template to get
	 * @return InputStream containing the template
	 * @throws ResourceNotFoundException
	 *             if template not found in classpath.
	 */
	public InputStream getResourceStream(String templateStream) throws ResourceNotFoundException {

		if (StringUtils.isEmpty(templateStream)) {
			throw new ResourceNotFoundException("Template can't be empty");
		}

		InputStream stream = new ByteArrayInputStream(templateStream.getBytes(StandardCharsets.UTF_8));
		
		return stream;
		
	}

	/**
	 * @see org.apache.velocity.runtime.resource.loader.ResourceLoader#isSourceModified(org.apache.velocity.runtime.resource.Resource)
	 */
	public boolean isSourceModified(Resource resource) {
		return false;
	}

	/**
	 * @see org.apache.velocity.runtime.resource.loader.ResourceLoader#getLastModified(org.apache.velocity.runtime.resource.Resource)
	 */
	public long getLastModified(Resource resource) {
		return 0;
	}
}