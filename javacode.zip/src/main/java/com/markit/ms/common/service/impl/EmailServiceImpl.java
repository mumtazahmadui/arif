package com.markit.ms.common.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.antlr.stringtemplate.StringTemplate;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.InitBinder;

import com.markit.ms.common.bean.Email;
import com.markit.ms.common.bean.EmailMaster;
import com.markit.ms.common.bean.TemplateDetails;
import com.markit.ms.common.bean.User;
import com.markit.ms.common.dao.EmailDao;
import com.markit.ms.common.service.EmailProcessService;
import com.markit.ms.common.service.EmailService;
import com.markit.ms.common.task.SendEmailTask;
import com.markit.ms.common.util.EmailTemplateConstants;
import com.markit.ms.common.util.TemplateTypeEnum;

/**
 * This class provides method implementation for sending mail through O360 mail server
 * 
 * @since RFA5.0
 *
 */
@Service
public class EmailServiceImpl implements EmailService {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	private EmailDao emailDao;
	
	@Autowired
	EmailProcessService emailProcessService;

    @Autowired
    private ApplicationContext applicationContext;
    
    private ExecutorService executorService;
    
	@Value("${mcpm.email}")
	private String mcpmEmailId;

	@Value("${mcpm.support}")
	private String body_mcpmEmail;

	@Value("${template_dir}")
	private String templateDir;

	@Value("${uk.contact}")
	private String ukContact;

	@Value("${us.contact}")
	private String usContact;

	@Value("${eu.contact}")
	private String euContact;

	@Value("${apac.contact}")
	private String apacContact;
	
	@PostConstruct
	public void init() {
		executorService = Executors.newFixedThreadPool(7);
	}

	@PreDestroy
	public void destroy() {
		executorService.shutdown();
	}
	
	@Override
	@Transactional
	public void saveMail(Email email, List<User> users, TemplateTypeEnum templateType) {
		LOGGER.debug("saveMail : save emails : start");

		TemplateDetails templateDetails = getTemplateDetails(templateType);
		
		if(templateDetails!=null) {
			EmailMaster mail = new EmailMaster(email);
			mail.setApplicationSource(EmailTemplateConstants.APPLICATION_SOURCE);
			mail.setTemplateId(templateDetails.getTemplateId());
			mail.setEmailType(templateType.name());
			mail.setFromEmailId(mcpmEmailId);
			mail.setStatus(EmailTemplateConstants.EmailStatus.PENDING.status);
			mail.setRetries(Integer.valueOf(0));
			if (email.getSubTemplateArgsMap() != null) {
				mail.setSubject(
						replaceSubjectArguments(email.getSubTemplateArgsMap(), templateDetails.getTemplateSubject()));
			} else {
				mail.setSubject(templateDetails.getTemplateSubject());
			}
			mail.setReplyToEmailId(templateDetails.getReplyToEmailId());

			/**
			 * for each user save mail
			 */
			List<Long> emailIds = new ArrayList<>();
			if (!CollectionUtils.isEmpty(users)) {
				for (int i = 0; i < users.size(); i++) {
					mail.setToEmailId(Arrays.asList(users.get(i).getEmail()));
					
					if(users.get(i).getFname()!=null) {
						mail.getTemplateArgsMap().put("user_first_name", users.get(i).getFname());						
					}
					
					emailIds.add(emailDao.saveMail(mail));
				}
			}
			
			/**
			 * start send email task thread
			 */
			if (emailIds.size() > 0) {
				LOGGER.debug("Started mail send task : emailIds : " + emailIds);
				executorService.execute(new SendEmailTask(applicationContext.getBean(EmailService.class), emailIds,
						templateDetails.getTemplateId()));
			}
			
		}else {
			LOGGER.error("saveMail : Template details not available");
		}
		LOGGER.debug("saveMail : save emails : end");

	}

	@Override
	public String getMailPreview(Map<String, Object> bodyArguments, TemplateTypeEnum templateType) {

		String mailTemplate = emailDao.getTemplate(templateType);

		if (mailTemplate != null) {
			
			return emailProcessService.getPreview(mailTemplate, bodyArguments);
		} else {
			LOGGER.debug("getMailPreview : template content not available");
			return null;
		}

	}

	@Override
	public TemplateDetails getTemplateDetails(TemplateTypeEnum templateType) {
		if(templateType!=null) {
			return emailDao.getTemplateDetails(templateType);			
		}else {
			LOGGER.error("getTemplateDetails : Template type not provided");
			return null;
		}
	}

	@Override
	public void addContactParams(Map<String, Object> additionalParams) {

		additionalParams.put("email_support", body_mcpmEmail);
		additionalParams.put("uk_contact", ukContact);
		additionalParams.put("us_contact", usContact);
		additionalParams.put("eu_contact", euContact);
		additionalParams.put("apac_contact", apacContact);

	}
	
	/**
	 * replace subject placeholder with arguments passed
	 * 
	 * @param arguments as string values are replaced
	 * @param content subject content
	 * @return
	 * final subject value to be send with mail
	 */
	private String replaceSubjectArguments(Map<String, Object> arguments, String content) {
			
		StringTemplate subject = new StringTemplate(content);
		subject.setAttributes(arguments);
		return subject.toString(); 

	}
	
	@Override
	public void sendMail(EmailMaster mailBean) throws MailException{
		LOGGER.debug("sendMail : mail send : "+mailBean.getId());
		if (mailBean != null) {
			final SimpleMailMessage message = new SimpleMailMessage();
			
			message.setTo(mailBean.getToEmailId().toArray(new String[mailBean.getToEmailId().size()]));			
			message.setSubject(mailBean.getSubject());
			message.setFrom(mailBean.getFromEmailId());
			message.setReplyTo(mailBean.getReplyToEmailId());
			
			if (CollectionUtils.isNotEmpty(mailBean.getCcEmailId())) {
				message.setCc(mailBean.getCcEmailId().toArray(new String[mailBean.getCcEmailId().size()]));
			}

			if (CollectionUtils.isNotEmpty(mailBean.getBccEmailId())) {
				message.setBcc(mailBean.getBccEmailId().toArray(new String[mailBean.getBccEmailId().size()]));
			}

			LOGGER.debug("sendMail : Sending email to mail server...");
			if(StringUtils.isNotEmpty(mailBean.getTemplateContent())) {
				emailProcessService.sendEmail(message, mailBean.getTemplateContent(), mailBean.getTemplateArgsMap());
			}else if (mailBean.getTemplateId() != null) {
				final String template = emailDao.getTemplate(mailBean.getTemplateId());
				if (template == null) {
					LOGGER.error("sendMail : template content not available");
				}
				emailProcessService.sendEmail(message, template, mailBean.getTemplateArgsMap());
			} else {
				LOGGER.debug("sendMail : No template available");
				emailProcessService.sendEmail(message, null, null);
			}
		}
	}

	@Override
	@Transactional
	public void updateMailStatus(EmailMaster mailBean) {
		emailDao.updateMailStatus(mailBean);
	}

	@Override
	public String getTemplate(Long templateId) {
		return emailDao.getTemplate(templateId);
	}

	@Override
	public List<EmailMaster> getEmail(List<Long> mailIds) {
		return emailDao.getEmail(mailIds);
	}
	
}
