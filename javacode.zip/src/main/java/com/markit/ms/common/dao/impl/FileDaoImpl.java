package com.markit.ms.common.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.markit.ms.common.bean.McFile;
import com.markit.ms.common.dao.IFileDao;

@Repository
public class FileDaoImpl extends BaseDAOImpl implements IFileDao {
	@Value("${GET_FILE}")
	private String GET_FILE;
	@Value("${ADD_FILE}")
	private String ADD_FILE;
	

	@Override
	public McFile getFile(Long McFileId) {
		SqlParameterSource paramSource = new MapSqlParameterSource()
		.addValue("id", McFileId);
		
		McFile mcFile = null;
		try{
			mcFile = namedParameterJdbcTemplate.queryForObject(GET_FILE, paramSource, new McFileMapper());
		} catch(EmptyResultDataAccessException error){
			mcFile = null;
		}
		return mcFile;
	}
	private static final class McFileMapper implements RowMapper<McFile> {

		@Override
		public McFile mapRow(ResultSet rs, int rowNum) throws SQLException {
			McFile mcFile = new McFile();
			mcFile.setId(rs.getLong("id"));
			mcFile.setFileName(rs.getString("file_name"));
			mcFile.setFileType(rs.getString("file_type"));
			mcFile.setMimeType(rs.getString("mime_type"));
			mcFile.setModifyBy(rs.getLong("modifyby"));	
			mcFile.setCreatedDate(rs.getDate("create_date"));
			mcFile.setCreatedDate(rs.getDate("modify_date"));
			mcFile.setDeleted(rs.getInt("deleted"));
			mcFile.setOriginalName(rs.getString("original_name"));
			mcFile.setCompanyId(rs.getLong("companyid"));
			return mcFile;
		}
		
	}

	@Override
	public McFile saveFile(McFile file) {
		 SqlParameterSource paramSource = new MapSqlParameterSource()
      	.addValue("companyId", file.getCompanyId())
          .addValue("originalName", file.getOriginalName())
          .addValue("fileName", file.getFileName())
          .addValue("fileType", file.getFileType())
          .addValue("deleted", file.getDeleted())
          .addValue("modifiedBy", file.getModifyBy());
      KeyHolder keyHolder = new GeneratedKeyHolder();
      namedParameterJdbcTemplate.update(ADD_FILE, paramSource, keyHolder);
      file.setId(keyHolder.getKey().longValue());
      return file;

	}

}
