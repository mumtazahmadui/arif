package com.markit.ms.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.dao.ICompanyDao;
import com.markit.ms.common.service.ICompanyService;

@Service
public class CompanyServiceImpl implements ICompanyService {
	
	@Autowired
	private ICompanyDao companyDao;

	@Override
	public Long getCompanyIdByEntityId(Long entityId) {
		return companyDao.getCompanyIdByEntityId(entityId);
	}

	@Override
	public String getCompanyIdType(Long companyId) {
		return companyDao.getCompanyIdType(companyId);
	}
}
