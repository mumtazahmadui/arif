package com.markit.ms.common.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.markit.ms.common.bean.EmailFilterMetadata;
import com.markit.ms.common.bean.TemplateDetails;
import com.markit.ms.common.dao.EmailFilterMetadataDao;
import com.markit.ms.common.service.EmailFilterMetadataService;
import com.markit.ms.common.service.EmailService;
import com.markit.ms.common.util.TemplateTypeEnum;

/**
 * 
 * This class provides method implementation for filter criteria in
 * database
 * 
 * @since RFA5.0
 */
@Service
public class EmailFilterMetadataServiceImpl implements EmailFilterMetadataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailFilterMetadataServiceImpl.class);

	@Autowired
	EmailService emailService;

	@Autowired
	EmailFilterMetadataDao emailFilterDao;

	@Override
	@Transactional
	public Long generateFilterToken(Long loggedInUser, String event, String filterJson, TemplateTypeEnum templateType) {

		EmailFilterMetadata metadata = new EmailFilterMetadata();
		metadata.setCreatedBy(loggedInUser);
		metadata.setFilterCriteria(filterJson);
		metadata.setEvent(event);

		if (templateType != null) {
			TemplateDetails o360Template = emailService.getTemplateDetails(templateType);
			LOGGER.debug("generateFilterToken : storing details of email template, ID:" + o360Template.getTemplateId());

			metadata.setTemplateId(o360Template.getTemplateId());
		}

		return emailFilterDao.generateFilterToken(metadata);
	}

	@Override
	public String getFiltersByFilterToken(Long filterToken) {
		return emailFilterDao.getFiltersByFilterToken(filterToken);
	}
	
	@Override
	public <T> T getFilters(Long filterToken,Class<T> classOfT) {
		
		String filterJson = emailFilterDao.getFiltersByFilterToken(filterToken);
		
		if(StringUtils.isNotEmpty(filterJson)) {
			
			GsonBuilder gsonBuilder = new GsonBuilder();
			Gson gson = gsonBuilder.create();
			
			return gson.fromJson(filterJson, classOfT);
					
		}
		return null;
	}

}
