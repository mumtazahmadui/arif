package com.markit.ms.common.bean;

import java.util.Date;

import com.markit.ms.rfa.util.CommonUtil;

public class MasterAgreementLookupKey {

	private String externalBrokerName;

	private String agreementType;

	private Date masterAgreementDate;

	private String additionalInfo;

	public String getExternalBrokerName() {
		return externalBrokerName;
	}

	public void setExternalBrokerName(String externalBrokerName) {
		this.externalBrokerName = externalBrokerName;
	}

	public String getAgreementType() {
		return agreementType;
	}

	public void setAgreementType(String agreementType) {
		this.agreementType = agreementType;
	}

	public Date getMasterAgreementDate() {
		return masterAgreementDate;
	}

	public void setMasterAgreementDate(Date masterAgreementDate) {
		this.masterAgreementDate = masterAgreementDate;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((externalBrokerName == null) ? 0 : externalBrokerName.hashCode())
				+ ((agreementType == null) ? 0
						: agreementType.hashCode()
								+ ((masterAgreementDate == null) ? 0 : masterAgreementDate.hashCode())
								+ ((additionalInfo == null) ? 0 : additionalInfo.hashCode()));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MasterAgreementLookupKey other = (MasterAgreementLookupKey) obj;
		if (externalBrokerName.equals(other.getExternalBrokerName()) && agreementType.equals(other.getAgreementType())
				&& masterAgreementDate.equals(other.getMasterAgreementDate())
				&& ((CommonUtil.isNull(additionalInfo) && CommonUtil.isNull(other.getAdditionalInfo()))
						|| additionalInfo.equalsIgnoreCase(other.getAdditionalInfo()))) {
			return true;
		} else
			return false;
	}
}
