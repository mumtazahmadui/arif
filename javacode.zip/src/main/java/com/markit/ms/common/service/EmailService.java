package com.markit.ms.common.service;

import java.util.List;
import java.util.Map;

import org.springframework.mail.MailException;

import com.markit.ms.common.bean.Email;
import com.markit.ms.common.bean.EmailMaster;
import com.markit.ms.common.bean.TemplateDetails;
import com.markit.ms.common.bean.User;
import com.markit.ms.common.util.TemplateTypeEnum;

/**
 * This class provides method for sending mail through O360 mail server
 * 
 * @since RFA5.0
 *
 */
public interface EmailService {

	/**
	 * persists email details for each user in database
	 * 
	 * @param email        holds parameters for each mail
	 * @param users        list of users to be mailed
	 * @param templateType <code></code> TemplateTypeEnum to be used
	 */
	void saveMail(Email email, List<User> users, TemplateTypeEnum templateType);

	/**
	 * 
	 * @param bodyArguments
	 * @param templateType  <code></code> TemplateTypeEnum to be used
	 * @return html view of template provided with all placeholders replaced with
	 *         provided arguments
	 */
	String getMailPreview(Map<String, Object> bodyArguments, TemplateTypeEnum templateType);

	/**
	 * 
	 * @param templateType
	 * @return <code>TemplateDetails</code> for template type provided
	 */
	TemplateDetails getTemplateDetails(TemplateTypeEnum templateType);

	/**
	 * adds mcpm application contact arguments to the email template arguments
	 * 
	 * @param additionalParams
	 */
	void addContactParams(Map<String, Object> additionalParams);

	/**
	 * create mail message from <code>EmailMaster</code> and sends mail to the users
	 * 
	 * @param mailBean
	 */
	void sendMail(EmailMaster mailBean) throws MailException;

	/**
	 * updates <code>EmailMaster</code> status and retries in database
	 * 
	 * @param mailBean
	 */
	void updateMailStatus(EmailMaster mailBean);

	/**
	 * 
	 * @param template id
	 * @return template content
	 */
	String getTemplate(Long templateId);

	/**
	 * 
	 * @param mailIds
	 * @return list of email master object containg template args if template id
	 *         exists
	 */
	List<EmailMaster> getEmail(List<Long> mailIds);

}
