package com.markit.ms.common.dao;

import java.util.List;

import com.markit.ms.common.bean.Signature;
import com.markit.ms.rfa.dto.McpmEntityUpdate;

public interface SignatureServiceDao {

	Signature saveSignature(Signature signature, Long loginTime);

	Signature getSignature(Long id);

	void updateFileIdAndHashCode(Long fileId, Long signatureID, String digest, int signedPDFPages);

	void freezeSellSideSignatures(Long amendmentId);

	Integer getSignatureCount(Long amenmentId, int isBS);

	List<McpmEntityUpdate> getEntitiesForUpdate(Long amendmentLetterId);
	
}
