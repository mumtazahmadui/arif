package com.markit.ms.common.dao;

public interface ICompanyDao {
	public Long getCompanyIdByEntityId(Long entityId);

	public String getCompanyIdType(Long companyId);
}
