package com.markit.ms.common.service.impl;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.StringWriter;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.esign.PdfSigner;
import com.markit.ms.common.dao.IUserDao;
import com.markit.ms.common.service.IExhibitPDFPageGenerator;
import com.markit.ms.common.service.IHTMLParser;
import com.markit.ms.common.service.ISignatureService;
import com.markit.ms.rfa.bean.PDFContext;
import com.markit.ms.rfa.util.CommonUtil;
import com.markit.ms.rfa.util.PDFUtil;
import com.markit.ms.rfa.util.QRCodeUtil;

@Service
public class ExhibitPDFPageGeneratorImpl implements IExhibitPDFPageGenerator {
 
	private static final String TEMPLATE_NAME = "report/template/exhibitPage.vm";
	@Resource 
    private VelocityEngine velocityEngine;
    @Autowired 
    private ISignatureService signatureService;
    @Resource PdfSigner pdfSigner;
    @Autowired
    IHTMLParser htmParser;

    @Resource private QueryService<Grid> selectExhibitColumns;
    
    @Resource private QueryService<Long> selectExhibitIdFromAmendment;
    @Autowired
    IUserDao userDao;
    
public byte[] generateExhibitPDF(Long amendmentId, PDFContext pdfContext) throws Exception {
    VelocityContext context = new VelocityContext();
    Properties p = new Properties();
    p.setProperty("resource.loader", "class");
    p.setProperty("class.resource.loader.description", "Velocity Classpath Resource Loader");
    p.setProperty("class.resource.loader.class", "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");     
    
    Long exhibitId = selectExhibitIdFromAmendment.executeQuery("amendmentId",amendmentId);
    if(exhibitId == null) {
    	return null; // No exhibit
    }
    String exhibitTable = htmParser.generateExhibitTable(amendmentId, exhibitId, pdfContext);
    exhibitTable = CommonUtil.addLocationTagPdf(exhibitTable);
    exhibitTable =  CommonUtil.updateAmpersandAndBRTag(exhibitTable);
    context.put("exhibitTable", exhibitTable);
    Integer noOfColumn = getNumberOfColumns(amendmentId, exhibitId);
    int widthInInches = PDFUtil.calculateWidth(noOfColumn);
    context.put("size",  widthInInches + "in 11in");
    context.put("columnPixel", PDFUtil.COLUMN_WIDTH + "px");
    context.put("width", widthInInches -1 + "in");
    context.put("height", (widthInInches/10) + "in");
    int margin=(widthInInches-1)/20;
    if(margin<2) {
    	margin=1;
    }
    context.put("margin", margin + ".6in");
    context.put("margintop", "-"+margin + ".6in");
    context.put("footerdata",QRCodeUtil.getQRCode(amendmentId.toString(), 150));
    
    velocityEngine.init(p);
    Template template = velocityEngine.getTemplate(TEMPLATE_NAME);
    StringWriter writer = new StringWriter();
    template.merge(context, writer);
    PDFServiceImpl pdfService = new PDFServiceImpl();
    String html = PDFUtil.stripNonValidXMLCharacters(writer.toString());
	byte[] exhibitPDF = pdfService.convert(html);
	
	return exhibitPDF;
}

private Integer getNumberOfColumns(Long amendmentId, Long exhibitId) {
	int count  = 0;
	Map<String, Object> params = new HashMap<>();
	params.put("exhibitId",exhibitId);
	params.put("amendmentId",amendmentId);
	
	Grid columns = selectExhibitColumns.executeQuery(params);
	for ( Map<String,String> column : columns.getRows()){
		String hidden = column.get("HIDDEN");
		if(Integer.parseInt(hidden) != 1){
			count++;
		}
	}
	return count;
}


}
