package com.markit.ms.common.bean;

import java.util.ArrayList;
import java.util.List;

/***
 * Holds the parameters for sending an Email from the system.
 * <p>
 * Table (O360_EMAIL_MASTER)
 * </p>
 * 
 * @since RFA5.0
 */
public class EmailMaster extends Email {

	private Long id;
	private List<String> toEmailId = new ArrayList<>();
	private String fromEmailId;
	private String replyToEmailId;
	private String messageBody;
	private Long templateId;
	private String subject;
	private String status;
	private int retries;
	private String emailType;
	private String applicationSource;
	private String templateContent;

	public EmailMaster() {
		super();
	}

	public EmailMaster(Email email) {
		super();
		this.setCcEmailId(email.getCcEmailId());
		this.setBccEmailId(email.getBccEmailId());
		this.setTemplateArgsMap(email.getTemplateArgsMap());
		this.setSubTemplateArgsMap(email.getSubTemplateArgsMap());
	}

	public String getApplicationSource() {
		return applicationSource;
	}

	public void setApplicationSource(String applicationSource) {
		this.applicationSource = applicationSource;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public List<String> getToEmailId() {
		return toEmailId;
	}

	public void setToEmailId(List<String> toEmailId) {
		this.toEmailId = toEmailId;
	}

	public void setToEmailId(String toEmailId) {
		if (this.toEmailId == null) {
			this.toEmailId = new ArrayList<>();
		}
		this.toEmailId.add(toEmailId);
	}

	public String getFromEmailId() {
		return fromEmailId;
	}

	public void setFromEmailId(String fromEmailId) {
		this.fromEmailId = fromEmailId;
	}

	public String getReplyToEmailId() {
		return replyToEmailId;
	}

	public void setReplyToEmailId(String replyToEmailId) {
		this.replyToEmailId = replyToEmailId;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getRetries() {
		return retries;
	}

	public void setRetries(int retries) {
		this.retries = retries;
	}

	public String getEmailType() {
		return emailType;
	}

	public void setEmailType(String emailType) {
		this.emailType = emailType;
	}

	public String getTemplateContent() {
		return templateContent;
	}

	public void setTemplateContent(String templateContent) {
		this.templateContent = templateContent;
	}

}
