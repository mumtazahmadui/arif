package com.markit.ms.common.bean;

public class Entity
{
    private long id;
    private String name;
    private String lei;
    private String trueLegalName;
    private String masterlistTrueLegalName;
    private String clientIdentifier;
    private int deleted;
    private String value; // This field is required by UI
    private Long isSleeve;
    private String parentTrueLegalName;
    private String parentClientIdentifier;
    
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLei() {
		return lei;
	}
	public void setLei(String lei) {
		this.lei = lei;
	}
	public String getTrueLegalName() {
		return trueLegalName;
	}
	public void setTrueLegalName(String trueLegalName) {
		this.trueLegalName = trueLegalName;
	}
	public String getMasterlistTrueLegalName() {
		return masterlistTrueLegalName;
	}
	public void setMasterlistTrueLegalName(String masterlistTrueLegalName) {
		this.masterlistTrueLegalName = masterlistTrueLegalName;
	}
	public String getClientIdentifier() {
		return clientIdentifier;
	}
	public void setClientIdentifier(String clientIdentifier) {
		this.clientIdentifier = clientIdentifier;
	}
	public int getDeleted() {
		return deleted;
	}
	public void setDeleted(int deleted) {
		this.deleted = deleted;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Long getIsSleeve() {
		return isSleeve;
	}
	public void setIsSleeve(Long isSleeve) {
		this.isSleeve = isSleeve;
	}
	public String getParentTrueLegalName() {
		return parentTrueLegalName;
	}
	public void setParentTrueLegalName(String parentTrueLegalName) {
		this.parentTrueLegalName = parentTrueLegalName;
	}
	public String getParentClientIdentifier() {
		return parentClientIdentifier;
	}
	public void setParentClientIdentifier(String parentClientIdentifier) {
		this.parentClientIdentifier = parentClientIdentifier;
	}
	
}
