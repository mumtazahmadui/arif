package com.markit.ms.common.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.markit.kyc.commons.service.query.domain.Grid;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.security.UserUtils;
import com.markit.ms.common.bean.User;
import com.markit.ms.common.model.CommonBaseResponse;
import com.markit.ms.common.service.IUserService;
import com.markit.ms.rfa.exception.RFAException;
import com.markit.ms.rfa.security.McpmUserxsDetails;
import com.markit.ms.rfa.security.domain.McpmUser;
import com.markit.ms.rfa.util.CommonUtil;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

@RestController
@Api(value = "user" , description = "User APIs")
public class UserController {
	
	@Autowired
	private IUserService userService;
	
	@RequestMapping(value = "/v1/user", method = RequestMethod.GET)
	@ApiOperation(value = "Get User")
	public CommonBaseResponse<User> getUser(HttpServletRequest request) throws RFAException{
		CommonBaseResponse<User> commonBaseResponse = new CommonBaseResponse<User>();
		 
		 McpmUserxsDetails mcpmUserxsDetails = (McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession();
		 McpmUser mcpmUser = mcpmUserxsDetails.getEffectiveUser();
		 
		 HashSet<String> permissions = new HashSet<String>(mcpmUser.getPermissions());
		 Long userId = mcpmUser.getId();
		 User user = userService.getUser(userId);
		 if(user.getCompanyType() == null) {
				user.setCompanyType("BS");	
		 }
		 user.setPermissions(permissions);
		 Date loginTime = mcpmUser.getLoginDateTime();
		 if(loginTime != null) {
			 user.setLoginTime(loginTime.toString());
		 }
		 commonBaseResponse.setData(user);
		 return commonBaseResponse;	
	}
	
	@RequestMapping(value = "/v1/users", method = RequestMethod.GET)
    public CommonBaseResponse<List<User>> getUsersByRole(HttpServletRequest request,
			@RequestParam(value="fromRow") Long fromRow,
			@RequestParam(value="pageSize") Long pageSize,
			@RequestParam(value="role") String role){
		CommonBaseResponse<List<User>> commonBaseResponse = new CommonBaseResponse<List<User>>();
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		List<String> permissions = new ArrayList<String>();
		List<User> userList = null;
		permissions.add(role);
		userList = userService.getAllUsersForCompanyByPermissionNameWithPagination(
				companyId, permissions, fromRow, pageSize);
		commonBaseResponse.setData(userList);
		return commonBaseResponse;
    }
	
	@RequestMapping(value = "/v1/notification/users", method = RequestMethod.GET)
    public CommonBaseResponse<List<User>> getUsersByRole(HttpServletRequest request,
			@RequestParam(value="role") String role){
		CommonBaseResponse<List<User>> commonBaseResponse = new CommonBaseResponse<List<User>>();
		Long companyId = CommonUtil.getCompanyIdFromSession(request);
		List<String> permissions = new ArrayList<String>();
		List<User> userList = null;
		permissions.add(role);
		userList = userService.getUsersOfCompanyByPermissionName(companyId, permissions);
		commonBaseResponse.setData(userList);
		return commonBaseResponse;
    }
	
	@RequestMapping(value = "/v1/notification/companyOtherUsers", method = RequestMethod.GET)
    public CommonBaseResponse<List<User>> getOtherUsersByRole(HttpServletRequest request,
			@RequestParam(value="role") String role){
		CommonBaseResponse<List<User>> commonBaseResponse = new CommonBaseResponse<List<User>>();

		List<String> permissions = new ArrayList<String>();
		permissions.add(role);
		
		List<User> userList = userService.getOtherUsersOfCompanyByPermissionName(CommonUtil.getCompanyIdFromSession(request)
				, permissions,CommonUtil.getUserIdFromSession(request));
		commonBaseResponse.setData(userList);
		return commonBaseResponse;
    }
	
	
	@RequestMapping(value = "/v1/escalation/companyOtherUsers", method = RequestMethod.GET)
    public CommonBaseResponse<List<User>> getOtherUsersByRoleForEscalation(HttpServletRequest request){
		CommonBaseResponse<List<User>> commonBaseResponse = new CommonBaseResponse<List<User>>();
		
		List<User> userList = userService.getOtherUsersOfCompanyForEscalation(CommonUtil.getCompanyIdFromSession(request)
				, CommonUtil.getUserIdFromSession(request));
		commonBaseResponse.setData(userList);
		return commonBaseResponse;
    }
}
