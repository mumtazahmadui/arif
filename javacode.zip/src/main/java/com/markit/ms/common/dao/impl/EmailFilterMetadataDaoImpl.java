package com.markit.ms.common.dao.impl;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.ms.common.bean.EmailFilterMetadata;
import com.markit.ms.common.dao.EmailFilterMetadataDao;

/**
 * 
 * @since RFA5.0
 */
@Repository
public class EmailFilterMetadataDaoImpl extends BaseDAOImpl implements EmailFilterMetadataDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailFilterMetadataDaoImpl.class);

	@Value("${EmailFilterReporsitory#saveFilterCriteria}")
	private String SAVE_FILTER_CRITERIA;

	@Value("${EmailFilterReporsitory#getFilterCriteria}")
	private String GET_FILTER_CRITERIA;

	@Override
	public Long generateFilterToken(EmailFilterMetadata metadata) {
		ObjectMapper mapper = new ObjectMapper();

		SqlParameterSource params = new MapSqlParameterSource(
				mapper.convertValue(metadata, new TypeReference<Map<String, Object>>() {
				}));

		KeyHolder keyHolder = new GeneratedKeyHolder();

		try {
			LOGGER.debug(
					"generateFilterToken : SAVE_FILTER_CRITERIA :" + SAVE_FILTER_CRITERIA);

			namedParameterJdbcTemplate.update(SAVE_FILTER_CRITERIA, params, keyHolder);

			return keyHolder.getKey().longValue();

		} catch (Exception e) {
			LOGGER.error("Error persisting EmailFilterMetadata in database", e);

		}
		return null;

	}

	@Override
	public String getFiltersByFilterToken(Long filterToken) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("filterId", filterToken);

		LOGGER.debug(
				"getFiltersByFilterToken : GET_FILTER_CRITERIA :" + GET_FILTER_CRITERIA);
		
		List<String> filterJsonList = namedParameterJdbcTemplate.queryForList(GET_FILTER_CRITERIA, params, String.class);
		if(filterJsonList.size()>0) {
			return filterJsonList.get(0);
		}else {
			LOGGER.error(
					"getFiltersByFilterToken : filter Json empty");
			return null ;
		}
		
	}

}
