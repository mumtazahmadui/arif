package com.markit.ms.common.service;

import com.markit.ms.rfa.bean.PDFContext;
import com.markit.kyc.commons.service.query.intf.QueryService;

public interface IAmendmentLetterPDFPageGenerator {
public byte[] getAmendmentLetterPDF(Long amendmentId, PDFContext pdfContext) throws Exception;

public byte[] getAmendmentLetterPDFSynchronous(Long amendmentId,
		PDFContext pdfContext) throws Exception;

public byte[] getLetterCommentPDF(Long amendmentId,QueryService<byte[]> selectComment) throws Exception;
}
