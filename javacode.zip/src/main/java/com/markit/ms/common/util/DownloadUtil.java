package com.markit.ms.common.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import net.sf.jxls.transformer.XLSTransformer;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

public class DownloadUtil
{
	private static final ThreadLocal<SimpleDateFormat> dateformatter =
		    new ThreadLocal<SimpleDateFormat>() {
		         @Override protected SimpleDateFormat initialValue() {
		             return new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
		     }
		 };

    public static String downloadStringData(HttpServletResponse response, String filename, String mimetype, String data)
        throws Exception
    {
        response.setContentType(mimetype);
        // response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment;filename=\"" + filename + "\"");
        
        PrintWriter out = response.getWriter();
        out.write(data);
        out.flush();
        out.close();
        return "";

    }

    public static void downloadFileByWorkbook(HttpServletResponse response, HSSFWorkbook workbook, String fileName)
    {

        OutputStream os = null;

        try {
            os = response.getOutputStream();
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
            response.setContentType("application/vnd.ms-excel");
            workbook.write(os);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                os.flush();
                os.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            workbook = null;
        }

    }

    public static void downloadFileBySXSSFWorkbook(HttpServletResponse response, SXSSFWorkbook workbook, String fileName)
    {

        OutputStream os = null;

        try {
            os = response.getOutputStream();
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
            response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            workbook.write(os);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                os.flush();
                os.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            workbook.dispose();
        }

    }

    @Deprecated
    public static void downloadFileByTemplate(HttpServletResponse response, Map<String, Object> beans, String template,
        String fileName)
    {

        OutputStream os = null;
        InputStream is = null;

        try {
            os = response.getOutputStream();
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
            is = new FileInputStream(template);
            XLSTransformer transformer = new XLSTransformer();
            HSSFWorkbook workbook = transformer.transformXLS(is, beans);
            workbook.write(os);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
                os.flush();
                os.close();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }

    public static String downloadFile(HttpServletResponse response, String fname, String filename, String mimetype,
        boolean deleteWhenDone) throws Exception
    {
        DataOutputStream dataOutStream = null;
        DataInputStream in = null;
        File f = null;

        try {
            if (fname != null && fname.trim().length() > 0) {
                f = new File(fname);

                // logger.debug("Sending file "+fname+" of size "+
                // f.length()+" as '"+filename+"' of with mime type '"+mimetype+"'");
                in = new DataInputStream(new FileInputStream(fname));
                response.setHeader("Cache-Control", "no-cache,must-revalidate");
                response.setContentType(mimetype);
                response.setHeader("Content-disposition", "attachment; filename=" + URLEncoder.encode(filename,"UTF-8"));
                response.setContentLength((int) f.length());

                // logger.debug("Getting the outputstream");
                dataOutStream = new DataOutputStream(response.getOutputStream());
                int i;
                byte[] buffer = new byte[32000];
                while ((in != null) && (i = in.read(buffer)) != -1) {
                    // logger.debug("Writing " + i + " bytes to the output stream");
                    dataOutStream.write(buffer, 0, i);
                }
                // logger.debug("Finished outputting");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null)
                in.close();
            if (dataOutStream != null) {
                dataOutStream.flush();
                dataOutStream.close();
            }
            if (deleteWhenDone == true && fname != null && fname.trim().length() > 0) {
                // Delete the temporary file if asked to
                f.delete();
            }
        }
        return fname;
    }

    @Deprecated
    public static <T> HSSFWorkbook setWorkSheet(HSSFWorkbook wb, String sheetName, String[] columns, List<T> ls)
        throws Exception
    {
        return DownloadUtil.setWorkSheet(wb, sheetName, columns, null, ls);
    }

    @Deprecated
    public static <T> HSSFWorkbook setWorkSheet(HSSFWorkbook wb, String sheetName, String[] columns, String[] titles,
        List<T> ls) throws Exception
    {
        Sheet sheet = wb.createSheet(sheetName);
        Row row = sheet.createRow(0);
        if (titles != null) {
            for (int k = 0; k < titles.length; k++) {
                row.createCell(k).setCellValue(titles[k]);
            }
        }
        if (ls != null) {
            for (int i = 0; i < ls.size(); i++) {
                T data = (T) ls.get(i);
                if (i == 0) {

                    if (titles == null) {
                        for (int k = 0; k < columns.length; k++) {
                            String column = columns[k];
                            Field field = data.getClass().getDeclaredField(column);
                            field.setAccessible(true);
                            DownloadTitle title = field.getAnnotation(DownloadTitle.class);
                            row.createCell(k).setCellValue(title != null ? title.name() : "No title provided");
                        }
                    }
                }
                row = sheet.createRow(i + 1);
                for (int j = 0; j < columns.length; j++) {
                    String column = columns[j];
                    Field field = data.getClass().getDeclaredField(column);
                    field.setAccessible(true);
                    Object obj = field.get(data);
                    Cell cell = row.createCell(j);
                    DownloadUtil.setCellValue(cell, obj);
                }
            }
        }
        return wb;
    }

    public static void setCellValue(Cell cell, Object obj)
    {
        if (obj == null)
            cell.setCellValue("");
        else if (obj instanceof String)
            cell.setCellValue((String) obj);
        else if (obj instanceof Double) {
            cell.setCellValue((Double) obj);
        } else if (obj instanceof Date) {
        	SimpleDateFormat simpleDateFormat = dateformatter.get();
            cell.setCellValue(simpleDateFormat.format((Date) obj));
        } else if (obj instanceof Integer) {
            cell.setCellValue((Integer) obj);
        } else if (obj instanceof Boolean)
            cell.setCellValue((Boolean) obj);
        else if (obj instanceof BigDecimal)
            cell.setCellValue(((BigDecimal) obj).toPlainString());
        else
            cell.setCellValue("Need To Case This Type");
    }

    public static HSSFWorkbook setWorkSheet(HSSFWorkbook wb, String sheetName, List<Map<String, Object>> ls,
        String[] headersArray, String[] columnsArray)
    {
        Sheet sheet = wb.createSheet(sheetName);
        Row row = sheet.createRow(0);
        if (headersArray != null) {
            for (int k = 0; k < headersArray.length; k++) {
                row.createCell(k).setCellValue(headersArray[k]);
            }
        }
        if (ls != null) {
            for (int i = 0; i < ls.size(); i++) {
                Map<String, Object> valuesMap = (Map) ls.get(i);
                row = sheet.createRow(i + 1);
                for (int j = 0; j < columnsArray.length; j++) {
                    Object value = valuesMap.get(columnsArray[j]);
                    Cell cell = row.createCell(j);
                    DownloadUtil.setCellValue(cell, value);
                }
            }
        }
        return wb;
    }
    public static void applyBorderStyle(CellStyle style){
    	style.setBorderBottom(CellStyle.BORDER_THIN);
    	style.setBorderTop(CellStyle.BORDER_THIN);
        style.setBorderRight(CellStyle.BORDER_THIN);
        style.setBorderLeft(CellStyle.BORDER_THIN);	
    }
    
    public static SXSSFWorkbook setWorkSheet(SXSSFWorkbook wb, String sheetName, List<Map<String, Object>> ls,
            String[] headersArray, String[] columnsArray)
        {
            Sheet sheet = wb.createSheet(sheetName);
            Row row = sheet.createRow(0);
            if (headersArray != null) {
                for (int k = 0; k < headersArray.length; k++) {
                    row.createCell(k).setCellValue(headersArray[k]);
                }
            }
            if (ls != null) {
                for (int i = 0; i < ls.size(); i++) {
                    Map<String, Object> valuesMap = (Map) ls.get(i);
                    row = sheet.createRow(i + 1);
                    for (int j = 0; j < columnsArray.length; j++) {
                        Object value = valuesMap.get(columnsArray[j]);
                        Cell cell = row.createCell(j);
                        DownloadUtil.setCellValue(cell, value);
                    }
                }
            }
            return wb;
        }
	
    public static String downloadFileFromOracleDB(HttpServletResponse response,  String filename, String mimetype,byte[] byteWSOutput,
        boolean deleteWhenDone) throws Exception
    {
        DataOutputStream dataOutStream = null;
        DataInputStream in = null;
        File f = null;

        try {
            if (byteWSOutput != null) {                   
                response.setHeader("Cache-Control", "no-cache,must-revalidate");
                response.setContentType(mimetype);
                response.setHeader("Content-disposition", "attachment; filename=\"" + filename + "\"");
                response.setContentLength((int) byteWSOutput.length);

                // logger.debug("Getting the outputstream");
                dataOutStream = new DataOutputStream(response.getOutputStream());
                dataOutStream.write(byteWSOutput);
               
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null)
                in.close();
            if (dataOutStream != null) {
                dataOutStream.flush();
                dataOutStream.close();
            }                
        }
        return  " ";
    }
    
    public static void downloadPdf(HttpServletResponse response, byte[] bytes, String fileName)
    {
        OutputStream os = null;
        try {
            os = response.getOutputStream();
            os.write(bytes);
            response.setHeader("Content-disposition", "attachment; filename=" + fileName);
            response.setContentType("application/pdf");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                os.flush();
                os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
