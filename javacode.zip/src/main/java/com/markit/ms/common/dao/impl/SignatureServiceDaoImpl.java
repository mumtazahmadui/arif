package com.markit.ms.common.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.beust.jcommander.internal.Maps;
import com.markit.kyc.commons.repository.core.StJdbcTemplate;
import com.markit.kyc.commons.service.query.intf.QueryService;
import com.markit.kyc.security.UserUtils;
import com.markit.ms.common.bean.Signature;
import com.markit.ms.common.dao.SignatureServiceDao;
import com.markit.ms.rfa.dao.resultsetextractor.McpmEntityResultSetExtractor;
import com.markit.ms.rfa.dto.McpmEntityUpdate;
import com.markit.ms.rfa.security.McpmUserxsDetails;

@Repository
public class SignatureServiceDaoImpl extends BaseDAOImpl implements SignatureServiceDao {
	@Value("${ADD_SIGNATURE}")
	private String ADD_SIGNATURE;

	@Value("${ADD_SIGNATURE_AUDIT}")
	private String ADD_SIGNATURE_AUDIT;

	@Value("${GET_SIGNATURE}")
	private String GET_SIGNATURE;

	@Value("${ADD_RFA_BS_SIGNATURE_TRANSITION_LOG}")
	private String ADD_RFA_BS_SIGNATURE_TRANSITION_LOG;

	@Value("${ADD_RFA_SS_SIGNATURE_TRANSITION_LOG}")
	private String ADD_RFA_SS_SIGNATURE_TRANSITION_LOG;

	@Value("${GET_ENTITIES_TO_BE_UPDATED}")
	private String GET_ENTITIES_TO_BE_UPDATED;

	@Value("${mcpm.entityUpdateUrl}")
	String mcpmEntityUpdateUrl;

	@Value("${UPDATE_SIGNATURE_FILE_ID}")
	String UPDATE_SIGNATURE_FILE_ID;

	@Value("${FREEZE_SS_SIGNATURES}")
	String FREEZE_SS_SIGNATURES;

	@Value("${UPDATE_PARTYB_CONTROL_COLUMN_AFTER_SIGN}")
	String UPDATE_PARTYB_CONTROL_COLUMN_AFTER_SIGN;

	@Value("${GET_SIGNATURE_COUNT}")
	private String GET_SIGNATURE_COUNT;

	@Value("${FREEZE_EXHIBIT_TEMPLATE_COLUMN_NAMES_FOR_MASTERLIST}")
	private String FREEZE_EXHIBIT_TEMPLATE_COLUMN_NAMES_FOR_MASTERLIST;

	@Value("${FREEZE_LINE_BREAKS}")
	private String FREEZE_LINE_BREAKS;

	@Resource
	private QueryService<Long> selectBSSignaturePresent;

	private static final Logger logger = LoggerFactory.getLogger(SignatureServiceDaoImpl.class);

	@Resource
	protected StJdbcTemplate jdbcTemplate;

	@Resource
	QueryService<Long> selectTermsOfUseFile;

	@Resource
	QueryService<String> selectMCPMLoginTime;

	@Override
	public Signature saveSignature(Signature signature, Long loginTime) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("userId", signature.getUserId())
				.addValue("title", signature.getTitle()).addValue("name", signature.getName()).addValue("companyId", signature.getCompanyId())
				.addValue("contactNumber", signature.getContactNumber()).addValue("email", signature.getEmail())
				.addValue("signStyle", signature.getSignStyle()).addValue("signatureDate", signature.getSignatureDate())
				.addValue("createdBy", signature.getCreatedBy()).addValue("modifiedBy", signature.getModifiedBy())
				.addValue("signature", signature.getSignature()).addValue("createdDate", signature.getCreatedDate())
				.addValue("modifiedDate", signature.getModifiedDate()).addValue("amendmentId", signature.getAmendmentId()).addValue("signType", signature.getSignType());
		KeyHolder keyHolder = new GeneratedKeyHolder();
		namedParameterJdbcTemplate.update(ADD_SIGNATURE, paramSource, keyHolder);
		signature.setId(keyHolder.getKey().longValue());

		handleAuditDataPoints(signature,loginTime);

		Map<String, Object>[] paramList = null;
		if(signature.getPlaceholdersSigned()!=null){
			paramList = new Map[signature.getPlaceholdersSigned().size()];
			for (int index = 0; index < paramList.length; index++) {
				paramList[index] = Maps.newHashMap();
				paramList[index].put("signatureId", signature.getId());
				paramList[index].put("placeHolderIndex", signature.getPlaceholdersSigned().get(index));
				paramList[index].put("transitionBy", signature.getModifiedBy());
			}
		}
		
		if (signature.getCompanyType().equalsIgnoreCase("BS")) {
			if (selectBSSignaturePresent.executeQuery("amendmentId", signature.getAmendmentId()) == 0) {
				SqlParameterSource paramMap = new MapSqlParameterSource().addValue("amendmentId", signature.getAmendmentId()).addValue("userId",
						signature.getCreatedBy());
				namedParameterJdbcTemplate.update(UPDATE_PARTYB_CONTROL_COLUMN_AFTER_SIGN, paramMap);
				namedParameterJdbcTemplate.update(FREEZE_EXHIBIT_TEMPLATE_COLUMN_NAMES_FOR_MASTERLIST, paramMap);
				namedParameterJdbcTemplate.update(FREEZE_LINE_BREAKS, paramMap);
			}
			if(paramList!=null)
				jdbcTemplate.batchUpdate(ADD_RFA_BS_SIGNATURE_TRANSITION_LOG, paramList);
			else{
				SqlParameterSource paramSourceBs = new MapSqlParameterSource().addValue("signatureId", signature.getId())
						.addValue("placeHolderIndex",null)
						.addValue("transitionBy", signature.getModifiedBy());
				jdbcTemplate.update(ADD_RFA_BS_SIGNATURE_TRANSITION_LOG, paramSourceBs);
			}
			// 1st sign is ensured in the query itself
			/*
			 * List<McpmEntityUpdate> mcpmEntitiesDetail =
			 * namedParameterJdbcTemplate.query(GET_ENTITIES_TO_BE_UPDATED,
			 * paramSource, new McpmEntityResultSetExtractor());
			 * if(mcpmEntitiesDetail != null && mcpmEntitiesDetail.size() > 0 &&
			 * mcpmEntitiesDetail.get(0).getEntityId() != null &&
			 * mcpmEntitiesDetail.get(0).getEntityId() != 0L){
			 * this.updateMcpmEntity(mcpmEntitiesDetail,
			 * signature.getCompanyId(), email); }
			 */
		} else {
			if(paramList!=null)
				jdbcTemplate.batchUpdate(ADD_RFA_SS_SIGNATURE_TRANSITION_LOG, paramList);
			else{
				SqlParameterSource paramSourceBs = new MapSqlParameterSource().addValue("signatureId", signature.getId())
						.addValue("placeHolderIndex",null)
						.addValue("transitionBy", signature.getModifiedBy());
				jdbcTemplate.update(ADD_RFA_SS_SIGNATURE_TRANSITION_LOG, paramSourceBs);
			}
		}

		return signature;
	}

	public List<McpmEntityUpdate> getEntitiesForUpdate(Long amendmentLetterId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentId", amendmentLetterId);
		return namedParameterJdbcTemplate.query(GET_ENTITIES_TO_BE_UPDATED, paramSource, new McpmEntityResultSetExtractor());
	}

	private void handleAuditDataPoints(Signature signature,Long loginTime) {
		Map<String, Object>[] params = new Map[16];
		Long esignTOUFileId = selectTermsOfUseFile.executeQuery("version", "1");
		String mcpmLoginTime = selectMCPMLoginTime.executeQuery("userId", signature.getUserId());
//		Long loggedInTime = ((McpmUserxsDetails) UserUtils.getUserxsUserDetailsFromSession()).getLoggedInTime();
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "AUTHORIZED_SIGNATORY_NAME", signature.getSignature(), 0);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "TITLE", signature.getTitle(), 1);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "CONTACT_PHONE", signature.getContactNumber(), 2);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "EMAIL", signature.getEmail(), 3);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "COMPANY", signature.getCompanyName(), 4);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "SIGN_STYLE", signature.getSignStyle() + "", 5);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "SIGN_TEXT", signature.getSignText(), 6);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "ACCEPT_DATE", signature.getAcceptDate(), 7);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "CALENDAR_DATE", signature.getCalendarDate(), 8);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "SIGN_TEXT_DATE", signature.getSignTextDate(), 9);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "SIGNATURE_DATE", signature.getSignatureDate(), 10);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "IP_ADDRESS", signature.getIpAddress(), 11);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "MCS_LOGIN_DATE_TIME", "" + loginTime, 12);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "MCS_LOGIN_DATE_TIME_EST", new Date(loginTime).toString(), 13);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "ESIGN_TERMS_DOC_ID", esignTOUFileId != null ? "" + esignTOUFileId : null,
				14);
		getParamMap(signature.getId(), signature.getCreatedBy(), params, "MCPM_LOGIN_TIME", mcpmLoginTime, 15);
		jdbcTemplate.batchUpdate(ADD_SIGNATURE_AUDIT, params);
	}

	private void getParamMap(Long signatureId, Long createdBy, Map<String, Object>[] params, String name, String value, int index) {
		Map<String, Object> param = Maps.newHashMap();
		param.put("signatureId", signatureId);
		param.put("createdBy", createdBy);
		param.put("ATTR_NAME", name);
		param.put("ATTR_VALUE", value);
		params[index] = param;
	}

	@Override
	public Signature getSignature(Long id) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("id", id);
		Signature signature = null;
		try {
			signature = namedParameterJdbcTemplate.queryForObject(GET_SIGNATURE, paramSource, new SignatureMapper());
		} catch (Exception e) {
			signature = null;
		}
		return signature;
	}

	private class SignatureMapper implements RowMapper<Signature> {

		@Override
		public Signature mapRow(ResultSet rs, int rowNum) throws SQLException {
			Signature signature = new Signature();
			signature.setId(rs.getLong("ID"));
			// signature.setFileId(rs.getLong("FILE_ID"));
			signature.setUserId(rs.getLong("USER_ID"));
			signature.setName(rs.getString("NAME"));
			signature.setTitle(rs.getString("TITLE"));
			signature.setCompanyId(rs.getLong("COMPANY_ID"));
			signature.setContactNumber(rs.getString("CONTACT_NUMBER"));
			signature.setEmail(rs.getString("CONTACT_EMAIL"));
			signature.setSignatureDate(rs.getString("SIGNATURE_DATE"));
			signature.setSignStyle(rs.getInt("FONT_STYLE"));
			signature.setCreatedBy(rs.getLong("CREATED_BY"));
			signature.setModifiedBy(rs.getLong("MODIFIED_BY"));
			signature.setCreatedDate(rs.getTimestamp("CREATED_DATE"));
			signature.setModifiedDate(rs.getTimestamp("MODIFIED_DATE"));
			signature.setDeleted(rs.getInt("DELETED"));
			return signature;
		}

	}

	@Override
	public void updateFileIdAndHashCode(Long fileId, Long signatureID, String digest, int signedPDFPages) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("signatureId", signatureID).addValue("fileId", fileId)
				.addValue("digest", digest).addValue("signedPDFPages", signedPDFPages);
		namedParameterJdbcTemplate.update(UPDATE_SIGNATURE_FILE_ID, paramSource);
	}

	@Override
	public void freezeSellSideSignatures(Long amendmentId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentId", amendmentId);

		namedParameterJdbcTemplate.update(FREEZE_SS_SIGNATURES, paramSource);

	}

	@Override
	public Integer getSignatureCount(Long amendmentId, int isBsCompany) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("amendmentId", amendmentId);
		if (isBsCompany == 0) {
			((MapSqlParameterSource) paramSource).addValue("companyType", "BS");
		} else if (isBsCompany == 1) {
			((MapSqlParameterSource) paramSource).addValue("companyType", "SS");
		}
		Integer signatureCount = null;
		try {
			signatureCount = namedParameterJdbcTemplate.queryForObject(GET_SIGNATURE_COUNT, paramSource,Integer.class);
		} catch (Exception e) {
			logger.error("Getting Signature count failed.");
			signatureCount = null;
		}
		return signatureCount;
	}
}
