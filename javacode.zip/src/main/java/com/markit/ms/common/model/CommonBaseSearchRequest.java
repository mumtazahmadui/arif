package com.markit.ms.common.model;

public class CommonBaseSearchRequest
{
    private Long userId;
    private Long companyId;
    private String sortOrder;
    private String sortBy;
    private Long offSet;
    private Long pageSize;
       
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortBy() {
		return sortBy;
	}
	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	public Long getPageSize() {
		return pageSize;
	}
	public void setPageSize(Long pageSize) {
		this.pageSize = pageSize;
	}
	public Long getOffSet() {
		return offSet;
	}
	public void setOffSet(Long offSet) {
		this.offSet = offSet;
	}
}
