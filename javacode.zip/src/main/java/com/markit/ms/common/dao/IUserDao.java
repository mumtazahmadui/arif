package com.markit.ms.common.dao;

import java.util.List;

import com.markit.ms.common.bean.User;

public interface IUserDao {
	public User getUser(long id);
	public List<String> getAllUsersForCompanyByPermissionName(Long companyId, List<String> permissionName);
	public List<User> getAllUsersForCompanyByPermissionNameWithPagination(
			Long companyId, List<String> permissionName, Long fromRow, Long pageSize);
	public List<User> getUsersOfCompanyByPermissionName(Long companyId, List<String> permissions);
	public List<User> getUsersByIds(List<Long> userIds);
	/**
	 * 
	 * @return list of users with provided permission except the logged-in user
	 */
	List<User> getOtherUsersOfCompanyByPermissionName(Long companyId, List<String> permissions, Long userId);
}
