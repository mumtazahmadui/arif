package com.markit.ms.common.bean;

/***
 * Holds the details for email template.
 * <p>
 * Table (O360_EMAIL_TEMPLATES)
 * </p>
 * @since RFA5.0
 */
public class TemplateDetails {

    private long templateId;
    private String templateSubject;
    private String replyToEmailId;
    private String templateType;
    private int templateTypeId;

    public long getTemplateId() {
        return templateId;
    }

    public void setTemplateId(long templateId) {
        this.templateId = templateId;
    }

    public String getTemplateSubject() {
        return templateSubject;
    }

    public void setTemplateSubject(String templateSubject) {
        this.templateSubject = templateSubject;
    }

    public String getReplyToEmailId() {
        return replyToEmailId;
    }

    public void setReplyToEmailId(String replyToEmailId) {
        this.replyToEmailId = replyToEmailId;
    }
	public int getTemplateTypeId() {
		return templateTypeId;
	}

	public void setTemplateTypeId(int templateTypeId) {
		this.templateTypeId = templateTypeId;
	}

	public String getTemplateType() {
		return templateType;
	}

	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
    
}
