package com.markit.ms.common.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Service;

import com.markit.ms.common.service.IMcpmEmailService;
import com.markit.ms.common.service.IRFAMailService;

@Service
public class RFAMailServiceImpl implements IRFAMailService {
	
	@Value("${mcpm.email}")
	private String mcpmEmail;
	
	@Value("${mcpm.support}")
	private String body_mcpmEmail;
	
	@Value("${template_dir}")
	private String templateDir;
	
	@Value("${uk.contact}")
	private String ukContact;
	
	@Value("${us.contact}")
	private String usContact;
	
	@Value("${eu.contact}")
	private String euContact;
	
	@Value("${apac.contact}")
	private String apacContact;
	
	@Value("${singapore.contact.isda}")
	private String singaporeContactIsda;
	
	@Autowired
	private IMcpmEmailService mcpmEmailService;
	
	@Override
	public void sendEmail(List<String> emailList, Map<String, Object> additionalParams, String bodyTemplate, String subTemplate) throws Exception {
		sendEmail(emailList, additionalParams, bodyTemplate, subTemplate, null);
	}
	
	@Override
	public void sendEmail(List<String> emailList, Map<String, Object> additionalParams, String bodyTemplate, String subTemplate,
			Map<String, Object> subjectVariables) throws Exception {
		sendEmailWithCC(emailList, additionalParams, bodyTemplate, subTemplate, subjectVariables, null);
	}

	@Override
	public void sendEmailWithCC(List<String> emailList, Map<String, Object> additionalParams, String bodyTemplate,
			String subTemplate, Map<String, Object> subjectVariables, String ccEmail) throws Exception {
		Map<String, Object> vmParams = new HashMap<String, Object>();
		vmParams.put("email_support", body_mcpmEmail);
		vmParams.put("uk_contact", ukContact);
		vmParams.put("us_contact", usContact);
		vmParams.put("eu_contact", euContact);
		vmParams.put("apac_contact", apacContact);
		vmParams.put("singapore_contact", singaporeContactIsda);
		vmParams.putAll(additionalParams);

		SimpleMailMessage simpleMailMessage = new SimpleMailMessage();
		simpleMailMessage.setFrom(mcpmEmail);

		if (CollectionUtils.isNotEmpty(emailList)) {
			for (String toEmailAddress : emailList) {
				simpleMailMessage.setTo(toEmailAddress);
				mcpmEmailService.sendEmail(simpleMailMessage, subTemplate, subjectVariables, bodyTemplate, vmParams, true, ccEmail);
			}
		}
		
	}
}