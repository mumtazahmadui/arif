package com.markit.ms.common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class CacheFilter implements Filter {
    
    @Override
    public void destroy() {
     // No need to implement.

    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1
        response.setHeader("Pragma", "no-cache"); // HTTP 1.0
        response.setDateHeader("Expires", 0); // Proxies
     /*   String profile = environment.getProperty("spring.profiles.active");
        if("LOCAL".equalsIgnoreCase(profile) || "DEV".equalsIgnoreCase(profile)) {
            if (request.getHeader("Origin") != null && !request.getHeader("Origin").isEmpty()) {
                response.addHeader("Access-Control-Allow-Origin", request.getHeader("Origin")); 
            } else {
                response.addHeader("Access-Control-Allow-Origin", "http://localhost:8080");
            }
            response.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT");
    
            System.out.println("!!!!!!!!!!!!!!!!!! CORS CORS CORS CORS Origin=" + request.getHeader("Origin"));
        }*/
        chain.doFilter(req, response);
    }

    @Override
    public void init(FilterConfig arg0) throws ServletException {
        // No need to implement.

    }

}
