package com.markit.ms.common.dao;

import java.util.List;
import java.util.Map;

import com.markit.ms.rfa.placeholders.request.BSPartyBTableRequest;
import com.markit.ms.rfa.placeholders.request.SSPartyBTableRequest;

public interface IPartyBPlaceholderDao {

	void updateBSLineBreaks(Long amendmentId, Long userId,
			String placeholderType, BSPartyBTableRequest bsPartyBTableRequest);

	void updateSSResponse(Long amendmentId, Long userId,
			SSPartyBTableRequest ssPartyBTableRequest);

	List<Map<String, String>> getLineBreaks(Long amendmentId,
			String placeholderType);

	List<Map<String, String>> getPreviousLineBreaks(Long amendmentId,
			String partybAdditionPlaceholder);

	public void updateAmendmentStatusAndNextStep(Long amendmentId);

	void updateAmendmentBySsResponse(Long amendmentId, Long userId);
	
	public void updateAmendment(Long amendmentId, Long userId);
}
