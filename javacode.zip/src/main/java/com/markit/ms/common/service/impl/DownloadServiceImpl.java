package com.markit.ms.common.service.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import com.markit.ms.common.bean.DownloadSheetData;
import com.markit.ms.common.constants.SpringConstants;
import com.markit.ms.common.util.DownloadUtil;

@Service
@Scope(SpringConstants.SPRING_SCOPE_PROTOTYPE)
public class DownloadServiceImpl {

	private final static Logger logger = Logger
			.getLogger(DownloadServiceImpl.class);

	@Deprecated
	public HSSFWorkbook getHSSFWorkbookFromList(String templatePath,
			List<DownloadSheetData> dataList) {
		InputStream myxls = null;
		HSSFWorkbook wb = null;
		try {
			myxls = new FileInputStream(templatePath);
			wb = new HSSFWorkbook(myxls);
			for (DownloadSheetData data : dataList) {
				writeSheet(wb, data.getSheet(), data.getRowDataStart(),
						data.getObjectList(), data.getHeaders());
			}
		} catch (Exception e) {
			logger.error(e);
			wb = null;
		} finally {
			if (myxls != null) {
				try {
					myxls.close();
				} catch (Exception e) {
					logger.error(e);
				}
			}
		}
		return wb;
	}

	@Deprecated
	public HSSFWorkbook getHSSFWorkbook(String templatePath,
			DownloadSheetData data) {
		InputStream myxls = null;
		HSSFWorkbook wb = null;
		try {
			myxls = new FileInputStream(templatePath);
			wb = new HSSFWorkbook(myxls);
			writeSheet(wb, data.getSheet(), data.getRowDataStart(),
					data.getObjectList(), data.getHeaders());
		} catch (Exception e) {
			logger.error(e);
		} finally {
			if (myxls != null) {
				try {
					myxls.close();
				} catch (Exception e) {
					logger.error(e);
				}
			}
		}
		return wb;
	}

	public SXSSFWorkbook getSXSSWorkbookFromList(InputStream inputStream,
			List<DownloadSheetData> dataList) throws Exception {
		FileInputStream fio = null;
		SXSSFWorkbook wb = null;
		OPCPackage opcPackage = null;
		try {
			opcPackage = OPCPackage.open(inputStream);
			XSSFWorkbook xssfwb = new XSSFWorkbook(opcPackage);
			wb = new SXSSFWorkbook(xssfwb, 1000);
			for (DownloadSheetData data : dataList) {
				writeSheet(wb, data.getSheet(), data.getRowDataStart(),
						data.getObjectList(), data.getHeaders());
			}
		} catch (Exception e){
			if (wb != null) {
				wb.dispose();
			}
			throw e;
		}
		finally {
			if (fio != null) {
				try {
					fio.close();
				} catch (Exception e) {
					logger.error(e);
				}
			}
		}
		return wb;
	}

	public SXSSFWorkbook getSXSSWorkbook(String templatePath,DownloadSheetData data) throws Exception {
		FileInputStream fio = null;
		SXSSFWorkbook wb = null;
		OPCPackage opcPackage = null;
		try {
			File file = new File(templatePath);
			fio = new FileInputStream(file.getAbsolutePath());
			opcPackage = OPCPackage.open(fio);
			XSSFWorkbook xssfwb = new XSSFWorkbook(opcPackage);
			wb = new SXSSFWorkbook(xssfwb, 1000);
			writeSheet(wb, data.getSheet(), data.getRowDataStart(),
					data.getObjectList(), data.getHeaders());

		} catch (Exception e) {
			logger.error(e);
			if (wb != null) {
				wb.dispose();
			}
			throw e;
		} finally {
			if (fio != null) {
				try {
					fio.close();
				} catch (Exception e) {
					logger.error(e);
				}
			}
		}
		return wb;
	}
	
	public SXSSFWorkbook getSXSSWorkbook(InputStream inputStream,List<String> headerList) throws Exception {
		FileInputStream fio = null;
		SXSSFWorkbook wb = null;
		OPCPackage opcPackage = null;
		try {
			opcPackage = OPCPackage.open(inputStream);
			XSSFWorkbook xssfwb = new XSSFWorkbook(opcPackage);
			wb = new SXSSFWorkbook(xssfwb, 1000);
			writeSheet(wb, 0, 0,headerList);
		} catch (Exception e) {
			logger.error(e);
			if (wb != null) {
				wb.dispose();
			}
			throw e;
		} finally {
			if (fio != null) {
				try {
					fio.close();
				} catch (Exception e) {
					logger.error(e);
				}
			}
		}
		return wb;
	}

	private void writeSheet(SXSSFWorkbook wb, int sheetNumber, int sheetStartRow, List<String> headerList){
		Sheet sheet = wb.getSheetAt(sheetNumber);
		Row row = sheet.createRow(0);
		Cell cell = null;
		for(int i = 0; i<headerList.size(); i++){
			cell = row.createCell(i);
			DownloadUtil.setCellValue(cell, headerList.get(i));
		}
	}

	public void writeSheet(Workbook wb, int sheetNumber, int sheetStartRow,
			List ls, String[] headers) throws Exception {
		Sheet sheet = wb.getSheetAt(sheetNumber);
		Row row = null;
		Object rowData = null;
		Cell cell = null;
		Class c = null;
		for (int i = 0; i < ls.size(); i++) {
			if (i == 0) {
				c = ls.get(0).getClass();
			}
			rowData = ls.get(i);
			row = sheet.createRow(i + sheetStartRow);
			for (int j = 0; j < headers.length; j++) {
				cell = row.createCell(j);
				Field field = /*c.getDeclaredField(headers[j]);*/
				ReflectionUtils.findField(c, headers[j]);
				field.setAccessible(true);
				DownloadUtil.setCellValue(cell, field.get(rowData));

			}
		}
	}
}
