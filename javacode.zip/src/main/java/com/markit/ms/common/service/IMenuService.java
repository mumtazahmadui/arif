package com.markit.ms.common.service;

public interface IMenuService
{
    public String getMenuItemsForUser(Long userId, boolean inIframe);

}
