package com.markit.ms.common.util;

import java.util.ArrayList;
import java.util.List;

import com.markit.ms.common.bean.Lookup;

public class LookupUtil {

	private LookupUtil() {
		throw new AssertionError();
	}
	
	public static List<Long> getIdsFromLookup(List<Lookup> lookups){
		
		if (lookups == null) return new ArrayList<>();
		
		List<Long> response = new ArrayList<>();
				
		for (Lookup lookup : lookups){
			if (lookup.getId() != null) 
				response.add(lookup.getId());
		}
		return response;
	}
	
}
