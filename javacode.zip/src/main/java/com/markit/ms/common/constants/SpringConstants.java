package com.markit.ms.common.constants;

public class SpringConstants
{

    public static final String SPRING_SCOPE_REQUEST = "request";

    public static final String SPRING_SCOPE_PROTOTYPE = "prototype";

    public static final String SERVICECONTEXT_NAME_PROTOTYPE = "serviceContextPrototype";

    public static final String SERVICECONTEXT_NAME_REQUEST = "serviceContextRequest";
}
