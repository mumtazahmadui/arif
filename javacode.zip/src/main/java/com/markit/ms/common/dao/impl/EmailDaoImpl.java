package com.markit.ms.common.dao.impl;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.markit.ms.common.bean.EmailMaster;
import com.markit.ms.common.bean.TemplateDetails;
import com.markit.ms.common.dao.EmailDao;
import com.markit.ms.common.util.TemplateTypeEnum;

/***
 * This class interacts with O360 database for dao operations
 * 
 * @since RFA5.0
 */
@Repository
public class EmailDaoImpl implements EmailDao {
	private static final Logger LOGGER = LoggerFactory.getLogger(EmailDaoImpl.class);

	@Autowired
	protected NamedParameterJdbcTemplate namedParameterJdbcTemplate_o360;

	@Autowired
	protected JdbcTemplate jdbcTemplate_o360;

	@Value("${EmailRepository#saveEmailMaster}")
	private String SAVE_EMAIL_MASTER;

	@Value("${EmailRepository#saveEmailArguments}")
	private String SAVE_EMAIL_TEMPLATE_ARGUMENTS;

	@Value("${EmailRepository#getTemplateDetails}")
	private String GET_TEMPLATE_DETAILS;

	@Value("${EmailRepository#getTemplate}")
	private String GET_TEMPLATE;

	@Value("${EmailRepository#getTemplateById}")
	private String GET_TEMPLATE_BY_ID;

	@Value("${EmailRepository#updateStatusEmailMaster}")
	private String UPDATE_STATUS_EMAIL_MASTER;

	@Value("${EmailRepository#getEmail}")
	private String GET_EMAIL_MASTER;

	@Value("${EmailRepository#getTemplateArgs}")
	private String GET_TEMPLATE_ARGS;

	public static final String TEMP_ARG_TYPE = "T";

	@Override
	public Long saveMail(EmailMaster email) {
		ObjectMapper mapper = new ObjectMapper();
		SqlParameterSource params = new MapSqlParameterSource(
				mapper.convertValue(email, new TypeReference<Map<String, Object>>() {
				}));

		KeyHolder keyHolder = new GeneratedKeyHolder();

		LOGGER.debug("saveMail : SAVE_EMAIL_MASTER :" + SAVE_EMAIL_MASTER);

		namedParameterJdbcTemplate_o360.update(SAVE_EMAIL_MASTER, params, keyHolder, new String[] { "MAIL_ID" });

		Long generatedId = keyHolder.getKey().longValue();

		/**
		 * insert arguments for template
		 */
		addTemplateArguments(email.getTemplateArgsMap(), generatedId);

		return generatedId;
	}

	/**
	 * persists the arguments required in the template of the mail.
	 * 
	 * @param argMap holds the parameters of template arguments
	 * @param mailId unique id for each mail
	 * @param type   type of arguments T/S (Template)/(Subject)
	 */
	private void addTemplateArguments(Map<String, Object> argMap, Long mailId) {
		LOGGER.debug("addTemplateArguments: SAVE_EMAIL_TEMPLATE_ARGUMENTS :" + SAVE_EMAIL_TEMPLATE_ARGUMENTS);

		for (Entry<String, Object> entry : argMap.entrySet()) {
			Object value = entry.getValue();
			jdbcTemplate_o360.update(connection -> {
				PreparedStatement ps = connection.prepareStatement(SAVE_EMAIL_TEMPLATE_ARGUMENTS);
				Object finalValue = value;
				String className = String.class.getName();

				int i = 0;
				ps.setLong(++i, mailId);
				ps.setString(++i, entry.getKey());

				if (!(finalValue instanceof String)) {
					/**
					 * get clob data for the argument value
					 */
					finalValue = getClob(value, connection);
					className = Object.class.getName();
					ps.setClob(++i, (Clob) finalValue);
				} else {
					ps.setString(++i, (String) finalValue);
				}
				ps.setString(++i, TEMP_ARG_TYPE);
				ps.setString(++i, className);
				return ps;
			});
		}
	}

	@Override
	public TemplateDetails getTemplateDetails(TemplateTypeEnum templateType) {

		SqlParameterSource params = new MapSqlParameterSource().addValue("templateType", templateType.name())
				.addValue("groupName", templateType.groupName).addValue("platformCode", templateType.platformCode);

		LOGGER.debug("getTemplateDetails :GET_TEMPLATE_DETAILS :" + GET_TEMPLATE_DETAILS);

		return namedParameterJdbcTemplate_o360.queryForObject(GET_TEMPLATE_DETAILS, params,
				new TemplateDetailsRowMapper());

	}

	@Override
	public String getTemplate(TemplateTypeEnum templateType) {

		SqlParameterSource params = new MapSqlParameterSource().addValue("templateType", templateType.name())
				.addValue("groupName", templateType.groupName).addValue("platformCode", templateType.platformCode);

		LOGGER.debug("getTemplate :GET_TEMPLATE :" + GET_TEMPLATE);

		return getClobData(GET_TEMPLATE, params);
	}

	/**
	 * Row Mapper for <code>TemplateDetails</code>
	 * 
	 * @since RFA5.0
	 * 
	 */
	private class TemplateDetailsRowMapper implements RowMapper<TemplateDetails> {
		public TemplateDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			if (rs == null) {
				return null;
			}

			TemplateDetails templateDetails = new TemplateDetails();
			templateDetails.setTemplateId(rs.getLong("TEMPLATE_ID"));
			templateDetails.setTemplateSubject(rs.getString("TEMPLATE_SUBJECT"));
			templateDetails.setReplyToEmailId(rs.getString("REPLY_TO_EMAIL_ID"));
			return templateDetails;
		}
	}

	/**
	 * converts obj data to clob data for persisting in database
	 * 
	 * @param obj
	 * @param connection
	 * @return Clob data type object
	 */
	private Clob getClob(Object obj, Connection connection) {
		try {
			Clob myClob = connection.createClob();
			try (ObjectOutputStream out = new ObjectOutputStream(myClob.setAsciiStream(0))) {
				out.writeObject(obj);
			} catch (Exception e) {
				LOGGER.error("getClob : Error while saving clob : " + e.toString());
			}
			return myClob;
		} catch (Exception e) {
			LOGGER.error("getClob : Error while saving clob : " + e.toString());
		}
		return null;
	}

	@Override
	public void updateMailStatus(EmailMaster mailBean) {
		SqlParameterSource params = new MapSqlParameterSource().addValue("mailId", mailBean.getId())
				.addValue("status", mailBean.getStatus()).addValue("retries", mailBean.getRetries());

		LOGGER.debug("updateMailStatus :UPDATE_STATUS_EMAIL_MASTER :" + UPDATE_STATUS_EMAIL_MASTER);

		namedParameterJdbcTemplate_o360.update(UPDATE_STATUS_EMAIL_MASTER, params);

	}

	@Override
	public String getTemplate(Long templateId) {

		SqlParameterSource params = new MapSqlParameterSource().addValue("id", templateId);

		LOGGER.debug("getTemplate :GET_TEMPLATE_BY_ID :" + GET_TEMPLATE_BY_ID);

		return getClobData(GET_TEMPLATE_BY_ID, params);
	}

	/**
	 * get clob data as string
	 */
	private String getClobData(String query, SqlParameterSource params) {
		return namedParameterJdbcTemplate_o360.queryForObject(query, params, (rs, row) -> {
			Clob clob = rs.getClob(1);
			return clob.getSubString(1, (int) clob.length());
		});
	}

	@Override
	public List<EmailMaster> getEmail(List<Long> mailIds) {
		EmailMaster mail = null;
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("mailId", mailIds);
		
		LOGGER.debug("getEmail :GET_EMAIL_MASTER :" + GET_EMAIL_MASTER);
		
		List<EmailMaster> mailList = namedParameterJdbcTemplate_o360.query(GET_EMAIL_MASTER, paramSource,
				new EmailRowMapper());

		if (mailList != null && !mailList.isEmpty()) {
			for (int i = 0; i < mailList.size(); i++) {
				mail = mailList.get(i);

				// If the mail has template then fetching the template Arguments.
				if (mail.getTemplateId() != null) {
					Map<String, Object> templateArgs = getTemplateAgrs(mail.getId());
					if (templateArgs != null && !templateArgs.isEmpty()) {
						mail.setTemplateArgsMap(templateArgs);
					}
				}
			}

		}
		return mailList;
	}

	private static final class EmailRowMapper implements RowMapper<EmailMaster> {

		@Override
		public EmailMaster mapRow(ResultSet rs, int arg1) throws SQLException {
			EmailMaster mail = null;
			if (rs != null) {
				mail = new EmailMaster();
				mail.setFromEmailId(rs.getString("SENDER_MAIL_ID"));
				mail.setToEmailId(getEmailCollection(rs.getString("RECIEVER_MAIL_ID")));
				mail.setBccEmailId(getEmailCollection(rs.getString("BCC_MAIL_ID")));
				mail.setCcEmailId(getEmailCollection(rs.getString("CC_MAIL_ID")));
				mail.setReplyToEmailId((rs.getString("REPLY_TO_EMAIL_ID")));
				mail.setSubject(rs.getString("SUBJECT"));
				mail.setTemplateId(rs.getLong("TEMPLATE_ID"));
				mail.setRetries(rs.getInt("RETRIES"));
				mail.setStatus(rs.getString("STATUS"));
				mail.setId(rs.getLong("MAIL_ID"));
			}

			return mail;
		}
		

		private List<String> getEmailCollection(String ids){
			return ids!=null?Arrays.asList(ids):null;
		}
	}
	

	/**
	 * get Template argument details for each mail id
	 * 
	 * @param mailId
	 * @return
	 */
	private Map<String, Object> getTemplateAgrs(Long mailId) {
		SqlParameterSource paramSource = new MapSqlParameterSource().addValue("mail_id", mailId);
		LOGGER.debug("getTemplateAgrs :getTemplateAgrs : mailId : " + mailId);
		return namedParameterJdbcTemplate_o360.query(GET_TEMPLATE_ARGS, paramSource, new TemplateArgsMapper());
	}

	private static final class TemplateArgsMapper implements ResultSetExtractor<Map<String, Object>> {

		@Override
		public Map<String, Object> extractData(ResultSet rs) throws SQLException, DataAccessException {

			Map<String, Object> tempArgs = new HashMap<>();

			while (rs.next()) {
				if (!rs.getString("MAP_VALUE_CLASS").equals(String.class.getName())) {
					tempArgs.put(rs.getString("MAP_KEY"), deserializeObject(rs));
				} else {
					tempArgs.put(rs.getString("MAP_KEY"), rs.getString("MAP_VALUE"));
				}
			}
			return tempArgs;
		}

		private Object deserializeObject(ResultSet rs) throws SQLException, DataAccessException {
			Clob clob = rs.getClob("MAP_VALUE");
			try (ObjectInputStream in = new ObjectInputStream(clob.getAsciiStream())) {
				return in.readObject();
			} catch (Exception ex) {
				LOGGER.error("TemplateArgsMapper : Exception while deserializing", ex);
				return null;
			}
		}
	}
}
