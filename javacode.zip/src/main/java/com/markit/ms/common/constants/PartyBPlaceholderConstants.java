package com.markit.ms.common.constants;

import com.markit.ms.rfa.bean.enumeration.PartyBAckStatus;

public class PartyBPlaceholderConstants {
// Query Params
	public static final String AMENDMENT_ID = "amendmentId";
	
	public static final String EXHIBIT_ID = "exhibitId";
	
	public static final String ALLOWED_PARTYB_STATUS = "allowedStatus";
	
	public static final String NOT_ALLOWED_PARTYB_STATUS = "NotAllowedStatus";

	public static final String LINE_BREAK_INDEX = "lineBreakIndex";

	public static final String LINE_BREAK_TEXT = "lineBreakText";

	public static final String SHOW_HEADER_TEXT = "showHeaderText";

	public static final String PLACEHOLDER_TYPE = "placeholderType";

	public static final String EXHIBIT_CONTROL_COLUMN_ID = "exhibitControlColumnId";

	public static final String USER_ID = "userId";

	public static final String PARTYB_ID = "partyBId";

	public static final String SS_RESPONSE_COMMENTS = "ssResponseComments";

	public static final String SS_RESPONSE_STATUS = "ssResponseStatus";

	public static final String FUND_NAME_CHANGE_ID = "fundNameChangeId";

	public static final String EXHIBIT_VALUE_CHANGE_ID = "exhibitValueChangeId";

	public static final String HIDE_SS_COLUMN = "hideSSColumn";
	
// Placeholder constants same as in DB RFA_LU_GRID_TYPE
	public static final String PARTYB_PLACEHOLDER_TYPE = "placeholderType";
	
	public static final String PARTYB_ADDITION_PLACEHOLDER = "PARTYB_ADDITION_TABLE";
	
	public static final String PARTYB_REMOVAL_PLACEHOLDER = "PARTYB_REMOVAL_TABLE";
	
	public static final String SLEEVE_ADDITION_PLACEHOLDER = "SLEEVE_ADDITION_TABLE";
	
	public static final String SLEEVE_REMOVAL_PLACEHOLDER = "SLEEVE_REMOVAL_TABLE";

	public static final String PARTYB_EXHIBIT_VALUE_CHANGE_PLACEHOLDER = "PARTYB_EXHIBIT_VALUE_CHANGE_TABLE";
	
	public static final String PARTYB_FUND_NAME_CHANGE_PLACEHOLDER = "PARTYB_FUND_NAME_CHANGE_TABLE";
//
	public static final String SS_RESPONSES_NOT_EDITABLE = PartyBAckStatus.ACCEPTED_SENT.getName() + "," +  PartyBAckStatus.REJECTED_SENT.getName();
}
