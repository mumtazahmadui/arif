package com.markit.ms.common.model;
import java.util.List;
import java.util.ArrayList;
public class CommonBaseSearchResponse<T> {
	private long totalCount;
	private List<T> dataList = new ArrayList<T>();
	public long getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}
	public List<T> getDataList() {
		return dataList;
	}
	public void setDataList(List<T> dataList) {
		this.dataList = dataList;
	}

}
