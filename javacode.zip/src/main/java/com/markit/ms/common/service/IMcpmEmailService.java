package com.markit.ms.common.service;

import java.util.Map;

import org.springframework.mail.SimpleMailMessage;

public interface IMcpmEmailService {

	public void sendEmail(final SimpleMailMessage msg, final String subjectTemplate, final Map<String, Object> subjectVariables,
			final String bodyTemplate, final Map<String, Object> bodyVariables, final boolean isHtml, String ccEmail) throws Exception;
}