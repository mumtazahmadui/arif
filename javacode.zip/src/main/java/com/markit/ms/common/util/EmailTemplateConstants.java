package com.markit.ms.common.util;

/**
 * 
 * @since RFA5.0
 */
public interface EmailTemplateConstants {

	String APPLICATION_SOURCE = "RFA";

	enum EmailStatus {

		SENT("S"), UNSENT("U"), FAILED("F"), BOUNCEDBACK("B"), READ("R"),PENDING("P");

		public String status;

		private EmailStatus(String status) {
			this.status = status;
		}
	}

	/**
	 * 
	 * Unique group name for each email template<br>
	 * Can be client specific or not
	 */
	enum TemplateGroupEnum {
		RFA_DESK_NOTIFICATION;
	}

}
