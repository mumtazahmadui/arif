package com.markit.ms.common.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.markit.ms.common.bean.MasterAgreementLookup;
import com.markit.ms.common.dao.IRfaLookupDao;
import com.markit.ms.common.service.IMasterAgreementLookupService;
import com.markit.ms.rfa.util.CommonUtil;

@Service
public class MasterAgreementLookupServiceImpl implements IMasterAgreementLookupService {

	@Autowired
	private IRfaLookupDao rfaLookupDao;

	@Override
	public MasterAgreementLookup getMasterAgreementLookup(String brokerName, String agreementType, Date agreementDate,
			String additionalInfo, Long companyId) {
		List<MasterAgreementLookup> mAgreementLookupList = rfaLookupDao.masterAgreementsLookupData(companyId,
				brokerName, agreementDate, agreementType, CommonUtil.isNull(additionalInfo) ? "" : additionalInfo);

		if (mAgreementLookupList.size() > 0 && mAgreementLookupList.size() < 2) {
			return mAgreementLookupList.get(0);
		}

		return null;
	}
}
