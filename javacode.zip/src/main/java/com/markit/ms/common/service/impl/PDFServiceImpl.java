package com.markit.ms.common.service.impl;
import java.io.ByteArrayOutputStream;

import org.springframework.stereotype.Service;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.markit.ms.common.service.IPDFService;
import com.markit.ms.rfa.util.PDFUtil;


@Service
public class PDFServiceImpl implements IPDFService {
	  public byte[] convert(String htmlStr) {
		    try {
		    //  PdfConverter
//		      htmlStr=htmlStr.replaceAll("<br[^>]*>", " ");
		      ITextRenderer renderer = new ITextRenderer();
		      //String htmlStr = new String(htmlBytes);
		      renderer.setDocumentFromString(PDFUtil.stripNonValidXMLCharacters(htmlStr), getBaseUrl());
		      renderer.layout();
		      ByteArrayOutputStream baos = new ByteArrayOutputStream();
		      renderer.createPDF(baos);
		      return baos.toByteArray();
		    }
		    catch (Exception e) {
		      throw new RuntimeException(e);
		    }
		  }

	  
	    private String getBaseUrl() throws java.net.URISyntaxException {
	        return getClass().getResource("/report/").toURI().toString();
	    }
	    
		
}
