package com.markit.ms.common.model;

import java.io.Serializable;


public class CommonBaseResponse<T> implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String SUCCESS = "Success";
	public static final String FAILED = "Failed";
	
	private String status = SUCCESS;
	
	private T data;
	
	public CommonBaseResponse() {
	
	}
	public CommonBaseResponse(String status) {
		this.status = status;
	}
	
	
	public T getData() {
		return data;
	}
	
	public void setData(T data) {
		this.data = data;
	}
	
	public String getMessage() {
		return status;
	}
	public void setFailed() {
		this.status = FAILED;
	}

	@Override
	public String toString() {
	       return "BaseResponse [ message=" + status + ", data=" + data + "]";
	}

}
